// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package QMF_SERVICE;

import com.qq.taf.jce.*;
import java.util.ArrayList;

// Referenced classes of package QMF_SERVICE:
//            WnsIpInfo

public final class WnsCmdHandShakeRsp extends JceStruct
{

    static ArrayList f;
    public int a;
    public ArrayList b;
    public byte c;
    public String d;
    public byte e;

    public WnsCmdHandShakeRsp()
    {
        a = 0;
        b = null;
        c = 0;
        d = "";
        e = 0;
    }

    public void readFrom(JceInputStream jceinputstream)
    {
        a = jceinputstream.read(a, 0, false);
        if(f == null)
        {
            f = new ArrayList();
            WnsIpInfo wnsipinfo = new WnsIpInfo();
            f.add(wnsipinfo);
        }
        b = (ArrayList)jceinputstream.read(f, 1, false);
        c = jceinputstream.read(c, 2, false);
        d = jceinputstream.readString(3, false);
        e = jceinputstream.read(e, 4, false);
    }

    public void writeTo(JceOutputStream jceoutputstream)
    {
        jceoutputstream.write(a, 0);
        if(b != null)
            jceoutputstream.write(b, 1);
        jceoutputstream.write(c, 2);
        if(d != null)
            jceoutputstream.write(d, 3);
        jceoutputstream.write(e, 4);
    }
}
