// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package QMF_SERVICE;

import com.qq.taf.jce.*;
import java.util.ArrayList;

// Referenced classes of package QMF_SERVICE:
//            WnsIpInfo, WnsReportTestIpInfo

public final class WnsCmdSpeed4TestReq extends JceStruct
{

    static ArrayList c;
    static ArrayList d;
    public ArrayList a;
    public ArrayList b;

    public WnsCmdSpeed4TestReq()
    {
        a = null;
        b = null;
    }

    public void readFrom(JceInputStream jceinputstream)
    {
        if(c == null)
        {
            c = new ArrayList();
            WnsIpInfo wnsipinfo = new WnsIpInfo();
            c.add(wnsipinfo);
        }
        a = (ArrayList)jceinputstream.read(c, 0, false);
        if(d == null)
        {
            d = new ArrayList();
            WnsReportTestIpInfo wnsreporttestipinfo = new WnsReportTestIpInfo();
            d.add(wnsreporttestipinfo);
        }
        b = (ArrayList)jceinputstream.read(d, 1, false);
    }

    public void writeTo(JceOutputStream jceoutputstream)
    {
        if(a != null)
            jceoutputstream.write(a, 0);
        if(b != null)
            jceoutputstream.write(b, 1);
    }
}
