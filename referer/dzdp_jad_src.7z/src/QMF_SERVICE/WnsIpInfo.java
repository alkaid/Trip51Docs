// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package QMF_SERVICE;

import com.qq.taf.jce.*;

public final class WnsIpInfo extends JceStruct
{

    public int a;
    public short b;
    public byte c;
    public String d;

    public WnsIpInfo()
    {
        a = 0;
        b = 0;
        c = 0;
        d = "";
    }

    public void readFrom(JceInputStream jceinputstream)
    {
        a = jceinputstream.read(a, 0, false);
        b = jceinputstream.read(b, 1, false);
        c = jceinputstream.read(c, 2, false);
        d = jceinputstream.readString(3, false);
    }

    public void writeTo(JceOutputStream jceoutputstream)
    {
        jceoutputstream.write(a, 0);
        jceoutputstream.write(b, 1);
        jceoutputstream.write(c, 2);
        if(d != null)
            jceoutputstream.write(d, 3);
    }
}
