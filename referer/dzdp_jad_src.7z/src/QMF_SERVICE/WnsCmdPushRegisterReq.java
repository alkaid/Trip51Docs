// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package QMF_SERVICE;

import com.qq.taf.jce.*;

public final class WnsCmdPushRegisterReq extends JceStruct
{

    static byte m[];
    static byte n[];
    public byte a[];
    public byte b[];
    public boolean c;
    public boolean d;
    public short e;
    public short f;
    public String g;
    public int h;
    public String i;
    public short j;
    public String k;
    public String l;

    public WnsCmdPushRegisterReq()
    {
        a = null;
        b = null;
        c = true;
        d = true;
        e = 0;
        f = 0;
        g = "";
        h = 1;
        i = "";
        j = 0;
        k = "";
        l = "";
    }

    public WnsCmdPushRegisterReq(byte abyte0[], byte abyte1[], boolean flag, boolean flag1, short word0, short word1, String s, 
            int i1, String s1, short word2, String s2, String s3)
    {
        a = null;
        b = null;
        c = true;
        d = true;
        e = 0;
        f = 0;
        g = "";
        h = 1;
        i = "";
        j = 0;
        k = "";
        l = "";
        a = abyte0;
        b = abyte1;
        c = flag;
        d = flag1;
        e = word0;
        f = word1;
        g = s;
        h = i1;
        i = s1;
        j = word2;
        k = s2;
        l = s3;
    }

    public void readFrom(JceInputStream jceinputstream)
    {
        if(m == null)
        {
            m = (byte[])new byte[1];
            ((byte[])m)[0] = 0;
        }
        a = (byte[])jceinputstream.read(m, 0, false);
        if(n == null)
        {
            n = (byte[])new byte[1];
            ((byte[])n)[0] = 0;
        }
        b = (byte[])jceinputstream.read(n, 1, false);
        c = jceinputstream.read(c, 2, false);
        d = jceinputstream.read(d, 3, false);
        e = jceinputstream.read(e, 4, false);
        f = jceinputstream.read(f, 5, false);
        g = jceinputstream.readString(6, false);
        h = jceinputstream.read(h, 7, false);
        i = jceinputstream.readString(8, false);
        j = jceinputstream.read(j, 9, false);
        k = jceinputstream.readString(10, false);
        l = jceinputstream.readString(11, false);
    }

    public void writeTo(JceOutputStream jceoutputstream)
    {
        if(a != null)
            jceoutputstream.write(a, 0);
        if(b != null)
            jceoutputstream.write(b, 1);
        jceoutputstream.write(c, 2);
        jceoutputstream.write(d, 3);
        jceoutputstream.write(e, 4);
        jceoutputstream.write(f, 5);
        if(g != null)
            jceoutputstream.write(g, 6);
        jceoutputstream.write(h, 7);
        if(i != null)
            jceoutputstream.write(i, 8);
        jceoutputstream.write(j, 9);
        if(k != null)
            jceoutputstream.write(k, 10);
        if(l != null)
            jceoutputstream.write(l, 11);
    }
}
