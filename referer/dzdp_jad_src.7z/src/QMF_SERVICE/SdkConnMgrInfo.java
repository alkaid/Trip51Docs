// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package QMF_SERVICE;

import com.qq.taf.jce.*;

public final class SdkConnMgrInfo extends JceStruct
{

    public byte a;
    public byte b;
    public byte c;

    public SdkConnMgrInfo()
    {
        a = 0;
        b = 0;
        c = 0;
    }

    public SdkConnMgrInfo(byte byte0, byte byte1, byte byte2)
    {
        a = 0;
        b = 0;
        c = 0;
        a = byte0;
        b = byte1;
        c = byte2;
    }

    public void readFrom(JceInputStream jceinputstream)
    {
        a = jceinputstream.read(a, 0, false);
        b = jceinputstream.read(b, 1, false);
        c = jceinputstream.read(c, 2, false);
    }

    public void writeTo(JceOutputStream jceoutputstream)
    {
        jceoutputstream.write(a, 0);
        jceoutputstream.write(b, 1);
        jceoutputstream.write(c, 2);
    }
}
