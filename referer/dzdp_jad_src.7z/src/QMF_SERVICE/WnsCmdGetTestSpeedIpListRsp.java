// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package QMF_SERVICE;

import com.qq.taf.jce.*;
import java.util.ArrayList;

// Referenced classes of package QMF_SERVICE:
//            WnsSpeedTestIpInfo

public final class WnsCmdGetTestSpeedIpListRsp extends JceStruct
{

    static ArrayList b;
    public ArrayList a;

    public WnsCmdGetTestSpeedIpListRsp()
    {
        a = null;
    }

    public void readFrom(JceInputStream jceinputstream)
    {
        if(b == null)
        {
            b = new ArrayList();
            WnsSpeedTestIpInfo wnsspeedtestipinfo = new WnsSpeedTestIpInfo();
            b.add(wnsspeedtestipinfo);
        }
        a = (ArrayList)jceinputstream.read(b, 0, false);
    }

    public void writeTo(JceOutputStream jceoutputstream)
    {
        if(a != null)
            jceoutputstream.write(a, 0);
    }
}
