// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package QMF_SERVICE;

import com.qq.taf.jce.*;

public final class WnsSpeedLatencyInfo extends JceStruct
{

    public long a;
    public long b;
    public long c;
    public long d;

    public WnsSpeedLatencyInfo()
    {
        a = 0L;
        b = 0L;
        c = 0L;
        d = 0L;
    }

    public WnsSpeedLatencyInfo(long l, long l1, long l2, long l3)
    {
        a = 0L;
        b = 0L;
        c = 0L;
        d = 0L;
        a = l;
        b = l1;
        c = l2;
        d = l3;
    }

    public void readFrom(JceInputStream jceinputstream)
    {
        a = jceinputstream.read(a, 0, true);
        b = jceinputstream.read(b, 1, true);
        c = jceinputstream.read(c, 2, true);
        d = jceinputstream.read(d, 3, true);
    }

    public void writeTo(JceOutputStream jceoutputstream)
    {
        jceoutputstream.write(a, 0);
        jceoutputstream.write(b, 1);
        jceoutputstream.write(c, 2);
        jceoutputstream.write(d, 3);
    }
}
