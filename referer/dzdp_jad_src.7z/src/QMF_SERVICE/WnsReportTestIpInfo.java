// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package QMF_SERVICE;

import com.qq.taf.jce.*;

// Referenced classes of package QMF_SERVICE:
//            WnsSpeedLatencyInfo

public final class WnsReportTestIpInfo extends JceStruct
{

    static WnsSpeedLatencyInfo j;
    public short a;
    public int b;
    public String c;
    public short d;
    public WnsSpeedLatencyInfo e;
    public String f;
    public byte g;
    public String h;
    public int i;

    public WnsReportTestIpInfo()
    {
        a = 0;
        b = 0;
        c = "";
        d = 0;
        e = null;
        f = "";
        g = 0;
        h = "";
        i = 0;
    }

    public void readFrom(JceInputStream jceinputstream)
    {
        a = jceinputstream.read(a, 0, true);
        b = jceinputstream.read(b, 1, false);
        c = jceinputstream.readString(2, false);
        d = jceinputstream.read(d, 3, false);
        if(j == null)
            j = new WnsSpeedLatencyInfo();
        e = (WnsSpeedLatencyInfo)jceinputstream.read(j, 4, true);
        f = jceinputstream.readString(5, false);
        g = jceinputstream.read(g, 6, true);
        h = jceinputstream.readString(7, false);
        i = jceinputstream.read(i, 8, false);
    }

    public void writeTo(JceOutputStream jceoutputstream)
    {
        jceoutputstream.write(a, 0);
        jceoutputstream.write(b, 1);
        if(c != null)
            jceoutputstream.write(c, 2);
        jceoutputstream.write(d, 3);
        jceoutputstream.write(e, 4);
        if(f != null)
            jceoutputstream.write(f, 5);
        jceoutputstream.write(g, 6);
        if(h != null)
            jceoutputstream.write(h, 7);
        jceoutputstream.write(i, 8);
    }
}
