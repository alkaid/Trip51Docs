// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package QMF_SERVICE;

import com.qq.taf.jce.*;

public final class WnsCloudCmdGetWidRsp extends JceStruct
{

    static byte d[];
    static byte e[];
    public long a;
    public byte b[];
    public byte c[];

    public WnsCloudCmdGetWidRsp()
    {
        a = 0L;
        b = null;
        c = null;
    }

    public void readFrom(JceInputStream jceinputstream)
    {
        a = jceinputstream.read(a, 0, false);
        if(d == null)
        {
            d = new byte[1];
            d[0] = 0;
        }
        b = jceinputstream.read(d, 1, false);
        if(e == null)
        {
            e = new byte[1];
            e[0] = 0;
        }
        c = jceinputstream.read(e, 2, false);
    }

    public void writeTo(JceOutputStream jceoutputstream)
    {
        jceoutputstream.write(a, 0);
        if(b != null)
            jceoutputstream.write(b, 1);
        if(c != null)
            jceoutputstream.write(c, 2);
    }
}
