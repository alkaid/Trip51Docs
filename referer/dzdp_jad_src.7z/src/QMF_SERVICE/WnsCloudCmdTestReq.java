// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package QMF_SERVICE;

import com.qq.taf.jce.*;

public final class WnsCloudCmdTestReq extends JceStruct
{

    public String a;

    public WnsCloudCmdTestReq()
    {
        a = "";
    }

    public void readFrom(JceInputStream jceinputstream)
    {
        a = jceinputstream.readString(0, false);
    }

    public void writeTo(JceOutputStream jceoutputstream)
    {
        if(a != null)
            jceoutputstream.write(a, 0);
    }
}
