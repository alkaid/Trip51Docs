// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package QMF_SERVICE;

import com.qq.taf.jce.*;

public final class WnsCmdPushRegisterRsp extends JceStruct
{

    static byte c[];
    public byte a[];
    public String b;

    public WnsCmdPushRegisterRsp()
    {
        a = null;
        b = "";
    }

    public void readFrom(JceInputStream jceinputstream)
    {
        if(c == null)
        {
            c = (byte[])new byte[1];
            ((byte[])c)[0] = 0;
        }
        a = (byte[])jceinputstream.read(c, 1, false);
        b = jceinputstream.readString(2, false);
    }

    public void writeTo(JceOutputStream jceoutputstream)
    {
        if(a != null)
            jceoutputstream.write(a, 1);
        if(b != null)
            jceoutputstream.write(b, 2);
    }
}
