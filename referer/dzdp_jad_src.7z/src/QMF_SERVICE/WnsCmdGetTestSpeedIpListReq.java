// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package QMF_SERVICE;

import com.qq.taf.jce.*;

public final class WnsCmdGetTestSpeedIpListReq extends JceStruct
{

    public byte a;

    public WnsCmdGetTestSpeedIpListReq()
    {
        a = 0;
    }

    public WnsCmdGetTestSpeedIpListReq(byte byte0)
    {
        a = 0;
        a = byte0;
    }

    public void readFrom(JceInputStream jceinputstream)
    {
        a = jceinputstream.read(a, 0, true);
    }

    public void writeTo(JceOutputStream jceoutputstream)
    {
        jceoutputstream.write(a, 0);
    }
}
