// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package QMF_SERVICE;

import com.qq.taf.jce.*;

// Referenced classes of package QMF_SERVICE:
//            SdkConnMgrInfo

public final class WnsCmdHandShakeReq extends JceStruct
{

    static SdkConnMgrInfo c;
    public int a;
    public SdkConnMgrInfo b;

    public WnsCmdHandShakeReq()
    {
        a = 0;
        b = null;
    }

    public WnsCmdHandShakeReq(int i, SdkConnMgrInfo sdkconnmgrinfo)
    {
        a = 0;
        b = null;
        a = i;
        b = sdkconnmgrinfo;
    }

    public void readFrom(JceInputStream jceinputstream)
    {
        a = jceinputstream.read(a, 0, false);
        if(c == null)
            c = new SdkConnMgrInfo();
        b = (SdkConnMgrInfo)jceinputstream.read(c, 1, false);
    }

    public void writeTo(JceOutputStream jceoutputstream)
    {
        jceoutputstream.write(a, 0);
        if(b != null)
            jceoutputstream.write(b, 1);
    }
}
