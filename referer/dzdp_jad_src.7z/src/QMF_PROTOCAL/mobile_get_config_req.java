// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package QMF_PROTOCAL;

import com.qq.taf.jce.*;

public final class mobile_get_config_req extends JceStruct
{

    public int a;
    public int b;
    public String c;

    public mobile_get_config_req()
    {
        a = 0;
        b = 0;
        c = "";
    }

    public mobile_get_config_req(int i, int j, String s)
    {
        a = 0;
        b = 0;
        c = "";
        a = i;
        b = j;
        c = s;
    }

    public void readFrom(JceInputStream jceinputstream)
    {
        a = jceinputstream.read(a, 0, false);
        b = jceinputstream.read(b, 1, false);
        c = jceinputstream.readString(2, false);
    }

    public void writeTo(JceOutputStream jceoutputstream)
    {
        jceoutputstream.write(a, 0);
        jceoutputstream.write(b, 1);
        if(c != null)
            jceoutputstream.write(c, 2);
    }
}
