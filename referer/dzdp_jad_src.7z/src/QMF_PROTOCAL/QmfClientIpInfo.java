// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package QMF_PROTOCAL;

import com.qq.taf.jce.*;

public final class QmfClientIpInfo extends JceStruct
{

    static byte e[];
    public byte a;
    public short b;
    public int c;
    public byte d[];

    public QmfClientIpInfo()
    {
        a = 0;
        b = 0;
        c = 0;
        d = null;
    }

    public QmfClientIpInfo(byte byte0, short word0, int i, byte abyte0[])
    {
        a = 0;
        b = 0;
        c = 0;
        d = null;
        a = byte0;
        b = word0;
        c = i;
        d = abyte0;
    }

    public void readFrom(JceInputStream jceinputstream)
    {
        a = jceinputstream.read(a, 0, true);
        b = jceinputstream.read(b, 1, true);
        c = jceinputstream.read(c, 2, true);
        if(e == null)
        {
            e = new byte[1];
            e[0] = 0;
        }
        d = jceinputstream.read(e, 3, false);
    }

    public void writeTo(JceOutputStream jceoutputstream)
    {
        jceoutputstream.write(a, 0);
        jceoutputstream.write(b, 1);
        jceoutputstream.write(c, 2);
        if(d != null)
            jceoutputstream.write(d, 3);
    }
}
