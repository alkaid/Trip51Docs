// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package QMF_PROTOCAL;

import com.qq.taf.jce.*;
import java.util.HashMap;
import java.util.Map;

public final class mobile_get_config_rsp extends JceStruct
{

    static Map d;
    public Map a;
    public String b;
    public int c;

    public mobile_get_config_rsp()
    {
        a = null;
        b = "";
        c = 0;
    }

    public void readFrom(JceInputStream jceinputstream)
    {
        if(d == null)
        {
            d = new HashMap();
            byte abyte0[] = (byte[])new byte[1];
            ((byte[])abyte0)[0] = 0;
            d.put("", abyte0);
        }
        a = (Map)jceinputstream.read(d, 0, false);
        b = jceinputstream.readString(1, false);
        c = jceinputstream.read(c, 2, false);
    }

    public void writeTo(JceOutputStream jceoutputstream)
    {
        if(a != null)
            jceoutputstream.write(a, 0);
        if(b != null)
            jceoutputstream.write(b, 1);
        jceoutputstream.write(c, 2);
    }
}
