// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package QMF_PROTOCAL;

import com.qq.taf.jce.*;

// Referenced classes of package QMF_PROTOCAL:
//            QmfTokenInfo, QmfClientIpInfo, UserAgent

public final class QmfUpstream extends JceStruct
{

    static QmfTokenInfo n;
    static QmfClientIpInfo o;
    static byte p[];
    static byte q[];
    static UserAgent r;
    public int a;
    public int b;
    public long c;
    public String d;
    public String e;
    public String f;
    public QmfTokenInfo g;
    public QmfClientIpInfo h;
    public byte i[];
    public byte j[];
    public long k;
    public String l;
    public UserAgent m;

    public QmfUpstream()
    {
        a = 0;
        b = 0;
        c = 0L;
        d = "";
        e = "";
        f = "";
        g = null;
        h = null;
        i = null;
        j = null;
        k = 0L;
        l = "";
        m = null;
    }

    public QmfUpstream(int i1, int j1, long l1, String s, String s1, String s2, 
            QmfTokenInfo qmftokeninfo, QmfClientIpInfo qmfclientipinfo, byte abyte0[], byte abyte1[], long l2, String s3, 
            UserAgent useragent)
    {
        a = 0;
        b = 0;
        c = 0L;
        d = "";
        e = "";
        f = "";
        g = null;
        h = null;
        i = null;
        j = null;
        k = 0L;
        l = "";
        m = null;
        a = i1;
        b = j1;
        c = l1;
        d = s;
        e = s1;
        f = s2;
        g = qmftokeninfo;
        h = qmfclientipinfo;
        i = abyte0;
        j = abyte1;
        k = l2;
        l = s3;
        m = useragent;
    }

    public void readFrom(JceInputStream jceinputstream)
    {
        a = jceinputstream.read(a, 0, true);
        b = jceinputstream.read(b, 1, true);
        c = jceinputstream.read(c, 2, true);
        d = jceinputstream.readString(3, true);
        e = jceinputstream.readString(4, true);
        f = jceinputstream.readString(5, true);
        if(n == null)
            n = new QmfTokenInfo();
        g = (QmfTokenInfo)jceinputstream.read(n, 6, true);
        if(o == null)
            o = new QmfClientIpInfo();
        h = (QmfClientIpInfo)jceinputstream.read(o, 7, true);
        if(p == null)
        {
            p = new byte[1];
            p[0] = 0;
        }
        i = jceinputstream.read(p, 8, true);
        if(q == null)
        {
            q = new byte[1];
            q[0] = 0;
        }
        j = jceinputstream.read(q, 9, true);
        k = jceinputstream.read(k, 11, false);
        l = jceinputstream.readString(14, false);
        if(r == null)
            r = new UserAgent();
        m = (UserAgent)jceinputstream.read(r, 16, false);
    }

    public void writeTo(JceOutputStream jceoutputstream)
    {
        jceoutputstream.write(a, 0);
        jceoutputstream.write(b, 1);
        jceoutputstream.write(c, 2);
        jceoutputstream.write(d, 3);
        jceoutputstream.write(e, 4);
        jceoutputstream.write(f, 5);
        jceoutputstream.write(g, 6);
        jceoutputstream.write(h, 7);
        jceoutputstream.write(i, 8);
        jceoutputstream.write(j, 9);
        jceoutputstream.write(k, 11);
        if(l != null)
            jceoutputstream.write(l, 14);
        if(m != null)
            jceoutputstream.write(m, 16);
    }
}
