// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package QMF_PROTOCAL;

import com.qq.taf.jce.*;
import java.util.HashMap;
import java.util.Map;

public final class QmfTokenInfo extends JceStruct
{

    static byte d[];
    static Map e;
    public int a;
    public byte b[];
    public Map c;

    public QmfTokenInfo()
    {
        a = 0;
        b = null;
        c = null;
    }

    public QmfTokenInfo(int i, byte abyte0[], Map map)
    {
        a = 0;
        b = null;
        c = null;
        a = i;
        b = abyte0;
        c = map;
    }

    public void readFrom(JceInputStream jceinputstream)
    {
        a = jceinputstream.read(a, 0, true);
        if(d == null)
        {
            d = new byte[1];
            d[0] = 0;
        }
        b = jceinputstream.read(d, 1, true);
        if(e == null)
        {
            e = new HashMap();
            Integer integer = Integer.valueOf(0);
            byte abyte0[] = new byte[1];
            abyte0[0] = 0;
            e.put(integer, abyte0);
        }
        c = (Map)jceinputstream.read(e, 2, false);
    }

    public void writeTo(JceOutputStream jceoutputstream)
    {
        jceoutputstream.write(a, 0);
        jceoutputstream.write(b, 1);
        if(c != null)
            jceoutputstream.write(c, 2);
    }
}
