// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package HttpUtils;

import android.content.Context;
import android.util.Base64;
import android.util.Log;
import com.alipay.mobilesecuritysdk.util.CommonUtils;
import java.util.ArrayList;
import java.util.List;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;

public class HttpFetcher
{

    public HttpFetcher()
    {
    }

    private List paramBuilder(String s, String s1, String s2, boolean flag)
    {
        if(s1 != null) goto _L2; else goto _L1
_L1:
        Object obj = null;
_L5:
        return ((List) (obj));
_L2:
        if(!flag)
            break MISSING_BLOCK_LABEL_35;
        String s3 = CommonUtils.textCompress(s1);
_L3:
        if(CommonUtils.isBlank(s3))
        {
            obj = null;
        } else
        {
            obj = new ArrayList();
            StringBuilder stringbuilder = new StringBuilder();
            if(!CommonUtils.isBlank(s))
            {
                ((List) (obj)).add(new BasicNameValuePair("serviceId", s));
                stringbuilder.append("serviceId=");
                stringbuilder.append(s);
                stringbuilder.append("&");
            }
            if(!CommonUtils.isBlank(s2))
            {
                ((List) (obj)).add(new BasicNameValuePair("version", s2));
                stringbuilder.append("version=");
                stringbuilder.append(s2);
                stringbuilder.append("&");
            }
            ((List) (obj)).add(new BasicNameValuePair("data", s3));
            stringbuilder.append("data=");
            stringbuilder.append(s3);
            stringbuilder.append("02000016-0010-0080-8000-10CA006D2CA5");
            ((List) (obj)).add(new BasicNameValuePair("sign", CommonUtils.MD5(stringbuilder.toString())));
            Log.i("ALP", (new StringBuilder(String.valueOf(stringbuilder.toString()))).append(obj.toString()).toString());
        }
        continue; /* Loop/switch isn't completed */
        s3 = Base64.encodeToString(s1.getBytes(), 8);
          goto _L3
        Exception exception;
        exception;
        Log.i("ALP", exception.getMessage());
        obj = null;
        if(true) goto _L5; else goto _L4
_L4:
    }

    public HttpClient getHttpClient()
    {
        BasicHttpParams basichttpparams = new BasicHttpParams();
        HttpConnectionParams.setConnectionTimeout(basichttpparams, 5000);
        HttpConnectionParams.setSoTimeout(basichttpparams, 5000);
        return new DefaultHttpClient(basichttpparams);
    }

    public HttpResponse uploadCollectedData(Context context, String s, String s1, String s2, String s3, boolean flag)
    {
        HttpResponse httpresponse = null;
        if(s2 != null) goto _L2; else goto _L1
_L1:
        HttpResponse httpresponse1 = null;
_L4:
        return httpresponse1;
_L2:
        HttpResponse httpresponse2;
        HttpPost httppost = new HttpPost(s);
        List list = paramBuilder(s1, s2, s3, flag);
        if(list == null)
        {
            httpresponse1 = null;
            continue; /* Loop/switch isn't completed */
        }
        httppost.setEntity(new UrlEncodedFormEntity(list, "UTF-8"));
        httpresponse2 = getHttpClient().execute(httppost);
        httpresponse = httpresponse2;
_L5:
        httpresponse1 = httpresponse;
        if(true) goto _L4; else goto _L3
_L3:
        Exception exception;
        exception;
        Log.i("ALP", exception.getMessage());
          goto _L5
    }
}
