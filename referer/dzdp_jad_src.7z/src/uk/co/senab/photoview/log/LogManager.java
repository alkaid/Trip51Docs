// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package uk.co.senab.photoview.log;


// Referenced classes of package uk.co.senab.photoview.log:
//            LoggerDefault, Logger

public final class LogManager
{

    private static Logger logger = new LoggerDefault();

    public LogManager()
    {
    }

    public static Logger getLogger()
    {
        return logger;
    }

    public static void setLogger(Logger logger1)
    {
        logger = logger1;
    }

}
