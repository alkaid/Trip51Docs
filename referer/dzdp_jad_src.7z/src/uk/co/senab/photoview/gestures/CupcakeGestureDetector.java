// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package uk.co.senab.photoview.gestures;

import android.content.Context;
import android.util.FloatMath;
import android.util.Log;
import android.view.*;

// Referenced classes of package uk.co.senab.photoview.gestures:
//            GestureDetector, OnGestureListener

public class CupcakeGestureDetector
    implements GestureDetector
{

    private static final String LOG_TAG = "CupcakeGestureDetector";
    private boolean mIsDragging;
    float mLastTouchX;
    float mLastTouchY;
    protected OnGestureListener mListener;
    final float mMinimumVelocity;
    final float mTouchSlop;
    private VelocityTracker mVelocityTracker;

    public CupcakeGestureDetector(Context context)
    {
        ViewConfiguration viewconfiguration = ViewConfiguration.get(context);
        mMinimumVelocity = viewconfiguration.getScaledMinimumFlingVelocity();
        mTouchSlop = viewconfiguration.getScaledTouchSlop();
    }

    float getActiveX(MotionEvent motionevent)
    {
        return motionevent.getX();
    }

    float getActiveY(MotionEvent motionevent)
    {
        return motionevent.getY();
    }

    public boolean isScaling()
    {
        return false;
    }

    public boolean onTouchEvent(MotionEvent motionevent)
    {
        boolean flag = false;
        motionevent.getAction();
        JVM INSTR tableswitch 0 3: default 36
    //                   0 38
    //                   1 237
    //                   2 97
    //                   3 215;
           goto _L1 _L2 _L3 _L4 _L5
_L1:
        return true;
_L2:
        mVelocityTracker = VelocityTracker.obtain();
        if(mVelocityTracker != null)
            mVelocityTracker.addMovement(motionevent);
        else
            Log.i("CupcakeGestureDetector", "Velocity tracker is null");
        mLastTouchX = getActiveX(motionevent);
        mLastTouchY = getActiveY(motionevent);
        mIsDragging = false;
        continue; /* Loop/switch isn't completed */
_L4:
        float f2 = getActiveX(motionevent);
        float f3 = getActiveY(motionevent);
        float f4 = f2 - mLastTouchX;
        float f5 = f3 - mLastTouchY;
        if(!mIsDragging)
        {
            if(FloatMath.sqrt(f4 * f4 + f5 * f5) >= mTouchSlop)
                flag = true;
            mIsDragging = flag;
        }
        if(mIsDragging)
        {
            mListener.onDrag(f4, f5);
            mLastTouchX = f2;
            mLastTouchY = f3;
            if(mVelocityTracker != null)
                mVelocityTracker.addMovement(motionevent);
        }
        continue; /* Loop/switch isn't completed */
_L5:
        if(mVelocityTracker != null)
        {
            mVelocityTracker.recycle();
            mVelocityTracker = null;
        }
        continue; /* Loop/switch isn't completed */
_L3:
        if(mIsDragging && mVelocityTracker != null)
        {
            mLastTouchX = getActiveX(motionevent);
            mLastTouchY = getActiveY(motionevent);
            mVelocityTracker.addMovement(motionevent);
            mVelocityTracker.computeCurrentVelocity(1000);
            float f = mVelocityTracker.getXVelocity();
            float f1 = mVelocityTracker.getYVelocity();
            if(Math.max(Math.abs(f), Math.abs(f1)) >= mMinimumVelocity)
                mListener.onFling(mLastTouchX, mLastTouchY, -f, -f1);
        }
        if(mVelocityTracker != null)
        {
            mVelocityTracker.recycle();
            mVelocityTracker = null;
        }
        if(true) goto _L1; else goto _L6
_L6:
    }

    public void setOnGestureListener(OnGestureListener ongesturelistener)
    {
        mListener = ongesturelistener;
    }
}
