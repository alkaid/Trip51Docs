// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package uk.co.senab.photoview.gestures;

import android.content.Context;
import android.view.MotionEvent;
import uk.co.senab.photoview.Compat;

// Referenced classes of package uk.co.senab.photoview.gestures:
//            CupcakeGestureDetector

public class EclairGestureDetector extends CupcakeGestureDetector
{

    private static final int INVALID_POINTER_ID = -1;
    private int mActivePointerId;
    private int mActivePointerIndex;

    public EclairGestureDetector(Context context)
    {
        super(context);
        mActivePointerId = -1;
        mActivePointerIndex = 0;
    }

    float getActiveX(MotionEvent motionevent)
    {
        float f1 = motionevent.getX(mActivePointerIndex);
        float f = f1;
_L2:
        return f;
        Exception exception;
        exception;
        f = motionevent.getX();
        if(true) goto _L2; else goto _L1
_L1:
    }

    float getActiveY(MotionEvent motionevent)
    {
        float f1 = motionevent.getY(mActivePointerIndex);
        float f = f1;
_L2:
        return f;
        Exception exception;
        exception;
        f = motionevent.getY();
        if(true) goto _L2; else goto _L1
_L1:
    }

    public boolean onTouchEvent(MotionEvent motionevent)
    {
        int i = 0;
        0xff & motionevent.getAction();
        JVM INSTR tableswitch 0 6: default 52
    //                   0 81
    //                   1 93
    //                   2 52
    //                   3 93
    //                   4 52
    //                   5 52
    //                   6 102;
           goto _L1 _L2 _L3 _L1 _L3 _L1 _L1 _L4
_L1:
        if(mActivePointerId != -1)
            i = mActivePointerId;
        mActivePointerIndex = motionevent.findPointerIndex(i);
        return super.onTouchEvent(motionevent);
_L2:
        mActivePointerId = motionevent.getPointerId(0);
        continue; /* Loop/switch isn't completed */
_L3:
        mActivePointerId = -1;
        continue; /* Loop/switch isn't completed */
_L4:
        int j = Compat.getPointerIndex(motionevent.getAction());
        if(motionevent.getPointerId(j) == mActivePointerId)
        {
            int k;
            if(j == 0)
                k = 1;
            else
                k = 0;
            mActivePointerId = motionevent.getPointerId(k);
            mLastTouchX = motionevent.getX(k);
            mLastTouchY = motionevent.getY(k);
        }
        if(true) goto _L1; else goto _L5
_L5:
    }
}
