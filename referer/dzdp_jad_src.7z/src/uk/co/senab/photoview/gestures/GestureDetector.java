// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package uk.co.senab.photoview.gestures;

import android.view.MotionEvent;

// Referenced classes of package uk.co.senab.photoview.gestures:
//            OnGestureListener

public interface GestureDetector
{

    public abstract boolean isScaling();

    public abstract boolean onTouchEvent(MotionEvent motionevent);

    public abstract void setOnGestureListener(OnGestureListener ongesturelistener);
}
