// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package uk.co.senab.photoview.gestures;

import android.content.Context;

// Referenced classes of package uk.co.senab.photoview.gestures:
//            CupcakeGestureDetector, GestureDetector, EclairGestureDetector, FroyoGestureDetector, 
//            OnGestureListener

public final class VersionedGestureDetector
{

    public VersionedGestureDetector()
    {
    }

    public static GestureDetector newInstance(Context context, OnGestureListener ongesturelistener)
    {
        int i = android.os.Build.VERSION.SDK_INT;
        Object obj;
        if(i < 5)
            obj = new CupcakeGestureDetector(context);
        else
        if(i < 8)
            obj = new EclairGestureDetector(context);
        else
            obj = new FroyoGestureDetector(context);
        ((GestureDetector) (obj)).setOnGestureListener(ongesturelistener);
        return ((GestureDetector) (obj));
    }
}
