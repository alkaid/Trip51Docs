// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package uk.co.senab.photoview;

import android.view.View;

public class Compat
{

    private static final int SIXTY_FPS_INTERVAL = 16;

    public Compat()
    {
    }

    public static int getPointerIndex(int i)
    {
        int j;
        if(android.os.Build.VERSION.SDK_INT >= 11)
            j = getPointerIndexHoneyComb(i);
        else
            j = getPointerIndexEclair(i);
        return j;
    }

    private static int getPointerIndexEclair(int i)
    {
        return (0xff00 & i) >> 8;
    }

    private static int getPointerIndexHoneyComb(int i)
    {
        return (0xff00 & i) >> 8;
    }

    public static void postOnAnimation(View view, Runnable runnable)
    {
        if(android.os.Build.VERSION.SDK_INT >= 16)
            postOnAnimationJellyBean(view, runnable);
        else
            view.postDelayed(runnable, 16L);
    }

    private static void postOnAnimationJellyBean(View view, Runnable runnable)
    {
        view.postOnAnimation(runnable);
    }
}
