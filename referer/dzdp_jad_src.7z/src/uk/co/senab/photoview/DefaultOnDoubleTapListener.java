// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package uk.co.senab.photoview;

import android.graphics.RectF;
import android.view.MotionEvent;

// Referenced classes of package uk.co.senab.photoview:
//            PhotoViewAttacher

public class DefaultOnDoubleTapListener
    implements android.view.GestureDetector.OnDoubleTapListener
{

    private PhotoViewAttacher photoViewAttacher;

    public DefaultOnDoubleTapListener(PhotoViewAttacher photoviewattacher)
    {
        setPhotoViewAttacher(photoviewattacher);
    }

    public boolean onDoubleTap(MotionEvent motionevent)
    {
        boolean flag = true;
        if(photoViewAttacher == null)
            flag = false;
        else
            try
            {
                float f = photoViewAttacher.getScale();
                float f1 = motionevent.getX();
                float f2 = motionevent.getY();
                if(f < photoViewAttacher.getMediumScale())
                    photoViewAttacher.setScale(photoViewAttacher.getMediumScale(), f1, f2, true);
                else
                if(f >= photoViewAttacher.getMediumScale() && f < photoViewAttacher.getMaximumScale())
                    photoViewAttacher.setScale(photoViewAttacher.getMaximumScale(), f1, f2, true);
                else
                    photoViewAttacher.setScale(photoViewAttacher.getMinimumScale(), f1, f2, true);
            }
            catch(ArrayIndexOutOfBoundsException arrayindexoutofboundsexception) { }
        return flag;
    }

    public boolean onDoubleTapEvent(MotionEvent motionevent)
    {
        return false;
    }

    public boolean onSingleTapConfirmed(MotionEvent motionevent)
    {
        boolean flag = false;
        if(photoViewAttacher != null) goto _L2; else goto _L1
_L1:
        return flag;
_L2:
        android.widget.ImageView imageview = photoViewAttacher.getImageView();
        if(photoViewAttacher.getOnPhotoTapListener() != null)
        {
            RectF rectf = photoViewAttacher.getDisplayRect();
            if(rectf != null)
            {
                float f = motionevent.getX();
                float f1 = motionevent.getY();
                if(rectf.contains(f, f1))
                {
                    float f2 = (f - rectf.left) / rectf.width();
                    float f3 = (f1 - rectf.top) / rectf.height();
                    photoViewAttacher.getOnPhotoTapListener().onPhotoTap(imageview, f2, f3);
                    flag = true;
                    continue; /* Loop/switch isn't completed */
                }
            }
        }
        if(photoViewAttacher.getOnViewTapListener() != null)
            photoViewAttacher.getOnViewTapListener().onViewTap(imageview, motionevent.getX(), motionevent.getY());
        if(true) goto _L1; else goto _L3
_L3:
    }

    public void setPhotoViewAttacher(PhotoViewAttacher photoviewattacher)
    {
        photoViewAttacher = photoviewattacher;
    }
}
