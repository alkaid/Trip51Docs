// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package QMF_LOG;

import com.qq.taf.jce.*;

public final class WnsCmdLogControlReq extends JceStruct
{

    public int a;
    public byte b;
    public short c;
    public int d;

    public WnsCmdLogControlReq()
    {
        a = 0;
        b = 0;
        c = 0;
        d = 0;
    }

    public void readFrom(JceInputStream jceinputstream)
    {
        a = jceinputstream.read(a, 0, true);
        b = jceinputstream.read(b, 1, true);
        c = jceinputstream.read(c, 2, true);
        d = jceinputstream.read(d, 3, true);
    }

    public void writeTo(JceOutputStream jceoutputstream)
    {
        jceoutputstream.write(a, 0);
        jceoutputstream.write(b, 1);
        jceoutputstream.write(c, 2);
        jceoutputstream.write(d, 3);
    }
}
