// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package QMF_LOG;

import com.qq.taf.jce.*;

public final class LogInfo extends JceStruct
{

    static byte i[];
    public long a;
    public long b;
    public byte c;
    public int d;
    public int e;
    public String f;
    public byte g[];
    public int h;

    public LogInfo()
    {
        a = 0L;
        b = 0L;
        c = 0;
        d = 0;
        e = 0;
        f = "";
        g = null;
        h = 0;
    }

    public void readFrom(JceInputStream jceinputstream)
    {
        a = jceinputstream.read(a, 1, true);
        b = jceinputstream.read(b, 2, true);
        c = jceinputstream.read(c, 3, true);
        d = jceinputstream.read(d, 4, true);
        e = jceinputstream.read(e, 5, true);
        f = jceinputstream.readString(6, true);
        if(i == null)
        {
            i = (byte[])new byte[1];
            ((byte[])i)[0] = 0;
        }
        g = (byte[])jceinputstream.read(i, 7, false);
        h = jceinputstream.read(h, 8, false);
    }

    public void writeTo(JceOutputStream jceoutputstream)
    {
        jceoutputstream.write(a, 1);
        jceoutputstream.write(b, 2);
        jceoutputstream.write(c, 3);
        jceoutputstream.write(d, 4);
        jceoutputstream.write(e, 5);
        jceoutputstream.write(f, 6);
        if(g != null)
            jceoutputstream.write(g, 7);
        jceoutputstream.write(h, 8);
    }
}
