// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package QMF_LOG;

import com.qq.taf.jce.*;
import java.util.ArrayList;

public final class LogUploadTask extends JceStruct
{

    static ArrayList j;
    static byte k[];
    public long a;
    public long b;
    public int c;
    public String d;
    public long e;
    public short f;
    public ArrayList g;
    public String h;
    public byte i[];

    public LogUploadTask()
    {
        a = 0L;
        b = 0L;
        c = 0;
        d = "";
        e = 0L;
        f = 0;
        g = null;
        h = "";
        i = null;
    }

    public void readFrom(JceInputStream jceinputstream)
    {
        a = jceinputstream.read(a, 0, true);
        b = jceinputstream.read(b, 1, true);
        c = jceinputstream.read(c, 2, true);
        d = jceinputstream.readString(3, false);
        e = jceinputstream.read(e, 4, false);
        f = jceinputstream.read(f, 5, false);
        if(j == null)
        {
            j = new ArrayList();
            Long long1 = Long.valueOf(0L);
            j.add(long1);
        }
        g = (ArrayList)jceinputstream.read(j, 6, false);
        h = jceinputstream.readString(7, false);
        if(k == null)
        {
            k = new byte[1];
            k[0] = 0;
        }
        i = jceinputstream.read(k, 8, false);
    }

    public void writeTo(JceOutputStream jceoutputstream)
    {
        jceoutputstream.write(a, 0);
        jceoutputstream.write(b, 1);
        jceoutputstream.write(c, 2);
        if(d != null)
            jceoutputstream.write(d, 3);
        jceoutputstream.write(e, 4);
        jceoutputstream.write(f, 5);
        if(g != null)
            jceoutputstream.write(g, 6);
        if(h != null)
            jceoutputstream.write(h, 7);
        if(i != null)
            jceoutputstream.write(i, 8);
    }
}
