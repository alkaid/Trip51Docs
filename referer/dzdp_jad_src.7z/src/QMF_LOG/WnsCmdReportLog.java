// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package QMF_LOG;

import com.qq.taf.jce.*;
import java.util.ArrayList;

// Referenced classes of package QMF_LOG:
//            LogInfo

public final class WnsCmdReportLog extends JceStruct
{

    static ArrayList n;
    static byte o[];
    public String a;
    public byte b;
    public short c;
    public int d;
    public ArrayList e;
    public byte f[];
    public String g;
    public String h;
    public String i;
    public String j;
    public String k;
    public long l;
    public int m;

    public WnsCmdReportLog()
    {
        a = "";
        b = 0;
        c = 0;
        d = 0;
        e = null;
        f = null;
        g = "";
        h = "";
        i = "";
        j = "";
        k = "";
        l = 0L;
        m = 0;
    }

    public void readFrom(JceInputStream jceinputstream)
    {
        a = jceinputstream.readString(0, true);
        b = jceinputstream.read(b, 1, true);
        c = jceinputstream.read(c, 2, true);
        d = jceinputstream.read(d, 3, true);
        if(n == null)
        {
            n = new ArrayList();
            LogInfo loginfo = new LogInfo();
            n.add(loginfo);
        }
        e = (ArrayList)jceinputstream.read(n, 4, true);
        if(o == null)
        {
            o = (byte[])new byte[1];
            ((byte[])o)[0] = 0;
        }
        f = (byte[])jceinputstream.read(o, 5, false);
        g = jceinputstream.readString(6, false);
        h = jceinputstream.readString(7, false);
        i = jceinputstream.readString(8, false);
        j = jceinputstream.readString(9, false);
        k = jceinputstream.readString(10, false);
        l = jceinputstream.read(l, 11, false);
        m = jceinputstream.read(m, 12, false);
    }

    public void writeTo(JceOutputStream jceoutputstream)
    {
        jceoutputstream.write(a, 0);
        jceoutputstream.write(b, 1);
        jceoutputstream.write(c, 2);
        jceoutputstream.write(d, 3);
        jceoutputstream.write(e, 4);
        if(f != null)
            jceoutputstream.write(f, 5);
        if(g != null)
            jceoutputstream.write(g, 6);
        if(h != null)
            jceoutputstream.write(h, 7);
        if(i != null)
            jceoutputstream.write(i, 8);
        if(j != null)
            jceoutputstream.write(j, 9);
        if(k != null)
            jceoutputstream.write(k, 10);
        jceoutputstream.write(l, 11);
        jceoutputstream.write(m, 12);
    }
}
