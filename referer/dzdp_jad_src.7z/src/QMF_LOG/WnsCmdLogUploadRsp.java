// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package QMF_LOG;

import com.qq.taf.jce.*;

public final class WnsCmdLogUploadRsp extends JceStruct
{

    public int a;
    public int b;

    public WnsCmdLogUploadRsp()
    {
        a = 0;
        b = 0;
    }

    public void readFrom(JceInputStream jceinputstream)
    {
        a = jceinputstream.read(a, 0, true);
        b = jceinputstream.read(b, 1, true);
    }

    public void writeTo(JceOutputStream jceoutputstream)
    {
        jceoutputstream.write(a, 0);
        jceoutputstream.write(b, 1);
    }
}
