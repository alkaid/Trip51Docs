// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package PUSHAPI;

import com.qq.taf.jce.*;

public final class PushRsp extends JceStruct
{

    public long a;
    public String b;
    public byte c;
    public String d;

    public PushRsp()
    {
        a = 0L;
        b = "";
        c = 0;
        d = "";
    }

    public PushRsp(long l, String s, byte byte0, String s1)
    {
        a = 0L;
        b = "";
        c = 0;
        d = "";
        a = l;
        b = s;
        c = byte0;
        d = s1;
    }

    public void readFrom(JceInputStream jceinputstream)
    {
        a = jceinputstream.read(a, 1, false);
        b = jceinputstream.readString(3, false);
        c = jceinputstream.read(c, 4, false);
        d = jceinputstream.readString(5, false);
    }

    public void writeTo(JceOutputStream jceoutputstream)
    {
        jceoutputstream.write(a, 1);
        if(b != null)
            jceoutputstream.write(b, 3);
        jceoutputstream.write(c, 4);
        if(d != null)
            jceoutputstream.write(d, 5);
    }
}
