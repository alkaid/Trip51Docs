// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package PUSHAPI;

import com.qq.taf.jce.*;

public final class STMsg extends JceStruct
{

    static byte f[];
    public long a;
    public byte b[];
    public byte c;
    public long d;
    public String e;

    public STMsg()
    {
        a = 0L;
        b = null;
        c = 0;
        d = 0L;
        e = "";
    }

    public void readFrom(JceInputStream jceinputstream)
    {
        a = jceinputstream.read(a, 0, true);
        if(f == null)
        {
            f = new byte[1];
            f[0] = 0;
        }
        b = jceinputstream.read(f, 1, true);
        c = jceinputstream.read(c, 2, false);
        d = jceinputstream.read(d, 3, false);
        e = jceinputstream.readString(4, false);
    }

    public void writeTo(JceOutputStream jceoutputstream)
    {
        jceoutputstream.write(a, 0);
        jceoutputstream.write(b, 1);
        jceoutputstream.write(c, 2);
        jceoutputstream.write(d, 3);
        if(e != null)
            jceoutputstream.write(e, 4);
    }
}
