// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package PUSHAPI;

import com.qq.taf.jce.*;
import java.util.ArrayList;

// Referenced classes of package PUSHAPI:
//            STMsg

public final class Push extends JceStruct
{

    static ArrayList e;
    public long a;
    public ArrayList b;
    public String c;
    public String d;

    public Push()
    {
        a = 0L;
        b = null;
        c = "";
        d = "";
    }

    public void readFrom(JceInputStream jceinputstream)
    {
        a = jceinputstream.read(a, 1, false);
        if(e == null)
        {
            e = new ArrayList();
            STMsg stmsg = new STMsg();
            e.add(stmsg);
        }
        b = (ArrayList)jceinputstream.read(e, 2, false);
        c = jceinputstream.readString(3, false);
        d = jceinputstream.readString(4, false);
    }

    public void writeTo(JceOutputStream jceoutputstream)
    {
        jceoutputstream.write(a, 1);
        if(b != null)
            jceoutputstream.write(b, 2);
        if(c != null)
            jceoutputstream.write(c, 3);
        if(d != null)
            jceoutputstream.write(d, 4);
    }
}
