// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.sina.weibo.sdk;

import android.content.*;
import android.content.pm.*;
import android.content.res.AssetManager;
import android.database.Cursor;
import android.net.Uri;
import android.text.TextUtils;
import com.sina.weibo.sdk.utils.LogUtil;
import java.io.IOException;
import java.io.InputStream;
import java.util.Iterator;
import java.util.List;
import org.json.JSONException;
import org.json.JSONObject;

// Referenced classes of package com.sina.weibo.sdk:
//            ApiUtils

public class WeiboAppManager
{
    public static class WeiboInfo
    {

        private String mPackageName;
        private int mSupportApi;

        private void setPackageName(String s)
        {
            mPackageName = s;
        }

        private void setSupportApi(int i)
        {
            mSupportApi = i;
        }

        public String getPackageName()
        {
            return mPackageName;
        }

        public int getSupportApi()
        {
            return mSupportApi;
        }

        public boolean isLegal()
        {
            boolean flag;
            if(!TextUtils.isEmpty(mPackageName) && mSupportApi > 0)
                flag = true;
            else
                flag = false;
            return flag;
        }

        public String toString()
        {
            return (new StringBuilder("WeiboInfo: PackageName = ")).append(mPackageName).append(", supportApi = ").append(mSupportApi).toString();
        }



        public WeiboInfo()
        {
        }
    }


    private static final String SDK_INT_FILE_NAME = "weibo_for_sdk.json";
    private static final String TAG = com/sina/weibo/sdk/WeiboAppManager.getName();
    private static final String WEIBO_IDENTITY_ACTION = "com.sina.weibo.action.sdkidentity";
    private static final Uri WEIBO_NAME_URI = Uri.parse("content://com.sina.weibo.sdkProvider/query/package");
    private static WeiboAppManager sInstance;
    private Context mContext;

    private WeiboAppManager(Context context)
    {
        mContext = context.getApplicationContext();
    }

    /**
     * @deprecated Method getInstance is deprecated
     */

    public static WeiboAppManager getInstance(Context context)
    {
        com/sina/weibo/sdk/WeiboAppManager;
        JVM INSTR monitorenter ;
        WeiboAppManager weiboappmanager;
        if(sInstance == null)
            sInstance = new WeiboAppManager(context);
        weiboappmanager = sInstance;
        com/sina/weibo/sdk/WeiboAppManager;
        JVM INSTR monitorexit ;
        return weiboappmanager;
        Exception exception;
        exception;
        throw exception;
    }

    private WeiboInfo queryWeiboInfoByAsset(Context context)
    {
        Intent intent = new Intent("com.sina.weibo.action.sdkidentity");
        intent.addCategory("android.intent.category.DEFAULT");
        List list = context.getPackageManager().queryIntentServices(intent, 0);
        WeiboInfo weiboinfo;
        if(list == null || list.isEmpty())
        {
            weiboinfo = null;
        } else
        {
            weiboinfo = null;
            Iterator iterator = list.iterator();
            while(iterator.hasNext()) 
            {
                ResolveInfo resolveinfo = (ResolveInfo)iterator.next();
                if(resolveinfo.serviceInfo != null && resolveinfo.serviceInfo.applicationInfo != null && !TextUtils.isEmpty(resolveinfo.serviceInfo.applicationInfo.packageName))
                {
                    WeiboInfo weiboinfo1 = parseWeiboInfoByAsset(resolveinfo.serviceInfo.applicationInfo.packageName);
                    if(weiboinfo1 != null)
                        if(weiboinfo == null)
                            weiboinfo = weiboinfo1;
                        else
                        if(weiboinfo.getSupportApi() < weiboinfo1.getSupportApi())
                            weiboinfo = weiboinfo1;
                }
            }
        }
        return weiboinfo;
    }

    private WeiboInfo queryWeiboInfoByProvider(Context context)
    {
        ContentResolver contentresolver;
        Cursor cursor;
        contentresolver = context.getContentResolver();
        cursor = null;
        Cursor cursor1 = contentresolver.query(WEIBO_NAME_URI, null, null, null, null);
        cursor = cursor1;
        if(cursor != null) goto _L2; else goto _L1
_L1:
        WeiboInfo weiboinfo;
        if(cursor != null)
            cursor.close();
        weiboinfo = null;
_L5:
        return weiboinfo;
_L2:
        int j;
        int k;
        String s;
        int i = cursor.getColumnIndex("support_api");
        j = cursor.getColumnIndex("package");
        if(!cursor.moveToFirst())
            break MISSING_BLOCK_LABEL_214;
        k = -1;
        s = cursor.getString(i);
        int l = Integer.parseInt(s);
        k = l;
_L3:
        String s1 = cursor.getString(j);
        if(TextUtils.isEmpty(s1) || !ApiUtils.validateWeiboSign(context, s1))
            break MISSING_BLOCK_LABEL_214;
        weiboinfo = new WeiboInfo();
        weiboinfo.setPackageName(s1);
        weiboinfo.setSupportApi(k);
        if(cursor != null)
            cursor.close();
        continue; /* Loop/switch isn't completed */
        NumberFormatException numberformatexception;
        numberformatexception;
        numberformatexception.printStackTrace();
          goto _L3
        Exception exception1;
        exception1;
        LogUtil.e(TAG, exception1.getMessage());
        if(cursor != null)
            cursor.close();
_L6:
        weiboinfo = null;
        if(true) goto _L5; else goto _L4
_L4:
        Exception exception;
        exception;
        if(cursor != null)
            cursor.close();
        throw exception;
        if(cursor != null)
            cursor.close();
          goto _L6
    }

    private WeiboInfo queryWeiboInfoInternal(Context context)
    {
        boolean flag;
        WeiboInfo weiboinfo;
        WeiboInfo weiboinfo1;
        boolean flag1;
        flag = true;
        weiboinfo = queryWeiboInfoByProvider(context);
        weiboinfo1 = queryWeiboInfoByAsset(context);
        if(weiboinfo != null)
            flag1 = flag;
        else
            flag1 = false;
        if(weiboinfo1 == null)
            flag = false;
        if(!flag1 || !flag) goto _L2; else goto _L1
_L1:
        if(weiboinfo.getSupportApi() < weiboinfo1.getSupportApi())
            weiboinfo = weiboinfo1;
_L4:
        return weiboinfo;
_L2:
        if(!flag1)
            if(flag)
                weiboinfo = weiboinfo1;
            else
                weiboinfo = null;
        if(true) goto _L4; else goto _L3
_L3:
    }

    /**
     * @deprecated Method getWeiboInfo is deprecated
     */

    public WeiboInfo getWeiboInfo()
    {
        this;
        JVM INSTR monitorenter ;
        WeiboInfo weiboinfo = queryWeiboInfoInternal(mContext);
        this;
        JVM INSTR monitorexit ;
        return weiboinfo;
        Exception exception;
        exception;
        throw exception;
    }

    public WeiboInfo parseWeiboInfoByAsset(String s)
    {
        if(!TextUtils.isEmpty(s)) goto _L2; else goto _L1
_L1:
        WeiboInfo weiboinfo = null;
_L12:
        return weiboinfo;
_L2:
        InputStream inputstream = null;
        byte abyte0[];
        StringBuilder stringbuilder;
        Context context = mContext.createPackageContext(s, 2);
        abyte0 = new byte[4096];
        inputstream = context.getAssets().open("weibo_for_sdk.json");
        stringbuilder = new StringBuilder();
_L8:
        int i = inputstream.read(abyte0, 0, 4096);
        if(i != -1) goto _L4; else goto _L3
_L3:
        if(TextUtils.isEmpty(stringbuilder.toString())) goto _L6; else goto _L5
_L5:
        boolean flag = ApiUtils.validateWeiboSign(mContext, s);
        if(flag) goto _L7; else goto _L6
_L6:
        android.content.pm.PackageManager.NameNotFoundException namenotfoundexception;
        if(inputstream != null)
            try
            {
                inputstream.close();
            }
            catch(IOException ioexception6)
            {
                LogUtil.e(TAG, ioexception6.getMessage());
            }
        weiboinfo = null;
        continue; /* Loop/switch isn't completed */
_L4:
        stringbuilder.append(new String(abyte0, 0, i));
          goto _L8
        namenotfoundexception;
        LogUtil.e(TAG, namenotfoundexception.getMessage());
        if(inputstream != null)
            try
            {
                inputstream.close();
            }
            catch(IOException ioexception5)
            {
                LogUtil.e(TAG, ioexception5.getMessage());
            }
_L10:
        weiboinfo = null;
        continue; /* Loop/switch isn't completed */
_L7:
        int j = (new JSONObject(stringbuilder.toString())).optInt("support_api", -1);
        weiboinfo = new WeiboInfo();
        weiboinfo.setPackageName(s);
        weiboinfo.setSupportApi(j);
        if(inputstream != null)
            try
            {
                inputstream.close();
            }
            catch(IOException ioexception7)
            {
                LogUtil.e(TAG, ioexception7.getMessage());
            }
        continue; /* Loop/switch isn't completed */
        IOException ioexception3;
        ioexception3;
        LogUtil.e(TAG, ioexception3.getMessage());
        if(inputstream != null)
            try
            {
                inputstream.close();
            }
            catch(IOException ioexception4)
            {
                LogUtil.e(TAG, ioexception4.getMessage());
            }
        continue; /* Loop/switch isn't completed */
        JSONException jsonexception;
        jsonexception;
        LogUtil.e(TAG, jsonexception.getMessage());
        if(inputstream != null)
            try
            {
                inputstream.close();
            }
            catch(IOException ioexception2)
            {
                LogUtil.e(TAG, ioexception2.getMessage());
            }
        continue; /* Loop/switch isn't completed */
        Exception exception1;
        exception1;
        LogUtil.e(TAG, exception1.getMessage());
        if(inputstream != null)
            try
            {
                inputstream.close();
            }
            catch(IOException ioexception1)
            {
                LogUtil.e(TAG, ioexception1.getMessage());
            }
        if(true) goto _L10; else goto _L9
_L9:
        Exception exception;
        exception;
        if(inputstream != null)
            try
            {
                inputstream.close();
            }
            catch(IOException ioexception)
            {
                LogUtil.e(TAG, ioexception.getMessage());
            }
        throw exception;
        if(true) goto _L12; else goto _L11
_L11:
    }

}
