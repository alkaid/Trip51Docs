// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.sina.weibo.sdk.net;

import android.app.IntentService;
import android.content.Intent;
import android.os.Bundle;
import android.os.IBinder;
import android.text.TextUtils;
import com.sina.weibo.sdk.WbAppInstallActivator;
import com.sina.weibo.sdk.exception.WeiboException;
import com.sina.weibo.sdk.utils.LogUtil;
import com.sina.weibo.sdk.utils.NotificationHelper;
import java.io.File;

// Referenced classes of package com.sina.weibo.sdk.net:
//            WeiboParameters, HttpManager

public class DownloadService extends IntentService
{

    private static final String APK_SAVE_DIR;
    public static final String EXTRA_DOWNLOAD_URL = "download_url";
    public static final String EXTRA_NOTIFICATION_CONTENT = "notification_content";
    private static final String TAG = com/sina/weibo/sdk/net/DownloadService.getCanonicalName();

    public DownloadService()
    {
        super(TAG);
    }

    private static String generateSaveFileName(String s)
    {
        String s1 = "";
        int i = s.lastIndexOf("/");
        if(i != -1)
            s1 = s.substring(i + 1, s.length());
        return s1;
    }

    public IBinder onBind(Intent intent)
    {
        return null;
    }

    public void onCreate()
    {
        super.onCreate();
    }

    protected void onHandleIntent(Intent intent)
    {
        Bundle bundle = intent.getExtras();
        if(bundle != null) goto _L2; else goto _L1
_L1:
        stopSelf();
_L6:
        return;
_L2:
        String s;
        String s1;
        String s2;
        s = bundle.getString("download_url");
        s1 = bundle.getString("notification_content");
        LogUtil.e(TAG, (new StringBuilder("onHandleIntent downLoadUrl:")).append(s).append("!!!!!").toString());
        if(TextUtils.isEmpty(s))
        {
            LogUtil.e(TAG, "downloadurl is null");
            stopSelf();
            continue; /* Loop/switch isn't completed */
        }
        s2 = "";
        String s3;
        String s4;
        s3 = HttpManager.openRedirectUrl4LocationUri(getApplicationContext(), s, "GET", new WeiboParameters(""));
        s4 = generateSaveFileName(s3);
        if(TextUtils.isEmpty(s4) || !s4.endsWith(".apk"))
        {
            LogUtil.e(TAG, "redirectDownloadUrl is illeagle");
            stopSelf();
            continue; /* Loop/switch isn't completed */
        }
          goto _L3
        WeiboException weiboexception;
        weiboexception;
        weiboexception.printStackTrace();
_L4:
        String s5;
        String s6;
        if(!TextUtils.isEmpty(s2))
        {
            if((new File(s2)).exists())
            {
                LogUtil.e(TAG, "download successed!");
                NotificationHelper.showNotification(getApplicationContext(), s1, s2);
            }
        } else
        {
            LogUtil.e(TAG, "download failed!");
        }
        continue; /* Loop/switch isn't completed */
_L3:
        s5 = APK_SAVE_DIR;
        s6 = HttpManager.downloadFile(getApplicationContext(), s3, s5, s4);
        s2 = s6;
          goto _L4
        if(true) goto _L6; else goto _L5
_L5:
    }

    public void onStart(Intent intent, int i)
    {
        super.onStart(intent, i);
        if(intent != null);
    }

    public int onStartCommand(Intent intent, int i, int j)
    {
        return super.onStartCommand(intent, i, j);
    }

    static 
    {
        APK_SAVE_DIR = WbAppInstallActivator.WB_APK_FILE_DIR;
    }
}
