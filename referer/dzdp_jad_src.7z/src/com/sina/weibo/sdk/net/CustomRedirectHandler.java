// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.sina.weibo.sdk.net;

import android.text.TextUtils;
import com.sina.weibo.sdk.utils.LogUtil;
import java.net.URI;
import org.apache.http.*;
import org.apache.http.client.RedirectHandler;
import org.apache.http.protocol.HttpContext;

public abstract class CustomRedirectHandler
    implements RedirectHandler
{

    private static final int MAX_REDIRECT_COUNT = 15;
    private static final String TAG = com/sina/weibo/sdk/net/CustomRedirectHandler.getCanonicalName();
    int redirectCount;
    String redirectUrl;
    private String tempRedirectUrl;

    public CustomRedirectHandler()
    {
    }

    public URI getLocationURI(HttpResponse httpresponse, HttpContext httpcontext)
        throws ProtocolException
    {
        LogUtil.d(TAG, (new StringBuilder("CustomRedirectHandler getLocationURI getRedirectUrl : ")).append(tempRedirectUrl).toString());
        URI uri;
        if(!TextUtils.isEmpty(tempRedirectUrl))
            uri = URI.create(tempRedirectUrl);
        else
            uri = null;
        return uri;
    }

    public int getRedirectCount()
    {
        return redirectCount;
    }

    public String getRedirectUrl()
    {
        return redirectUrl;
    }

    public boolean isRedirectRequested(HttpResponse httpresponse, HttpContext httpcontext)
    {
        int i = httpresponse.getStatusLine().getStatusCode();
        if(i != 301 && i != 302) goto _L2; else goto _L1
_L1:
        tempRedirectUrl = httpresponse.getFirstHeader("Location").getValue();
        if(TextUtils.isEmpty(tempRedirectUrl) || redirectCount >= 15 || !shouldRedirectUrl(tempRedirectUrl)) goto _L4; else goto _L3
_L3:
        boolean flag;
        redirectCount = 1 + redirectCount;
        flag = true;
_L6:
        return flag;
_L2:
        if(i == 200)
            redirectUrl = tempRedirectUrl;
        else
            onReceivedException();
_L4:
        flag = false;
        if(true) goto _L6; else goto _L5
_L5:
    }

    public abstract void onReceivedException();

    public abstract boolean shouldRedirectUrl(String s);

}
