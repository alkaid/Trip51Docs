// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.sina.weibo.sdk.net;

import android.content.Context;
import android.graphics.Bitmap;
import android.text.TextUtils;
import android.webkit.URLUtil;
import com.sina.weibo.sdk.exception.WeiboException;
import com.sina.weibo.sdk.exception.WeiboHttpException;
import com.sina.weibo.sdk.utils.*;
import java.io.*;
import java.net.URI;
import java.security.KeyStore;
import java.security.cert.*;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.zip.GZIPInputStream;
import org.apache.http.*;
import org.apache.http.client.HttpClient;
import org.apache.http.client.RedirectHandler;
import org.apache.http.client.methods.*;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.conn.scheme.*;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.entity.ByteArrayEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.tsccm.ThreadSafeClientConnManager;
import org.apache.http.params.*;
import org.apache.http.protocol.HttpContext;

// Referenced classes of package com.sina.weibo.sdk.net:
//            WeiboParameters, NetStateManager, CustomRedirectHandler

class HttpManager
{

    private static final String BOUNDARY = getBoundry();
    private static final int BUFFER_SIZE = 8192;
    private static final int CONNECTION_TIMEOUT = 25000;
    private static final String END_MP_BOUNDARY = (new StringBuilder("--")).append(BOUNDARY).append("--").toString();
    private static final String HTTP_METHOD_GET = "GET";
    private static final String HTTP_METHOD_POST = "POST";
    private static final String MP_BOUNDARY = (new StringBuilder("--")).append(BOUNDARY).toString();
    private static final String MULTIPART_FORM_DATA = "multipart/form-data";
    private static final int SOCKET_TIMEOUT = 20000;
    private static final String TAG = "HttpManager";
    private static SSLSocketFactory sSSLSocketFactory;

    HttpManager()
    {
    }

    private static void buildParams(OutputStream outputstream, WeiboParameters weiboparameters)
        throws WeiboException
    {
        Set set;
        Iterator iterator;
        set = weiboparameters.keySet();
        iterator = set.iterator();
_L3:
        if(iterator.hasNext()) goto _L2; else goto _L1
_L1:
        Iterator iterator1 = set.iterator();
_L4:
        if(!iterator1.hasNext())
        {
            outputstream.write((new StringBuilder("\r\n")).append(END_MP_BOUNDARY).toString().getBytes());
            return;
        }
        break MISSING_BLOCK_LABEL_182;
_L2:
        IOException ioexception;
        String s = (String)iterator.next();
        if(weiboparameters.get(s) instanceof String)
        {
            StringBuilder stringbuilder = new StringBuilder(100);
            stringbuilder.setLength(0);
            stringbuilder.append(MP_BOUNDARY).append("\r\n");
            stringbuilder.append("content-disposition: form-data; name=\"").append(s).append("\"\r\n\r\n");
            stringbuilder.append(weiboparameters.get(s)).append("\r\n");
            outputstream.write(stringbuilder.toString().getBytes());
        }
          goto _L3
        try
        {
            String s1 = (String)iterator1.next();
            Object obj = weiboparameters.get(s1);
            if(obj instanceof Bitmap)
            {
                StringBuilder stringbuilder1 = new StringBuilder();
                stringbuilder1.append(MP_BOUNDARY).append("\r\n");
                stringbuilder1.append("content-disposition: form-data; name=\"").append(s1).append("\"; filename=\"file\"\r\n");
                stringbuilder1.append("Content-Type: application/octet-stream; charset=utf-8\r\n\r\n");
                outputstream.write(stringbuilder1.toString().getBytes());
                Bitmap bitmap = (Bitmap)obj;
                ByteArrayOutputStream bytearrayoutputstream = new ByteArrayOutputStream();
                bitmap.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, bytearrayoutputstream);
                outputstream.write(bytearrayoutputstream.toByteArray());
                outputstream.write("\r\n".getBytes());
            } else
            if(obj instanceof ByteArrayOutputStream)
            {
                StringBuilder stringbuilder2 = new StringBuilder();
                stringbuilder2.append(MP_BOUNDARY).append("\r\n");
                stringbuilder2.append("content-disposition: form-data; name=\"").append(s1).append("\"; filename=\"file\"\r\n");
                stringbuilder2.append("Content-Type: application/octet-stream; charset=utf-8\r\n\r\n");
                outputstream.write(stringbuilder2.toString().getBytes());
                ByteArrayOutputStream bytearrayoutputstream1 = (ByteArrayOutputStream)obj;
                outputstream.write(bytearrayoutputstream1.toByteArray());
                outputstream.write("\r\n".getBytes());
                bytearrayoutputstream1.close();
            }
        }
        // Misplaced declaration of an exception variable
        catch(IOException ioexception)
        {
            throw new WeiboException(ioexception);
        }
          goto _L4
    }

    private static native String calcOauthSignNative(Context context, String s, String s1);

    /**
     * @deprecated Method downloadFile is deprecated
     */

    public static String downloadFile(Context context, String s, String s1, String s2)
        throws WeiboException
    {
        com/sina/weibo/sdk/net/HttpManager;
        JVM INSTR monitorenter ;
        File file1;
        File file = new File(s1);
        if(!file.exists())
            file.mkdirs();
        file1 = new File(file, s2);
        if(!file1.exists()) goto _L2; else goto _L1
_L1:
        String s7 = file1.getPath();
        String s3 = s7;
_L4:
        com/sina/weibo/sdk/net/HttpManager;
        JVM INSTR monitorexit ;
        return s3;
_L2:
label0:
        {
            if(URLUtil.isValidUrl(s))
                break label0;
            s3 = "";
        }
        if(true) goto _L4; else goto _L3
_L3:
        HttpClient httpclient;
        long l;
        File file2;
        httpclient = getNewHttpClient();
        l = 0L;
        StringBuilder stringbuilder = new StringBuilder(String.valueOf(s2));
        file2 = new File(s1, stringbuilder.append("_temp").toString());
        if(!file2.exists()) goto _L6; else goto _L5
_L5:
        l = file2.length();
_L11:
        HttpResponse httpresponse;
        int i;
        long l1;
        HttpGet httpget = new HttpGet(s);
        httpget.setHeader("RANGE", (new StringBuilder("bytes=")).append(l).append("-").toString());
        httpresponse = httpclient.execute(httpget);
        i = httpresponse.getStatusLine().getStatusCode();
        l1 = 0L;
        if(i != 206) goto _L8; else goto _L7
_L7:
        long l2;
        l2 = l;
        Header aheader[] = httpresponse.getHeaders("Content-Range");
        if(aheader != null && aheader.length != 0)
        {
            String s6 = aheader[0].getValue();
            l1 = Long.parseLong(s6.substring(1 + s6.indexOf('/')));
        }
_L14:
        HttpEntity httpentity;
        Header header1;
        httpentity = httpresponse.getEntity();
        header1 = httpresponse.getFirstHeader("Content-Encoding");
        if(header1 == null || header1.getValue().toLowerCase().indexOf("gzip") <= -1) goto _L10; else goto _L9
_L9:
        Object obj = new GZIPInputStream(httpentity.getContent());
_L15:
        RandomAccessFile randomaccessfile;
        byte abyte0[];
        randomaccessfile = new RandomAccessFile(file2, "rw");
        randomaccessfile.seek(l2);
        abyte0 = new byte[1024];
_L16:
        int j;
        j = ((InputStream) (obj)).read(abyte0);
        if(j != -1)
            break MISSING_BLOCK_LABEL_638;
        randomaccessfile.close();
        ((InputStream) (obj)).close();
        if(l1 != 0L && file2.length() >= l1)
            break MISSING_BLOCK_LABEL_651;
        file2.delete();
        if(httpclient == null)
            break MISSING_BLOCK_LABEL_441;
        httpclient.getConnectionManager().closeExpiredConnections();
        httpclient.getConnectionManager().closeIdleConnections(300L, TimeUnit.SECONDS);
_L13:
        s3 = "";
          goto _L4
_L6:
        file2.createNewFile();
          goto _L11
        IOException ioexception;
        ioexception;
        ioexception.printStackTrace();
        file2.delete();
        if(httpclient == null) goto _L13; else goto _L12
_L12:
        httpclient.getConnectionManager().closeExpiredConnections();
        httpclient.getConnectionManager().closeIdleConnections(300L, TimeUnit.SECONDS);
          goto _L13
        Exception exception;
        exception;
        throw exception;
_L8:
        if(i != 200)
            break MISSING_BLOCK_LABEL_563;
        l2 = 0L;
        Header header = httpresponse.getFirstHeader("Content-Length");
        if(header != null)
            l1 = Integer.valueOf(header.getValue()).intValue();
          goto _L14
        String s4 = readRsponse(httpresponse);
        WeiboHttpException weibohttpexception = new WeiboHttpException(s4, i);
        throw weibohttpexception;
        Exception exception1;
        exception1;
        if(httpclient == null)
            break MISSING_BLOCK_LABEL_623;
        httpclient.getConnectionManager().closeExpiredConnections();
        httpclient.getConnectionManager().closeIdleConnections(300L, TimeUnit.SECONDS);
        throw exception1;
_L10:
        obj = httpentity.getContent();
          goto _L15
        randomaccessfile.write(abyte0, 0, j);
          goto _L16
        String s5;
        file2.renameTo(file1);
        s5 = file1.getPath();
        s3 = s5;
        if(httpclient == null) goto _L4; else goto _L17
_L17:
        httpclient.getConnectionManager().closeExpiredConnections();
        httpclient.getConnectionManager().closeIdleConnections(300L, TimeUnit.SECONDS);
          goto _L4
    }

    private static String getBoundry()
    {
        StringBuffer stringbuffer;
        int i;
        stringbuffer = new StringBuffer();
        i = 1;
_L2:
        long l;
        if(i >= 12)
            return stringbuffer.toString();
        l = System.currentTimeMillis() + (long)i;
        if(l % 3L != 0L)
            break; /* Loop/switch isn't completed */
        stringbuffer.append((char)(int)l % 9);
_L3:
        i++;
        if(true) goto _L2; else goto _L1
_L1:
        if(l % 3L == 1L)
            stringbuffer.append((char)(int)(65L + l % 26L));
        else
            stringbuffer.append((char)(int)(97L + l % 26L));
          goto _L3
        if(true) goto _L2; else goto _L4
_L4:
    }

    private static Certificate getCertificate(String s)
        throws CertificateException, IOException
    {
        CertificateFactory certificatefactory;
        InputStream inputstream;
        certificatefactory = CertificateFactory.getInstance("X.509");
        inputstream = com/sina/weibo/sdk/net/HttpManager.getResourceAsStream(s);
        Certificate certificate = certificatefactory.generateCertificate(inputstream);
        if(inputstream != null)
            inputstream.close();
        return certificate;
        Exception exception;
        exception;
        if(inputstream != null)
            inputstream.close();
        throw exception;
    }

    private static HttpClient getNewHttpClient()
    {
        DefaultHttpClient defaulthttpclient;
        try
        {
            BasicHttpParams basichttpparams = new BasicHttpParams();
            HttpProtocolParams.setVersion(basichttpparams, HttpVersion.HTTP_1_1);
            HttpProtocolParams.setContentCharset(basichttpparams, "UTF-8");
            SchemeRegistry schemeregistry = new SchemeRegistry();
            schemeregistry.register(new Scheme("http", PlainSocketFactory.getSocketFactory(), 80));
            schemeregistry.register(new Scheme("https", getSSLSocketFactory(), 443));
            ThreadSafeClientConnManager threadsafeclientconnmanager = new ThreadSafeClientConnManager(basichttpparams, schemeregistry);
            HttpConnectionParams.setConnectionTimeout(basichttpparams, 25000);
            HttpConnectionParams.setSoTimeout(basichttpparams, 20000);
            defaulthttpclient = new DefaultHttpClient(threadsafeclientconnmanager, basichttpparams);
        }
        catch(Exception exception)
        {
            defaulthttpclient = new DefaultHttpClient();
        }
        return defaulthttpclient;
    }

    private static String getOauthSign(Context context, String s, String s1, String s2, String s3)
    {
        StringBuilder stringbuilder = new StringBuilder("");
        if(!TextUtils.isEmpty(s))
            stringbuilder.append(s);
        if(!TextUtils.isEmpty(s1))
            stringbuilder.append(s1);
        if(!TextUtils.isEmpty(s2))
            stringbuilder.append(s2);
        return calcOauthSignNative(context, stringbuilder.toString(), s3);
    }

    private static SSLSocketFactory getSSLSocketFactory()
    {
        if(sSSLSocketFactory == null)
            try
            {
                KeyStore keystore = KeyStore.getInstance(KeyStore.getDefaultType());
                keystore.load(null, null);
                Certificate certificate = getCertificate("cacert_cn.cer");
                Certificate certificate1 = getCertificate("cacert_com.cer");
                keystore.setCertificateEntry("cnca", certificate);
                keystore.setCertificateEntry("comca", certificate1);
                sSSLSocketFactory = new SSLSocketFactory(keystore);
                LogUtil.d("HttpManager", "getSSLSocketFactory noraml !!!!!");
            }
            catch(Exception exception)
            {
                exception.printStackTrace();
                sSSLSocketFactory = SSLSocketFactory.getSocketFactory();
                LogUtil.d("HttpManager", "getSSLSocketFactory error default !!!!!");
            }
        return sSSLSocketFactory;
    }

    private static String getTimestamp()
    {
        return String.valueOf(System.currentTimeMillis() / 1000L);
    }

    public static String openRedirectUrl4LocationUri(Context context, String s, String s1, WeiboParameters weiboparameters)
    {
        DefaultHttpClient defaulthttpclient = null;
        CustomRedirectHandler customredirecthandler = new CustomRedirectHandler() {

            public void onReceivedException()
            {
            }

            public boolean shouldRedirectUrl(String s3)
            {
                return true;
            }

        }
;
        Object obj;
        defaulthttpclient = (DefaultHttpClient)getNewHttpClient();
        defaulthttpclient.setRedirectHandler(customredirecthandler);
        setHttpCommonParam(context, weiboparameters);
        obj = null;
        defaulthttpclient.getParams().setParameter("http.route.default-proxy", NetStateManager.getAPN());
        if(!s1.equals("GET")) goto _L2; else goto _L1
_L1:
        obj = new HttpGet((new StringBuilder(String.valueOf(s))).append("?").append(weiboparameters.encodeUrl()).toString());
_L4:
        String s2;
        ((HttpUriRequest) (obj)).setHeader("User-Agent", NetworkHelper.generateUA(context));
        defaulthttpclient.execute(((HttpUriRequest) (obj)));
        s2 = customredirecthandler.getRedirectUrl();
        shutdownHttpClient(defaulthttpclient);
        return s2;
_L2:
        if(!s1.equals("POST")) goto _L4; else goto _L3
_L3:
        HttpPost httppost = new HttpPost(s);
        obj = httppost;
          goto _L4
        IOException ioexception;
        ioexception;
_L8:
        throw new WeiboException(ioexception);
        Exception exception;
        exception;
_L6:
        shutdownHttpClient(defaulthttpclient);
        throw exception;
        exception;
        if(true) goto _L6; else goto _L5
_L5:
        ioexception;
        if(true) goto _L8; else goto _L7
_L7:
    }

    public static String openUrl(Context context, String s, String s1, WeiboParameters weiboparameters)
        throws WeiboException
    {
        String s2 = readRsponse(requestHttpExecute(context, s, s1, weiboparameters));
        LogUtil.d("HttpManager", (new StringBuilder("Response : ")).append(s2).toString());
        return s2;
    }

    public static String openUrl4RdirectURL(Context context, String s, String s1, WeiboParameters weiboparameters)
        throws WeiboException
    {
        DefaultHttpClient defaulthttpclient = null;
        Object obj;
        defaulthttpclient = (DefaultHttpClient)getNewHttpClient();
        defaulthttpclient.setRedirectHandler(new RedirectHandler() {

            public URI getLocationURI(HttpResponse httpresponse1, HttpContext httpcontext)
                throws ProtocolException
            {
                LogUtil.d("HttpManager", "openUrl4RdirectURL getLocationURI method");
                return null;
            }

            public boolean isRedirectRequested(HttpResponse httpresponse1, HttpContext httpcontext)
            {
                LogUtil.d("HttpManager", "openUrl4RdirectURL isRedirectRequested method");
                return false;
            }

        }
);
        setHttpCommonParam(context, weiboparameters);
        obj = null;
        defaulthttpclient.getParams().setParameter("http.route.default-proxy", NetStateManager.getAPN());
        if(!s1.equals("GET")) goto _L2; else goto _L1
_L1:
        String s4 = (new StringBuilder(String.valueOf(s))).append("?").append(weiboparameters.encodeUrl()).toString();
        LogUtil.d("HttpManager", (new StringBuilder("openUrl4RdirectURL GET url : ")).append(s4).toString());
        obj = new HttpGet(s4);
_L6:
        HttpResponse httpresponse;
        int i;
        httpresponse = defaulthttpclient.execute(((HttpUriRequest) (obj)));
        i = httpresponse.getStatusLine().getStatusCode();
        if(i != 301 && i != 302) goto _L4; else goto _L3
_L3:
        String s2;
        s2 = httpresponse.getFirstHeader("Location").getValue();
        LogUtil.d("HttpManager", (new StringBuilder("RedirectURL = ")).append(s2).toString());
        shutdownHttpClient(defaulthttpclient);
_L9:
        return s2;
_L2:
        if(!s1.equals("POST")) goto _L6; else goto _L5
_L5:
        HttpPost httppost = new HttpPost(s);
        LogUtil.d("HttpManager", (new StringBuilder("openUrl4RdirectURL POST url : ")).append(s).toString());
        obj = httppost;
          goto _L6
_L4:
        if(i != 200) goto _L8; else goto _L7
_L7:
        String s3 = readRsponse(httpresponse);
        s2 = s3;
        shutdownHttpClient(defaulthttpclient);
          goto _L9
_L8:
        throw new WeiboHttpException(readRsponse(httpresponse), i);
        IOException ioexception;
        ioexception;
        throw new WeiboException(ioexception);
        Exception exception;
        exception;
        shutdownHttpClient(defaulthttpclient);
        throw exception;
          goto _L6
    }

    private static String readRsponse(HttpResponse httpresponse)
        throws WeiboException
    {
        if(httpresponse != null) goto _L2; else goto _L1
_L1:
        String s = null;
_L5:
        return s;
_L2:
        HttpEntity httpentity;
        Object obj;
        ByteArrayOutputStream bytearrayoutputstream;
        httpentity = httpresponse.getEntity();
        obj = null;
        bytearrayoutputstream = new ByteArrayOutputStream();
        byte abyte0[];
        obj = httpentity.getContent();
        Header header = httpresponse.getFirstHeader("Content-Encoding");
        if(header != null && header.getValue().toLowerCase().indexOf("gzip") > -1)
            obj = new GZIPInputStream(((InputStream) (obj)));
        abyte0 = new byte[8192];
_L3:
        int i;
        i = ((InputStream) (obj)).read(abyte0);
        if(i != -1)
            break MISSING_BLOCK_LABEL_170;
        s = new String(bytearrayoutputstream.toByteArray(), "UTF-8");
        LogUtil.d("HttpManager", (new StringBuilder("readRsponse result : ")).append(s).toString());
        Exception exception;
        IOException ioexception2;
        if(obj != null)
            try
            {
                ((InputStream) (obj)).close();
            }
            catch(IOException ioexception4)
            {
                ioexception4.printStackTrace();
            }
        if(bytearrayoutputstream != null)
            try
            {
                bytearrayoutputstream.close();
            }
            catch(IOException ioexception3)
            {
                ioexception3.printStackTrace();
            }
        continue; /* Loop/switch isn't completed */
        bytearrayoutputstream.write(abyte0, 0, i);
          goto _L3
        ioexception2;
        throw new WeiboException(ioexception2);
        exception;
        if(obj != null)
            try
            {
                ((InputStream) (obj)).close();
            }
            catch(IOException ioexception1)
            {
                ioexception1.printStackTrace();
            }
        if(bytearrayoutputstream != null)
            try
            {
                bytearrayoutputstream.close();
            }
            catch(IOException ioexception)
            {
                ioexception.printStackTrace();
            }
        throw exception;
        if(true) goto _L5; else goto _L4
_L4:
    }

    private static HttpResponse requestHttpExecute(Context context, String s, String s1, WeiboParameters weiboparameters)
    {
        HttpClient httpclient;
        ByteArrayOutputStream bytearrayoutputstream;
        httpclient = null;
        bytearrayoutputstream = null;
        Object obj;
        httpclient = getNewHttpClient();
        httpclient.getParams().setParameter("http.route.default-proxy", NetStateManager.getAPN());
        obj = null;
        setHttpCommonParam(context, weiboparameters);
        if(!s1.equals("GET")) goto _L2; else goto _L1
_L1:
        String s3 = (new StringBuilder(String.valueOf(s))).append("?").append(weiboparameters.encodeUrl()).toString();
        obj = new HttpGet(s3);
        LogUtil.d("HttpManager", (new StringBuilder("requestHttpExecute GET Url : ")).append(s3).toString());
_L6:
        HttpResponse httpresponse;
        httpresponse = httpclient.execute(((HttpUriRequest) (obj)));
        int i = httpresponse.getStatusLine().getStatusCode();
        if(i != 200)
            throw new WeiboHttpException(readRsponse(httpresponse), i);
          goto _L3
        IOException ioexception1;
        ioexception1;
_L9:
        throw new WeiboException(ioexception1);
        Exception exception;
        exception;
_L7:
        ByteArrayOutputStream bytearrayoutputstream1;
        HttpPost httppost;
        Object obj1;
        String s2;
        if(bytearrayoutputstream != null)
            try
            {
                bytearrayoutputstream.close();
            }
            catch(IOException ioexception) { }
        shutdownHttpClient(httpclient);
        throw exception;
_L2:
        if(!s1.equals("POST")) goto _L5; else goto _L4
_L4:
        LogUtil.d("HttpManager", (new StringBuilder("requestHttpExecute POST Url : ")).append(s).toString());
        httppost = new HttpPost(s);
        obj = httppost;
        bytearrayoutputstream1 = new ByteArrayOutputStream();
        if(weiboparameters.hasBinaryData())
        {
            httppost.setHeader("Content-Type", (new StringBuilder("multipart/form-data; boundary=")).append(BOUNDARY).toString());
            buildParams(bytearrayoutputstream1, weiboparameters);
        } else
        {
            obj1 = weiboparameters.get("content-type");
            if(obj1 != null && (obj1 instanceof String))
            {
                weiboparameters.remove("content-type");
                httppost.setHeader("Content-Type", (String)obj1);
            } else
            {
                httppost.setHeader("Content-Type", "application/x-www-form-urlencoded");
            }
            s2 = weiboparameters.encodeUrl();
            LogUtil.d("HttpManager", (new StringBuilder("requestHttpExecute POST postParam : ")).append(s2).toString());
            bytearrayoutputstream1.write(s2.getBytes("UTF-8"));
        }
        httppost.setEntity(new ByteArrayEntity(bytearrayoutputstream1.toByteArray()));
        bytearrayoutputstream = bytearrayoutputstream1;
          goto _L6
        exception;
        bytearrayoutputstream = bytearrayoutputstream1;
          goto _L7
_L5:
        if(!s1.equals("DELETE")) goto _L6; else goto _L8
_L8:
        obj = new HttpDelete(s);
          goto _L6
_L3:
        if(bytearrayoutputstream != null)
            try
            {
                bytearrayoutputstream.close();
            }
            catch(IOException ioexception2) { }
        shutdownHttpClient(httpclient);
        return httpresponse;
        ioexception1;
        bytearrayoutputstream = bytearrayoutputstream1;
          goto _L9
    }

    private static void setHttpCommonParam(Context context, WeiboParameters weiboparameters)
    {
        String s;
        String s1;
        String s2;
        Object obj;
        Object obj1;
        s = "";
        if(!TextUtils.isEmpty(weiboparameters.getAppKey()))
        {
            s = Utility.getAid(context, weiboparameters.getAppKey());
            if(!TextUtils.isEmpty(s))
                weiboparameters.put("aid", s);
        }
        s1 = getTimestamp();
        weiboparameters.put("oauth_timestamp", s1);
        s2 = "";
        obj = weiboparameters.get("access_token");
        obj1 = weiboparameters.get("refresh_token");
        if(obj == null || !(obj instanceof String)) goto _L2; else goto _L1
_L1:
        s2 = (String)obj;
_L4:
        weiboparameters.put("oauth_sign", getOauthSign(context, s, s2, weiboparameters.getAppKey(), s1));
        return;
_L2:
        if(obj1 != null && (obj1 instanceof String))
            s2 = (String)obj1;
        if(true) goto _L4; else goto _L3
_L3:
    }

    private static void shutdownHttpClient(HttpClient httpclient)
    {
        if(httpclient == null)
            break MISSING_BLOCK_LABEL_15;
        httpclient.getConnectionManager().closeExpiredConnections();
_L2:
        return;
        Exception exception;
        exception;
        if(true) goto _L2; else goto _L1
_L1:
    }

    static 
    {
        System.loadLibrary("weibosdkcore");
    }
}
