// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.sina.weibo.sdk.net;

import android.content.*;
import android.database.Cursor;
import android.net.Uri;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import org.apache.http.HttpHost;

public class NetStateManager
{
    public static final class NetState extends Enum
    {

        private static final NetState ENUM$VALUES[];
        public static final NetState Mobile;
        public static final NetState NOWAY;
        public static final NetState WIFI;

        public static NetState valueOf(String s)
        {
            return (NetState)Enum.valueOf(com/sina/weibo/sdk/net/NetStateManager$NetState, s);
        }

        public static NetState[] values()
        {
            NetState anetstate[] = ENUM$VALUES;
            int i = anetstate.length;
            NetState anetstate1[] = new NetState[i];
            System.arraycopy(anetstate, 0, anetstate1, 0, i);
            return anetstate1;
        }

        static 
        {
            Mobile = new NetState("Mobile", 0);
            WIFI = new NetState("WIFI", 1);
            NOWAY = new NetState("NOWAY", 2);
            NetState anetstate[] = new NetState[3];
            anetstate[0] = Mobile;
            anetstate[1] = WIFI;
            anetstate[2] = NOWAY;
            ENUM$VALUES = anetstate;
        }

        private NetState(String s, int i)
        {
            super(s, i);
        }
    }

    public class NetStateReceive extends BroadcastReceiver
    {

        final NetStateManager this$0;

        public void onReceive(Context context, Intent intent)
        {
            NetStateManager.mContext = context;
            if("android.net.conn.CONNECTIVITY_CHANGE".equals(intent.getAction()))
            {
                WifiManager wifimanager = (WifiManager)context.getSystemService("wifi");
                WifiInfo wifiinfo = wifimanager.getConnectionInfo();
                if(!wifimanager.isWifiEnabled() || -1 == wifiinfo.getNetworkId())
                    NetStateManager.CUR_NETSTATE = NetState.Mobile;
            }
        }

        public NetStateReceive()
        {
            this$0 = NetStateManager.this;
            super();
        }
    }


    public static NetState CUR_NETSTATE;
    private static Context mContext;

    public NetStateManager()
    {
    }

    public static HttpHost getAPN()
    {
        HttpHost httphost = null;
        Uri uri = Uri.parse("content://telephony/carriers/preferapn");
        Cursor cursor = null;
        if(mContext != null)
            cursor = mContext.getContentResolver().query(uri, null, null, null, null);
        if(cursor != null && cursor.moveToFirst())
        {
            String s = cursor.getString(cursor.getColumnIndex("proxy"));
            if(s != null && s.trim().length() > 0)
                httphost = new HttpHost(s, 80);
            cursor.close();
        }
        return httphost;
    }

    static 
    {
        CUR_NETSTATE = NetState.Mobile;
    }

}
