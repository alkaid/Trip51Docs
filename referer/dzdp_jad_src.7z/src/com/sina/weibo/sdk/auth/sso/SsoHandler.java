// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.sina.weibo.sdk.auth.sso;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.*;
import android.os.IBinder;
import android.os.RemoteException;
import android.text.TextUtils;
import com.sina.sso.RemoteSSO;
import com.sina.weibo.sdk.WeiboAppManager;
import com.sina.weibo.sdk.auth.*;
import com.sina.weibo.sdk.exception.WeiboDialogException;
import com.sina.weibo.sdk.exception.WeiboException;
import com.sina.weibo.sdk.utils.*;
import java.util.Iterator;
import java.util.List;

// Referenced classes of package com.sina.weibo.sdk.auth.sso:
//            WebAuthHandler

public class SsoHandler
{
    private static final class AuthType extends Enum
    {

        public static final AuthType ALL;
        private static final AuthType ENUM$VALUES[];
        public static final AuthType SsoOnly;
        public static final AuthType WebOnly;

        public static AuthType valueOf(String s)
        {
            return (AuthType)Enum.valueOf(com/sina/weibo/sdk/auth/sso/SsoHandler$AuthType, s);
        }

        public static AuthType[] values()
        {
            AuthType aauthtype[] = ENUM$VALUES;
            int i = aauthtype.length;
            AuthType aauthtype1[] = new AuthType[i];
            System.arraycopy(aauthtype, 0, aauthtype1, 0, i);
            return aauthtype1;
        }

        static 
        {
            ALL = new AuthType("ALL", 0);
            SsoOnly = new AuthType("SsoOnly", 1);
            WebOnly = new AuthType("WebOnly", 2);
            AuthType aauthtype[] = new AuthType[3];
            aauthtype[0] = ALL;
            aauthtype[1] = SsoOnly;
            aauthtype[2] = WebOnly;
            ENUM$VALUES = aauthtype;
        }

        private AuthType(String s, int i)
        {
            super(s, i);
        }
    }


    public static final String AUTH_FAILED_MSG = "auth failed!!!!!";
    public static final String AUTH_FAILED_NOT_INSTALL_MSG = "not install weibo client!!!!!";
    private static final String DEFAULT_WEIBO_REMOTE_SSO_SERVICE_NAME = "com.sina.weibo.remotessoservice";
    private static final int REQUEST_CODE_SSO_AUTH = 32973;
    private static final String TAG = "Weibo_SSO_login";
    private Activity mAuthActivity;
    private AuthInfo mAuthInfo;
    private WeiboAuthListener mAuthListener;
    private ServiceConnection mConnection;
    private int mSSOAuthRequestCode;
    private WebAuthHandler mWebAuthHandler;
    private com.sina.weibo.sdk.WeiboAppManager.WeiboInfo mWeiboInfo;

    public SsoHandler(Activity activity, AuthInfo authinfo)
    {
        mConnection = new ServiceConnection() {

            final SsoHandler this$0;

            public void onServiceConnected(ComponentName componentname, IBinder ibinder)
            {
                RemoteSSO remotesso = com.sina.sso.RemoteSSO.Stub.asInterface(ibinder);
                String s = remotesso.getPackageName();
                String s1 = remotesso.getActivityName();
                mAuthActivity.getApplicationContext().unbindService(mConnection);
                if(!startSingleSignOn(s, s1))
                    mWebAuthHandler.anthorize(mAuthListener);
_L1:
                return;
                RemoteException remoteexception;
                remoteexception;
                remoteexception.printStackTrace();
                  goto _L1
            }

            public void onServiceDisconnected(ComponentName componentname)
            {
                mWebAuthHandler.anthorize(mAuthListener);
            }

            
            {
                this$0 = SsoHandler.this;
                super();
            }
        }
;
        mAuthActivity = activity;
        mAuthInfo = authinfo;
        mWebAuthHandler = new WebAuthHandler(activity, authinfo);
        mWeiboInfo = WeiboAppManager.getInstance(activity).getWeiboInfo();
        AidTask.getInstance(mAuthActivity).aidTaskInit(authinfo.getAppKey());
    }

    private void authorize(int i, WeiboAuthListener weiboauthlistener, AuthType authtype)
    {
        boolean flag;
        mSSOAuthRequestCode = i;
        mAuthListener = weiboauthlistener;
        flag = false;
        if(authtype == AuthType.SsoOnly)
            flag = true;
        if(authtype != AuthType.WebOnly) goto _L2; else goto _L1
_L1:
        if(weiboauthlistener != null)
            mWebAuthHandler.anthorize(weiboauthlistener);
_L4:
        return;
_L2:
        if(!bindRemoteSSOService(mAuthActivity.getApplicationContext()))
            if(flag)
            {
                if(mAuthListener != null)
                    mAuthListener.onWeiboException(new WeiboException("not install weibo client!!!!!"));
            } else
            {
                mWebAuthHandler.anthorize(mAuthListener);
            }
        if(true) goto _L4; else goto _L3
_L3:
    }

    private boolean bindRemoteSSOService(Context context)
    {
        boolean flag;
        if(!isWeiboAppInstalled())
        {
            flag = false;
        } else
        {
            String s = mWeiboInfo.getPackageName();
            Intent intent = new Intent("com.sina.weibo.remotessoservice");
            intent.setPackage(s);
            flag = context.bindService(intent, mConnection, 1);
        }
        return flag;
    }

    public static ComponentName isServiceExisted(Context context, String s)
    {
        Iterator iterator = ((ActivityManager)context.getSystemService("activity")).getRunningServices(0x7fffffff).iterator();
_L4:
        if(iterator.hasNext()) goto _L2; else goto _L1
_L1:
        ComponentName componentname = null;
_L3:
        return componentname;
_L2:
        componentname = ((android.app.ActivityManager.RunningServiceInfo)iterator.next()).service;
        if(!componentname.getPackageName().equals(s) || !componentname.getClassName().equals((new StringBuilder(String.valueOf(s))).append(".business.RemoteSSOService").toString())) goto _L4; else goto _L3
    }

    private boolean startSingleSignOn(String s, String s1)
    {
        boolean flag = true;
        Intent intent = new Intent();
        intent.setClassName(s, s1);
        intent.putExtras(mWebAuthHandler.getAuthInfo().getAuthBundle());
        intent.putExtra("_weibo_command_type", 3);
        intent.putExtra("_weibo_transaction", String.valueOf(System.currentTimeMillis()));
        intent.putExtra("aid", Utility.getAid(mAuthActivity, mAuthInfo.getAppKey()));
        boolean flag1;
        if(!SecurityHelper.validateAppSignatureForIntent(mAuthActivity, intent))
        {
            flag1 = false;
        } else
        {
            String s2 = Utility.getAid(mAuthActivity, mAuthInfo.getAppKey());
            if(!TextUtils.isEmpty(s2))
                intent.putExtra("aid", s2);
            try
            {
                mAuthActivity.startActivityForResult(intent, mSSOAuthRequestCode);
            }
            catch(ActivityNotFoundException activitynotfoundexception)
            {
                flag = false;
            }
            flag1 = flag;
        }
        return flag1;
    }

    public void authorize(WeiboAuthListener weiboauthlistener)
    {
        authorize(32973, weiboauthlistener, AuthType.ALL);
    }

    public void authorizeCallBack(int i, int j, Intent intent)
    {
        LogUtil.d("Weibo_SSO_login", (new StringBuilder("requestCode: ")).append(i).append(", resultCode: ").append(j).append(", data: ").append(intent).toString());
        if(i != mSSOAuthRequestCode) goto _L2; else goto _L1
_L1:
        if(j != -1) goto _L4; else goto _L3
_L3:
        if(SecurityHelper.checkResponseAppLegal(mAuthActivity, mWeiboInfo, intent))
        {
            String s = intent.getStringExtra("error");
            if(s == null)
                s = intent.getStringExtra("error_type");
            if(s != null)
            {
                if(s.equals("access_denied") || s.equals("OAuthAccessDeniedException"))
                {
                    LogUtil.d("Weibo_SSO_login", "Login canceled by user.");
                    mAuthListener.onCancel();
                } else
                {
                    String s1 = intent.getStringExtra("error_description");
                    if(s1 != null)
                        s = (new StringBuilder(String.valueOf(s))).append(":").append(s1).toString();
                    LogUtil.d("Weibo_SSO_login", (new StringBuilder("Login failed: ")).append(s).toString());
                    mAuthListener.onWeiboException(new WeiboDialogException(s, j, s1));
                }
            } else
            {
                android.os.Bundle bundle = intent.getExtras();
                Oauth2AccessToken oauth2accesstoken = Oauth2AccessToken.parseAccessToken(bundle);
                if(oauth2accesstoken != null && oauth2accesstoken.isSessionValid())
                {
                    LogUtil.d("Weibo_SSO_login", (new StringBuilder("Login Success! ")).append(oauth2accesstoken.toString()).toString());
                    mAuthListener.onComplete(bundle);
                } else
                {
                    LogUtil.d("Weibo_SSO_login", "Failed to receive access token by SSO");
                    mWebAuthHandler.anthorize(mAuthListener);
                }
            }
        }
_L2:
        return;
_L4:
        if(j == 0)
            if(intent != null)
            {
                LogUtil.d("Weibo_SSO_login", (new StringBuilder("Login failed: ")).append(intent.getStringExtra("error")).toString());
                mAuthListener.onWeiboException(new WeiboDialogException(intent.getStringExtra("error"), intent.getIntExtra("error_code", -1), intent.getStringExtra("failing_url")));
            } else
            {
                LogUtil.d("Weibo_SSO_login", "Login canceled by user.");
                mAuthListener.onCancel();
            }
        if(true) goto _L2; else goto _L5
_L5:
    }

    public void authorizeClientSso(WeiboAuthListener weiboauthlistener)
    {
        authorize(32973, weiboauthlistener, AuthType.SsoOnly);
    }

    public void authorizeWeb(WeiboAuthListener weiboauthlistener)
    {
        authorize(32973, weiboauthlistener, AuthType.WebOnly);
    }

    public boolean isWeiboAppInstalled()
    {
        boolean flag;
        if(mWeiboInfo != null && mWeiboInfo.isLegal())
            flag = true;
        else
            flag = false;
        return flag;
    }





}
