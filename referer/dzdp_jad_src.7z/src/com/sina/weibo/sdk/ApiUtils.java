// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.sina.weibo.sdk;

import android.content.Context;
import android.content.pm.*;
import android.text.TextUtils;
import com.sina.weibo.sdk.utils.LogUtil;
import com.sina.weibo.sdk.utils.MD5;

public class ApiUtils
{

    public static final int BUILD_INT = 10350;
    public static final int BUILD_INT_440 = 10355;
    public static final int BUILD_INT_VER_2_2 = 10351;
    public static final int BUILD_INT_VER_2_3 = 10352;
    public static final int BUILD_INT_VER_2_5 = 10353;
    private static final String TAG = com/sina/weibo/sdk/ApiUtils.getName();

    public ApiUtils()
    {
    }

    private static boolean containSign(Signature asignature[], String s)
    {
        boolean flag = false;
        if(asignature != null && s != null) goto _L2; else goto _L1
_L1:
        return flag;
_L2:
        int i = asignature.length;
        int j = 0;
        do
        {
            if(j < i)
            {
label0:
                {
                    if(!s.equals(MD5.hexdigest(asignature[j].toByteArray())))
                        break label0;
                    LogUtil.d(TAG, "check pass");
                    flag = true;
                }
            }
            if(true)
                continue;
            j++;
        } while(true);
        if(true) goto _L1; else goto _L3
_L3:
    }

    public static boolean validateWeiboSign(Context context, String s)
    {
        boolean flag = false;
        if(!TextUtils.isEmpty(s)) goto _L2; else goto _L1
_L1:
        return flag;
_L2:
        PackageInfo packageinfo = context.getPackageManager().getPackageInfo(s, 64);
        flag = containSign(packageinfo.signatures, "18da2bf10352443a00a5e046d9fca6bd");
        continue; /* Loop/switch isn't completed */
        android.content.pm.PackageManager.NameNotFoundException namenotfoundexception;
        namenotfoundexception;
        if(true) goto _L1; else goto _L3
_L3:
    }

}
