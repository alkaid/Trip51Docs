// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.sina.weibo.sdk.component;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.http.SslError;
import android.os.Bundle;
import android.webkit.SslErrorHandler;
import android.webkit.WebView;
import com.sina.weibo.sdk.auth.AuthInfo;
import com.sina.weibo.sdk.auth.WeiboAuthListener;
import com.sina.weibo.sdk.exception.WeiboAuthException;
import com.sina.weibo.sdk.utils.Utility;

// Referenced classes of package com.sina.weibo.sdk.component:
//            WeiboWebViewClient, AuthRequestParam, BrowserRequestCallBack, WeiboSdkBrowser

class AuthWeiboWebViewClient extends WeiboWebViewClient
{

    private boolean isCallBacked;
    private Activity mAct;
    private AuthRequestParam mAuthRequestParam;
    private WeiboAuthListener mListener;

    public AuthWeiboWebViewClient(Activity activity, AuthRequestParam authrequestparam)
    {
        isCallBacked = false;
        mAct = activity;
        mAuthRequestParam = authrequestparam;
        mListener = mAuthRequestParam.getAuthListener();
    }

    private void handleRedirectUrl(String s)
    {
        Bundle bundle;
        String s1;
        String s2;
        String s3;
        bundle = Utility.parseUrl(s);
        s1 = bundle.getString("error");
        s2 = bundle.getString("error_code");
        s3 = bundle.getString("error_description");
        if(s1 != null || s2 != null) goto _L2; else goto _L1
_L1:
        if(mListener != null)
            mListener.onComplete(bundle);
_L4:
        return;
_L2:
        if(mListener != null)
            mListener.onWeiboException(new WeiboAuthException(s2, s1, s3));
        if(true) goto _L4; else goto _L3
_L3:
    }

    public void onPageFinished(WebView webview, String s)
    {
        if(mCallBack != null)
            mCallBack.onPageFinishedCallBack(webview, s);
        super.onPageFinished(webview, s);
    }

    public void onPageStarted(WebView webview, String s, Bitmap bitmap)
    {
        if(mCallBack != null)
            mCallBack.onPageStartedCallBack(webview, s, bitmap);
        if(s.startsWith(mAuthRequestParam.getAuthInfo().getRedirectUrl()) && !isCallBacked)
        {
            isCallBacked = true;
            handleRedirectUrl(s);
            webview.stopLoading();
            WeiboSdkBrowser.closeBrowser(mAct, mAuthRequestParam.getAuthListenerKey(), null);
        } else
        {
            super.onPageStarted(webview, s, bitmap);
        }
    }

    public void onReceivedError(WebView webview, int i, String s, String s1)
    {
        if(mCallBack != null)
            mCallBack.onReceivedErrorCallBack(webview, i, s, s1);
        super.onReceivedError(webview, i, s, s1);
    }

    public void onReceivedSslError(WebView webview, SslErrorHandler sslerrorhandler, SslError sslerror)
    {
        if(mCallBack != null)
            mCallBack.onReceivedSslErrorCallBack(webview, sslerrorhandler, sslerror);
        super.onReceivedSslError(webview, sslerrorhandler, sslerror);
    }

    public boolean shouldOverrideUrlLoading(WebView webview, String s)
    {
        boolean flag = true;
        if(mCallBack != null)
            mCallBack.shouldOverrideUrlLoadingCallBack(webview, s);
        if(s.startsWith("sms:"))
        {
            Intent intent = new Intent("android.intent.action.VIEW");
            intent.putExtra("address", s.replace("sms:", ""));
            intent.setType("vnd.android-dir/mms-sms");
            mAct.startActivity(intent);
        } else
        if(s.startsWith("sinaweibo://browser/close"))
        {
            if(mListener != null)
                mListener.onCancel();
            WeiboSdkBrowser.closeBrowser(mAct, mAuthRequestParam.getAuthListenerKey(), null);
        } else
        {
            flag = super.shouldOverrideUrlLoading(webview, s);
        }
        return flag;
    }
}
