// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.sina.weibo.sdk.component;

import android.app.Activity;
import android.content.*;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import com.sina.weibo.sdk.api.*;
import com.sina.weibo.sdk.api.share.BaseRequest;
import com.sina.weibo.sdk.auth.WeiboAuthListener;
import com.sina.weibo.sdk.net.WeiboParameters;
import com.sina.weibo.sdk.utils.*;
import java.io.*;
import org.json.JSONException;
import org.json.JSONObject;

// Referenced classes of package com.sina.weibo.sdk.component:
//            BrowserRequestParamBase, BrowserLauncher, WeiboSdkBrowser, WeiboCallbackManager

public class ShareRequestParam extends BrowserRequestParamBase
{
    class UploadPicResult
    {

        private int code;
        private String picId;

        public static UploadPicResult parse(String s)
        {
            UploadPicResult uploadpicresult;
            if(TextUtils.isEmpty(s))
            {
                uploadpicresult = null;
            } else
            {
                uploadpicresult = new UploadPicResult();
                try
                {
                    JSONObject jsonobject = new JSONObject(s);
                    uploadpicresult.code = jsonobject.optInt("code", -2);
                    uploadpicresult.picId = jsonobject.optString("data", "");
                }
                catch(JSONException jsonexception) { }
            }
            return uploadpicresult;
        }

        public int getCode()
        {
            return code;
        }

        public String getPicId()
        {
            return picId;
        }

        private UploadPicResult()
        {
            code = -2;
        }
    }


    public static final String REQ_PARAM_AID = "aid";
    public static final String REQ_PARAM_KEY_HASH = "key_hash";
    public static final String REQ_PARAM_PACKAGENAME = "packagename";
    public static final String REQ_PARAM_PICINFO = "picinfo";
    public static final String REQ_PARAM_SOURCE = "source";
    public static final String REQ_PARAM_TITLE = "title";
    public static final String REQ_PARAM_TOKEN = "access_token";
    public static final String REQ_PARAM_VERSION = "version";
    public static final String REQ_UPLOAD_PIC_PARAM_IMG = "img";
    public static final String RESP_UPLOAD_PIC_PARAM_CODE = "code";
    public static final String RESP_UPLOAD_PIC_PARAM_DATA = "data";
    public static final int RESP_UPLOAD_PIC_SUCC_CODE = 1;
    private static final String SHARE_URL = "http://service.weibo.com/share/mobilesdk.php";
    public static final String UPLOAD_PIC_URL = "http://service.weibo.com/share/mobilesdk_uppic.php";
    private String mAppKey;
    private String mAppPackage;
    private WeiboAuthListener mAuthListener;
    private String mAuthListenerKey;
    private byte mBase64ImgData[];
    private BaseRequest mBaseRequest;
    private String mHashKey;
    private String mShareContent;
    private String mToken;

    public ShareRequestParam(Context context)
    {
        super(context);
        mLaucher = BrowserLauncher.SHARE;
    }

    private void handleMblogPic(String s, byte abyte0[])
    {
        if(TextUtils.isEmpty(s)) goto _L2; else goto _L1
_L1:
        File file = new File(s);
        if(!file.exists() || !file.canRead() || file.length() <= 0L) goto _L2; else goto _L3
_L3:
        byte abyte1[] = new byte[(int)file.length()];
        FileInputStream fileinputstream = null;
        FileInputStream fileinputstream1 = new FileInputStream(file);
        fileinputstream1.read(abyte1);
        mBase64ImgData = Base64.encodebyte(abyte1);
        if(fileinputstream1 == null)
            break MISSING_BLOCK_LABEL_94;
        fileinputstream1.close();
_L4:
        return;
        IOException ioexception1;
        ioexception1;
_L6:
        Exception exception1;
        Exception exception3;
        if(fileinputstream != null)
            try
            {
                fileinputstream.close();
            }
            catch(Exception exception) { }
            catch(SecurityException securityexception) { }
_L2:
        if(abyte0 != null && abyte0.length > 0)
            mBase64ImgData = Base64.encodebyte(abyte0);
          goto _L4
        exception1;
_L5:
        if(fileinputstream == null)
            break MISSING_BLOCK_LABEL_139;
        try
        {
            fileinputstream.close();
        }
        catch(Exception exception2) { }
        throw exception1;
        exception3;
          goto _L4
        exception1;
        fileinputstream = fileinputstream1;
          goto _L5
        IOException ioexception;
        ioexception;
        fileinputstream = fileinputstream1;
          goto _L6
    }

    private void handleSharedMessage(Bundle bundle)
    {
        WeiboMultiMessage weibomultimessage = new WeiboMultiMessage();
        weibomultimessage.toObject(bundle);
        StringBuilder stringbuilder = new StringBuilder();
        if(weibomultimessage.textObject instanceof TextObject)
            stringbuilder.append(weibomultimessage.textObject.text);
        if(weibomultimessage.imageObject instanceof ImageObject)
        {
            ImageObject imageobject1 = weibomultimessage.imageObject;
            handleMblogPic(imageobject1.imagePath, imageobject1.imageData);
        }
        if(weibomultimessage.mediaObject instanceof TextObject)
            stringbuilder.append(((TextObject)weibomultimessage.mediaObject).text);
        if(weibomultimessage.mediaObject instanceof ImageObject)
        {
            ImageObject imageobject = (ImageObject)weibomultimessage.mediaObject;
            handleMblogPic(imageobject.imagePath, imageobject.imageData);
        }
        if(weibomultimessage.mediaObject instanceof WebpageObject)
        {
            WebpageObject webpageobject = (WebpageObject)weibomultimessage.mediaObject;
            stringbuilder.append(" ").append(webpageobject.actionUrl);
        }
        if(weibomultimessage.mediaObject instanceof MusicObject)
        {
            MusicObject musicobject = (MusicObject)weibomultimessage.mediaObject;
            stringbuilder.append(" ").append(musicobject.actionUrl);
        }
        if(weibomultimessage.mediaObject instanceof VideoObject)
        {
            VideoObject videoobject = (VideoObject)weibomultimessage.mediaObject;
            stringbuilder.append(" ").append(videoobject.actionUrl);
        }
        if(weibomultimessage.mediaObject instanceof VoiceObject)
        {
            VoiceObject voiceobject = (VoiceObject)weibomultimessage.mediaObject;
            stringbuilder.append(" ").append(voiceobject.actionUrl);
        }
        mShareContent = stringbuilder.toString();
    }

    private void sendSdkResponse(Activity activity, int i, String s)
    {
        Bundle bundle = activity.getIntent().getExtras();
        if(bundle != null)
        {
            Intent intent = new Intent("com.sina.weibo.sdk.action.ACTION_SDK_REQ_ACTIVITY");
            intent.setFlags(0x20000);
            intent.setPackage(bundle.getString("_weibo_appPackage"));
            intent.putExtras(bundle);
            intent.putExtra("_weibo_appPackage", activity.getPackageName());
            intent.putExtra("_weibo_resp_errcode", i);
            intent.putExtra("_weibo_resp_errstr", s);
            try
            {
                activity.startActivityForResult(intent, 765);
            }
            catch(ActivityNotFoundException activitynotfoundexception) { }
        }
    }

    public WeiboParameters buildUploadPicParam(WeiboParameters weiboparameters)
    {
        if(hasImage())
            weiboparameters.put("img", new String(mBase64ImgData));
        return weiboparameters;
    }

    public String buildUrl(String s)
    {
        android.net.Uri.Builder builder = Uri.parse("http://service.weibo.com/share/mobilesdk.php").buildUpon();
        builder.appendQueryParameter("title", mShareContent);
        builder.appendQueryParameter("version", "0030105000");
        if(!TextUtils.isEmpty(mAppKey))
            builder.appendQueryParameter("source", mAppKey);
        if(!TextUtils.isEmpty(mToken))
            builder.appendQueryParameter("access_token", mToken);
        String s1 = Utility.getAid(mContext, mAppKey);
        if(!TextUtils.isEmpty(s1))
            builder.appendQueryParameter("aid", s1);
        if(!TextUtils.isEmpty(mAppPackage))
            builder.appendQueryParameter("packagename", mAppPackage);
        if(!TextUtils.isEmpty(mHashKey))
            builder.appendQueryParameter("key_hash", mHashKey);
        if(!TextUtils.isEmpty(s))
            builder.appendQueryParameter("picinfo", s);
        return builder.build().toString();
    }

    public void execRequest(Activity activity, int i)
    {
        if(i == 3)
        {
            sendSdkCancleResponse(activity);
            WeiboSdkBrowser.closeBrowser(activity, mAuthListenerKey, null);
        }
    }

    public String getAppKey()
    {
        return mAppKey;
    }

    public String getAppPackage()
    {
        return mAppPackage;
    }

    public WeiboAuthListener getAuthListener()
    {
        return mAuthListener;
    }

    public String getAuthListenerKey()
    {
        return mAuthListenerKey;
    }

    public byte[] getBase64ImgData()
    {
        return mBase64ImgData;
    }

    public String getHashKey()
    {
        return mHashKey;
    }

    public String getShareContent()
    {
        return mShareContent;
    }

    public String getToken()
    {
        return mToken;
    }

    public boolean hasImage()
    {
        boolean flag;
        if(mBase64ImgData != null && mBase64ImgData.length > 0)
            flag = true;
        else
            flag = false;
        return flag;
    }

    public void onCreateRequestParamBundle(Bundle bundle)
    {
        if(mBaseRequest != null)
            mBaseRequest.toBundle(bundle);
        if(!TextUtils.isEmpty(mAppPackage))
            mHashKey = MD5.hexdigest(Utility.getSign(mContext, mAppPackage));
        bundle.putString("access_token", mToken);
        bundle.putString("source", mAppKey);
        bundle.putString("packagename", mAppPackage);
        bundle.putString("key_hash", mHashKey);
        bundle.putString("_weibo_appPackage", mAppPackage);
        bundle.putString("_weibo_appKey", mAppKey);
        bundle.putInt("_weibo_flag", 0x20130329);
        bundle.putString("_weibo_sign", mHashKey);
        if(mAuthListener != null)
        {
            WeiboCallbackManager weibocallbackmanager = WeiboCallbackManager.getInstance(mContext);
            mAuthListenerKey = weibocallbackmanager.genCallbackKey();
            weibocallbackmanager.setWeiboAuthListener(mAuthListenerKey, mAuthListener);
            bundle.putString("key_listener", mAuthListenerKey);
        }
    }

    protected void onSetupRequestParam(Bundle bundle)
    {
        mAppKey = bundle.getString("source");
        mAppPackage = bundle.getString("packagename");
        mHashKey = bundle.getString("key_hash");
        mToken = bundle.getString("access_token");
        mAuthListenerKey = bundle.getString("key_listener");
        if(!TextUtils.isEmpty(mAuthListenerKey))
            mAuthListener = WeiboCallbackManager.getInstance(mContext).getWeiboAuthListener(mAuthListenerKey);
        handleSharedMessage(bundle);
        mUrl = buildUrl("");
    }

    public void sendSdkCancleResponse(Activity activity)
    {
        sendSdkResponse(activity, 1, "send cancel!!!");
    }

    public void sendSdkErrorResponse(Activity activity, String s)
    {
        sendSdkResponse(activity, 2, s);
    }

    public void sendSdkOkResponse(Activity activity)
    {
        sendSdkResponse(activity, 0, "send ok!!!");
    }

    public void setAppKey(String s)
    {
        mAppKey = s;
    }

    public void setAppPackage(String s)
    {
        mAppPackage = s;
    }

    public void setAuthListener(WeiboAuthListener weiboauthlistener)
    {
        mAuthListener = weiboauthlistener;
    }

    public void setBaseRequest(BaseRequest baserequest)
    {
        mBaseRequest = baserequest;
    }

    public void setToken(String s)
    {
        mToken = s;
    }
}
