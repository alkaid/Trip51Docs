// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.sina.weibo.sdk.component.view;

import android.content.Context;
import android.content.Intent;
import android.util.AttributeSet;
import android.view.View;
import android.widget.*;
import com.sina.weibo.sdk.auth.WeiboAuthListener;
import com.sina.weibo.sdk.component.WeiboSdkBrowser;
import com.sina.weibo.sdk.component.WidgetRequestParam;
import com.sina.weibo.sdk.utils.ResourceManager;

public class CommentComponentView extends FrameLayout
{
    public static final class Category extends Enum
    {

        private static final Category ENUM$VALUES[];
        public static final Category MOVIE;
        public static final Category TRAVEL;
        private String mVal;

        public static Category valueOf(String s)
        {
            return (Category)Enum.valueOf(com/sina/weibo/sdk/component/view/CommentComponentView$Category, s);
        }

        public static Category[] values()
        {
            Category acategory[] = ENUM$VALUES;
            int i = acategory.length;
            Category acategory1[] = new Category[i];
            System.arraycopy(acategory, 0, acategory1, 0, i);
            return acategory1;
        }

        public String getValue()
        {
            return mVal;
        }

        static 
        {
            MOVIE = new Category("MOVIE", 0, "1001");
            TRAVEL = new Category("TRAVEL", 1, "1002");
            Category acategory[] = new Category[2];
            acategory[0] = MOVIE;
            acategory[1] = TRAVEL;
            ENUM$VALUES = acategory;
        }

        private Category(String s, int i, String s1)
        {
            super(s, i);
            mVal = s1;
        }
    }

    public static class RequestParam
    {

        private String mAccessToken;
        private String mAppKey;
        private WeiboAuthListener mAuthlistener;
        private Category mCategory;
        private String mContent;
        private String mTopic;

        public static RequestParam createRequestParam(String s, String s1, String s2, Category category, WeiboAuthListener weiboauthlistener)
        {
            RequestParam requestparam = new RequestParam();
            requestparam.mAppKey = s;
            requestparam.mTopic = s1;
            requestparam.mContent = s2;
            requestparam.mCategory = category;
            requestparam.mAuthlistener = weiboauthlistener;
            return requestparam;
        }

        public static RequestParam createRequestParam(String s, String s1, String s2, String s3, Category category, WeiboAuthListener weiboauthlistener)
        {
            RequestParam requestparam = new RequestParam();
            requestparam.mAppKey = s;
            requestparam.mAccessToken = s1;
            requestparam.mTopic = s2;
            requestparam.mContent = s3;
            requestparam.mCategory = category;
            requestparam.mAuthlistener = weiboauthlistener;
            return requestparam;
        }







        private RequestParam()
        {
        }
    }


    private static final String ALREADY_COMMENT_EN = "Comment";
    private static final String ALREADY_COMMENT_ZH_CN = "\u5FAE\u535A\u70ED\u8BC4";
    private static final String ALREADY_COMMENT_ZH_TW = "\u5FAE\u535A\u71B1\u8A55";
    private static final String COMMENT_H5 = "http://widget.weibo.com/distribution/socail_comments_sdk.php";
    private RequestParam mCommentParam;
    private LinearLayout mContentLy;

    public CommentComponentView(Context context)
    {
        super(context);
        init(context);
    }

    public CommentComponentView(Context context, AttributeSet attributeset)
    {
        super(context, attributeset);
        init(context);
    }

    public CommentComponentView(Context context, AttributeSet attributeset, int i)
    {
        super(context, attributeset, i);
        init(context);
    }

    private void execAttented()
    {
        WidgetRequestParam widgetrequestparam = new WidgetRequestParam(getContext());
        widgetrequestparam.setUrl("http://widget.weibo.com/distribution/socail_comments_sdk.php");
        widgetrequestparam.setSpecifyTitle(ResourceManager.getString(getContext(), "Comment", "\u5FAE\u535A\u70ED\u8BC4", "\u5FAE\u535A\u71B1\u8A55"));
        widgetrequestparam.setAppKey(mCommentParam.mAppKey);
        widgetrequestparam.setCommentTopic(mCommentParam.mTopic);
        widgetrequestparam.setCommentContent(mCommentParam.mContent);
        widgetrequestparam.setCommentCategory(mCommentParam.mCategory.getValue());
        widgetrequestparam.setAuthListener(mCommentParam.mAuthlistener);
        widgetrequestparam.setToken(mCommentParam.mAccessToken);
        android.os.Bundle bundle = widgetrequestparam.createRequestParamBundle();
        Intent intent = new Intent(getContext(), com/sina/weibo/sdk/component/WeiboSdkBrowser);
        intent.putExtras(bundle);
        getContext().startActivity(intent);
    }

    private void init(Context context)
    {
        mContentLy = new LinearLayout(context);
        mContentLy.setOrientation(0);
        mContentLy.setLayoutParams(new android.view.ViewGroup.LayoutParams(-2, -2));
        ImageView imageview = new ImageView(context);
        imageview.setImageDrawable(ResourceManager.getDrawable(context, "sdk_weibo_logo.png"));
        android.widget.LinearLayout.LayoutParams layoutparams = new android.widget.LinearLayout.LayoutParams(ResourceManager.dp2px(getContext(), 20), ResourceManager.dp2px(getContext(), 20));
        layoutparams.gravity = 16;
        imageview.setLayoutParams(layoutparams);
        TextView textview = new TextView(context);
        textview.setText(ResourceManager.getString(context, "Comment", "\u5FAE\u535A\u70ED\u8BC4", "\u5FAE\u535A\u71B1\u8A55"));
        textview.setTextColor(-32256);
        textview.setTextSize(2, 15F);
        textview.setIncludeFontPadding(false);
        android.widget.LinearLayout.LayoutParams layoutparams1 = new android.widget.LinearLayout.LayoutParams(-2, -2);
        layoutparams1.gravity = 16;
        layoutparams1.leftMargin = ResourceManager.dp2px(getContext(), 4);
        textview.setLayoutParams(layoutparams1);
        mContentLy.addView(imageview);
        mContentLy.addView(textview);
        addView(mContentLy);
        textview.setOnClickListener(new android.view.View.OnClickListener() {

            final CommentComponentView this$0;

            public void onClick(View view)
            {
                execAttented();
            }

            
            {
                this$0 = CommentComponentView.this;
                super();
            }
        }
);
    }

    public void setCommentParam(RequestParam requestparam)
    {
        mCommentParam = requestparam;
    }

}
