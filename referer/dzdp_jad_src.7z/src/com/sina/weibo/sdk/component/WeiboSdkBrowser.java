// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.sina.weibo.sdk.component;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.*;
import android.widget.*;
import com.sina.weibo.sdk.auth.AuthInfo;
import com.sina.weibo.sdk.auth.WeiboAuthListener;
import com.sina.weibo.sdk.component.view.LoadingBar;
import com.sina.weibo.sdk.exception.WeiboException;
import com.sina.weibo.sdk.net.*;
import com.sina.weibo.sdk.utils.*;

// Referenced classes of package com.sina.weibo.sdk.component:
//            BrowserRequestCallBack, WeiboCallbackManager, BrowserLauncher, AuthRequestParam, 
//            ShareRequestParam, WidgetRequestParam, BrowserRequestParamBase, AuthWeiboWebViewClient, 
//            WeiboWebViewClient, ShareWeiboWebViewClient, WidgetWeiboWebViewClient

public class WeiboSdkBrowser extends Activity
    implements BrowserRequestCallBack
{
    private class WeiboChromeClient extends WebChromeClient
    {

        final WeiboSdkBrowser this$0;

        public void onProgressChanged(WebView webview, int i)
        {
            mLoadingBar.drawProgress(i);
            if(i != 100) goto _L2; else goto _L1
_L1:
            isLoading = false;
            refreshAllViews();
_L4:
            return;
_L2:
            if(!isLoading)
            {
                isLoading = true;
                refreshAllViews();
            }
            if(true) goto _L4; else goto _L3
_L3:
        }

        public void onReceivedTitle(WebView webview, String s)
        {
            if(!isWeiboCustomScheme(mUrl))
            {
                mHtmlTitle = s;
                updateTitleName();
            }
        }

        private WeiboChromeClient()
        {
            this$0 = WeiboSdkBrowser.this;
            super();
        }

        WeiboChromeClient(WeiboChromeClient weibochromeclient)
        {
            this();
        }
    }


    public static final String BROWSER_CLOSE_SCHEME = "sinaweibo://browser/close";
    public static final String BROWSER_WIDGET_SCHEME = "sinaweibo://browser/datatransfer";
    private static final String CANCEL_EN = "Close";
    private static final String CANCEL_ZH_CN = "\u5173\u95ED";
    private static final String CANCEL_ZH_TW = "\u5173\u95ED";
    private static final String CHANNEL_DATA_ERROR_EN = "channel_data_error";
    private static final String CHANNEL_DATA_ERROR_ZH_CN = "\u91CD\u65B0\u52A0\u8F7D";
    private static final String CHANNEL_DATA_ERROR_ZH_TW = "\u91CD\u65B0\u8F09\u5165";
    private static final String EMPTY_PROMPT_BAD_NETWORK_UI_EN = "A network error occurs, please tap the button to reload";
    private static final String EMPTY_PROMPT_BAD_NETWORK_UI_ZH_CN = "\u7F51\u7EDC\u51FA\u9519\u5566\uFF0C\u8BF7\u70B9\u51FB\u6309\u94AE\u91CD\u65B0\u52A0\u8F7D";
    private static final String EMPTY_PROMPT_BAD_NETWORK_UI_ZH_TW = "\u7DB2\u8DEF\u51FA\u932F\u5566\uFF0C\u8ACB\u9EDE\u64CA\u6309\u9215\u91CD\u65B0\u8F09\u5165";
    private static final String LOADINFO_EN = "Loading....";
    private static final String LOADINFO_ZH_CN = "\u52A0\u8F7D\u4E2D....";
    private static final String LOADINFO_ZH_TW = "\u8F09\u5165\u4E2D....";
    private static final String TAG = com/sina/weibo/sdk/component/WeiboSdkBrowser.getName();
    private static final String WEIBOBROWSER_NO_TITLE_EN = "No Title";
    private static final String WEIBOBROWSER_NO_TITLE_ZH_CN = "\u65E0\u6807\u9898";
    private static final String WEIBOBROWSER_NO_TITLE_ZH_TW = "\u7121\u6A19\u984C";
    private boolean isErrorPage;
    private boolean isLoading;
    private String mHtmlTitle;
    private TextView mLeftBtn;
    private Button mLoadErrorRetryBtn;
    private LinearLayout mLoadErrorView;
    private LoadingBar mLoadingBar;
    private BrowserRequestParamBase mRequestParam;
    private String mSpecifyTitle;
    private TextView mTitleText;
    private String mUrl;
    private WebView mWebView;
    private WeiboWebViewClient mWeiboWebViewClient;

    public WeiboSdkBrowser()
    {
    }

    public static void closeBrowser(Activity activity, String s, String s1)
    {
        WeiboCallbackManager weibocallbackmanager = WeiboCallbackManager.getInstance(activity.getApplicationContext());
        if(!TextUtils.isEmpty(s))
        {
            weibocallbackmanager.removeWeiboAuthListener(s);
            activity.finish();
        }
        if(!TextUtils.isEmpty(s1))
        {
            weibocallbackmanager.removeWidgetRequestCallback(s1);
            activity.finish();
        }
    }

    private BrowserRequestParamBase createBrowserRequestParam(Bundle bundle)
    {
        Object obj;
        BrowserLauncher browserlauncher;
        obj = null;
        browserlauncher = (BrowserLauncher)bundle.getSerializable("key_launcher");
        if(browserlauncher != BrowserLauncher.AUTH) goto _L2; else goto _L1
_L1:
        Object obj1;
        AuthRequestParam authrequestparam = new AuthRequestParam(this);
        authrequestparam.setupRequestParam(bundle);
        installAuthWeiboWebViewClient(authrequestparam);
        obj1 = authrequestparam;
_L4:
        return ((BrowserRequestParamBase) (obj1));
_L2:
        if(browserlauncher != BrowserLauncher.SHARE)
            break; /* Loop/switch isn't completed */
        ShareRequestParam sharerequestparam = new ShareRequestParam(this);
        sharerequestparam.setupRequestParam(bundle);
        installShareWeiboWebViewClient(sharerequestparam);
        obj = sharerequestparam;
_L6:
        obj1 = obj;
        if(true) goto _L4; else goto _L3
_L3:
        if(browserlauncher != BrowserLauncher.WIDGET) goto _L6; else goto _L5
_L5:
        WidgetRequestParam widgetrequestparam = new WidgetRequestParam(this);
        widgetrequestparam.setupRequestParam(bundle);
        installWidgetWeiboWebViewClient(widgetrequestparam);
        obj = widgetrequestparam;
          goto _L6
    }

    private void handleReceivedError(WebView webview, int i, String s, String s1)
    {
        if(!s1.startsWith("sinaweibo"))
        {
            isErrorPage = true;
            promptError();
        }
    }

    private void hiddenErrorPrompt()
    {
        mLoadErrorView.setVisibility(8);
        mWebView.setVisibility(0);
    }

    private boolean initDataFromIntent(Intent intent)
    {
        boolean flag;
        flag = false;
        mRequestParam = createBrowserRequestParam(intent.getExtras());
        if(mRequestParam != null) goto _L2; else goto _L1
_L1:
        return flag;
_L2:
        mUrl = mRequestParam.getUrl();
        if(!TextUtils.isEmpty(mUrl))
        {
            LogUtil.d(TAG, (new StringBuilder("LOAD URL : ")).append(mUrl).toString());
            mSpecifyTitle = mRequestParam.getSpecifyTitle();
            flag = true;
        }
        if(true) goto _L1; else goto _L3
_L3:
    }

    private void initWebView()
    {
        mWebView.getSettings().setJavaScriptEnabled(true);
        if(isWeiboShareRequestParam(mRequestParam))
            mWebView.getSettings().setUserAgentString(Utility.generateUA(this));
        mWebView.getSettings().setSavePassword(false);
        mWebView.setWebViewClient(mWeiboWebViewClient);
        mWebView.setWebChromeClient(new WeiboChromeClient(null));
        mWebView.requestFocus();
        mWebView.setScrollBarStyle(0);
    }

    private void installAuthWeiboWebViewClient(AuthRequestParam authrequestparam)
    {
        mWeiboWebViewClient = new AuthWeiboWebViewClient(this, authrequestparam);
        mWeiboWebViewClient.setBrowserRequestCallBack(this);
    }

    private void installShareWeiboWebViewClient(ShareRequestParam sharerequestparam)
    {
        ShareWeiboWebViewClient shareweibowebviewclient = new ShareWeiboWebViewClient(this, sharerequestparam);
        shareweibowebviewclient.setBrowserRequestCallBack(this);
        mWeiboWebViewClient = shareweibowebviewclient;
    }

    private void installWidgetWeiboWebViewClient(WidgetRequestParam widgetrequestparam)
    {
        WidgetWeiboWebViewClient widgetweibowebviewclient = new WidgetWeiboWebViewClient(this, widgetrequestparam);
        widgetweibowebviewclient.setBrowserRequestCallBack(this);
        mWeiboWebViewClient = widgetweibowebviewclient;
    }

    private boolean isWeiboCustomScheme(String s)
    {
        boolean flag;
        flag = false;
        break MISSING_BLOCK_LABEL_2;
        if(!TextUtils.isEmpty(s) && "sinaweibo".equalsIgnoreCase(Uri.parse(s).getAuthority()))
            flag = true;
        return flag;
    }

    private boolean isWeiboShareRequestParam(BrowserRequestParamBase browserrequestparambase)
    {
        boolean flag;
        if(browserrequestparambase.getLauncher() == BrowserLauncher.SHARE)
            flag = true;
        else
            flag = false;
        return flag;
    }

    private void openUrl(String s)
    {
        mWebView.loadUrl(s);
    }

    private void promptError()
    {
        mLoadErrorView.setVisibility(0);
        mWebView.setVisibility(8);
    }

    private void setContentView()
    {
        RelativeLayout relativelayout = new RelativeLayout(this);
        relativelayout.setLayoutParams(new android.view.ViewGroup.LayoutParams(-1, -1));
        relativelayout.setBackgroundColor(-1);
        LinearLayout linearlayout = new LinearLayout(this);
        linearlayout.setId(1);
        linearlayout.setOrientation(1);
        linearlayout.setLayoutParams(new android.view.ViewGroup.LayoutParams(-1, -2));
        RelativeLayout relativelayout1 = new RelativeLayout(this);
        relativelayout1.setLayoutParams(new android.view.ViewGroup.LayoutParams(-1, ResourceManager.dp2px(this, 45)));
        relativelayout1.setBackgroundDrawable(ResourceManager.getNinePatchDrawable(this, "weibosdk_navigationbar_background.9.png"));
        TextView textview = new TextView(this);
        mLeftBtn = textview;
        mLeftBtn.setClickable(true);
        mLeftBtn.setTextSize(2, 17F);
        mLeftBtn.setTextColor(ResourceManager.createColorStateList(-32256, 0x66ff8200));
        mLeftBtn.setText(ResourceManager.getString(this, "Close", "\u5173\u95ED", "\u5173\u95ED"));
        android.widget.RelativeLayout.LayoutParams layoutparams = new android.widget.RelativeLayout.LayoutParams(-2, -2);
        layoutparams.addRule(5);
        layoutparams.addRule(15);
        layoutparams.leftMargin = ResourceManager.dp2px(this, 10);
        layoutparams.rightMargin = ResourceManager.dp2px(this, 10);
        mLeftBtn.setLayoutParams(layoutparams);
        relativelayout1.addView(mLeftBtn);
        TextView textview1 = new TextView(this);
        mTitleText = textview1;
        mTitleText.setTextSize(2, 18F);
        mTitleText.setTextColor(0xff525252);
        mTitleText.setEllipsize(android.text.TextUtils.TruncateAt.END);
        mTitleText.setSingleLine(true);
        mTitleText.setGravity(17);
        mTitleText.setMaxWidth(ResourceManager.dp2px(this, 160));
        android.widget.RelativeLayout.LayoutParams layoutparams1 = new android.widget.RelativeLayout.LayoutParams(-2, -2);
        layoutparams1.addRule(13);
        mTitleText.setLayoutParams(layoutparams1);
        relativelayout1.addView(mTitleText);
        TextView textview2 = new TextView(this);
        textview2.setLayoutParams(new android.widget.LinearLayout.LayoutParams(-1, ResourceManager.dp2px(this, 2)));
        textview2.setBackgroundDrawable(ResourceManager.getNinePatchDrawable(this, "weibosdk_common_shadow_top.9.png"));
        LoadingBar loadingbar = new LoadingBar(this);
        mLoadingBar = loadingbar;
        mLoadingBar.setBackgroundColor(0);
        mLoadingBar.drawProgress(0);
        android.widget.LinearLayout.LayoutParams layoutparams2 = new android.widget.LinearLayout.LayoutParams(-1, ResourceManager.dp2px(this, 3));
        mLoadingBar.setLayoutParams(layoutparams2);
        linearlayout.addView(relativelayout1);
        linearlayout.addView(textview2);
        linearlayout.addView(mLoadingBar);
        WebView webview = new WebView(this);
        mWebView = webview;
        mWebView.setBackgroundColor(-1);
        android.widget.RelativeLayout.LayoutParams layoutparams3 = new android.widget.RelativeLayout.LayoutParams(-1, -1);
        layoutparams3.addRule(3, 1);
        mWebView.setLayoutParams(layoutparams3);
        LinearLayout linearlayout1 = new LinearLayout(this);
        mLoadErrorView = linearlayout1;
        mLoadErrorView.setVisibility(8);
        mLoadErrorView.setOrientation(1);
        mLoadErrorView.setGravity(17);
        android.widget.RelativeLayout.LayoutParams layoutparams4 = new android.widget.RelativeLayout.LayoutParams(-1, -1);
        layoutparams4.addRule(3, 1);
        mLoadErrorView.setLayoutParams(layoutparams4);
        ImageView imageview = new ImageView(this);
        imageview.setImageDrawable(ResourceManager.getDrawable(this, "weibosdk_empty_failed.png"));
        android.widget.LinearLayout.LayoutParams layoutparams5 = new android.widget.LinearLayout.LayoutParams(-2, -2);
        int i = ResourceManager.dp2px(this, 8);
        layoutparams5.bottomMargin = i;
        layoutparams5.rightMargin = i;
        layoutparams5.topMargin = i;
        layoutparams5.leftMargin = i;
        imageview.setLayoutParams(layoutparams5);
        mLoadErrorView.addView(imageview);
        TextView textview3 = new TextView(this);
        textview3.setGravity(1);
        textview3.setTextColor(0xffbdbdbd);
        textview3.setTextSize(2, 14F);
        textview3.setText(ResourceManager.getString(this, "A network error occurs, please tap the button to reload", "\u7F51\u7EDC\u51FA\u9519\u5566\uFF0C\u8BF7\u70B9\u51FB\u6309\u94AE\u91CD\u65B0\u52A0\u8F7D", "\u7DB2\u8DEF\u51FA\u932F\u5566\uFF0C\u8ACB\u9EDE\u64CA\u6309\u9215\u91CD\u65B0\u8F09\u5165"));
        textview3.setLayoutParams(new android.widget.LinearLayout.LayoutParams(-2, -2));
        mLoadErrorView.addView(textview3);
        Button button = new Button(this);
        mLoadErrorRetryBtn = button;
        mLoadErrorRetryBtn.setGravity(17);
        mLoadErrorRetryBtn.setTextColor(0xff787878);
        mLoadErrorRetryBtn.setTextSize(2, 16F);
        mLoadErrorRetryBtn.setText(ResourceManager.getString(this, "channel_data_error", "\u91CD\u65B0\u52A0\u8F7D", "\u91CD\u65B0\u8F09\u5165"));
        mLoadErrorRetryBtn.setBackgroundDrawable(ResourceManager.createStateListDrawable(this, "weibosdk_common_button_alpha.9.png", "weibosdk_common_button_alpha_highlighted.9.png"));
        android.widget.LinearLayout.LayoutParams layoutparams6 = new android.widget.LinearLayout.LayoutParams(ResourceManager.dp2px(this, 142), ResourceManager.dp2px(this, 46));
        layoutparams6.topMargin = ResourceManager.dp2px(this, 10);
        mLoadErrorRetryBtn.setLayoutParams(layoutparams6);
        Button button1 = mLoadErrorRetryBtn;
        android.view.View.OnClickListener onclicklistener = new android.view.View.OnClickListener() {

            final WeiboSdkBrowser this$0;

            public void onClick(View view)
            {
                openUrl(mUrl);
                isErrorPage = false;
            }

            
            {
                this$0 = WeiboSdkBrowser.this;
                super();
            }
        }
;
        button1.setOnClickListener(onclicklistener);
        mLoadErrorView.addView(mLoadErrorRetryBtn);
        relativelayout.addView(linearlayout);
        relativelayout.addView(mWebView);
        relativelayout.addView(mLoadErrorView);
        setContentView(((View) (relativelayout)));
        setTopNavTitle();
    }

    private void setTopNavTitle()
    {
        mTitleText.setText(mSpecifyTitle);
        mLeftBtn.setOnClickListener(new android.view.View.OnClickListener() {

            final WeiboSdkBrowser this$0;

            public void onClick(View view)
            {
                mRequestParam.execRequest(WeiboSdkBrowser.this, 3);
                finish();
            }

            
            {
                this$0 = WeiboSdkBrowser.this;
                super();
            }
        }
);
    }

    private void setViewLoading()
    {
        mTitleText.setText(ResourceManager.getString(this, "Loading....", "\u52A0\u8F7D\u4E2D....", "\u8F09\u5165\u4E2D...."));
        mLoadingBar.setVisibility(0);
    }

    private void setViewNormal()
    {
        updateTitleName();
        mLoadingBar.setVisibility(8);
    }

    public static void startAuth(Context context, String s, AuthInfo authinfo, WeiboAuthListener weiboauthlistener)
    {
        AuthRequestParam authrequestparam = new AuthRequestParam(context);
        authrequestparam.setLauncher(BrowserLauncher.AUTH);
        authrequestparam.setUrl(s);
        authrequestparam.setAuthInfo(authinfo);
        authrequestparam.setAuthListener(weiboauthlistener);
        Intent intent = new Intent(context, com/sina/weibo/sdk/component/WeiboSdkBrowser);
        intent.putExtras(authrequestparam.createRequestParamBundle());
        context.startActivity(intent);
    }

    private void startShare()
    {
        LogUtil.d(TAG, "Enter startShare()............");
        final ShareRequestParam req = (ShareRequestParam)mRequestParam;
        if(req.hasImage())
        {
            LogUtil.d(TAG, "loadUrl hasImage............");
            WeiboParameters weiboparameters = req.buildUploadPicParam(new WeiboParameters(req.getAppKey()));
            (new AsyncWeiboRunner(this)).requestAsync("http://service.weibo.com/share/mobilesdk_uppic.php", weiboparameters, "POST", new RequestListener() {

                final WeiboSdkBrowser this$0;
                private final ShareRequestParam val$req;

                public void onComplete(String s)
                {
                    LogUtil.d(WeiboSdkBrowser.TAG, (new StringBuilder("post onComplete : ")).append(s).toString());
                    ShareRequestParam.UploadPicResult uploadpicresult = ShareRequestParam.UploadPicResult.parse(s);
                    if(uploadpicresult != null && uploadpicresult.getCode() == 1 && !TextUtils.isEmpty(uploadpicresult.getPicId()))
                    {
                        openUrl(req.buildUrl(uploadpicresult.getPicId()));
                    } else
                    {
                        req.sendSdkErrorResponse(WeiboSdkBrowser.this, "upload pic faild");
                        finish();
                    }
                }

                public void onWeiboException(WeiboException weiboexception)
                {
                    LogUtil.d(WeiboSdkBrowser.TAG, (new StringBuilder("post onWeiboException ")).append(weiboexception.getMessage()).toString());
                    req.sendSdkErrorResponse(WeiboSdkBrowser.this, weiboexception.getMessage());
                    finish();
                }

            
            {
                this$0 = WeiboSdkBrowser.this;
                req = sharerequestparam;
                super();
            }
            }
);
        } else
        {
            openUrl(mUrl);
        }
    }

    public static void startShared(Context context, String s, AuthInfo authinfo, WeiboAuthListener weiboauthlistener)
    {
    }

    private void updateTitleName()
    {
        String s = "";
        if(TextUtils.isEmpty(mHtmlTitle)) goto _L2; else goto _L1
_L1:
        s = mHtmlTitle;
_L4:
        mTitleText.setText(s);
        return;
_L2:
        if(!TextUtils.isEmpty(mSpecifyTitle))
            s = mSpecifyTitle;
        if(true) goto _L4; else goto _L3
_L3:
    }

    protected void onCreate(Bundle bundle)
    {
        super.onCreate(bundle);
        if(!initDataFromIntent(getIntent()))
        {
            finish();
        } else
        {
            setContentView();
            initWebView();
            if(isWeiboShareRequestParam(mRequestParam))
                startShare();
            else
                openUrl(mUrl);
        }
    }

    protected void onDestroy()
    {
        NetworkHelper.clearCookies(this);
        super.onDestroy();
    }

    public boolean onKeyUp(int i, KeyEvent keyevent)
    {
        boolean flag;
        if(i == 4)
        {
            mRequestParam.execRequest(this, 3);
            finish();
            flag = true;
        } else
        {
            flag = super.onKeyUp(i, keyevent);
        }
        return flag;
    }

    public void onPageFinishedCallBack(WebView webview, String s)
    {
        LogUtil.d(TAG, (new StringBuilder("onPageFinished URL: ")).append(s).toString());
        if(isErrorPage)
        {
            promptError();
        } else
        {
            isErrorPage = false;
            hiddenErrorPrompt();
        }
    }

    public void onPageStartedCallBack(WebView webview, String s, Bitmap bitmap)
    {
        LogUtil.d(TAG, (new StringBuilder("onPageStarted URL: ")).append(s).toString());
        mUrl = s;
        if(!isWeiboCustomScheme(s))
            mHtmlTitle = "";
    }

    public void onReceivedErrorCallBack(WebView webview, int i, String s, String s1)
    {
        LogUtil.d(TAG, (new StringBuilder("onReceivedError: errorCode = ")).append(i).append(", description = ").append(s).append(", failingUrl = ").append(s1).toString());
        handleReceivedError(webview, i, s, s1);
    }

    public void onReceivedSslErrorCallBack(WebView webview, SslErrorHandler sslerrorhandler, SslError sslerror)
    {
        LogUtil.d(TAG, "onReceivedSslErrorCallBack.........");
    }

    protected void onResume()
    {
        super.onResume();
    }

    protected void refreshAllViews()
    {
        if(isLoading)
            setViewLoading();
        else
            setViewNormal();
    }

    public boolean shouldOverrideUrlLoadingCallBack(WebView webview, String s)
    {
        LogUtil.i(TAG, (new StringBuilder("shouldOverrideUrlLoading URL: ")).append(s).toString());
        return false;
    }












}
