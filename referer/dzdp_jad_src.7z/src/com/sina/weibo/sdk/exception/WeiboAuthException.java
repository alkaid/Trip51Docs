// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.sina.weibo.sdk.exception;


// Referenced classes of package com.sina.weibo.sdk.exception:
//            WeiboException

public class WeiboAuthException extends WeiboException
{

    public static final String DEFAULT_AUTH_ERROR_CODE = "-1";
    public static final String DEFAULT_AUTH_ERROR_DESC = "Unknown Error Description";
    public static final String DEFAULT_AUTH_ERROR_TYPE = "Unknown Error Type";
    private static final long serialVersionUID = 1L;
    private final String mErrorCode;
    private final String mErrorType;

    public WeiboAuthException(String s, String s1, String s2)
    {
        super(s2);
        mErrorType = s1;
        mErrorCode = s;
    }

    public String getErrorCode()
    {
        return mErrorCode;
    }

    public String getErrorType()
    {
        return mErrorType;
    }
}
