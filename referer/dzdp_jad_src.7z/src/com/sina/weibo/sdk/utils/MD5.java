// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.sina.weibo.sdk.utils;

import java.io.PrintStream;
import java.security.MessageDigest;

public class MD5
{

    private static final char hexDigits[];

    public MD5()
    {
    }

    public static String hexdigest(String s)
    {
        String s1 = null;
        String s2 = hexdigest(s.getBytes());
        s1 = s2;
_L2:
        return s1;
        Exception exception;
        exception;
        exception.printStackTrace();
        if(true) goto _L2; else goto _L1
_L1:
    }

    public static String hexdigest(byte abyte0[])
    {
        String s = null;
        byte abyte1[];
        char ac[];
        int i;
        int j;
        MessageDigest messagedigest = MessageDigest.getInstance("MD5");
        messagedigest.update(abyte0);
        abyte1 = messagedigest.digest();
        ac = new char[32];
        i = 0;
        j = 0;
_L1:
        if(i >= 16)
        {
            s = new String(ac);
            break MISSING_BLOCK_LABEL_111;
        }
        byte byte0 = abyte1[i];
        int k = j + 1;
        ac[j] = hexDigits[0xf & byte0 >>> 4];
        j = k + 1;
        ac[k] = hexDigits[byte0 & 0xf];
        i++;
          goto _L1
        Exception exception;
        exception;
        exception.printStackTrace();
        return s;
    }

    public static void main(String args[])
    {
        System.out.println(hexdigest("c"));
    }

    static 
    {
        char ac[] = new char[16];
        ac[0] = '0';
        ac[1] = '1';
        ac[2] = '2';
        ac[3] = '3';
        ac[4] = '4';
        ac[5] = '5';
        ac[6] = '6';
        ac[7] = '7';
        ac[8] = '8';
        ac[9] = '9';
        ac[10] = 'a';
        ac[11] = 'b';
        ac[12] = 'c';
        ac[13] = 'd';
        ac[14] = 'e';
        ac[15] = 'f';
        hexDigits = ac;
    }
}
