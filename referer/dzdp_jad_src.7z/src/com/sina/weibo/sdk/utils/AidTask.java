// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.sina.weibo.sdk.utils;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.*;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.WindowManager;
import com.sina.weibo.sdk.exception.WeiboException;
import com.sina.weibo.sdk.exception.WeiboHttpException;
import com.sina.weibo.sdk.net.AsyncWeiboRunner;
import com.sina.weibo.sdk.net.WeiboParameters;
import java.io.*;
import java.lang.reflect.Method;
import java.security.KeyFactory;
import java.security.PublicKey;
import java.security.spec.X509EncodedKeySpec;
import java.util.concurrent.locks.ReentrantLock;
import javax.crypto.Cipher;
import org.json.JSONException;
import org.json.JSONObject;

// Referenced classes of package com.sina.weibo.sdk.utils:
//            LogUtil, Base64, Utility

public class AidTask
{
    public static final class AidInfo
    {

        private String mAid;
        private String mSubCookie;

        public static AidInfo parseJson(String s)
            throws WeiboException
        {
            AidInfo aidinfo;
            JSONObject jsonobject;
            aidinfo = new AidInfo();
            try
            {
                jsonobject = new JSONObject(s);
                if(jsonobject.has("error") || jsonobject.has("error_code"))
                {
                    LogUtil.d("AidTask", "loadAidFromNet has error !!!");
                    throw new WeiboException("loadAidFromNet has error !!!");
                }
            }
            catch(JSONException jsonexception)
            {
                LogUtil.d("AidTask", (new StringBuilder("loadAidFromNet JSONException Msg : ")).append(jsonexception.getMessage()).toString());
                throw new WeiboException("loadAidFromNet has error !!!");
            }
            aidinfo.mAid = jsonobject.optString("aid", "");
            aidinfo.mSubCookie = jsonobject.optString("sub", "");
            return aidinfo;
        }

        public String getAid()
        {
            return mAid;
        }

        public String getSubCookie()
        {
            return mSubCookie;
        }

        public AidInfo()
        {
        }
    }


    private static final String AID_FILE_NAME = "weibo_sdk_aid";
    private static final String TAG = "AidTask";
    private static final int VERSION = 1;
    public static final int WHAT_LOAD_AID_API_ERR = 1002;
    public static final int WHAT_LOAD_AID_IO_ERR = 1003;
    public static final int WHAT_LOAD_AID_SUC = 1001;
    private static AidTask sInstance;
    private String mAppKey;
    private Context mContext;
    private volatile ReentrantLock mTaskLock;

    private AidTask(Context context)
    {
        mTaskLock = new ReentrantLock(true);
        mContext = context.getApplicationContext();
        (new Thread(new Runnable() {

            final AidTask this$0;

            public void run()
            {
                int i = 0;
                do
                {
                    if(i >= 1)
                        return;
                    File file = getAidInfoFile(i);
                    try
                    {
                        file.delete();
                    }
                    catch(Exception exception) { }
                    i++;
                } while(true);
            }

            
            {
                this$0 = AidTask.this;
                super();
            }
        }
)).start();
    }

    /**
     * @deprecated Method cacheAidInfo is deprecated
     */

    private void cacheAidInfo(String s)
    {
        this;
        JVM INSTR monitorenter ;
        boolean flag = TextUtils.isEmpty(s);
        if(!flag) goto _L2; else goto _L1
_L1:
        this;
        JVM INSTR monitorexit ;
        return;
_L2:
        FileOutputStream fileoutputstream = null;
        FileOutputStream fileoutputstream1 = new FileOutputStream(getAidInfoFile(1));
        fileoutputstream1.write(s.getBytes());
        if(fileoutputstream1 == null) goto _L1; else goto _L3
_L3:
        Exception exception;
        Exception exception2;
        Exception exception3;
        try
        {
            fileoutputstream1.close();
        }
        catch(IOException ioexception2) { }
          goto _L1
        exception3;
_L7:
        if(fileoutputstream == null) goto _L1; else goto _L4
_L4:
        try
        {
            fileoutputstream.close();
        }
        catch(IOException ioexception) { }
          goto _L1
        exception2;
_L6:
        if(fileoutputstream == null)
            break MISSING_BLOCK_LABEL_85;
        try
        {
            fileoutputstream.close();
        }
        catch(IOException ioexception1) { }
        throw exception2;
        exception;
        this;
        JVM INSTR monitorexit ;
        throw exception;
        exception2;
        fileoutputstream = fileoutputstream1;
        if(true) goto _L6; else goto _L5
_L5:
        Exception exception1;
        exception1;
        fileoutputstream = fileoutputstream1;
          goto _L7
    }

    private String encryptRsa(String s, String s1)
        throws Exception
    {
        Cipher cipher;
        ByteArrayOutputStream bytearrayoutputstream;
        byte abyte0[];
        cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
        cipher.init(1, getPublicKey(s1));
        bytearrayoutputstream = null;
        abyte0 = s.getBytes("UTF-8");
        ByteArrayOutputStream bytearrayoutputstream1 = new ByteArrayOutputStream();
        int i = 0;
_L2:
        int j;
        String s3;
        j = splite(abyte0, i, 117);
        if(j != -1)
            break MISSING_BLOCK_LABEL_190;
        bytearrayoutputstream1.flush();
        byte abyte2[] = bytearrayoutputstream1.toByteArray();
        LogUtil.d("AidTask", (new StringBuilder("encryptRsa total enBytes len = ")).append(abyte2.length).toString());
        byte abyte3[] = Base64.encodebyte(abyte2);
        LogUtil.d("AidTask", (new StringBuilder("encryptRsa total base64byte len = ")).append(abyte3.length).toString());
        String s2 = new String(abyte3, "UTF-8");
        s3 = (new StringBuilder("01")).append(s2).toString();
        LogUtil.d("AidTask", (new StringBuilder("encryptRsa total base64string : ")).append(s3).toString());
        Exception exception;
        byte abyte1[];
        if(bytearrayoutputstream1 != null)
            try
            {
                bytearrayoutputstream1.close();
            }
            catch(IOException ioexception1) { }
        return s3;
        abyte1 = cipher.doFinal(abyte0, i, j);
        bytearrayoutputstream1.write(abyte1);
        LogUtil.d("AidTask", (new StringBuilder("encryptRsa offset = ")).append(i).append("     len = ").append(j).append("     enBytes len = ").append(abyte1.length).toString());
        i += j;
        if(true) goto _L2; else goto _L1
_L1:
        exception;
_L4:
        if(bytearrayoutputstream != null)
            try
            {
                bytearrayoutputstream.close();
            }
            catch(IOException ioexception) { }
        throw exception;
        exception;
        bytearrayoutputstream = bytearrayoutputstream1;
        if(true) goto _L4; else goto _L3
_L3:
    }

    private String genMfpString()
    {
        JSONObject jsonobject = new JSONObject();
        String s16;
        String s1 = getOS();
        if(!TextUtils.isEmpty(s1))
            jsonobject.put("1", s1);
        String s2 = getImei();
        if(!TextUtils.isEmpty(s2))
            jsonobject.put("2", s2);
        String s3 = getMeid();
        if(!TextUtils.isEmpty(s3))
            jsonobject.put("3", s3);
        String s4 = getImsi();
        if(!TextUtils.isEmpty(s4))
            jsonobject.put("4", s4);
        String s5 = getMac();
        if(!TextUtils.isEmpty(s5))
            jsonobject.put("5", s5);
        String s6 = getIccid();
        if(!TextUtils.isEmpty(s6))
            jsonobject.put("6", s6);
        String s7 = getSerialNo();
        if(!TextUtils.isEmpty(s7))
            jsonobject.put("7", s7);
        String s8 = getAndroidId();
        if(!TextUtils.isEmpty(s8))
            jsonobject.put("10", s8);
        String s9 = getCpu();
        if(!TextUtils.isEmpty(s9))
            jsonobject.put("13", s9);
        String s10 = getModel();
        if(!TextUtils.isEmpty(s10))
            jsonobject.put("14", s10);
        String s11 = getSdSize();
        if(!TextUtils.isEmpty(s11))
            jsonobject.put("15", s11);
        String s12 = getResolution();
        if(!TextUtils.isEmpty(s12))
            jsonobject.put("16", s12);
        String s13 = getSsid();
        if(!TextUtils.isEmpty(s13))
            jsonobject.put("17", s13);
        String s14 = getDeviceName();
        if(!TextUtils.isEmpty(s14))
            jsonobject.put("18", s14);
        String s15 = getConnectType();
        if(!TextUtils.isEmpty(s15))
            jsonobject.put("19", s15);
        s16 = jsonobject.toString();
        String s = s16;
_L2:
        return s;
        JSONException jsonexception;
        jsonexception;
        s = "";
        if(true) goto _L2; else goto _L1
_L1:
    }

    private File getAidInfoFile(int i)
    {
        return new File(mContext.getFilesDir(), (new StringBuilder("weibo_sdk_aid")).append(i).toString());
    }

    private String getAndroidId()
    {
        String s1 = android.provider.Settings.Secure.getString(mContext.getContentResolver(), "android_id");
        String s = s1;
_L2:
        return s;
        Exception exception;
        exception;
        s = "";
        if(true) goto _L2; else goto _L1
_L1:
    }

    private String getConnectType()
    {
        String s = "none";
        NetworkInfo networkinfo = ((ConnectivityManager)mContext.getSystemService("connectivity")).getActiveNetworkInfo();
        if(networkinfo == null) goto _L2; else goto _L1
_L1:
        if(networkinfo.getType() != 0) goto _L4; else goto _L3
_L3:
        networkinfo.getSubtype();
        JVM INSTR tableswitch 1 15: default 131
    //                   1 137
    //                   2 137
    //                   3 144
    //                   4 137
    //                   5 144
    //                   6 144
    //                   7 137
    //                   8 144
    //                   9 144
    //                   10 144
    //                   11 137
    //                   12 144
    //                   13 151
    //                   14 144
    //                   15 144;
           goto _L5 _L6 _L6 _L7 _L6 _L7 _L7 _L6 _L7 _L7 _L7 _L6 _L7 _L8 _L7 _L7
_L4:
        if(networkinfo.getType() == 1)
            s = "wifi";
        break; /* Loop/switch isn't completed */
        Exception exception;
        exception;
        break; /* Loop/switch isn't completed */
_L5:
        s = "none";
_L2:
        return s;
_L6:
        s = "2G";
        continue; /* Loop/switch isn't completed */
_L7:
        s = "3G";
        continue; /* Loop/switch isn't completed */
_L8:
        s = "4G";
        if(true) goto _L2; else goto _L9
_L9:
    }

    private String getCpu()
    {
        String s;
        try
        {
            s = Build.CPU_ABI;
        }
        catch(Exception exception)
        {
            s = "";
        }
        return s;
    }

    private String getDeviceName()
    {
        String s;
        try
        {
            s = Build.BRAND;
        }
        catch(Exception exception)
        {
            s = "";
        }
        return s;
    }

    private String getIccid()
    {
        String s1 = ((TelephonyManager)mContext.getSystemService("phone")).getSimSerialNumber();
        String s = s1;
_L2:
        return s;
        Exception exception;
        exception;
        s = "";
        if(true) goto _L2; else goto _L1
_L1:
    }

    private String getImei()
    {
        String s1 = ((TelephonyManager)mContext.getSystemService("phone")).getDeviceId();
        String s = s1;
_L2:
        return s;
        Exception exception;
        exception;
        s = "";
        if(true) goto _L2; else goto _L1
_L1:
    }

    private String getImsi()
    {
        String s1 = ((TelephonyManager)mContext.getSystemService("phone")).getSubscriberId();
        String s = s1;
_L2:
        return s;
        Exception exception;
        exception;
        s = "";
        if(true) goto _L2; else goto _L1
_L1:
    }

    /**
     * @deprecated Method getInstance is deprecated
     */

    public static AidTask getInstance(Context context)
    {
        com/sina/weibo/sdk/utils/AidTask;
        JVM INSTR monitorenter ;
        AidTask aidtask;
        if(sInstance == null)
            sInstance = new AidTask(context);
        aidtask = sInstance;
        com/sina/weibo/sdk/utils/AidTask;
        JVM INSTR monitorexit ;
        return aidtask;
        Exception exception;
        exception;
        throw exception;
    }

    private String getMac()
    {
        WifiManager wifimanager = (WifiManager)mContext.getSystemService("wifi");
        String s;
        if(wifimanager == null)
            s = "";
        else
            try
            {
                WifiInfo wifiinfo = wifimanager.getConnectionInfo();
                if(wifiinfo != null)
                    s = wifiinfo.getMacAddress();
                else
                    s = "";
            }
            catch(Exception exception)
            {
                s = "";
            }
        return s;
    }

    private String getMeid()
    {
        String s1 = ((TelephonyManager)mContext.getSystemService("phone")).getDeviceId();
        String s = s1;
_L2:
        return s;
        Exception exception;
        exception;
        s = "";
        if(true) goto _L2; else goto _L1
_L1:
    }

    private String getMfp()
    {
        String s;
        String s1;
        s = genMfpString();
        s1 = "";
        String s2 = new String(s.getBytes(), "UTF-8");
        s1 = s2;
_L2:
        LogUtil.d("AidTask", (new StringBuilder("genMfpString() utf-8 string : ")).append(s1).toString());
        String s3;
        try
        {
            s3 = encryptRsa(s1, "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDHHM0Fi2Z6+QYKXqFUX2Cy6AaWq3cPi+GSn9oeAwQbPZR75JB7Netm0HtBVVbtPhzT7UO2p1JhFUKWqrqoYuAjkgMVPmA0sFrQohns5EE44Y86XQopD4ZO+dE5KjUZFE6vrPO3rWW3np2BqlgKpjnYZri6TJApmIpGcQg9/G/3zQIDAQAB");
            LogUtil.d("AidTask", (new StringBuilder("encryptRsa() string : ")).append(s3).toString());
        }
        catch(Exception exception)
        {
            LogUtil.e("AidTask", exception.getMessage());
            s3 = "";
        }
        return s3;
        UnsupportedEncodingException unsupportedencodingexception;
        unsupportedencodingexception;
        if(true) goto _L2; else goto _L1
_L1:
    }

    private String getModel()
    {
        String s;
        try
        {
            s = Build.MODEL;
        }
        catch(Exception exception)
        {
            s = "";
        }
        return s;
    }

    private String getOS()
    {
        String s1 = (new StringBuilder("Android ")).append(android.os.Build.VERSION.RELEASE).toString();
        String s = s1;
_L2:
        return s;
        Exception exception;
        exception;
        s = "";
        if(true) goto _L2; else goto _L1
_L1:
    }

    private PublicKey getPublicKey(String s)
        throws Exception
    {
        X509EncodedKeySpec x509encodedkeyspec = new X509EncodedKeySpec(Base64.decode(s.getBytes()));
        return KeyFactory.getInstance("RSA").generatePublic(x509encodedkeyspec);
    }

    private String getResolution()
    {
        String s1;
        DisplayMetrics displaymetrics = new DisplayMetrics();
        ((WindowManager)mContext.getSystemService("window")).getDefaultDisplay().getMetrics(displaymetrics);
        s1 = (new StringBuilder(String.valueOf(String.valueOf(displaymetrics.widthPixels)))).append("*").append(String.valueOf(displaymetrics.heightPixels)).toString();
        String s = s1;
_L2:
        return s;
        Exception exception;
        exception;
        s = "";
        if(true) goto _L2; else goto _L1
_L1:
    }

    private String getSdSize()
    {
        String s1;
        StatFs statfs = new StatFs(Environment.getExternalStorageDirectory().getPath());
        s1 = Long.toString((long)statfs.getBlockSize() * (long)statfs.getBlockCount());
        String s = s1;
_L2:
        return s;
        Exception exception;
        exception;
        s = "";
        if(true) goto _L2; else goto _L1
_L1:
    }

    private String getSerialNo()
    {
        String s = "";
        try
        {
            Class class1 = Class.forName("android.os.SystemProperties");
            Class aclass[] = new Class[2];
            aclass[0] = java/lang/String;
            aclass[1] = java/lang/String;
            Method method = class1.getMethod("get", aclass);
            Object aobj[] = new Object[2];
            aobj[0] = "ro.serialno";
            aobj[1] = "unknown";
            s = (String)method.invoke(class1, aobj);
        }
        catch(Exception exception) { }
        return s;
    }

    private String getSsid()
    {
        WifiInfo wifiinfo = ((WifiManager)mContext.getSystemService("wifi")).getConnectionInfo();
        if(wifiinfo == null) goto _L2; else goto _L1
_L1:
        String s1 = wifiinfo.getSSID();
        String s = s1;
_L4:
        return s;
        Exception exception;
        exception;
_L2:
        s = "";
        if(true) goto _L4; else goto _L3
_L3:
    }

    private String loadAidFromNet()
        throws WeiboException
    {
        String s = mContext.getPackageName();
        String s1 = Utility.getSign(mContext, s);
        String s2 = getMfp();
        WeiboParameters weiboparameters = new WeiboParameters(mAppKey);
        weiboparameters.put("appkey", mAppKey);
        weiboparameters.put("mfp", s2);
        weiboparameters.put("packagename", s);
        weiboparameters.put("key_hash", s1);
        String s3;
        try
        {
            s3 = (new AsyncWeiboRunner(mContext)).request("http://api.weibo.com/oauth2/getaid.json", weiboparameters, "GET");
            LogUtil.d("AidTask", (new StringBuilder("loadAidFromNet response : ")).append(s3).toString());
        }
        catch(WeiboException weiboexception)
        {
            LogUtil.d("AidTask", (new StringBuilder("loadAidFromNet WeiboException Msg : ")).append(weiboexception.getMessage()).toString());
            throw weiboexception;
        }
        return s3;
    }

    /**
     * @deprecated Method loadAidInfoFromCache is deprecated
     */

    private AidInfo loadAidInfoFromCache()
    {
        this;
        JVM INSTR monitorenter ;
        FileInputStream fileinputstream = null;
        FileInputStream fileinputstream1 = new FileInputStream(getAidInfoFile(1));
        AidInfo aidinfo1;
        byte abyte0[] = new byte[fileinputstream1.available()];
        fileinputstream1.read(abyte0);
        aidinfo1 = AidInfo.parseJson(new String(abyte0));
        AidInfo aidinfo;
        aidinfo = aidinfo1;
        if(fileinputstream1 == null)
            break MISSING_BLOCK_LABEL_58;
        Exception exception1;
        Exception exception2;
        Exception exception3;
        try
        {
            fileinputstream1.close();
        }
        catch(IOException ioexception2) { }
        this;
        JVM INSTR monitorexit ;
        return aidinfo;
        exception3;
_L2:
        if(fileinputstream == null)
            break MISSING_BLOCK_LABEL_73;
        try
        {
            fileinputstream.close();
        }
        catch(IOException ioexception) { }
        aidinfo = null;
        break MISSING_BLOCK_LABEL_58;
        exception2;
_L1:
        if(fileinputstream == null)
            break MISSING_BLOCK_LABEL_89;
        try
        {
            fileinputstream.close();
        }
        catch(IOException ioexception1) { }
        throw exception2;
        exception1;
_L3:
        this;
        JVM INSTR monitorexit ;
        throw exception1;
        exception2;
        fileinputstream = fileinputstream1;
          goto _L1
        Exception exception;
        exception;
        fileinputstream = fileinputstream1;
          goto _L2
        exception1;
          goto _L3
    }

    private int splite(byte abyte0[], int i, int j)
    {
        int k;
        if(i >= abyte0.length)
            k = -1;
        else
            k = Math.min(abyte0.length - i, j);
        return k;
    }

    public void aidTaskInit()
    {
        aidTaskInit(mAppKey);
    }

    public void aidTaskInit(String s)
    {
        if(!TextUtils.isEmpty(s))
        {
            mAppKey = s;
            (new Thread(new Runnable() {

                final AidTask this$0;

                public void run()
                {
                    if(mTaskLock.tryLock())
                    {
label0:
                        {
                            if(TextUtils.isEmpty(loadAidFromCache()))
                                break label0;
                            mTaskLock.unlock();
                        }
                    }
_L1:
                    return;
                    int i = 0;
_L3:
                    if(i < 3)
                        break MISSING_BLOCK_LABEL_60;
_L2:
                    mTaskLock.unlock();
                      goto _L1
                    String s1 = loadAidFromNet();
                    AidInfo.parseJson(s1);
                    cacheAidInfo(s1);
                      goto _L2
                    WeiboException weiboexception;
                    weiboexception;
                    LogUtil.e("AidTask", (new StringBuilder("AidTaskInit WeiboException Msg : ")).append(weiboexception.getMessage()).toString());
                    i++;
                      goto _L3
                }

            
            {
                this$0 = AidTask.this;
                super();
            }
            }
)).start();
        }
    }

    public void getAidAsync(Handler handler)
    {
        if(!TextUtils.isEmpty(mAppKey))
            (new Thread(new Runnable() {

                final AidTask this$0;
                private final Handler val$h;
                private final Message val$msg;

                public void run()
                {
                    String s = loadAidFromNet();
                    AidInfo aidinfo = AidInfo.parseJson(s);
                    cacheAidInfo(s);
                    msg.what = 1001;
                    msg.obj = aidinfo;
                    if(h != null)
                        h.sendMessage(msg);
_L1:
                    return;
                    WeiboException weiboexception;
                    weiboexception;
                    if((weiboexception.getCause() instanceof IOException) || (weiboexception instanceof WeiboHttpException))
                    {
                        msg.what = 1003;
                        if(h != null)
                            h.sendMessage(msg);
                    } else
                    {
                        msg.what = 1002;
                        if(h != null)
                            h.sendMessage(msg);
                    }
                      goto _L1
                }

            
            {
                this$0 = AidTask.this;
                msg = message;
                h = handler;
                super();
            }
            }
)).start();
    }

    public AidInfo getAidSync()
        throws WeiboException
    {
        AidInfo aidinfo;
        if(TextUtils.isEmpty(mAppKey))
        {
            aidinfo = null;
        } else
        {
            String s = loadAidFromNet();
            aidinfo = AidInfo.parseJson(s);
            cacheAidInfo(s);
        }
        return aidinfo;
    }

    public ReentrantLock getTaskLock()
    {
        return mTaskLock;
    }

    /**
     * @deprecated Method loadAidFromCache is deprecated
     */

    public String loadAidFromCache()
    {
        this;
        JVM INSTR monitorenter ;
        AidInfo aidinfo = loadAidInfoFromCache();
        if(aidinfo == null) goto _L2; else goto _L1
_L1:
        String s1 = aidinfo.getAid();
        String s = s1;
_L4:
        this;
        JVM INSTR monitorexit ;
        return s;
_L2:
        s = "";
        if(true) goto _L4; else goto _L3
_L3:
        Exception exception;
        exception;
        throw exception;
    }

    /**
     * @deprecated Method loadSubCookieFromCache is deprecated
     */

    public String loadSubCookieFromCache()
    {
        this;
        JVM INSTR monitorenter ;
        AidInfo aidinfo = loadAidInfoFromCache();
        if(aidinfo == null) goto _L2; else goto _L1
_L1:
        String s1 = aidinfo.getSubCookie();
        String s = s1;
_L4:
        this;
        JVM INSTR monitorexit ;
        return s;
_L2:
        s = "";
        if(true) goto _L4; else goto _L3
_L3:
        Exception exception;
        exception;
        throw exception;
    }

    public void setAppkey(String s)
    {
        mAppKey = s;
    }




}
