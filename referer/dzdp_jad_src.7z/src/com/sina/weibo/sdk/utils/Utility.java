// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.sina.weibo.sdk.utils;

import android.content.Context;
import android.content.pm.*;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import java.io.UnsupportedEncodingException;
import java.net.*;
import java.util.Locale;
import java.util.UUID;

// Referenced classes of package com.sina.weibo.sdk.utils:
//            AidTask, MD5

public class Utility
{

    private static final String DEFAULT_CHARSET = "UTF-8";

    public Utility()
    {
    }

    public static Bundle decodeUrl(String s)
    {
        int i;
        Bundle bundle;
        i = 0;
        bundle = new Bundle();
        if(s == null) goto _L2; else goto _L1
_L1:
        String as[];
        int j;
        as = s.split("&");
        j = as.length;
_L5:
        if(i < j) goto _L3; else goto _L2
_L2:
        return bundle;
_L3:
        String as1[] = as[i].split("=");
        try
        {
            bundle.putString(URLDecoder.decode(as1[0], "UTF-8"), URLDecoder.decode(as1[1], "UTF-8"));
        }
        catch(UnsupportedEncodingException unsupportedencodingexception)
        {
            unsupportedencodingexception.printStackTrace();
        }
        i++;
        if(true) goto _L5; else goto _L4
_L4:
    }

    public static String generateGUID()
    {
        return UUID.randomUUID().toString().replace("-", "");
    }

    public static String generateUA(Context context)
    {
        StringBuilder stringbuilder = new StringBuilder();
        stringbuilder.append(Build.MANUFACTURER).append("-").append(Build.MODEL);
        stringbuilder.append("_");
        stringbuilder.append(android.os.Build.VERSION.RELEASE);
        stringbuilder.append("_");
        stringbuilder.append("weibosdk");
        stringbuilder.append("_");
        stringbuilder.append("0030105000");
        stringbuilder.append("_android");
        return stringbuilder.toString();
    }

    public static String getAid(Context context, String s)
    {
        AidTask aidtask = AidTask.getInstance(context);
        String s1 = aidtask.loadAidFromCache();
        if(TextUtils.isEmpty(s1))
        {
            aidtask.aidTaskInit(s);
            s1 = "";
        }
        return s1;
    }

    public static String getSign(Context context, String s)
    {
        String s1;
        PackageInfo packageinfo;
        int i;
        s1 = null;
        try
        {
            packageinfo = context.getPackageManager().getPackageInfo(s, 64);
        }
        catch(android.content.pm.PackageManager.NameNotFoundException namenotfoundexception)
        {
            continue; /* Loop/switch isn't completed */
        }
        i = 0;
_L5:
        if(i < packageinfo.signatures.length) goto _L2; else goto _L1
_L1:
        return s1;
_L2:
        byte abyte0[] = packageinfo.signatures[i].toByteArray();
        if(abyte0 == null)
            break; /* Loop/switch isn't completed */
        s1 = MD5.hexdigest(abyte0);
        if(true) goto _L1; else goto _L3
_L3:
        i++;
        if(true) goto _L5; else goto _L4
_L4:
    }

    public static boolean isChineseLocale(Context context)
    {
label0:
        {
            boolean flag = true;
            boolean flag1;
            try
            {
                Locale locale = context.getResources().getConfiguration().locale;
                if(Locale.CHINA.equals(locale) || Locale.CHINESE.equals(locale) || Locale.SIMPLIFIED_CHINESE.equals(locale))
                    break label0;
                flag1 = Locale.TAIWAN.equals(locale);
            }
            catch(Exception exception)
            {
                break label0;
            }
            if(!flag1)
                flag = false;
        }
        return flag;
    }

    public static Bundle parseUri(String s)
    {
        Bundle bundle1 = decodeUrl((new URI(s)).getQuery());
        Bundle bundle = bundle1;
_L2:
        return bundle;
        Exception exception;
        exception;
        bundle = new Bundle();
        if(true) goto _L2; else goto _L1
_L1:
    }

    public static Bundle parseUrl(String s)
    {
        Bundle bundle;
        try
        {
            URL url = new URL(s);
            bundle = decodeUrl(url.getQuery());
            bundle.putAll(decodeUrl(url.getRef()));
        }
        catch(MalformedURLException malformedurlexception)
        {
            bundle = new Bundle();
        }
        return bundle;
    }

    public static String safeString(String s)
    {
        if(TextUtils.isEmpty(s))
            s = "";
        return s;
    }
}
