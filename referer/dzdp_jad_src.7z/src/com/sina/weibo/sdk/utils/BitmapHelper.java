// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.sina.weibo.sdk.utils;

import android.graphics.BitmapFactory;
import android.graphics.Rect;
import java.io.*;

public final class BitmapHelper
{

    public BitmapHelper()
    {
    }

    public static int getSampleSizeAutoFitToScreen(int i, int j, int k, int l)
    {
        int i1;
        if(j == 0 || i == 0)
            i1 = 1;
        else
            i1 = Math.min(Math.max(k / i, l / j), Math.max(l / i, k / j));
        return i1;
    }

    public static int getSampleSizeOfNotTooLarge(Rect rect)
    {
        double d = (2D * ((double)rect.width() * (double)rect.height())) / 5242880D;
        int i;
        if(d >= 1.0D)
            i = (int)d;
        else
            i = 1;
        return i;
    }

    public static boolean makesureSizeNotTooLarge(Rect rect)
    {
        boolean flag;
        if(2 * (rect.width() * rect.height()) > 0x500000)
            flag = false;
        else
            flag = true;
        return flag;
    }

    public static boolean verifyBitmap(InputStream inputstream)
    {
        boolean flag;
        if(inputstream == null)
        {
            flag = false;
        } else
        {
            android.graphics.BitmapFactory.Options options = new android.graphics.BitmapFactory.Options();
            options.inJustDecodeBounds = true;
            if(!(inputstream instanceof BufferedInputStream))
                inputstream = new BufferedInputStream(inputstream);
            BitmapFactory.decodeStream(inputstream, null, options);
            try
            {
                inputstream.close();
            }
            catch(IOException ioexception)
            {
                ioexception.printStackTrace();
            }
            if(options.outHeight > 0 && options.outWidth > 0)
                flag = true;
            else
                flag = false;
        }
        return flag;
    }

    public static boolean verifyBitmap(String s)
    {
        boolean flag1 = verifyBitmap(((InputStream) (new FileInputStream(s))));
        boolean flag = flag1;
_L2:
        return flag;
        FileNotFoundException filenotfoundexception;
        filenotfoundexception;
        filenotfoundexception.printStackTrace();
        flag = false;
        if(true) goto _L2; else goto _L1
_L1:
    }

    public static boolean verifyBitmap(byte abyte0[])
    {
        return verifyBitmap(((InputStream) (new ByteArrayInputStream(abyte0))));
    }
}
