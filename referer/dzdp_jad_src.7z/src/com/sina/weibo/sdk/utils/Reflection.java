// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.sina.weibo.sdk.utils;

import java.lang.reflect.*;

public class Reflection
{

    public Reflection()
    {
    }

    public static Object getByArray(Object obj, int i)
    {
        return Array.get(obj, i);
    }

    public static Object getProperty(Object obj, String s)
        throws Exception
    {
        return obj.getClass().getField(s).get(obj);
    }

    public static Object getStaticProperty(String s, String s1)
        throws Exception
    {
        Class class1 = Class.forName(s);
        return class1.getField(s1).get(class1);
    }

    public static Object invokeMethod(Object obj, String s, Class aclass[], Object aobj[])
    {
        Object obj2 = obj.getClass().getMethod(s, aclass).invoke(obj, aobj);
        Object obj1 = obj2;
_L2:
        return obj1;
        SecurityException securityexception;
        securityexception;
        securityexception.printStackTrace();
_L3:
        obj1 = null;
        if(true) goto _L2; else goto _L1
_L1:
        NoSuchMethodException nosuchmethodexception;
        nosuchmethodexception;
        nosuchmethodexception.printStackTrace();
          goto _L3
        IllegalArgumentException illegalargumentexception;
        illegalargumentexception;
        illegalargumentexception.printStackTrace();
          goto _L3
        IllegalAccessException illegalaccessexception;
        illegalaccessexception;
        illegalaccessexception.printStackTrace();
          goto _L3
        InvocationTargetException invocationtargetexception;
        invocationtargetexception;
        invocationtargetexception.printStackTrace();
          goto _L3
    }

    public static Object invokeMethod(Object obj, String s, Object aobj[])
        throws Exception
    {
        Class class1 = obj.getClass();
        Class aclass[] = new Class[aobj.length];
        int i = 0;
        int j = aobj.length;
        do
        {
            if(i >= j)
                return class1.getMethod(s, aclass).invoke(obj, aobj);
            aclass[i] = aobj[i].getClass();
            i++;
        } while(true);
    }

    public static Object invokeParamsMethod(Object obj, String s, Class aclass[], Object aobj[])
        throws SecurityException, NoSuchMethodException, IllegalArgumentException, IllegalAccessException, InvocationTargetException
    {
        Method method = obj.getClass().getMethod(s, aclass);
        method.setAccessible(true);
        return method.invoke(obj, aobj);
    }

    public static Object invokeStaticMethod(Class class1, String s, Class aclass[], Object aobj[])
    {
        Object obj = null;
        Object obj1 = class1.getMethod(s, aclass).invoke(null, aobj);
        obj = obj1;
_L2:
        return obj;
        SecurityException securityexception;
        securityexception;
        securityexception.printStackTrace();
        continue; /* Loop/switch isn't completed */
        NoSuchMethodException nosuchmethodexception;
        nosuchmethodexception;
        nosuchmethodexception.printStackTrace();
        continue; /* Loop/switch isn't completed */
        IllegalArgumentException illegalargumentexception;
        illegalargumentexception;
        illegalargumentexception.printStackTrace();
        continue; /* Loop/switch isn't completed */
        IllegalAccessException illegalaccessexception;
        illegalaccessexception;
        illegalaccessexception.printStackTrace();
        continue; /* Loop/switch isn't completed */
        InvocationTargetException invocationtargetexception;
        invocationtargetexception;
        invocationtargetexception.printStackTrace();
        if(true) goto _L2; else goto _L1
_L1:
    }

    public static Object invokeStaticMethod(String s, String s1, Class aclass[], Object aobj[])
    {
        Object obj = null;
        Object obj1 = Class.forName(s).getMethod(s1, aclass).invoke(null, aobj);
        obj = obj1;
_L2:
        return obj;
        ClassNotFoundException classnotfoundexception;
        classnotfoundexception;
        classnotfoundexception.printStackTrace();
        continue; /* Loop/switch isn't completed */
        SecurityException securityexception;
        securityexception;
        securityexception.printStackTrace();
        continue; /* Loop/switch isn't completed */
        NoSuchMethodException nosuchmethodexception;
        nosuchmethodexception;
        nosuchmethodexception.printStackTrace();
        continue; /* Loop/switch isn't completed */
        IllegalArgumentException illegalargumentexception;
        illegalargumentexception;
        illegalargumentexception.printStackTrace();
        continue; /* Loop/switch isn't completed */
        IllegalAccessException illegalaccessexception;
        illegalaccessexception;
        illegalaccessexception.printStackTrace();
        continue; /* Loop/switch isn't completed */
        InvocationTargetException invocationtargetexception;
        invocationtargetexception;
        invocationtargetexception.printStackTrace();
        if(true) goto _L2; else goto _L1
_L1:
    }

    public static Object invokeStaticMethod(String s, String s1, Object aobj[])
        throws Exception
    {
        Class class1 = Class.forName(s);
        Class aclass[] = new Class[aobj.length];
        int i = 0;
        int j = aobj.length;
        do
        {
            if(i >= j)
                return class1.getMethod(s1, aclass).invoke(null, aobj);
            aclass[i] = aobj[i].getClass();
            i++;
        } while(true);
    }

    public static void invokeVoidMethod(Object obj, String s, boolean flag)
    {
        Class class1 = obj.getClass();
        Class aclass[] = new Class[1];
        aclass[0] = Boolean.TYPE;
        Method method = class1.getMethod(s, aclass);
        Object aobj[] = new Object[1];
        aobj[0] = Boolean.valueOf(flag);
        method.invoke(obj, aobj);
_L2:
        return;
        InvocationTargetException invocationtargetexception;
        invocationtargetexception;
        continue; /* Loop/switch isn't completed */
        IllegalAccessException illegalaccessexception;
        illegalaccessexception;
        continue; /* Loop/switch isn't completed */
        IllegalArgumentException illegalargumentexception;
        illegalargumentexception;
        continue; /* Loop/switch isn't completed */
        NoSuchMethodException nosuchmethodexception;
        nosuchmethodexception;
        continue; /* Loop/switch isn't completed */
        SecurityException securityexception;
        securityexception;
        if(true) goto _L2; else goto _L1
_L1:
    }

    public static boolean isInstance(Object obj, Class class1)
    {
        return class1.isInstance(obj);
    }

    public static Object newInstance(String s, Class aclass[], Object aobj[])
        throws Exception
    {
        return Class.forName(s).getConstructor(aclass).newInstance(aobj);
    }
}
