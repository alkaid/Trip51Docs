// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.sina.weibo.sdk.utils;

import android.content.Context;
import android.content.Intent;
import android.content.pm.*;
import com.sina.weibo.sdk.ApiUtils;

// Referenced classes of package com.sina.weibo.sdk.utils:
//            MD5

public class SecurityHelper
{

    public SecurityHelper()
    {
    }

    public static boolean checkResponseAppLegal(Context context, com.sina.weibo.sdk.WeiboAppManager.WeiboInfo weiboinfo, Intent intent)
    {
        boolean flag;
        flag = true;
        break MISSING_BLOCK_LABEL_2;
        while(true) 
        {
            do
                return flag;
            while(weiboinfo != null && weiboinfo.getSupportApi() <= 10352 || weiboinfo == null);
            String s;
            if(intent != null)
                s = intent.getStringExtra("_weibo_appPackage");
            else
                s = null;
            if(s == null || intent.getStringExtra("_weibo_transaction") == null || !ApiUtils.validateWeiboSign(context, s))
                flag = false;
        }
    }

    public static boolean containSign(Signature asignature[], String s)
    {
        boolean flag = false;
        if(asignature != null && s != null) goto _L2; else goto _L1
_L1:
        return flag;
_L2:
        int i = asignature.length;
        int j = 0;
        do
        {
            if(j < i)
            {
label0:
                {
                    if(!s.equals(MD5.hexdigest(asignature[j].toByteArray())))
                        break label0;
                    flag = true;
                }
            }
            if(true)
                continue;
            j++;
        } while(true);
        if(true) goto _L1; else goto _L3
_L3:
    }

    public static boolean validateAppSignatureForIntent(Context context, Intent intent)
    {
        boolean flag;
        PackageManager packagemanager;
        flag = false;
        packagemanager = context.getPackageManager();
        if(packagemanager != null) goto _L2; else goto _L1
_L1:
        return flag;
_L2:
        String s;
        ResolveInfo resolveinfo = packagemanager.resolveActivity(intent, 0);
        if(resolveinfo == null)
            continue; /* Loop/switch isn't completed */
        s = resolveinfo.activityInfo.packageName;
        boolean flag1 = containSign(packagemanager.getPackageInfo(s, 64).signatures, "18da2bf10352443a00a5e046d9fca6bd");
        flag = flag1;
        continue; /* Loop/switch isn't completed */
        android.content.pm.PackageManager.NameNotFoundException namenotfoundexception;
        namenotfoundexception;
        namenotfoundexception.printStackTrace();
        continue; /* Loop/switch isn't completed */
        Exception exception;
        exception;
        exception.printStackTrace();
        if(true) goto _L1; else goto _L3
_L3:
    }
}
