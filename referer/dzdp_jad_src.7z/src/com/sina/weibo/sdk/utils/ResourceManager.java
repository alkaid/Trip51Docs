// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.sina.weibo.sdk.utils;

import android.content.Context;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.text.TextUtils;
import android.util.*;
import android.view.*;
import java.io.IOException;
import java.io.InputStream;
import java.util.Locale;

// Referenced classes of package com.sina.weibo.sdk.utils:
//            LogUtil

public class ResourceManager
{

    private static final String DRAWABLE = "drawable";
    private static final String DRAWABLE_HDPI = "drawable-hdpi";
    private static final String DRAWABLE_LDPI = "drawable-ldpi";
    private static final String DRAWABLE_MDPI = "drawable-mdpi";
    private static final String DRAWABLE_XHDPI = "drawable-xhdpi";
    private static final String DRAWABLE_XXHDPI = "drawable-xxhdpi";
    private static final String PRE_INSTALL_DRAWBLE_PATHS[];
    private static final String TAG = com/sina/weibo/sdk/utils/ResourceManager.getName();

    public ResourceManager()
    {
    }

    public static ColorStateList createColorStateList(int i, int j)
    {
        int ai[] = new int[4];
        ai[0] = j;
        ai[1] = j;
        ai[2] = j;
        ai[3] = i;
        int ai1[][] = new int[4][];
        int ai2[] = new int[1];
        ai2[0] = 0x10100a7;
        ai1[0] = ai2;
        int ai3[] = new int[1];
        ai3[0] = 0x10100a1;
        ai1[1] = ai3;
        int ai4[] = new int[1];
        ai4[0] = 0x101009c;
        ai1[2] = ai4;
        ai1[3] = StateSet.WILD_CARD;
        return new ColorStateList(ai1, ai);
    }

    public static StateListDrawable createStateListDrawable(Context context, String s, String s1)
    {
        Drawable drawable;
        Drawable drawable1;
        StateListDrawable statelistdrawable;
        int ai[];
        int ai1[];
        int ai2[];
        if(s.indexOf(".9") > -1)
            drawable = getNinePatchDrawable(context, s);
        else
            drawable = getDrawable(context, s);
        if(s1.indexOf(".9") > -1)
            drawable1 = getNinePatchDrawable(context, s1);
        else
            drawable1 = getDrawable(context, s1);
        statelistdrawable = new StateListDrawable();
        ai = new int[1];
        ai[0] = 0x10100a7;
        statelistdrawable.addState(ai, drawable1);
        ai1 = new int[1];
        ai1[0] = 0x10100a1;
        statelistdrawable.addState(ai1, drawable1);
        ai2 = new int[1];
        ai2[0] = 0x101009c;
        statelistdrawable.addState(ai2, drawable1);
        statelistdrawable.addState(StateSet.WILD_CARD, drawable);
        return statelistdrawable;
    }

    public static int dp2px(Context context, int i)
    {
        DisplayMetrics displaymetrics = context.getResources().getDisplayMetrics();
        return (int)(0.5D + (double)((float)i * displaymetrics.density));
    }

    private static Drawable extractDrawable(Context context, String s)
        throws Exception
    {
        InputStream inputstream = context.getAssets().open(s);
        DisplayMetrics displaymetrics = context.getResources().getDisplayMetrics();
        TypedValue typedvalue = new TypedValue();
        typedvalue.density = displaymetrics.densityDpi;
        Drawable drawable = Drawable.createFromResourceStream(context.getResources(), typedvalue, inputstream, s);
        inputstream.close();
        return drawable;
    }

    private static View extractView(Context context, String s, ViewGroup viewgroup)
        throws Exception
    {
        android.content.res.XmlResourceParser xmlresourceparser = context.getAssets().openXmlResourceParser(s);
        return ((LayoutInflater)context.getSystemService("layout_inflater")).inflate(xmlresourceparser, viewgroup);
    }

    private static String getAppropriatePathOfDrawable(Context context, String s)
    {
        if(!TextUtils.isEmpty(s)) goto _L2; else goto _L1
_L1:
        String s2;
        LogUtil.e(TAG, "id is NOT correct!");
        s2 = null;
_L5:
        return s2;
_L2:
        String s1;
        int i;
        int j;
        int k;
        int l;
        s1 = getCurrentDpiFolder(context);
        LogUtil.d(TAG, "find Appropriate path...");
        i = -1;
        j = -1;
        k = -1;
        l = 0;
_L7:
        if(l < PRE_INSTALL_DRAWBLE_PATHS.length) goto _L4; else goto _L3
_L3:
        int i1;
        if(i > 0 && k > 0)
        {
            if(Math.abs(j - k) <= Math.abs(j - i))
                i1 = k;
            else
                i1 = i;
        } else
        if(i > 0 && k < 0)
            i1 = i;
        else
        if(i < 0 && k > 0)
        {
            i1 = k;
        } else
        {
            i1 = -1;
            LogUtil.e(TAG, "Not find the appropriate path for drawable");
        }
        if(i1 < 0)
        {
            LogUtil.e(TAG, "Not find the appropriate path for drawable");
            s2 = null;
        } else
        {
            s2 = (new StringBuilder(String.valueOf(PRE_INSTALL_DRAWBLE_PATHS[i1]))).append("/").append(s).toString();
        }
          goto _L5
_L4:
        if(PRE_INSTALL_DRAWBLE_PATHS[l].equals(s1))
            j = l;
        s2 = (new StringBuilder(String.valueOf(PRE_INSTALL_DRAWBLE_PATHS[l]))).append("/").append(s).toString();
        if(!isFileExisted(context, s2))
            break MISSING_BLOCK_LABEL_178;
        if(j == l) goto _L5; else goto _L6
_L6:
        if(j >= 0)
            break MISSING_BLOCK_LABEL_184;
        i = l;
        l++;
          goto _L7
        k = l;
          goto _L3
    }

    private static String getCurrentDpiFolder(Context context)
    {
        int i = context.getResources().getDisplayMetrics().densityDpi;
        String s;
        if(i <= 120)
            s = "drawable-ldpi";
        else
        if(i > 120 && i <= 160)
            s = "drawable-mdpi";
        else
        if(i > 160 && i <= 240)
            s = "drawable-hdpi";
        else
        if(i > 240 && i <= 320)
            s = "drawable-xhdpi";
        else
            s = "drawable-xxhdpi";
        return s;
    }

    public static Drawable getDrawable(Context context, String s)
    {
        return getDrawableFromAssert(context, getAppropriatePathOfDrawable(context, s), false);
    }

    private static Drawable getDrawableFromAssert(Context context, String s, boolean flag)
    {
        AssetManager assetmanager;
        InputStream inputstream;
        assetmanager = context.getAssets();
        inputstream = null;
        inputstream = assetmanager.open(s);
        if(inputstream == null) goto _L2; else goto _L1
_L1:
        Bitmap bitmap;
        DisplayMetrics displaymetrics;
        bitmap = BitmapFactory.decodeStream(inputstream);
        displaymetrics = context.getResources().getDisplayMetrics();
        if(!flag) goto _L4; else goto _L3
_L3:
        Object obj;
        android.content.res.Configuration configuration = context.getResources().getConfiguration();
        obj = new NinePatchDrawable(new Resources(context.getAssets(), displaymetrics, configuration), bitmap, bitmap.getNinePatchChunk(), new Rect(0, 0, 0, 0), null);
_L8:
        Exception exception;
        IOException ioexception1;
        if(inputstream != null)
            try
            {
                inputstream.close();
            }
            catch(IOException ioexception3)
            {
                ioexception3.printStackTrace();
            }
_L6:
        return ((Drawable) (obj));
_L4:
        bitmap.setDensity(displaymetrics.densityDpi);
        obj = new BitmapDrawable(context.getResources(), bitmap);
        continue; /* Loop/switch isn't completed */
        ioexception1;
        ioexception1.printStackTrace();
        if(inputstream != null)
        {
            try
            {
                inputstream.close();
            }
            catch(IOException ioexception2)
            {
                ioexception2.printStackTrace();
            }
            obj = null;
        } else
        {
            obj = null;
        }
        if(true) goto _L6; else goto _L5
_L5:
        exception;
        if(inputstream != null)
            try
            {
                inputstream.close();
            }
            catch(IOException ioexception)
            {
                ioexception.printStackTrace();
            }
        throw exception;
_L2:
        obj = null;
        if(true) goto _L8; else goto _L7
_L7:
    }

    public static Locale getLanguage()
    {
        Locale locale = Locale.getDefault();
        if(!Locale.SIMPLIFIED_CHINESE.equals(locale) && !Locale.TRADITIONAL_CHINESE.equals(locale))
            locale = Locale.ENGLISH;
        return locale;
    }

    public static Drawable getNinePatchDrawable(Context context, String s)
    {
        return getDrawableFromAssert(context, getAppropriatePathOfDrawable(context, s), true);
    }

    public static String getString(Context context, String s, String s1, String s2)
    {
        Locale locale = getLanguage();
        if(!Locale.SIMPLIFIED_CHINESE.equals(locale))
            if(Locale.TRADITIONAL_CHINESE.equals(locale))
                s1 = s2;
            else
                s1 = s;
        return s1;
    }

    private static boolean isFileExisted(Context context, String s)
    {
        boolean flag = false;
        if(context != null && !TextUtils.isEmpty(s)) goto _L2; else goto _L1
_L1:
        return flag;
_L2:
        AssetManager assetmanager;
        InputStream inputstream;
        assetmanager = context.getAssets();
        inputstream = null;
        inputstream = assetmanager.open(s);
        LogUtil.d(TAG, (new StringBuilder("file [")).append(s).append("] existed").toString());
        if(inputstream != null)
            try
            {
                inputstream.close();
            }
            catch(IOException ioexception3)
            {
                ioexception3.printStackTrace();
            }
        flag = true;
        continue; /* Loop/switch isn't completed */
        IOException ioexception1;
        ioexception1;
        LogUtil.d(TAG, (new StringBuilder("file [")).append(s).append("] NOT existed").toString());
        if(inputstream != null)
            try
            {
                inputstream.close();
            }
            catch(IOException ioexception2)
            {
                ioexception2.printStackTrace();
            }
        if(true) goto _L1; else goto _L3
_L3:
        Exception exception;
        exception;
        if(inputstream != null)
            try
            {
                inputstream.close();
            }
            catch(IOException ioexception)
            {
                ioexception.printStackTrace();
            }
        throw exception;
    }

    static 
    {
        String as[] = new String[6];
        as[0] = "drawable-xxhdpi";
        as[1] = "drawable-xhdpi";
        as[2] = "drawable-hdpi";
        as[3] = "drawable-mdpi";
        as[4] = "drawable-ldpi";
        as[5] = "drawable";
        PRE_INSTALL_DRAWBLE_PATHS = as;
    }
}
