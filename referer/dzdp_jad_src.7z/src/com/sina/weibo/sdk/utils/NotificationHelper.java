// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.sina.weibo.sdk.utils;

import android.app.*;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.text.TextUtils;
import java.io.File;

// Referenced classes of package com.sina.weibo.sdk.utils:
//            ResourceManager

public class NotificationHelper
{

    private static final int NOTIFICATION_ID = 1;
    private static final String WEIBO = "Weibo";
    private static final String WEIBO_ZH_CN = "\u5FAE\u535A";
    private static final String WEIBO_ZH_TW = "\u5FAE\u535A";

    public NotificationHelper()
    {
    }

    private static PendingIntent buildInstallApkIntent(Context context, String s)
    {
        PendingIntent pendingintent;
        if(!TextUtils.isEmpty(s))
        {
            Intent intent = new Intent("android.intent.action.VIEW");
            intent.setDataAndType(Uri.fromFile(new File(s)), "application/vnd.android.package-archive");
            pendingintent = PendingIntent.getActivity(context, 0, intent, 16);
        } else
        {
            pendingintent = PendingIntent.getActivity(context, 0, new Intent(), 16);
        }
        return pendingintent;
    }

    private static Notification buildNotification(Context context, String s, String s1)
    {
        String s2 = ResourceManager.getString(context, "Weibo", "\u5FAE\u535A", "\u5FAE\u535A");
        android.support.v4.app.NotificationCompat.Builder builder = new android.support.v4.app.NotificationCompat.Builder(context);
        builder.setAutoCancel(true);
        builder.setWhen(System.currentTimeMillis());
        builder.setLargeIcon(((BitmapDrawable)ResourceManager.getDrawable(context, "ic_com_sina_weibo_sdk_weibo_logo.png")).getBitmap());
        builder.setSmallIcon(getNotificationIcon(context));
        builder.setContentTitle(s2);
        builder.setTicker(s);
        builder.setContentText(s);
        builder.setContentIntent(buildInstallApkIntent(context, s1));
        return builder.build();
    }

    private static int getNotificationIcon(Context context)
    {
        int i = getResourceId(context, "com_sina_weibo_sdk_weibo_logo", "drawable");
        if(i <= 0)
            i = 0x108009b;
        return i;
    }

    private static int getResourceId(Context context, String s, String s1)
    {
        String s2;
        PackageManager packagemanager;
        s2 = context.getApplicationContext().getPackageName();
        packagemanager = context.getPackageManager();
        int j = packagemanager.getResourcesForApplication(s2).getIdentifier(s, s1, s2);
        int i = j;
_L2:
        return i;
        android.content.pm.PackageManager.NameNotFoundException namenotfoundexception;
        namenotfoundexception;
        namenotfoundexception.printStackTrace();
        i = 0;
        if(true) goto _L2; else goto _L1
_L1:
    }

    public static void showNotification(Context context, String s, String s1)
    {
        if(!TextUtils.isEmpty(s))
            ((NotificationManager)context.getSystemService("notification")).notify(1, buildNotification(context, s, s1));
    }
}
