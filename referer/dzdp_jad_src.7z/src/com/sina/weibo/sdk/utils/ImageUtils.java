// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.sina.weibo.sdk.utils;

import android.content.Context;
import android.graphics.*;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.text.TextUtils;
import java.io.*;

// Referenced classes of package com.sina.weibo.sdk.utils:
//            BitmapHelper, NetworkHelper

public class ImageUtils
{

    public ImageUtils()
    {
    }

    private static void delete(File file)
    {
        if(file != null && file.exists() && !file.delete())
            throw new RuntimeException((new StringBuilder(String.valueOf(file.getAbsolutePath()))).append(" doesn't be deleted!").toString());
        else
            return;
    }

    private static boolean deleteDependon(String s)
    {
        boolean flag;
        if(TextUtils.isEmpty(s))
        {
            flag = false;
        } else
        {
            File file = new File(s);
            int i = 1;
            byte byte0 = 0;
            if(1 < 0)
                byte0 = 5;
            flag = false;
            if(file != null)
                while(!flag && i <= byte0 && file.isFile() && file.exists()) 
                {
                    flag = file.delete();
                    if(!flag)
                        i++;
                }
        }
        return flag;
    }

    private static boolean isFileExisted(String s)
    {
        boolean flag = false;
        if(!TextUtils.isEmpty(s)) goto _L2; else goto _L1
_L1:
        return flag;
_L2:
        File file = new File(s);
        if(file != null && file.exists())
            flag = true;
        if(true) goto _L1; else goto _L3
_L3:
    }

    private static boolean isParentExist(File file)
    {
        boolean flag = false;
        if(file != null) goto _L2; else goto _L1
_L1:
        return flag;
_L2:
        File file1 = file.getParentFile();
        if(file1 != null && !file1.exists() && (file.exists() || file.mkdirs()))
            flag = true;
        if(true) goto _L1; else goto _L3
_L3:
    }

    public static boolean isWifi(Context context)
    {
        boolean flag = true;
        NetworkInfo networkinfo = ((ConnectivityManager)context.getSystemService("connectivity")).getActiveNetworkInfo();
        if(networkinfo == null || networkinfo.getType() != flag)
            flag = false;
        return flag;
    }

    private static void makesureFileExist(String s)
    {
        if(s != null) goto _L2; else goto _L1
_L1:
        return;
_L2:
        File file = new File(s);
        if(file != null && !file.exists() && isParentExist(file))
        {
            if(file.exists())
                delete(file);
            try
            {
                file.createNewFile();
            }
            catch(IOException ioexception)
            {
                ioexception.printStackTrace();
            }
        }
        if(true) goto _L1; else goto _L3
_L3:
    }

    private static void revitionImageSize(String s, int i, int j)
        throws IOException
    {
        if(i <= 0)
            throw new IllegalArgumentException("size must be greater than 0!");
        if(!isFileExisted(s))
        {
            if(s == null)
                s = "null";
            throw new FileNotFoundException(s);
        }
        if(!BitmapHelper.verifyBitmap(s))
            throw new IOException("");
        FileInputStream fileinputstream = new FileInputStream(s);
        android.graphics.BitmapFactory.Options options = new android.graphics.BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeStream(fileinputstream, null, options);
        int k;
        Bitmap bitmap;
        try
        {
            fileinputstream.close();
        }
        catch(Exception exception)
        {
            exception.printStackTrace();
        }
        k = 0;
        do
        {
            if(options.outWidth >> k <= i && options.outHeight >> k <= i)
            {
                options.inSampleSize = (int)Math.pow(2D, k);
                options.inJustDecodeBounds = false;
                bitmap = safeDecodeBimtapFile(s, options);
                if(bitmap == null)
                    throw new IOException("Bitmap decode error!");
                break;
            }
            k++;
        } while(true);
        deleteDependon(s);
        makesureFileExist(s);
        FileOutputStream fileoutputstream = new FileOutputStream(s);
        if(options != null && options.outMimeType != null && options.outMimeType.contains("png"))
            bitmap.compress(android.graphics.Bitmap.CompressFormat.PNG, j, fileoutputstream);
        else
            bitmap.compress(android.graphics.Bitmap.CompressFormat.JPEG, j, fileoutputstream);
        try
        {
            fileoutputstream.close();
        }
        catch(Exception exception1)
        {
            exception1.printStackTrace();
        }
        bitmap.recycle();
    }

    private static void revitionImageSizeHD(String s, int i, int j)
        throws IOException
    {
        Bitmap bitmap;
        float f;
        if(i <= 0)
            throw new IllegalArgumentException("size must be greater than 0!");
        if(!isFileExisted(s))
        {
            if(s == null)
                s = "null";
            FileNotFoundException filenotfoundexception = new FileNotFoundException(s);
            throw filenotfoundexception;
        }
        if(!BitmapHelper.verifyBitmap(s))
            throw new IOException("");
        int k = i * 2;
        FileInputStream fileinputstream = new FileInputStream(s);
        android.graphics.BitmapFactory.Options options = new android.graphics.BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeStream(fileinputstream, null, options);
        int l;
        try
        {
            fileinputstream.close();
        }
        catch(Exception exception)
        {
            exception.printStackTrace();
        }
        l = 0;
        do
        {
            if(options.outWidth >> l <= k && options.outHeight >> l <= k)
            {
                options.inSampleSize = (int)Math.pow(2D, l);
                options.inJustDecodeBounds = false;
                bitmap = safeDecodeBimtapFile(s, options);
                if(bitmap == null)
                    throw new IOException("Bitmap decode error!");
                break;
            }
            l++;
        } while(true);
        deleteDependon(s);
        makesureFileExist(s);
        int i1;
        Bitmap bitmap1;
        Canvas canvas;
        Matrix matrix;
        if(bitmap.getWidth() > bitmap.getHeight())
            i1 = bitmap.getWidth();
        else
            i1 = bitmap.getHeight();
        f = (float)i / (float)i1;
        if(f >= 1.0F) goto _L2; else goto _L1
_L1:
        bitmap1 = Bitmap.createBitmap((int)(f * (float)bitmap.getWidth()), (int)(f * (float)bitmap.getHeight()), android.graphics.Bitmap.Config.ARGB_8888);
        if(bitmap1 == null)
            bitmap.recycle();
        canvas = new Canvas(bitmap1);
        matrix = new Matrix();
        matrix.setScale(f, f);
        canvas.drawBitmap(bitmap, matrix, new Paint());
        bitmap.recycle();
        bitmap = bitmap1;
_L2:
        FileOutputStream fileoutputstream = new FileOutputStream(s);
        OutOfMemoryError outofmemoryerror;
        if(options != null && options.outMimeType != null && options.outMimeType.contains("png"))
            bitmap.compress(android.graphics.Bitmap.CompressFormat.PNG, j, fileoutputstream);
        else
            bitmap.compress(android.graphics.Bitmap.CompressFormat.JPEG, j, fileoutputstream);
        try
        {
            fileoutputstream.close();
        }
        catch(Exception exception1)
        {
            exception1.printStackTrace();
        }
        bitmap.recycle();
        return;
        outofmemoryerror;
        System.gc();
        f = (float)(0.80000000000000004D * (double)f);
        if(true) goto _L1; else goto _L3
_L3:
    }

    public static boolean revitionPostImageSize(Context context, String s)
    {
        boolean flag;
label0:
        {
            try
            {
                if(NetworkHelper.isWifiValid(context))
                    revitionImageSizeHD(s, 1600, 75);
                else
                    revitionImageSize(s, 1024, 75);
            }
            catch(IOException ioexception)
            {
                ioexception.printStackTrace();
                flag = false;
                break label0;
            }
            flag = true;
        }
        return flag;
    }

    private static Bitmap safeDecodeBimtapFile(String s, android.graphics.BitmapFactory.Options options)
    {
        android.graphics.BitmapFactory.Options options1;
        Bitmap bitmap;
        int i;
        FileInputStream fileinputstream;
        options1 = options;
        if(options1 == null)
        {
            options1 = new android.graphics.BitmapFactory.Options();
            options1.inSampleSize = 1;
        }
        bitmap = null;
        i = 0;
        fileinputstream = null;
_L4:
        if(i < 5) goto _L2; else goto _L1
_L1:
        fileinputstream;
_L3:
        return bitmap;
_L2:
        FileInputStream fileinputstream1 = new FileInputStream(s);
        Bitmap bitmap1 = BitmapFactory.decodeStream(fileinputstream1, null, options);
        bitmap = bitmap1;
        fileinputstream1.close();
          goto _L3
        IOException ioexception1;
        ioexception1;
        ioexception1.printStackTrace();
          goto _L3
        OutOfMemoryError outofmemoryerror;
        outofmemoryerror;
_L5:
        outofmemoryerror.printStackTrace();
        options1.inSampleSize = 2 * options1.inSampleSize;
        try
        {
            fileinputstream1.close();
        }
        catch(IOException ioexception)
        {
            ioexception.printStackTrace();
        }
        i++;
        fileinputstream = fileinputstream1;
          goto _L4
        FileNotFoundException filenotfoundexception1;
        filenotfoundexception1;
        fileinputstream;
          goto _L3
        FileNotFoundException filenotfoundexception;
        filenotfoundexception;
          goto _L3
        outofmemoryerror;
        fileinputstream1 = fileinputstream;
          goto _L5
    }
}
