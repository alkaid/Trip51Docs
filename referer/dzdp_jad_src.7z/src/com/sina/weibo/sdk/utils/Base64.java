// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.sina.weibo.sdk.utils;


public final class Base64
{

    private static char alphabet[];
    private static byte codes[];

    public Base64()
    {
    }

    public static byte[] decode(byte abyte0[])
    {
        int i = 3 * ((3 + abyte0.length) / 4);
        if(abyte0.length > 0 && abyte0[-1 + abyte0.length] == 61)
            i--;
        if(abyte0.length > 1 && abyte0[-2 + abyte0.length] == 61)
            i--;
        byte abyte1[] = new byte[i];
        int j = 0;
        int k = 0;
        int l = 0;
        int i1 = 0;
        do
        {
            byte byte0;
            if(i1 >= abyte0.length)
                if(l != abyte1.length)
                    throw new RuntimeException("miscalculated data length!");
                else
                    return abyte1;
            byte0 = codes[0xff & abyte0[i1]];
            if(byte0 >= 0)
            {
                int j1 = k << 6;
                j += 6;
                k = j1 | byte0;
                if(j >= 8)
                {
                    j -= 8;
                    int k1 = l + 1;
                    abyte1[l] = (byte)(0xff & k >> j);
                    l = k1;
                }
            }
            i1++;
        } while(true);
    }

    public static char[] encode(byte abyte0[])
    {
        char ac[] = new char[4 * ((2 + abyte0.length) / 3)];
        int i = 0;
        int j = 0;
        do
        {
            if(i >= abyte0.length)
                return ac;
            boolean flag = false;
            boolean flag1 = false;
            int k = (0xff & abyte0[i]) << 8;
            if(i + 1 < abyte0.length)
            {
                k |= 0xff & abyte0[i + 1];
                flag1 = true;
            }
            int l = k << 8;
            if(i + 2 < abyte0.length)
            {
                l |= 0xff & abyte0[i + 2];
                flag = true;
            }
            int i1 = j + 3;
            char ac1[] = alphabet;
            int j1;
            int k1;
            int l1;
            char ac2[];
            int i2;
            int j2;
            int k2;
            if(flag)
                j1 = l & 0x3f;
            else
                j1 = 64;
            ac[i1] = ac1[j1];
            k1 = l >> 6;
            l1 = j + 2;
            ac2 = alphabet;
            if(flag1)
                i2 = k1 & 0x3f;
            else
                i2 = 64;
            ac[l1] = ac2[i2];
            j2 = k1 >> 6;
            ac[j + 1] = alphabet[j2 & 0x3f];
            k2 = j2 >> 6;
            ac[j + 0] = alphabet[k2 & 0x3f];
            i += 3;
            j += 4;
        } while(true);
    }

    public static byte[] encodebyte(byte abyte0[])
    {
        byte abyte1[] = new byte[4 * ((2 + abyte0.length) / 3)];
        int i = 0;
        int j = 0;
        do
        {
            if(i >= abyte0.length)
                return abyte1;
            boolean flag = false;
            boolean flag1 = false;
            int k = (0xff & abyte0[i]) << 8;
            if(i + 1 < abyte0.length)
            {
                k |= 0xff & abyte0[i + 1];
                flag1 = true;
            }
            int l = k << 8;
            if(i + 2 < abyte0.length)
            {
                l |= 0xff & abyte0[i + 2];
                flag = true;
            }
            int i1 = j + 3;
            char ac[] = alphabet;
            int j1;
            int k1;
            int l1;
            char ac1[];
            int i2;
            int j2;
            int k2;
            if(flag)
                j1 = l & 0x3f;
            else
                j1 = 64;
            abyte1[i1] = (byte)ac[j1];
            k1 = l >> 6;
            l1 = j + 2;
            ac1 = alphabet;
            if(flag1)
                i2 = k1 & 0x3f;
            else
                i2 = 64;
            abyte1[l1] = (byte)ac1[i2];
            j2 = k1 >> 6;
            abyte1[j + 1] = (byte)alphabet[j2 & 0x3f];
            k2 = j2 >> 6;
            abyte1[j + 0] = (byte)alphabet[k2 & 0x3f];
            i += 3;
            j += 4;
        } while(true);
    }

    static 
    {
        int i;
        alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=".toCharArray();
        codes = new byte[256];
        i = 0;
_L7:
        if(i < 256) goto _L2; else goto _L1
_L1:
        int j = 65;
_L8:
        if(j <= 90) goto _L4; else goto _L3
_L3:
        int k = 97;
_L9:
        if(k <= 122) goto _L6; else goto _L5
_L5:
        int l = 48;
_L10:
        if(l > 57)
        {
            codes[43] = 62;
            codes[47] = 63;
            return;
        }
        break MISSING_BLOCK_LABEL_117;
_L2:
        codes[i] = -1;
        i++;
          goto _L7
_L4:
        codes[j] = (byte)(j - 65);
        j++;
          goto _L8
_L6:
        codes[k] = (byte)(-97 + (k + 26));
        k++;
          goto _L9
        codes[l] = (byte)(-48 + (l + 52));
        l++;
          goto _L10
    }
}
