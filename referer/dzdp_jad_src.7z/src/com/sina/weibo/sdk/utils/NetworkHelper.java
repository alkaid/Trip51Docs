// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.sina.weibo.sdk.utils;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.*;
import android.webkit.CookieManager;
import android.webkit.CookieSyncManager;
import java.util.List;

public class NetworkHelper
{

    public NetworkHelper()
    {
    }

    public static void clearCookies(Context context)
    {
        CookieSyncManager.createInstance(context);
        CookieManager.getInstance().removeAllCookie();
        CookieSyncManager.getInstance().sync();
    }

    public static String generateUA(Context context)
    {
        StringBuilder stringbuilder = new StringBuilder();
        stringbuilder.append("Android");
        stringbuilder.append("__");
        stringbuilder.append("weibo");
        stringbuilder.append("__");
        stringbuilder.append("sdk");
        stringbuilder.append("__");
        try
        {
            stringbuilder.append(context.getPackageManager().getPackageInfo(context.getPackageName(), 16).versionName.replaceAll("\\s+", "_"));
        }
        catch(Exception exception)
        {
            stringbuilder.append("unknown");
        }
        return stringbuilder.toString();
    }

    public static NetworkInfo getActiveNetworkInfo(Context context)
    {
        return ((ConnectivityManager)context.getSystemService("connectivity")).getActiveNetworkInfo();
    }

    public static NetworkInfo getNetworkInfo(Context context, int i)
    {
        return ((ConnectivityManager)context.getSystemService("connectivity")).getNetworkInfo(i);
    }

    public static int getNetworkType(Context context)
    {
        int i = -1;
        if(context != null)
        {
            NetworkInfo networkinfo = getActiveNetworkInfo(context);
            if(networkinfo != null)
                i = networkinfo.getType();
        }
        return i;
    }

    public static android.net.NetworkInfo.DetailedState getWifiConnectivityState(Context context)
    {
        NetworkInfo networkinfo = getNetworkInfo(context, 1);
        android.net.NetworkInfo.DetailedState detailedstate;
        if(networkinfo == null)
            detailedstate = android.net.NetworkInfo.DetailedState.FAILED;
        else
            detailedstate = networkinfo.getDetailedState();
        return detailedstate;
    }

    public static int getWifiState(Context context)
    {
        WifiManager wifimanager = (WifiManager)context.getSystemService("wifi");
        int i;
        if(wifimanager == null)
            i = 4;
        else
            i = wifimanager.getWifiState();
        return i;
    }

    public static boolean hasInternetPermission(Context context)
    {
        boolean flag = true;
        if(context != null && context.checkCallingOrSelfPermission("android.permission.INTERNET") != 0)
            flag = false;
        return flag;
    }

    public static boolean isMobileNetwork(Context context)
    {
        boolean flag;
        NetworkInfo networkinfo;
        flag = false;
        if(context != null)
        {
            networkinfo = getActiveNetworkInfo(context);
            break MISSING_BLOCK_LABEL_11;
        }
_L1:
        return flag;
        if(networkinfo != null && networkinfo != null && networkinfo.getType() == 0 && networkinfo.isConnected())
            flag = true;
          goto _L1
    }

    public static boolean isNetworkAvailable(Context context)
    {
        boolean flag = false;
        if(context != null)
        {
            NetworkInfo networkinfo = getActiveNetworkInfo(context);
            if(networkinfo != null && networkinfo.isConnected())
                flag = true;
        }
        return flag;
    }

    public static boolean isWifiValid(Context context)
    {
        boolean flag = true;
        if(context != null)
        {
            NetworkInfo networkinfo = getActiveNetworkInfo(context);
            if(networkinfo == null || flag != networkinfo.getType() || !networkinfo.isConnected())
                flag = false;
        } else
        {
            flag = false;
        }
        return flag;
    }

    public static boolean wifiConnection(Context context, String s, String s1)
    {
        boolean flag;
        WifiManager wifimanager;
        String s2;
        WifiInfo wifiinfo;
        flag = false;
        wifimanager = (WifiManager)context.getSystemService("wifi");
        s2 = (new StringBuilder("\"")).append(s).append("\"").toString();
        wifiinfo = wifimanager.getConnectionInfo();
        if(wifiinfo == null || !s.equals(wifiinfo.getSSID()) && !s2.equals(wifiinfo.getSSID())) goto _L2; else goto _L1
_L1:
        flag = true;
_L4:
        return flag;
_L2:
        List list;
        int i;
        list = wifimanager.getScanResults();
        if(list == null || list.size() == 0)
            continue; /* Loop/switch isn't completed */
        i = -1 + list.size();
_L5:
        if(i >= 0)
        {
label0:
            {
                String s3 = ((ScanResult)list.get(i)).SSID;
                if(!s.equals(s3) && !s2.equals(s3))
                    break label0;
                WifiConfiguration wificonfiguration = new WifiConfiguration();
                wificonfiguration.SSID = s2;
                wificonfiguration.preSharedKey = (new StringBuilder("\"")).append(s1).append("\"").toString();
                wificonfiguration.status = 2;
                flag = wifimanager.enableNetwork(wifimanager.addNetwork(wificonfiguration), false);
            }
        }
        if(true) goto _L4; else goto _L3
_L3:
        i--;
          goto _L5
        if(true) goto _L4; else goto _L6
_L6:
    }
}
