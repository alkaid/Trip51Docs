// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.sina.weibo.sdk.constant;


public class WBPageConstants
{
    public static final class ExceptionMsg
    {

        public static final String CARDID_ERROR = "cardId\u4E0D\u80FD\u4E3A\u7A7A";
        public static final String CONTEXT_ERROR = "context\u4E0D\u80FD\u4E3A\u7A7A";
        public static final String COUNT_ERROR = "count\u4E0D\u80FD\u4E3A\u8D1F\u6570";
        public static final String MBLOGID_ERROR = "mblogId(\u5FAE\u535Aid)\u4E0D\u80FD\u4E3A\u7A7A";
        public static final String PAGEID_ERROR = "pageId\u4E0D\u80FD\u4E3A\u7A7A";
        public static final String SINAINTERNALBROWSER = "sinainternalbrowser\u4E0D\u5408\u6CD5";
        public static final String UID_NICK_ERROR = "uid\u548Cnick\u5FC5\u987B\u81F3\u5C11\u6709\u4E00\u4E2A\u4E0D\u4E3A\u7A7A";
        public static final String URL_ERROR = "url\u4E0D\u80FD\u4E3A\u7A7A";
        public static final String WEIBO_NOT_INSTALLED = "\u65E0\u6CD5\u627E\u5230\u5FAE\u535A\u5B98\u65B9\u5BA2\u6237\u7AEF";

        public ExceptionMsg()
        {
        }
    }

    public static final class ParamKey
    {

        public static final String CARDID = "cardid";
        public static final String CONTENT = "content";
        public static final String COUNT = "count";
        public static final String EXTPARAM = "extparam";
        public static final String LATITUDE = "latitude";
        public static final String LONGITUDE = "longitude";
        public static final String MBLOGID = "mblogid";
        public static final String NICK = "nick";
        public static final String OFFSET = "offset";
        public static final String PACKAGENAME = "packagename";
        public static final String PAGE = "page";
        public static final String PAGEID = "pageid";
        public static final String POIID = "poiid";
        public static final String POINAME = "poiname";
        public static final String SINAINTERNALBROWSER = "sinainternalbrowser";
        public static final String TITLE = "title";
        public static final String UID = "uid";
        public static final String URL = "url";

        public ParamKey()
        {
        }
    }

    public static final class Scheme
    {

        public static final String BROWSER = "sinaweibo://browser";
        public static final String MAP = "sinaweibo://map";
        public static final String MBLOGDETAIL = "sinaweibo://detail";
        public static final String NEARBYPEOPLE = "sinaweibo://nearbypeople";
        public static final String NEARBYWEIBO = "sinaweibo://nearbyweibo";
        public static final String PAGEDETAILINFO = "sinaweibo://pagedetailinfo";
        public static final String PAGEINFO = "sinaweibo://pageinfo";
        public static final String PAGEPHOTOLIST = "sinaweibo://pagephotolist";
        public static final String PAGEPRODUCTLIST = "sinaweibo://pageproductlist";
        public static final String PAGEUSERLIST = "sinaweibo://pageuserlist";
        public static final String PAGEWEIBOLIST = "sinaweibo://pageweibolist";
        public static final String QRCODE = "sinaweibo://qrcode";
        public static final String SENDWEIBO = "sinaweibo://sendweibo";
        public static final String USERINFO = "sinaweibo://userinfo";
        public static final String USERTRENDS = "sinaweibo://usertrends";

        public Scheme()
        {
        }
    }


    public WBPageConstants()
    {
    }
}
