// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.sina.weibo.sdk;

import android.content.Context;
import android.content.Intent;
import android.content.pm.*;
import android.os.Bundle;
import android.os.Environment;
import android.text.TextUtils;
import android.util.Pair;
import com.sina.weibo.sdk.exception.WeiboException;
import com.sina.weibo.sdk.net.AsyncWeiboRunner;
import com.sina.weibo.sdk.net.DownloadService;
import com.sina.weibo.sdk.net.RequestListener;
import com.sina.weibo.sdk.net.WeiboParameters;
import com.sina.weibo.sdk.utils.LogUtil;
import com.sina.weibo.sdk.utils.MD5;
import com.sina.weibo.sdk.utils.NetworkHelper;
import com.sina.weibo.sdk.utils.NotificationHelper;
import com.sina.weibo.sdk.utils.Utility;
import java.io.File;
import java.util.concurrent.CountDownLatch;
import org.json.JSONException;
import org.json.JSONObject;

// Referenced classes of package com.sina.weibo.sdk:
//            WeiboAppManager

public class WbAppInstallActivator
{
    public static class NotificationInfo
    {

        private String downloadUrl;
        private String notificationContent;
        private int versionCode;

        public String getDownloadUrl()
        {
            return downloadUrl;
        }

        public String getNotificationContent()
        {
            return notificationContent;
        }

        public int getVersionCode()
        {
            return versionCode;
        }

        public boolean isNotificationInfoValid()
        {
            boolean flag;
            if(TextUtils.isEmpty(notificationContent))
                flag = false;
            else
                flag = true;
            return flag;
        }

        public void setDownloadUrl(String s)
        {
            downloadUrl = s;
        }

        public void setNotificationContent(String s)
        {
            notificationContent = s;
        }

        public void setVersionCode(int i)
        {
            versionCode = i;
        }




        public NotificationInfo(String s)
        {
            try
            {
                JSONObject jsonobject = new JSONObject(s);
                if(jsonobject.has("error") || jsonobject.has("error_code"))
                {
                    LogUtil.d(WbAppInstallActivator.TAG, "parse NotificationInfo error !!!");
                } else
                {
                    downloadUrl = jsonobject.optString("sdk_url", "");
                    notificationContent = jsonobject.optString("sdk_push", "");
                    versionCode = jsonobject.optInt("version_code");
                }
            }
            catch(JSONException jsonexception)
            {
                LogUtil.d(WbAppInstallActivator.TAG, (new StringBuilder("parse NotificationInfo error: ")).append(jsonexception.getMessage()).toString());
            }
        }
    }


    private static final String TAG = com/sina/weibo/sdk/WbAppInstallActivator.getName();
    public static final String WB_APK_FILE_DIR = (new StringBuilder()).append(Environment.getExternalStorageDirectory()).append("/Android/org_share_data/").toString();
    private static WbAppInstallActivator mInstance;
    private boolean isFree;
    private String mAppkey;
    private Context mContext;
    private CountDownLatch mCountDownlatch;
    private NotificationInfo mNotificationInfo;

    private WbAppInstallActivator(Context context, String s)
    {
        isFree = true;
        mContext = context.getApplicationContext();
        mAppkey = s;
    }

    private static boolean checkApkSign(PackageInfo packageinfo)
    {
        boolean flag = false;
        if(packageinfo != null) goto _L2; else goto _L1
_L1:
        return flag;
_L2:
        String s;
        int i;
        if(packageinfo.signatures == null)
        {
            if(android.os.Build.VERSION.SDK_INT < 11)
                flag = true;
            continue; /* Loop/switch isn't completed */
        }
        s = "";
        i = 0;
_L4:
label0:
        {
            if(i < packageinfo.signatures.length)
                break label0;
            flag = "18da2bf10352443a00a5e046d9fca6bd".equals(s);
        }
        if(true) goto _L1; else goto _L3
_L3:
        byte abyte0[] = packageinfo.signatures[i].toByteArray();
        if(abyte0 != null)
            s = MD5.hexdigest(abyte0);
        i++;
          goto _L4
        if(true) goto _L1; else goto _L5
_L5:
    }

    private static boolean checkPackageName(PackageInfo packageinfo)
    {
        boolean flag = false;
        if(packageinfo != null) goto _L2; else goto _L1
_L1:
        return flag;
_L2:
        String s = packageinfo.packageName;
        if("com.sina.weibo".equals(s) || "com.sina.weibog3".equals(s))
            flag = true;
        if(true) goto _L1; else goto _L3
_L3:
    }

    /**
     * @deprecated Method getInstance is deprecated
     */

    public static WbAppInstallActivator getInstance(Context context, String s)
    {
        com/sina/weibo/sdk/WbAppInstallActivator;
        JVM INSTR monitorenter ;
        WbAppInstallActivator wbappinstallactivator;
        if(mInstance == null)
            mInstance = new WbAppInstallActivator(context, s);
        wbappinstallactivator = mInstance;
        com/sina/weibo/sdk/WbAppInstallActivator;
        JVM INSTR monitorexit ;
        return wbappinstallactivator;
        Exception exception;
        exception;
        throw exception;
    }

    private static boolean isWeiboApk(PackageInfo packageinfo)
    {
        boolean flag;
        if(checkPackageName(packageinfo) && checkApkSign(packageinfo))
            flag = true;
        else
            flag = false;
        return flag;
    }

    private void loadNotificationInfo()
    {
        String s = mAppkey;
        requestNotificationInfo(mContext, s, new RequestListener() {

            final WbAppInstallActivator this$0;

            public void onComplete(String s1)
            {
                mNotificationInfo = new NotificationInfo(s1);
                mCountDownlatch.countDown();
            }

            public void onWeiboException(WeiboException weiboexception)
            {
                LogUtil.d(WbAppInstallActivator.TAG, (new StringBuilder("requestNotificationInfo WeiboException Msg : ")).append(weiboexception.getMessage()).toString());
                mCountDownlatch.countDown();
            }

            
            {
                this$0 = WbAppInstallActivator.this;
                super();
            }
        }
);
    }

    private static void requestNotificationInfo(Context context, String s, RequestListener requestlistener)
    {
        String s1 = context.getPackageName();
        String s2 = Utility.getSign(context, s1);
        WeiboParameters weiboparameters = new WeiboParameters(s);
        weiboparameters.put("appkey", s);
        weiboparameters.put("packagename", s1);
        weiboparameters.put("key_hash", s2);
        (new AsyncWeiboRunner(context)).requestAsync("http://api.weibo.cn/2/client/common_config", weiboparameters, "GET", requestlistener);
    }

    private static void showNotification(Context context, String s, String s1)
    {
        if(!TextUtils.isEmpty(s))
            NotificationHelper.showNotification(context, s, s1);
    }

    private static void startDownloadService(Context context, String s, String s1)
    {
        Intent intent = new Intent(context, com/sina/weibo/sdk/net/DownloadService);
        Bundle bundle = new Bundle();
        bundle.putString("notification_content", s);
        bundle.putString("download_url", s1);
        intent.putExtras(bundle);
        context.startService(intent);
    }

    private static Pair walkDir(Context context, String s)
    {
        Pair pair = null;
        if(!TextUtils.isEmpty(s)) goto _L2; else goto _L1
_L1:
        return pair;
_L2:
        File afile[];
        int i;
        File file1;
        int j;
        int k;
        File file = new File(s);
        if(!file.exists() || !file.isDirectory())
            continue; /* Loop/switch isn't completed */
        afile = file.listFiles();
        if(afile == null)
            continue; /* Loop/switch isn't completed */
        i = 0;
        file1 = null;
        j = afile.length;
        k = 0;
_L4:
label0:
        {
            if(k < j)
                break label0;
            pair = new Pair(Integer.valueOf(i), file1);
        }
        if(true) goto _L1; else goto _L3
_L3:
        File file2;
        PackageInfo packageinfo;
label1:
        {
            file2 = afile[k];
            String s1 = file2.getName();
            if(!file2.isFile() || !s1.endsWith(".apk"))
                break label1;
            packageinfo = context.getPackageManager().getPackageArchiveInfo(file2.getAbsolutePath(), 64);
        }
        if(isWeiboApk(packageinfo) && packageinfo.versionCode > i)
        {
            i = packageinfo.versionCode;
            file1 = file2;
        }
        k++;
          goto _L4
    }

    public void activateWeiboInstall()
    {
        WeiboAppManager.WeiboInfo weiboinfo = WeiboAppManager.getInstance(mContext).getWeiboInfo();
        boolean flag;
        if(weiboinfo != null && weiboinfo.isLegal())
            flag = false;
        else
            flag = true;
        if(flag && isFree)
        {
            isFree = false;
            mCountDownlatch = new CountDownLatch(1);
            loadNotificationInfo();
            (new Thread(new Runnable() {

                final WbAppInstallActivator this$0;
                private final String val$dir;

                public void run()
                {
                    Pair pair = WbAppInstallActivator.walkDir(mContext, dir);
                    mCountDownlatch.await();
                    if(mNotificationInfo == null || !mNotificationInfo.isNotificationInfoValid()) goto _L2; else goto _L1
_L1:
                    String s;
                    String s1;
                    s = mNotificationInfo.downloadUrl;
                    s1 = mNotificationInfo.notificationContent;
                    if(pair == null || pair.second == null || ((Integer)pair.first).intValue() < mNotificationInfo.versionCode) goto _L4; else goto _L3
_L3:
                    WbAppInstallActivator.showNotification(mContext, s1, ((File)pair.second).getAbsolutePath());
_L2:
                    isFree = true;
_L6:
                    return;
_L4:
                    if(NetworkHelper.isWifiValid(mContext) && !TextUtils.isEmpty(s))
                        WbAppInstallActivator.startDownloadService(mContext, s1, s);
                    continue; /* Loop/switch isn't completed */
                    InterruptedException interruptedexception;
                    interruptedexception;
                    interruptedexception.printStackTrace();
                    isFree = true;
                    if(true) goto _L6; else goto _L5
_L5:
                    Exception exception;
                    exception;
                    isFree = true;
                    throw exception;
                    if(true) goto _L2; else goto _L7
_L7:
                }

            
            {
                this$0 = WbAppInstallActivator.this;
                dir = s;
                super();
            }
            }
)).start();
        }
    }










}
