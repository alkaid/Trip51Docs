// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.sina.weibo.sdk.api;

import android.graphics.Bitmap;
import android.os.Parcel;
import com.sina.weibo.sdk.utils.LogUtil;
import java.io.*;

// Referenced classes of package com.sina.weibo.sdk.api:
//            BaseMediaObject

public class ImageObject extends BaseMediaObject
{

    public static final android.os.Parcelable.Creator CREATOR = new android.os.Parcelable.Creator() {

        public ImageObject createFromParcel(Parcel parcel)
        {
            return new ImageObject(parcel);
        }

        public volatile Object createFromParcel(Parcel parcel)
        {
            return createFromParcel(parcel);
        }

        public ImageObject[] newArray(int i)
        {
            return new ImageObject[i];
        }

        public volatile Object[] newArray(int i)
        {
            return newArray(i);
        }

    }
;
    private static final int DATA_SIZE = 0x200000;
    public byte imageData[];
    public String imagePath;

    public ImageObject()
    {
    }

    public ImageObject(Parcel parcel)
    {
        imageData = parcel.createByteArray();
        imagePath = parcel.readString();
    }

    public boolean checkArgs()
    {
        boolean flag = false;
        if(imageData != null || imagePath != null) goto _L2; else goto _L1
_L1:
        LogUtil.e("Weibo.ImageObject", "imageData and imagePath are null");
_L4:
        return flag;
_L2:
        if(imageData != null && imageData.length > 0x200000)
        {
            LogUtil.e("Weibo.ImageObject", "imageData is too large");
            continue; /* Loop/switch isn't completed */
        }
        if(imagePath != null && imagePath.length() > 512)
        {
            LogUtil.e("Weibo.ImageObject", "imagePath is too length");
            continue; /* Loop/switch isn't completed */
        }
        if(imagePath != null)
        {
            File file = new File(imagePath);
            try
            {
                if(!file.exists() || file.length() == 0L || file.length() > 0xa00000L)
                {
                    LogUtil.e("Weibo.ImageObject", "checkArgs fail, image content is too large or not exists");
                    continue; /* Loop/switch isn't completed */
                }
            }
            catch(SecurityException securityexception)
            {
                LogUtil.e("Weibo.ImageObject", "checkArgs fail, image content is too large or not exists");
                continue; /* Loop/switch isn't completed */
            }
        }
        flag = true;
        if(true) goto _L4; else goto _L3
_L3:
    }

    public int describeContents()
    {
        return 0;
    }

    public int getObjType()
    {
        return 2;
    }

    public final void setImageObject(Bitmap bitmap)
    {
        ByteArrayOutputStream bytearrayoutputstream = null;
        ByteArrayOutputStream bytearrayoutputstream1 = new ByteArrayOutputStream();
        bitmap.compress(android.graphics.Bitmap.CompressFormat.JPEG, 85, bytearrayoutputstream1);
        imageData = bytearrayoutputstream1.toByteArray();
        if(bytearrayoutputstream1 == null)
            break MISSING_BLOCK_LABEL_37;
        bytearrayoutputstream1.close();
_L1:
        return;
        Exception exception;
        exception;
_L3:
        exception.printStackTrace();
        LogUtil.e("Weibo.ImageObject", "put thumb failed");
        if(bytearrayoutputstream != null)
            try
            {
                bytearrayoutputstream.close();
            }
            catch(IOException ioexception1)
            {
                ioexception1.printStackTrace();
            }
          goto _L1
        Exception exception1;
        exception1;
_L2:
        if(bytearrayoutputstream != null)
            try
            {
                bytearrayoutputstream.close();
            }
            catch(IOException ioexception)
            {
                ioexception.printStackTrace();
            }
        throw exception1;
        IOException ioexception2;
        ioexception2;
        ioexception2.printStackTrace();
          goto _L1
        exception1;
        bytearrayoutputstream = bytearrayoutputstream1;
          goto _L2
        exception;
        bytearrayoutputstream = bytearrayoutputstream1;
          goto _L3
    }

    protected BaseMediaObject toExtraMediaObject(String s)
    {
        return this;
    }

    protected String toExtraMediaString()
    {
        return "";
    }

    public void writeToParcel(Parcel parcel, int i)
    {
        parcel.writeByteArray(imageData);
        parcel.writeString(imagePath);
    }

}
