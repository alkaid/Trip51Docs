// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.sina.weibo.sdk.api.share;

import android.app.Activity;
import android.app.Dialog;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.text.TextUtils;
import com.sina.weibo.sdk.ApiUtils;
import com.sina.weibo.sdk.WeiboAppManager;
import com.sina.weibo.sdk.api.WeiboMessage;
import com.sina.weibo.sdk.api.WeiboMultiMessage;
import com.sina.weibo.sdk.auth.AuthInfo;
import com.sina.weibo.sdk.auth.WeiboAuthListener;
import com.sina.weibo.sdk.component.ShareRequestParam;
import com.sina.weibo.sdk.component.WeiboSdkBrowser;
import com.sina.weibo.sdk.exception.WeiboShareException;
import com.sina.weibo.sdk.utils.*;

// Referenced classes of package com.sina.weibo.sdk.api.share:
//            IWeiboShareAPI, WeiboDownloader, ProvideMessageForWeiboRequest, SendMessageToWeiboResponse, 
//            VersionCheckHandler, BaseRequest, SendMultiMessageToWeiboRequest, SendMessageToWeiboRequest, 
//            BaseResponse, IWeiboDownloadListener

class WeiboShareAPIImpl
    implements IWeiboShareAPI
{

    private static final String TAG = com/sina/weibo/sdk/api/share/WeiboShareAPIImpl.getName();
    private String mAppKey;
    private Context mContext;
    private Dialog mDownloadConfirmDialog;
    private IWeiboDownloadListener mDownloadListener;
    private boolean mNeedDownloadWeibo;
    private com.sina.weibo.sdk.WeiboAppManager.WeiboInfo mWeiboInfo;

    public WeiboShareAPIImpl(Context context, String s, boolean flag)
    {
        mWeiboInfo = null;
        mNeedDownloadWeibo = true;
        mDownloadConfirmDialog = null;
        mContext = context;
        mAppKey = s;
        mNeedDownloadWeibo = flag;
        mWeiboInfo = WeiboAppManager.getInstance(context).getWeiboInfo();
        if(mWeiboInfo != null)
            LogUtil.d(TAG, mWeiboInfo.toString());
        else
            LogUtil.d(TAG, "WeiboInfo is null");
        AidTask.getInstance(context).aidTaskInit(s);
    }

    private WeiboMessage adapterMultiMessage2SingleMessage(WeiboMultiMessage weibomultimessage)
    {
        WeiboMessage weibomessage;
        if(weibomultimessage == null)
        {
            weibomessage = new WeiboMessage();
        } else
        {
            Bundle bundle = new Bundle();
            weibomultimessage.toBundle(bundle);
            weibomessage = new WeiboMessage(bundle);
        }
        return weibomessage;
    }

    private boolean checkEnvironment(boolean flag)
        throws WeiboShareException
    {
        if(isWeiboAppInstalled()) goto _L2; else goto _L1
_L1:
        if(!flag) goto _L4; else goto _L3
_L3:
        boolean flag1;
        if(mDownloadConfirmDialog == null)
        {
            mDownloadConfirmDialog = WeiboDownloader.createDownloadConfirmDialog(mContext, mDownloadListener);
            mDownloadConfirmDialog.show();
        } else
        if(!mDownloadConfirmDialog.isShowing())
            mDownloadConfirmDialog.show();
        flag1 = false;
_L6:
        return flag1;
_L4:
        throw new WeiboShareException("Weibo is not installed!");
_L2:
        if(!isWeiboAppSupportAPI())
            throw new WeiboShareException("Weibo do not support share api!");
        if(!ApiUtils.validateWeiboSign(mContext, mWeiboInfo.getPackageName()))
            throw new WeiboShareException("Weibo signature is incorrect!");
        flag1 = true;
        if(true) goto _L6; else goto _L5
_L5:
    }

    private boolean launchWeiboActivity(Activity activity, String s, String s1, String s2, Bundle bundle)
    {
        boolean flag = false;
        if(activity != null && !TextUtils.isEmpty(s) && !TextUtils.isEmpty(s1) && !TextUtils.isEmpty(s2)) goto _L2; else goto _L1
_L1:
        LogUtil.e(TAG, "launchWeiboActivity fail, invalid arguments");
_L4:
        return flag;
_L2:
        Intent intent;
        intent = new Intent();
        intent.setPackage(s1);
        intent.setAction(s);
        String s3 = activity.getPackageName();
        intent.putExtra("_weibo_sdkVersion", "0030105000");
        intent.putExtra("_weibo_appPackage", s3);
        intent.putExtra("_weibo_appKey", s2);
        intent.putExtra("_weibo_flag", 0x20130329);
        intent.putExtra("_weibo_sign", MD5.hexdigest(Utility.getSign(activity, s3)));
        if(bundle != null)
            intent.putExtras(bundle);
        LogUtil.d(TAG, (new StringBuilder("launchWeiboActivity intent=")).append(intent).append(", extra=").append(intent.getExtras()).toString());
        activity.startActivityForResult(intent, 765);
        flag = true;
        continue; /* Loop/switch isn't completed */
        ActivityNotFoundException activitynotfoundexception;
        activitynotfoundexception;
        LogUtil.e(TAG, activitynotfoundexception.getMessage());
        if(true) goto _L4; else goto _L3
_L3:
    }

    private void registerWeiboDownloadListener(IWeiboDownloadListener iweibodownloadlistener)
    {
        mDownloadListener = iweibodownloadlistener;
    }

    private void sendBroadcast(Context context, String s, String s1, String s2, Bundle bundle)
    {
        Intent intent = new Intent(s);
        String s3 = context.getPackageName();
        intent.putExtra("_weibo_sdkVersion", "0030105000");
        intent.putExtra("_weibo_appPackage", s3);
        intent.putExtra("_weibo_appKey", s1);
        intent.putExtra("_weibo_flag", 0x20130329);
        intent.putExtra("_weibo_sign", MD5.hexdigest(Utility.getSign(context, s3)));
        if(!TextUtils.isEmpty(s2))
            intent.setPackage(s2);
        if(bundle != null)
            intent.putExtras(bundle);
        LogUtil.d(TAG, (new StringBuilder("intent=")).append(intent).append(", extra=").append(intent.getExtras()).toString());
        context.sendBroadcast(intent, "com.sina.weibo.permission.WEIBO_SDK_PERMISSION");
    }

    private boolean startShareWeiboActivity(Activity activity, String s, BaseRequest baserequest, WeiboAuthListener weiboauthlistener)
    {
        new Bundle();
        String s1 = activity.getPackageName();
        ShareRequestParam sharerequestparam = new ShareRequestParam(activity);
        sharerequestparam.setToken(s);
        sharerequestparam.setAppKey(mAppKey);
        sharerequestparam.setAppPackage(s1);
        sharerequestparam.setBaseRequest(baserequest);
        sharerequestparam.setSpecifyTitle("\u5FAE\u535A\u5206\u4EAB");
        sharerequestparam.setAuthListener(weiboauthlistener);
        Intent intent = new Intent(activity, com/sina/weibo/sdk/component/WeiboSdkBrowser);
        intent.putExtras(sharerequestparam.createRequestParamBundle());
        activity.startActivity(intent);
        boolean flag = true;
_L2:
        return flag;
        ActivityNotFoundException activitynotfoundexception;
        activitynotfoundexception;
        flag = false;
        if(true) goto _L2; else goto _L1
_L1:
    }

    public int getWeiboAppSupportAPI()
    {
        int i;
        if(mWeiboInfo == null || !mWeiboInfo.isLegal())
            i = -1;
        else
            i = mWeiboInfo.getSupportApi();
        return i;
    }

    public boolean handleWeiboRequest(Intent intent, IWeiboHandler.Request request)
    {
        boolean flag = false;
        if(intent != null && request != null)
        {
            String s = intent.getStringExtra("_weibo_appPackage");
            String s1 = intent.getStringExtra("_weibo_transaction");
            if(TextUtils.isEmpty(s))
            {
                LogUtil.e(TAG, "handleWeiboRequest faild appPackage validateSign faild");
                request.onRequest(null);
            } else
            if(TextUtils.isEmpty(s1))
            {
                LogUtil.e(TAG, "handleWeiboRequest faild intent _weibo_transaction is null");
                request.onRequest(null);
            } else
            if(!ApiUtils.validateWeiboSign(mContext, s))
            {
                LogUtil.e(TAG, "handleWeiboRequest faild appPackage validateSign faild");
                request.onRequest(null);
            } else
            {
                request.onRequest(new ProvideMessageForWeiboRequest(intent.getExtras()));
                flag = true;
            }
        }
        return flag;
    }

    public boolean handleWeiboResponse(Intent intent, IWeiboHandler.Response response)
    {
        boolean flag = false;
        String s = intent.getStringExtra("_weibo_appPackage");
        String s1 = intent.getStringExtra("_weibo_transaction");
        if(TextUtils.isEmpty(s))
            LogUtil.e(TAG, "handleWeiboResponse faild appPackage is null");
        else
        if(!(response instanceof Activity))
        {
            LogUtil.e(TAG, "handleWeiboResponse faild handler is not Activity");
        } else
        {
            Activity activity = (Activity)response;
            String s2 = activity.getCallingPackage();
            LogUtil.d(TAG, (new StringBuilder("handleWeiboResponse getCallingPackage : ")).append(s2).toString());
            if(TextUtils.isEmpty(s1))
                LogUtil.e(TAG, "handleWeiboResponse faild intent _weibo_transaction is null");
            else
            if(!ApiUtils.validateWeiboSign(mContext, s) && !s.equals(activity.getPackageName()))
            {
                LogUtil.e(TAG, "handleWeiboResponse faild appPackage validateSign faild");
            } else
            {
                response.onResponse(new SendMessageToWeiboResponse(intent.getExtras()));
                flag = true;
            }
        }
        return flag;
    }

    public boolean isSupportWeiboPay()
    {
        boolean flag;
        if(getWeiboAppSupportAPI() >= 10353)
            flag = true;
        else
            flag = false;
        return flag;
    }

    public boolean isWeiboAppInstalled()
    {
        boolean flag;
        if(mWeiboInfo != null && mWeiboInfo.isLegal())
            flag = true;
        else
            flag = false;
        return flag;
    }

    public boolean isWeiboAppSupportAPI()
    {
        boolean flag;
        if(getWeiboAppSupportAPI() >= 10350)
            flag = true;
        else
            flag = false;
        return flag;
    }

    public boolean launchWeibo(Activity activity)
    {
        boolean flag = false;
        if(isWeiboAppInstalled()) goto _L2; else goto _L1
_L1:
        LogUtil.e(TAG, "launchWeibo faild WeiboInfo is null");
_L4:
        return flag;
_L2:
        activity.startActivity(activity.getPackageManager().getLaunchIntentForPackage(mWeiboInfo.getPackageName()));
        flag = true;
        continue; /* Loop/switch isn't completed */
        Exception exception;
        exception;
        LogUtil.e(TAG, exception.getMessage());
        if(true) goto _L4; else goto _L3
_L3:
    }

    public boolean launchWeiboPay(Activity activity, String s)
    {
        boolean flag;
        if(!isWeiboAppInstalled())
        {
            flag = false;
        } else
        {
            Bundle bundle = new Bundle();
            bundle.putString("rawdata", s);
            bundle.putInt("_weibo_command_type", 4);
            bundle.putString("_weibo_transaction", String.valueOf(System.currentTimeMillis()));
            flag = launchWeiboActivity(activity, "com.sina.weibo.sdk.action.ACTION_WEIBO_PAY_ACTIVITY", mWeiboInfo.getPackageName(), mAppKey, bundle);
        }
        return flag;
    }

    public boolean registerApp()
    {
        sendBroadcast(mContext, "com.sina.weibo.sdk.Intent.ACTION_WEIBO_REGISTER", mAppKey, null, null);
        return true;
    }

    public boolean sendRequest(Activity activity, BaseRequest baserequest)
    {
        boolean flag = false;
        if(baserequest != null) goto _L2; else goto _L1
_L1:
        LogUtil.e(TAG, "sendRequest faild request is null");
_L4:
        return flag;
_L2:
        boolean flag1 = checkEnvironment(mNeedDownloadWeibo);
        Exception exception;
        if(flag1)
            if(!baserequest.check(mContext, mWeiboInfo, new VersionCheckHandler()))
            {
                LogUtil.e(TAG, "sendRequest faild request check faild");
            } else
            {
                Bundle bundle = new Bundle();
                baserequest.toBundle(bundle);
                flag = launchWeiboActivity(activity, "com.sina.weibo.sdk.action.ACTION_WEIBO_ACTIVITY", mWeiboInfo.getPackageName(), mAppKey, bundle);
            }
        continue; /* Loop/switch isn't completed */
        exception;
        LogUtil.e(TAG, exception.getMessage());
        if(true) goto _L4; else goto _L3
_L3:
    }

    public boolean sendRequest(Activity activity, BaseRequest baserequest, AuthInfo authinfo, String s, WeiboAuthListener weiboauthlistener)
    {
        boolean flag;
        if(baserequest == null)
        {
            LogUtil.e(TAG, "sendRequest faild request is null !");
            flag = false;
        } else
        if(isWeiboAppInstalled() && isWeiboAppSupportAPI())
        {
            if(getWeiboAppSupportAPI() >= 10351)
                flag = sendRequest(activity, baserequest);
            else
            if(baserequest instanceof SendMultiMessageToWeiboRequest)
            {
                SendMultiMessageToWeiboRequest sendmultimessagetoweiborequest = (SendMultiMessageToWeiboRequest)baserequest;
                SendMessageToWeiboRequest sendmessagetoweiborequest = new SendMessageToWeiboRequest();
                sendmessagetoweiborequest.packageName = sendmultimessagetoweiborequest.packageName;
                sendmessagetoweiborequest.transaction = sendmultimessagetoweiborequest.transaction;
                sendmessagetoweiborequest.message = adapterMultiMessage2SingleMessage(sendmultimessagetoweiborequest.multiMessage);
                flag = sendRequest(activity, ((BaseRequest) (sendmessagetoweiborequest)));
            } else
            {
                flag = sendRequest(activity, baserequest);
            }
        } else
        {
            flag = startShareWeiboActivity(activity, s, baserequest, weiboauthlistener);
        }
        return flag;
    }

    public boolean sendResponse(BaseResponse baseresponse)
    {
        boolean flag = false;
        if(baseresponse == null)
            LogUtil.e(TAG, "sendResponse failed response null");
        else
        if(!baseresponse.check(mContext, new VersionCheckHandler()))
        {
            LogUtil.e(TAG, "sendResponse check fail");
        } else
        {
            Bundle bundle = new Bundle();
            baseresponse.toBundle(bundle);
            sendBroadcast(mContext, "com.sina.weibo.sdk.Intent.ACTION_WEIBO_RESPONSE", mAppKey, baseresponse.reqPackageName, bundle);
            flag = true;
        }
        return flag;
    }

}
