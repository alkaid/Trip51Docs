// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.sina.weibo.sdk.api;

import android.os.Parcel;
import android.text.TextUtils;
import com.sina.weibo.sdk.utils.LogUtil;
import org.json.JSONException;
import org.json.JSONObject;

// Referenced classes of package com.sina.weibo.sdk.api:
//            BaseMediaObject

public class VoiceObject extends BaseMediaObject
{

    public static final android.os.Parcelable.Creator CREATOR = new android.os.Parcelable.Creator() {

        public VoiceObject createFromParcel(Parcel parcel)
        {
            return new VoiceObject(parcel);
        }

        public volatile Object createFromParcel(Parcel parcel)
        {
            return createFromParcel(parcel);
        }

        public VoiceObject[] newArray(int i)
        {
            return new VoiceObject[i];
        }

        public volatile Object[] newArray(int i)
        {
            return newArray(i);
        }

    }
;
    public static final String EXTRA_KEY_DEFAULTTEXT = "extra_key_defaulttext";
    public String dataHdUrl;
    public String dataUrl;
    public String defaultText;
    public int duration;
    public String h5Url;

    public VoiceObject()
    {
    }

    public VoiceObject(Parcel parcel)
    {
        super(parcel);
        h5Url = parcel.readString();
        dataUrl = parcel.readString();
        dataHdUrl = parcel.readString();
        duration = parcel.readInt();
    }

    public boolean checkArgs()
    {
        boolean flag = false;
        if(super.checkArgs())
            if(dataUrl != null && dataUrl.length() > 512)
                LogUtil.e("Weibo.VoiceObject", "checkArgs fail, dataUrl is invalid");
            else
            if(dataHdUrl != null && dataHdUrl.length() > 512)
                LogUtil.e("Weibo.VoiceObject", "checkArgs fail, dataHdUrl is invalid");
            else
            if(duration <= 0)
                LogUtil.e("Weibo.VoiceObject", "checkArgs fail, duration is invalid");
            else
                flag = true;
        return flag;
    }

    public int getObjType()
    {
        return 6;
    }

    protected BaseMediaObject toExtraMediaObject(String s)
    {
        if(!TextUtils.isEmpty(s))
            try
            {
                defaultText = (new JSONObject(s)).optString("extra_key_defaulttext");
            }
            catch(JSONException jsonexception) { }
        return this;
    }

    protected String toExtraMediaString()
    {
        String s1;
        JSONObject jsonobject = new JSONObject();
        if(!TextUtils.isEmpty(defaultText))
            jsonobject.put("extra_key_defaulttext", defaultText);
        s1 = jsonobject.toString();
        String s = s1;
_L2:
        return s;
        JSONException jsonexception;
        jsonexception;
        s = "";
        if(true) goto _L2; else goto _L1
_L1:
    }

    public void writeToParcel(Parcel parcel, int i)
    {
        super.writeToParcel(parcel, i);
        parcel.writeString(h5Url);
        parcel.writeString(dataUrl);
        parcel.writeString(dataHdUrl);
        parcel.writeInt(duration);
    }

}
