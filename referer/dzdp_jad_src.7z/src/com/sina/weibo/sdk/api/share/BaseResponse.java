// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.sina.weibo.sdk.api.share;

import android.content.Context;
import android.os.Bundle;

// Referenced classes of package com.sina.weibo.sdk.api.share:
//            Base, VersionCheckHandler

public abstract class BaseResponse extends Base
{

    public int errCode;
    public String errMsg;
    public String reqPackageName;

    public BaseResponse()
    {
    }

    abstract boolean check(Context context, VersionCheckHandler versioncheckhandler);

    public void fromBundle(Bundle bundle)
    {
        errCode = bundle.getInt("_weibo_resp_errcode");
        errMsg = bundle.getString("_weibo_resp_errstr");
        transaction = bundle.getString("_weibo_transaction");
        reqPackageName = bundle.getString("_weibo_appPackage");
    }

    public void toBundle(Bundle bundle)
    {
        bundle.putInt("_weibo_command_type", getType());
        bundle.putInt("_weibo_resp_errcode", errCode);
        bundle.putString("_weibo_resp_errstr", errMsg);
        bundle.putString("_weibo_transaction", transaction);
    }
}
