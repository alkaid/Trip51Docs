// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.sina.weibo.sdk.api.share;


// Referenced classes of package com.sina.weibo.sdk.api.share:
//            BaseRequest, BaseResponse

public interface IWeiboHandler
{
    public static interface Request
    {

        public abstract void onRequest(BaseRequest baserequest);
    }

    public static interface Response
    {

        public abstract void onResponse(BaseResponse baseresponse);
    }

}
