// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.sina.weibo.sdk.api;

import android.graphics.Bitmap;
import android.os.Parcel;
import android.os.Parcelable;
import com.sina.weibo.sdk.utils.LogUtil;
import java.io.ByteArrayOutputStream;
import java.io.IOException;

public abstract class BaseMediaObject
    implements Parcelable
{

    public static final int MEDIA_TYPE_CMD = 7;
    public static final int MEDIA_TYPE_IMAGE = 2;
    public static final int MEDIA_TYPE_MUSIC = 3;
    public static final int MEDIA_TYPE_TEXT = 1;
    public static final int MEDIA_TYPE_VIDEO = 4;
    public static final int MEDIA_TYPE_VOICE = 6;
    public static final int MEDIA_TYPE_WEBPAGE = 5;
    public String actionUrl;
    public String description;
    public String identify;
    public String schema;
    public byte thumbData[];
    public String title;

    public BaseMediaObject()
    {
    }

    public BaseMediaObject(Parcel parcel)
    {
        actionUrl = parcel.readString();
        schema = parcel.readString();
        identify = parcel.readString();
        title = parcel.readString();
        description = parcel.readString();
        thumbData = parcel.createByteArray();
    }

    protected boolean checkArgs()
    {
        boolean flag;
        if(actionUrl == null || actionUrl.length() > 512)
        {
            LogUtil.e("Weibo.BaseMediaObject", "checkArgs fail, actionUrl is invalid");
            flag = false;
        } else
        if(identify == null || identify.length() > 512)
        {
            LogUtil.e("Weibo.BaseMediaObject", "checkArgs fail, identify is invalid");
            flag = false;
        } else
        if(thumbData == null || thumbData.length > 32768)
        {
            StringBuilder stringbuilder = new StringBuilder("checkArgs fail, thumbData is invalid,size is ");
            int i;
            if(thumbData != null)
                i = thumbData.length;
            else
                i = -1;
            LogUtil.e("Weibo.BaseMediaObject", stringbuilder.append(i).append("! more then 32768.").toString());
            flag = false;
        } else
        if(title == null || title.length() > 512)
        {
            LogUtil.e("Weibo.BaseMediaObject", "checkArgs fail, title is invalid");
            flag = false;
        } else
        if(description == null || description.length() > 1024)
        {
            LogUtil.e("Weibo.BaseMediaObject", "checkArgs fail, description is invalid");
            flag = false;
        } else
        {
            flag = true;
        }
        return flag;
    }

    public int describeContents()
    {
        return 0;
    }

    public abstract int getObjType();

    public final void setThumbImage(Bitmap bitmap)
    {
        ByteArrayOutputStream bytearrayoutputstream = null;
        ByteArrayOutputStream bytearrayoutputstream1 = new ByteArrayOutputStream();
        bitmap.compress(android.graphics.Bitmap.CompressFormat.JPEG, 85, bytearrayoutputstream1);
        thumbData = bytearrayoutputstream1.toByteArray();
        if(bytearrayoutputstream1 == null)
            break MISSING_BLOCK_LABEL_37;
        bytearrayoutputstream1.close();
_L1:
        return;
        Exception exception;
        exception;
_L3:
        exception.printStackTrace();
        LogUtil.e("Weibo.BaseMediaObject", "put thumb failed");
        if(bytearrayoutputstream != null)
            try
            {
                bytearrayoutputstream.close();
            }
            catch(IOException ioexception1)
            {
                ioexception1.printStackTrace();
            }
          goto _L1
        Exception exception1;
        exception1;
_L2:
        if(bytearrayoutputstream != null)
            try
            {
                bytearrayoutputstream.close();
            }
            catch(IOException ioexception)
            {
                ioexception.printStackTrace();
            }
        throw exception1;
        IOException ioexception2;
        ioexception2;
        ioexception2.printStackTrace();
          goto _L1
        exception1;
        bytearrayoutputstream = bytearrayoutputstream1;
          goto _L2
        exception;
        bytearrayoutputstream = bytearrayoutputstream1;
          goto _L3
    }

    protected abstract BaseMediaObject toExtraMediaObject(String s);

    protected abstract String toExtraMediaString();

    public void writeToParcel(Parcel parcel, int i)
    {
        parcel.writeString(actionUrl);
        parcel.writeString(schema);
        parcel.writeString(identify);
        parcel.writeString(title);
        parcel.writeString(description);
        parcel.writeByteArray(thumbData);
    }
}
