// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.sina.weibo.sdk.api.share;

import android.content.Context;
import android.text.TextUtils;
import com.sina.weibo.sdk.WeiboAppManager;
import com.sina.weibo.sdk.api.*;
import com.sina.weibo.sdk.utils.LogUtil;

// Referenced classes of package com.sina.weibo.sdk.api.share:
//            IVersionCheckHandler

public class VersionCheckHandler
    implements IVersionCheckHandler
{

    private static final String TAG = com/sina/weibo/sdk/api/share/VersionCheckHandler.getName();

    public VersionCheckHandler()
    {
    }

    public boolean checkRequest(Context context, com.sina.weibo.sdk.WeiboAppManager.WeiboInfo weiboinfo, WeiboMessage weibomessage)
    {
        boolean flag;
        if(weiboinfo == null || !weiboinfo.isLegal())
        {
            flag = false;
        } else
        {
            LogUtil.d(TAG, (new StringBuilder("WeiboMessage WeiboInfo package : ")).append(weiboinfo.getPackageName()).toString());
            LogUtil.d(TAG, (new StringBuilder("WeiboMessage WeiboInfo supportApi : ")).append(weiboinfo.getSupportApi()).toString());
            if(weiboinfo.getSupportApi() < 10351 && weibomessage.mediaObject != null && (weibomessage.mediaObject instanceof VoiceObject))
                weibomessage.mediaObject = null;
            if(weiboinfo.getSupportApi() < 10352 && weibomessage.mediaObject != null && (weibomessage.mediaObject instanceof CmdObject))
                weibomessage.mediaObject = null;
            flag = true;
        }
        return flag;
    }

    public boolean checkRequest(Context context, com.sina.weibo.sdk.WeiboAppManager.WeiboInfo weiboinfo, WeiboMultiMessage weibomultimessage)
    {
        boolean flag = false;
        if(weiboinfo != null && weiboinfo.isLegal()) goto _L2; else goto _L1
_L1:
        return flag;
_L2:
        LogUtil.d(TAG, (new StringBuilder("WeiboMultiMessage WeiboInfo package : ")).append(weiboinfo.getPackageName()).toString());
        LogUtil.d(TAG, (new StringBuilder("WeiboMultiMessage WeiboInfo supportApi : ")).append(weiboinfo.getSupportApi()).toString());
        if(weiboinfo.getSupportApi() >= 10351)
        {
            if(weiboinfo.getSupportApi() < 10352 && weibomultimessage.mediaObject != null && (weibomultimessage.mediaObject instanceof CmdObject))
                weibomultimessage.mediaObject = null;
            flag = true;
        }
        if(true) goto _L1; else goto _L3
_L3:
    }

    public boolean checkResponse(Context context, String s, WeiboMessage weibomessage)
    {
        boolean flag;
        if(TextUtils.isEmpty(s))
            flag = false;
        else
            flag = checkRequest(context, WeiboAppManager.getInstance(context).parseWeiboInfoByAsset(s), weibomessage);
        return flag;
    }

    public boolean checkResponse(Context context, String s, WeiboMultiMessage weibomultimessage)
    {
        boolean flag;
        if(TextUtils.isEmpty(s))
            flag = false;
        else
            flag = checkRequest(context, WeiboAppManager.getInstance(context).parseWeiboInfoByAsset(s), weibomultimessage);
        return flag;
    }

}
