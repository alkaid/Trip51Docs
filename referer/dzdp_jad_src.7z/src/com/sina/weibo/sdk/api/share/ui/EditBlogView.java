// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.sina.weibo.sdk.api.share.ui;

import android.content.Context;
import android.text.Editable;
import android.text.Selection;
import android.text.style.ImageSpan;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.inputmethod.*;
import android.widget.EditText;
import java.util.*;

public class EditBlogView extends EditText
{
    public static interface OnEnterListener
    {

        public abstract void onEnterKey();
    }

    public static interface OnSelectionListener
    {

        public abstract void onSelectionChanged(int i, int j);
    }


    private boolean canSelectionChanged;
    private int count;
    private Context ctx;
    private List listeners;
    private OnEnterListener mOnEnterListener;

    public EditBlogView(Context context)
    {
        super(context);
        canSelectionChanged = true;
        init();
    }

    public EditBlogView(Context context, AttributeSet attributeset)
    {
        super(context, attributeset);
        canSelectionChanged = true;
        init();
    }

    public EditBlogView(Context context, AttributeSet attributeset, int i)
    {
        super(context, attributeset, i);
        canSelectionChanged = true;
        init();
    }

    private void init()
    {
        ctx = getContext();
        listeners = new ArrayList();
    }

    public int correctPosition(int i)
    {
        if(i != -1) goto _L2; else goto _L1
_L1:
        return i;
_L2:
        Editable editable = getText();
        if(i < editable.length())
        {
            Object aobj[] = editable.getSpans(i, i, android/text/style/ImageSpan);
            if(aobj != null && aobj.length != 0 && i != editable.getSpanStart(aobj[0]))
                i = editable.getSpanEnd(aobj[0]);
        }
        if(true) goto _L1; else goto _L3
_L3:
    }

    public void enableSelectionChanged(boolean flag)
    {
        canSelectionChanged = flag;
    }

    public InputConnection onCreateInputConnection(EditorInfo editorinfo)
    {
        return new InputConnectionWrapper(super.onCreateInputConnection(editorinfo), false) {

            final EditBlogView this$0;

            public boolean commitText(CharSequence charsequence, int i)
            {
                Editable editable = getEditableText();
                new String(editable.toString());
                int j = Selection.getSelectionStart(editable);
                int k = Selection.getSelectionEnd(editable);
                if(j != -1 && k != -1)
                {
                    int l = correctPosition(j);
                    int i1 = correctPosition(k);
                    if(l > i1)
                    {
                        int j1 = l;
                        l = i1;
                        i1 = j1;
                    }
                    if(l != j || i1 != k)
                        Selection.setSelection(editable, l, i1);
                    if(l != i1)
                        getText().delete(l, i1);
                }
                return super.commitText(charsequence, i);
            }

            public boolean setComposingText(CharSequence charsequence, int i)
            {
                Editable editable = getEditableText();
                new String(editable.toString());
                int j = Selection.getSelectionStart(editable);
                int k = Selection.getSelectionEnd(editable);
                if(j != -1 && k != -1)
                {
                    int l = correctPosition(j);
                    int i1 = correctPosition(k);
                    if(l > i1)
                    {
                        int j1 = l;
                        l = i1;
                        i1 = j1;
                    }
                    if(l != j || i1 != k)
                        Selection.setSelection(editable, l, i1);
                    if(l != i1)
                        getText().delete(l, i1);
                }
                return super.setComposingText(charsequence, i);
            }

            
            {
                this$0 = EditBlogView.this;
                super(inputconnection, flag);
            }
        }
;
    }

    public boolean onKeyDown(int i, KeyEvent keyevent)
    {
        if(i == 66 && mOnEnterListener != null)
            mOnEnterListener.onEnterKey();
        return super.onKeyDown(i, keyevent);
    }

    protected void onSelectionChanged(int i, int j)
    {
        super.onSelectionChanged(i, j);
        if(canSelectionChanged && listeners != null && !listeners.isEmpty())
        {
            Iterator iterator = listeners.iterator();
            while(iterator.hasNext()) 
                ((OnSelectionListener)iterator.next()).onSelectionChanged(i, j);
        }
    }

    public void setOnEnterListener(OnEnterListener onenterlistener)
    {
        mOnEnterListener = onenterlistener;
    }

    public void setOnSelectionListener(OnSelectionListener onselectionlistener)
    {
        listeners.add(onselectionlistener);
    }
}
