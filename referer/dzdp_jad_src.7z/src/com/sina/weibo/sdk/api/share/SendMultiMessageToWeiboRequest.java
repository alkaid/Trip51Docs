// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.sina.weibo.sdk.api.share;

import android.content.Context;
import android.os.Bundle;
import com.sina.weibo.sdk.api.WeiboMultiMessage;

// Referenced classes of package com.sina.weibo.sdk.api.share:
//            BaseRequest, VersionCheckHandler

public class SendMultiMessageToWeiboRequest extends BaseRequest
{

    public WeiboMultiMessage multiMessage;

    public SendMultiMessageToWeiboRequest()
    {
    }

    public SendMultiMessageToWeiboRequest(Bundle bundle)
    {
        fromBundle(bundle);
    }

    final boolean check(Context context, com.sina.weibo.sdk.WeiboAppManager.WeiboInfo weiboinfo, VersionCheckHandler versioncheckhandler)
    {
        boolean flag;
        flag = false;
        break MISSING_BLOCK_LABEL_3;
        if(multiMessage != null && weiboinfo != null && weiboinfo.isLegal() && (versioncheckhandler == null || versioncheckhandler.checkRequest(context, weiboinfo, multiMessage)))
            flag = multiMessage.checkArgs();
        return flag;
    }

    public void fromBundle(Bundle bundle)
    {
        super.fromBundle(bundle);
        multiMessage = new WeiboMultiMessage(bundle);
    }

    public int getType()
    {
        return 1;
    }

    public void toBundle(Bundle bundle)
    {
        super.toBundle(bundle);
        bundle.putAll(multiMessage.toBundle(bundle));
    }
}
