// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.ut.device;

import android.content.Context;

public class UTDevice
{

    public UTDevice()
    {
    }

    public static String getUtdid(Context context)
    {
        return com.ta.utdid2.device.UTDevice.getUtdid(context);
    }
}
