// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing;

import com.google.zxing.common.BitMatrix;
import java.util.Map;

// Referenced classes of package com.google.zxing:
//            WriterException, BarcodeFormat

public interface Writer
{

    public abstract BitMatrix encode(String s, BarcodeFormat barcodeformat, int i, int j)
        throws WriterException;

    public abstract BitMatrix encode(String s, BarcodeFormat barcodeformat, int i, int j, Map map)
        throws WriterException;
}
