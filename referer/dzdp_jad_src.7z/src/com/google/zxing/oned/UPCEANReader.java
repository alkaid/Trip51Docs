// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.oned;

import com.google.zxing.*;
import com.google.zxing.common.BitArray;
import java.util.Arrays;
import java.util.Map;

// Referenced classes of package com.google.zxing.oned:
//            OneDReader, UPCEANExtensionSupport, EANManufacturerOrgSupport

public abstract class UPCEANReader extends OneDReader
{

    static final int L_AND_G_PATTERNS[][];
    static final int L_PATTERNS[][];
    private static final float MAX_AVG_VARIANCE = 0.48F;
    private static final float MAX_INDIVIDUAL_VARIANCE = 0.7F;
    static final int MIDDLE_PATTERN[];
    static final int START_END_PATTERN[];
    private final StringBuilder decodeRowStringBuffer = new StringBuilder(20);
    private final EANManufacturerOrgSupport eanManSupport = new EANManufacturerOrgSupport();
    private final UPCEANExtensionSupport extensionReader = new UPCEANExtensionSupport();

    protected UPCEANReader()
    {
    }

    static boolean checkStandardUPCEANChecksum(CharSequence charsequence)
        throws FormatException
    {
        boolean flag;
        int i;
        flag = false;
        i = charsequence.length();
        if(i != 0) goto _L2; else goto _L1
_L1:
        return flag;
_L2:
        int j = 0;
        for(int k = i - 2; k >= 0; k -= 2)
        {
            int k1 = -48 + charsequence.charAt(k);
            if(k1 < 0 || k1 > 9)
                throw FormatException.getFormatInstance();
            j += k1;
        }

        int l = j * 3;
        for(int i1 = i - 1; i1 >= 0; i1 -= 2)
        {
            int j1 = -48 + charsequence.charAt(i1);
            if(j1 < 0 || j1 > 9)
                throw FormatException.getFormatInstance();
            l += j1;
        }

        if(l % 10 == 0)
            flag = true;
        if(true) goto _L1; else goto _L3
_L3:
    }

    static int decodeDigit(BitArray bitarray, int ai[], int i, int ai1[][])
        throws NotFoundException
    {
        recordPattern(bitarray, i, ai);
        float f = 0.48F;
        int j = -1;
        int k = ai1.length;
        for(int l = 0; l < k; l++)
        {
            float f1 = patternMatchVariance(ai, ai1[l], 0.7F);
            if(f1 < f)
            {
                f = f1;
                j = l;
            }
        }

        if(j >= 0)
            return j;
        else
            throw NotFoundException.getNotFoundInstance();
    }

    static int[] findGuardPattern(BitArray bitarray, int i, boolean flag, int ai[])
        throws NotFoundException
    {
        return findGuardPattern(bitarray, i, flag, ai, new int[ai.length]);
    }

    private static int[] findGuardPattern(BitArray bitarray, int i, boolean flag, int ai[], int ai1[])
        throws NotFoundException
    {
        int j = ai.length;
        int k = bitarray.getSize();
        boolean flag1 = flag;
        int l;
        int i1;
        int j1;
        int k1;
        if(flag)
            l = bitarray.getNextUnset(i);
        else
            l = bitarray.getNextSet(i);
        i1 = 0;
        j1 = l;
        k1 = l;
        while(k1 < k) 
        {
            if(flag1 ^ bitarray.get(k1))
            {
                ai1[i1] = 1 + ai1[i1];
            } else
            {
                if(i1 == j - 1)
                {
                    if(patternMatchVariance(ai1, ai, 0.7F) < 0.48F)
                    {
                        int ai2[] = new int[2];
                        ai2[0] = j1;
                        ai2[1] = k1;
                        return ai2;
                    }
                    j1 += ai1[0] + ai1[1];
                    System.arraycopy(ai1, 2, ai1, 0, j - 2);
                    ai1[j - 2] = 0;
                    ai1[j - 1] = 0;
                    i1--;
                } else
                {
                    i1++;
                }
                ai1[i1] = 1;
                if(!flag1)
                    flag1 = true;
                else
                    flag1 = false;
            }
            k1++;
        }
        throw NotFoundException.getNotFoundInstance();
    }

    static int[] findStartGuardPattern(BitArray bitarray)
        throws NotFoundException
    {
        boolean flag = false;
        int ai[] = null;
        int i = 0;
        int ai1[] = new int[START_END_PATTERN.length];
        do
        {
            if(flag)
                break;
            Arrays.fill(ai1, 0, START_END_PATTERN.length, 0);
            ai = findGuardPattern(bitarray, i, false, START_END_PATTERN, ai1);
            int j = ai[0];
            i = ai[1];
            int k = j - (i - j);
            if(k >= 0)
                flag = bitarray.isRange(k, j, false);
        } while(true);
        return ai;
    }

    boolean checkChecksum(String s)
        throws FormatException
    {
        return checkStandardUPCEANChecksum(s);
    }

    int[] decodeEnd(BitArray bitarray, int i)
        throws NotFoundException
    {
        return findGuardPattern(bitarray, i, false, START_END_PATTERN);
    }

    protected abstract int decodeMiddle(BitArray bitarray, int ai[], StringBuilder stringbuilder)
        throws NotFoundException;

    public Result decodeRow(int i, BitArray bitarray, Map map)
        throws NotFoundException, ChecksumException, FormatException
    {
        return decodeRow(i, bitarray, findStartGuardPattern(bitarray), map);
    }

    public Result decodeRow(int i, BitArray bitarray, int ai[], Map map)
        throws NotFoundException, ChecksumException, FormatException
    {
        int ai1[];
        String s;
        BarcodeFormat barcodeformat;
        Result result;
        int i1;
        ResultPointCallback resultpointcallback;
        StringBuilder stringbuilder;
        int j;
        int k;
        int l;
        if(map == null)
            resultpointcallback = null;
        else
            resultpointcallback = (ResultPointCallback)map.get(DecodeHintType.NEED_RESULT_POINT_CALLBACK);
        if(resultpointcallback != null)
        {
            ResultPoint resultpoint = new ResultPoint((float)(ai[0] + ai[1]) / 2.0F, i);
            resultpointcallback.foundPossibleResultPoint(resultpoint);
        }
        stringbuilder = decodeRowStringBuffer;
        stringbuilder.setLength(0);
        j = decodeMiddle(bitarray, ai, stringbuilder);
        if(resultpointcallback != null)
        {
            ResultPoint resultpoint1 = new ResultPoint(j, i);
            resultpointcallback.foundPossibleResultPoint(resultpoint1);
        }
        ai1 = decodeEnd(bitarray, j);
        if(resultpointcallback != null)
        {
            ResultPoint resultpoint2 = new ResultPoint((float)(ai1[0] + ai1[1]) / 2.0F, i);
            resultpointcallback.foundPossibleResultPoint(resultpoint2);
        }
        k = ai1[1];
        l = k + (k - ai1[0]);
        if(l >= bitarray.getSize() || !bitarray.isRange(k, l, false))
            throw NotFoundException.getNotFoundInstance();
        s = stringbuilder.toString();
        if(s.length() < 8)
            throw FormatException.getFormatInstance();
        if(!checkChecksum(s))
            throw ChecksumException.getChecksumInstance();
        float f = (float)(ai[1] + ai[0]) / 2.0F;
        float f1 = (float)(ai1[1] + ai1[0]) / 2.0F;
        barcodeformat = getBarcodeFormat();
        ResultPoint aresultpoint[] = new ResultPoint[2];
        ResultPoint resultpoint3 = new ResultPoint(f, i);
        aresultpoint[0] = resultpoint3;
        ResultPoint resultpoint4 = new ResultPoint(f1, i);
        aresultpoint[1] = resultpoint4;
        result = new Result(s, null, aresultpoint, barcodeformat);
        i1 = 0;
        int l1;
        Result result1 = extensionReader.decodeRow(i, bitarray, ai1[1]);
        result.putMetadata(ResultMetadataType.UPC_EAN_EXTENSION, result1.getText());
        result.putAllMetadata(result1.getResultMetadata());
        result.addResultPoints(result1.getResultPoints());
        l1 = result1.getText().length();
        i1 = l1;
_L2:
        int ai2[];
        if(map == null)
            ai2 = null;
        else
            ai2 = (int[])(int[])map.get(DecodeHintType.ALLOWED_EAN_EXTENSIONS);
        if(ai2 != null)
        {
            boolean flag = false;
            int j1 = ai2.length;
            int k1 = 0;
label0:
            do
            {
label1:
                {
                    if(k1 < j1)
                    {
                        if(i1 != ai2[k1])
                            break label1;
                        flag = true;
                    }
                    if(!flag)
                        throw NotFoundException.getNotFoundInstance();
                    break label0;
                }
                k1++;
            } while(true);
        }
        if(barcodeformat == BarcodeFormat.EAN_13 || barcodeformat == BarcodeFormat.UPC_A)
        {
            String s1 = eanManSupport.lookupCountryIdentifier(s);
            if(s1 != null)
                result.putMetadata(ResultMetadataType.POSSIBLE_COUNTRY, s1);
        }
        return result;
        ReaderException readerexception;
        readerexception;
        if(true) goto _L2; else goto _L1
_L1:
    }

    abstract BarcodeFormat getBarcodeFormat();

    static 
    {
        int ai[] = new int[3];
        ai[0] = 1;
        ai[1] = 1;
        ai[2] = 1;
        START_END_PATTERN = ai;
        int ai1[] = new int[5];
        ai1[0] = 1;
        ai1[1] = 1;
        ai1[2] = 1;
        ai1[3] = 1;
        ai1[4] = 1;
        MIDDLE_PATTERN = ai1;
        int ai2[][] = new int[10][];
        int ai3[] = new int[4];
        ai3[0] = 3;
        ai3[1] = 2;
        ai3[2] = 1;
        ai3[3] = 1;
        ai2[0] = ai3;
        int ai4[] = new int[4];
        ai4[0] = 2;
        ai4[1] = 2;
        ai4[2] = 2;
        ai4[3] = 1;
        ai2[1] = ai4;
        int ai5[] = new int[4];
        ai5[0] = 2;
        ai5[1] = 1;
        ai5[2] = 2;
        ai5[3] = 2;
        ai2[2] = ai5;
        int ai6[] = new int[4];
        ai6[0] = 1;
        ai6[1] = 4;
        ai6[2] = 1;
        ai6[3] = 1;
        ai2[3] = ai6;
        int ai7[] = new int[4];
        ai7[0] = 1;
        ai7[1] = 1;
        ai7[2] = 3;
        ai7[3] = 2;
        ai2[4] = ai7;
        int ai8[] = new int[4];
        ai8[0] = 1;
        ai8[1] = 2;
        ai8[2] = 3;
        ai8[3] = 1;
        ai2[5] = ai8;
        int ai9[] = new int[4];
        ai9[0] = 1;
        ai9[1] = 1;
        ai9[2] = 1;
        ai9[3] = 4;
        ai2[6] = ai9;
        int ai10[] = new int[4];
        ai10[0] = 1;
        ai10[1] = 3;
        ai10[2] = 1;
        ai10[3] = 2;
        ai2[7] = ai10;
        int ai11[] = new int[4];
        ai11[0] = 1;
        ai11[1] = 2;
        ai11[2] = 1;
        ai11[3] = 3;
        ai2[8] = ai11;
        int ai12[] = new int[4];
        ai12[0] = 3;
        ai12[1] = 1;
        ai12[2] = 1;
        ai12[3] = 2;
        ai2[9] = ai12;
        L_PATTERNS = ai2;
        L_AND_G_PATTERNS = new int[20][];
        System.arraycopy(L_PATTERNS, 0, L_AND_G_PATTERNS, 0, 10);
        for(int i = 10; i < 20; i++)
        {
            int ai13[] = L_PATTERNS[i - 10];
            int ai14[] = new int[ai13.length];
            for(int j = 0; j < ai13.length; j++)
                ai14[j] = ai13[-1 + (ai13.length - j)];

            L_AND_G_PATTERNS[i] = ai14;
        }

    }
}
