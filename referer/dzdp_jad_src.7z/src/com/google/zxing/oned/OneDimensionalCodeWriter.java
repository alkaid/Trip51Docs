// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.oned;

import com.google.zxing.*;
import com.google.zxing.common.BitMatrix;
import java.util.Map;

public abstract class OneDimensionalCodeWriter
    implements Writer
{

    public OneDimensionalCodeWriter()
    {
    }

    protected static int appendPattern(boolean aflag[], int i, int ai[], boolean flag)
    {
        boolean flag1 = flag;
        int j = 0;
        int k = ai.length;
        int l = 0;
        while(l < k) 
        {
            int i1 = ai[l];
            int j1 = 0;
            int k1;
            int l1;
            for(k1 = i; j1 < i1; k1 = l1)
            {
                l1 = k1 + 1;
                aflag[k1] = flag1;
                j1++;
            }

            j += i1;
            if(!flag1)
                flag1 = true;
            else
                flag1 = false;
            l++;
            i = k1;
        }
        return j;
    }

    private static BitMatrix renderResult(boolean aflag[], int i, int j, int k)
    {
        int l = aflag.length;
        int i1 = l + k;
        int j1 = Math.max(i, i1);
        int k1 = Math.max(1, j);
        int l1 = j1 / i1;
        int i2 = (j1 - l * l1) / 2;
        BitMatrix bitmatrix = new BitMatrix(j1, k1);
        int j2 = 0;
        for(int k2 = i2; j2 < l; k2 += l1)
        {
            if(aflag[j2])
                bitmatrix.setRegion(k2, 0, l1, k1);
            j2++;
        }

        return bitmatrix;
    }

    public final BitMatrix encode(String s, BarcodeFormat barcodeformat, int i, int j)
        throws WriterException
    {
        return encode(s, barcodeformat, i, j, null);
    }

    public BitMatrix encode(String s, BarcodeFormat barcodeformat, int i, int j, Map map)
        throws WriterException
    {
        if(s.isEmpty())
            throw new IllegalArgumentException("Found empty contents");
        if(i < 0 || j < 0)
            throw new IllegalArgumentException((new StringBuilder()).append("Negative size is not allowed. Input: ").append(i).append('x').append(j).toString());
        int k = getDefaultMargin();
        if(map != null)
        {
            Integer integer = (Integer)map.get(EncodeHintType.MARGIN);
            if(integer != null)
                k = integer.intValue();
        }
        return renderResult(encode(s), i, j, k);
    }

    public abstract boolean[] encode(String s);

    public int getDefaultMargin()
    {
        return 10;
    }
}
