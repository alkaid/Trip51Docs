// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.oned;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.NotFoundException;
import com.google.zxing.common.BitArray;

// Referenced classes of package com.google.zxing.oned:
//            UPCEANReader

public final class EAN8Reader extends UPCEANReader
{

    private final int decodeMiddleCounters[] = new int[4];

    public EAN8Reader()
    {
    }

    protected int decodeMiddle(BitArray bitarray, int ai[], StringBuilder stringbuilder)
        throws NotFoundException
    {
        int ai1[] = decodeMiddleCounters;
        ai1[0] = 0;
        ai1[1] = 0;
        ai1[2] = 0;
        ai1[3] = 0;
        int i = bitarray.getSize();
        int j = ai[1];
        for(int k = 0; k < 4 && j < i; k++)
        {
            stringbuilder.append((char)(48 + decodeDigit(bitarray, ai1, j, L_PATTERNS)));
            int l1 = ai1.length;
            for(int i2 = 0; i2 < l1; i2++)
                j += ai1[i2];

        }

        int l = findGuardPattern(bitarray, j, true, MIDDLE_PATTERN)[1];
        for(int i1 = 0; i1 < 4 && l < i; i1++)
        {
            stringbuilder.append((char)(48 + decodeDigit(bitarray, ai1, l, L_PATTERNS)));
            int j1 = ai1.length;
            for(int k1 = 0; k1 < j1; k1++)
                l += ai1[k1];

        }

        return l;
    }

    BarcodeFormat getBarcodeFormat()
    {
        return BarcodeFormat.EAN_8;
    }
}
