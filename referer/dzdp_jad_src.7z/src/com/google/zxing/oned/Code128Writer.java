// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.oned;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import java.util.*;

// Referenced classes of package com.google.zxing.oned:
//            OneDimensionalCodeWriter, Code128Reader

public final class Code128Writer extends OneDimensionalCodeWriter
{

    private static final int CODE_CODE_B = 100;
    private static final int CODE_CODE_C = 99;
    private static final int CODE_FNC_1 = 102;
    private static final int CODE_FNC_2 = 97;
    private static final int CODE_FNC_3 = 96;
    private static final int CODE_FNC_4_B = 100;
    private static final int CODE_START_B = 104;
    private static final int CODE_START_C = 105;
    private static final int CODE_STOP = 106;
    private static final char ESCAPE_FNC_1 = 241;
    private static final char ESCAPE_FNC_2 = 242;
    private static final char ESCAPE_FNC_3 = 243;
    private static final char ESCAPE_FNC_4 = 244;

    public Code128Writer()
    {
    }

    private static boolean isDigits(CharSequence charsequence, int i, int j)
    {
        boolean flag;
        int k;
        int l;
        int i1;
        flag = false;
        k = i + j;
        l = charsequence.length();
        i1 = i;
_L5:
        if(i1 >= k || i1 >= l) goto _L2; else goto _L1
_L1:
        char c;
        c = charsequence.charAt(i1);
        if(c >= '0' && c <= '9')
            continue; /* Loop/switch isn't completed */
        if(c == '\361') goto _L4; else goto _L3
_L3:
        return flag;
_L4:
        k++;
        i1++;
          goto _L5
_L2:
        if(k <= l)
            flag = true;
          goto _L3
    }

    public BitMatrix encode(String s, BarcodeFormat barcodeformat, int i, int j, Map map)
        throws WriterException
    {
        if(barcodeformat != BarcodeFormat.CODE_128)
            throw new IllegalArgumentException((new StringBuilder()).append("Can only encode CODE_128, but got ").append(barcodeformat).toString());
        else
            return super.encode(s, barcodeformat, i, j, map);
    }

    public boolean[] encode(String s)
    {
        int i;
        int j;
        i = s.length();
        if(i < 1 || i > 80)
            throw new IllegalArgumentException((new StringBuilder()).append("Contents length should be between 1 and 80 characters, but got ").append(i).toString());
        j = 0;
_L9:
        ArrayList arraylist;
        int k;
        int l;
        int i1;
        int j1;
        if(j < i)
        {
            char c = s.charAt(j);
            if(c < ' ' || c > '~')
                switch(c)
                {
                default:
                    throw new IllegalArgumentException((new StringBuilder()).append("Bad character in input: ").append(c).toString());

                case 241: 
                case 242: 
                case 243: 
                case 244: 
                    break;
                }
            j++;
            continue; /* Loop/switch isn't completed */
        }
        arraylist = new ArrayList();
        k = 0;
        l = 1;
        i1 = 0;
        j1 = 0;
_L6:
        byte byte1;
        int l2;
        if(j1 >= i)
            break MISSING_BLOCK_LABEL_390;
        byte byte0;
        if(i1 == 99)
            byte0 = 2;
        else
            byte0 = 4;
        if(isDigits(s, j1, byte0))
            byte1 = 99;
        else
            byte1 = 100;
        if(byte1 != i1)
            break MISSING_BLOCK_LABEL_353;
        s.charAt(j1);
        JVM INSTR tableswitch 241 244: default 232
    //                   241 304
    //                   242 311
    //                   243 318
    //                   244 325;
           goto _L1 _L2 _L3 _L4 _L5
_L1:
        if(i1 == 100)
        {
            l2 = -32 + s.charAt(j1);
        } else
        {
            l2 = Integer.parseInt(s.substring(j1, j1 + 2));
            j1++;
        }
        j1++;
_L7:
        arraylist.add(Code128Reader.CODE_PATTERNS[l2]);
        k += l2 * l;
        if(j1 != 0)
            l++;
          goto _L6
_L2:
        l2 = 102;
        break MISSING_BLOCK_LABEL_250;
_L3:
        l2 = 97;
        break MISSING_BLOCK_LABEL_250;
_L4:
        l2 = 96;
        break MISSING_BLOCK_LABEL_250;
_L5:
        l2 = 100;
        break MISSING_BLOCK_LABEL_250;
        if(i1 == 0)
        {
            if(byte1 == 100)
                l2 = 104;
            else
                l2 = 105;
        } else
        {
            l2 = byte1;
        }
        i1 = byte1;
          goto _L7
        int k1 = k % 103;
        arraylist.add(Code128Reader.CODE_PATTERNS[k1]);
        arraylist.add(Code128Reader.CODE_PATTERNS[106]);
        int l1 = 0;
        for(Iterator iterator = arraylist.iterator(); iterator.hasNext();)
        {
            int ai[] = (int[])iterator.next();
            int j2 = ai.length;
            int k2 = 0;
            while(k2 < j2) 
            {
                l1 += ai[k2];
                k2++;
            }
        }

        boolean aflag[] = new boolean[l1];
        int i2 = 0;
        for(Iterator iterator1 = arraylist.iterator(); iterator1.hasNext();)
            i2 += appendPattern(aflag, i2, (int[])iterator1.next(), true);

        return aflag;
        if(true) goto _L9; else goto _L8
_L8:
    }
}
