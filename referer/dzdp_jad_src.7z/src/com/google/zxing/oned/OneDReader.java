// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.oned;

import com.google.zxing.*;
import com.google.zxing.common.BitArray;
import java.util.*;

public abstract class OneDReader
    implements Reader
{

    public OneDReader()
    {
    }

    private Result doDecode(BinaryBitmap binarybitmap, Map map)
        throws NotFoundException
    {
        int i;
        int j;
        BitArray bitarray;
        int k;
        i = binarybitmap.getWidth();
        j = binarybitmap.getHeight();
        bitarray = new BitArray(i);
        k = j >> 1;
        if(map == null) goto _L2; else goto _L1
_L1:
        DecodeHintType decodehinttype1 = DecodeHintType.TRY_HARDER;
        if(!map.containsKey(decodehinttype1)) goto _L2; else goto _L3
_L3:
        boolean flag = true;
_L7:
        int j1;
        int l1;
        byte byte0;
        int l;
        int i1;
        if(flag)
            byte0 = 8;
        else
            byte0 = 5;
        l = Math.max(1, j >> byte0);
        if(flag)
            i1 = j;
        else
            i1 = 15;
        j1 = 0;
_L8:
        if(j1 >= i1) goto _L5; else goto _L4
_L4:
        int k1 = (j1 + 1) / 2;
        boolean flag1;
        if((j1 & 1) == 0)
            flag1 = true;
        else
            flag1 = false;
        if(!flag1)
            k1 = -k1;
        l1 = k + l * k1;
        if(l1 >= 0 && l1 < j) goto _L6; else goto _L5
_L5:
        throw NotFoundException.getNotFoundInstance();
_L2:
        flag = false;
          goto _L7
_L6:
        BitArray bitarray1 = binarybitmap.getBlackRow(l1, bitarray);
        int i2;
        bitarray = bitarray1;
        i2 = 0;
_L9:
        if(i2 >= 2)
            break MISSING_BLOCK_LABEL_366;
        if(i2 == 1)
        {
            bitarray.reverse();
            if(map != null)
            {
                DecodeHintType decodehinttype = DecodeHintType.NEED_RESULT_POINT_CALLBACK;
                if(map.containsKey(decodehinttype))
                {
                    EnumMap enummap = new EnumMap(com/google/zxing/DecodeHintType);
                    enummap.putAll(map);
                    enummap.remove(DecodeHintType.NEED_RESULT_POINT_CALLBACK);
                    map = enummap;
                }
            }
        }
        Result result;
        result = decodeRow(l1, bitarray, map);
        if(i2 == 1)
        {
            result.putMetadata(ResultMetadataType.ORIENTATION, Integer.valueOf(180));
            ResultPoint aresultpoint[] = result.getResultPoints();
            if(aresultpoint != null)
            {
                aresultpoint[0] = new ResultPoint((float)i - aresultpoint[0].getX() - 1.0F, aresultpoint[0].getY());
                aresultpoint[1] = new ResultPoint((float)i - aresultpoint[1].getX() - 1.0F, aresultpoint[1].getY());
            }
        }
        return result;
        NotFoundException notfoundexception;
        notfoundexception;
        j1++;
          goto _L8
        ReaderException readerexception;
        readerexception;
        i2++;
          goto _L9
    }

    protected static float patternMatchVariance(int ai[], int ai1[], float f)
    {
        float f1;
        int i;
        int j;
        int k;
        f1 = (1.0F / 0.0F);
        i = ai.length;
        j = 0;
        k = 0;
        for(int l = 0; l < i; l++)
        {
            j += ai[l];
            k += ai1[l];
        }

        if(j >= k) goto _L2; else goto _L1
_L1:
        return f1;
_L2:
        float f2 = (float)j / (float)k;
        float f3 = f * f2;
        float f4 = 0.0F;
        int i1 = 0;
        while(i1 < i) 
        {
            int j1 = ai[i1];
            float f5 = f2 * (float)ai1[i1];
            float f6;
            if((float)j1 > f5)
                f6 = (float)j1 - f5;
            else
                f6 = f5 - (float)j1;
            if(f6 > f3)
                continue; /* Loop/switch isn't completed */
            f4 += f6;
            i1++;
        }
        f1 = f4 / (float)j;
        if(true) goto _L1; else goto _L3
_L3:
    }

    protected static void recordPattern(BitArray bitarray, int i, int ai[])
        throws NotFoundException
    {
        int j;
        int k;
        boolean flag;
        int l;
        int i1;
        j = ai.length;
        Arrays.fill(ai, 0, j, 0);
        k = bitarray.getSize();
        if(i >= k)
            throw NotFoundException.getNotFoundInstance();
        if(!bitarray.get(i))
            flag = true;
        else
            flag = false;
        l = 0;
        i1 = i;
        if(i1 >= k) goto _L2; else goto _L1
_L1:
        if(!(flag ^ bitarray.get(i1))) goto _L4; else goto _L3
_L3:
        ai[l] = 1 + ai[l];
_L6:
        i1++;
        break MISSING_BLOCK_LABEL_43;
_L4:
        if(++l != j)
            break MISSING_BLOCK_LABEL_118;
_L2:
        if(l != j && (l != j - 1 || i1 != k))
            throw NotFoundException.getNotFoundInstance();
        else
            return;
        ai[l] = 1;
        if(!flag)
            flag = true;
        else
            flag = false;
        if(true) goto _L6; else goto _L5
_L5:
    }

    protected static void recordPatternInReverse(BitArray bitarray, int i, int ai[])
        throws NotFoundException
    {
        int j = ai.length;
        boolean flag = bitarray.get(i);
        do
        {
            if(i <= 0 || j < 0)
                break;
            i--;
            if(bitarray.get(i) != flag)
            {
                j--;
                if(!flag)
                    flag = true;
                else
                    flag = false;
            }
        } while(true);
        if(j >= 0)
        {
            throw NotFoundException.getNotFoundInstance();
        } else
        {
            recordPattern(bitarray, i + 1, ai);
            return;
        }
    }

    public Result decode(BinaryBitmap binarybitmap)
        throws NotFoundException, FormatException
    {
        return decode(binarybitmap, null);
    }

    public Result decode(BinaryBitmap binarybitmap, Map map)
        throws NotFoundException, FormatException
    {
        Result result1 = doDecode(binarybitmap, map);
        Result result = result1;
_L2:
        return result;
        NotFoundException notfoundexception;
        notfoundexception;
        boolean flag;
        BinaryBitmap binarybitmap1;
        Map map1;
        int i;
        ResultPoint aresultpoint[];
        if(map != null && map.containsKey(DecodeHintType.TRY_HARDER))
            flag = true;
        else
            flag = false;
        if(!flag || !binarybitmap.isRotateSupported())
            break; /* Loop/switch isn't completed */
        binarybitmap1 = binarybitmap.rotateCounterClockwise();
        result = doDecode(binarybitmap1, map);
        map1 = result.getResultMetadata();
        i = 270;
        if(map1 != null && map1.containsKey(ResultMetadataType.ORIENTATION))
            i = (i + ((Integer)map1.get(ResultMetadataType.ORIENTATION)).intValue()) % 360;
        result.putMetadata(ResultMetadataType.ORIENTATION, Integer.valueOf(i));
        aresultpoint = result.getResultPoints();
        if(aresultpoint != null)
        {
            int j = binarybitmap1.getHeight();
            int k = 0;
            while(k < aresultpoint.length) 
            {
                aresultpoint[k] = new ResultPoint((float)j - aresultpoint[k].getY() - 1.0F, aresultpoint[k].getX());
                k++;
            }
        }
        if(true) goto _L2; else goto _L1
_L1:
        throw notfoundexception;
    }

    public abstract Result decodeRow(int i, BitArray bitarray, Map map)
        throws NotFoundException, ChecksumException, FormatException;

    public void reset()
    {
    }
}
