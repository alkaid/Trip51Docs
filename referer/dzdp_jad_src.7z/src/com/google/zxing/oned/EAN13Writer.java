// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.oned;

import com.google.zxing.*;
import com.google.zxing.common.BitMatrix;
import java.util.Map;

// Referenced classes of package com.google.zxing.oned:
//            UPCEANWriter, UPCEANReader, EAN13Reader

public final class EAN13Writer extends UPCEANWriter
{

    private static final int CODE_WIDTH = 95;

    public EAN13Writer()
    {
    }

    public BitMatrix encode(String s, BarcodeFormat barcodeformat, int i, int j, Map map)
        throws WriterException
    {
        if(barcodeformat != BarcodeFormat.EAN_13)
            throw new IllegalArgumentException((new StringBuilder()).append("Can only encode EAN_13, but got ").append(barcodeformat).toString());
        else
            return super.encode(s, barcodeformat, i, j, map);
    }

    public boolean[] encode(String s)
    {
        if(s.length() != 13)
            throw new IllegalArgumentException((new StringBuilder()).append("Requested contents should be 13 digits long, but got ").append(s.length()).toString());
        try
        {
            if(!UPCEANReader.checkStandardUPCEANChecksum(s))
                throw new IllegalArgumentException("Contents do not pass checksum");
        }
        catch(FormatException formatexception)
        {
            throw new IllegalArgumentException("Illegal contents");
        }
        int i = Integer.parseInt(s.substring(0, 1));
        int j = EAN13Reader.FIRST_DIGIT_ENCODINGS[i];
        boolean aflag[] = new boolean[95];
        int k = 0 + appendPattern(aflag, 0, UPCEANReader.START_END_PATTERN, true);
        for(int l = 1; l <= 6; l++)
        {
            int l1 = Integer.parseInt(s.substring(l, l + 1));
            if((1 & j >> 6 - l) == 1)
                l1 += 10;
            k += appendPattern(aflag, k, UPCEANReader.L_AND_G_PATTERNS[l1], false);
        }

        int i1 = k + appendPattern(aflag, k, UPCEANReader.MIDDLE_PATTERN, false);
        for(int j1 = 7; j1 <= 12; j1++)
        {
            int k1 = Integer.parseInt(s.substring(j1, j1 + 1));
            i1 += appendPattern(aflag, i1, UPCEANReader.L_PATTERNS[k1], true);
        }

        appendPattern(aflag, i1, UPCEANReader.START_END_PATTERN, true);
        return aflag;
    }
}
