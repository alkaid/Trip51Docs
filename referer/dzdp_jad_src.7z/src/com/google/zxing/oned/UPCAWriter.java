// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.oned;

import com.google.zxing.*;
import com.google.zxing.common.BitMatrix;
import java.util.Map;

// Referenced classes of package com.google.zxing.oned:
//            EAN13Writer

public final class UPCAWriter
    implements Writer
{

    private final EAN13Writer subWriter = new EAN13Writer();

    public UPCAWriter()
    {
    }

    private static String preencode(String s)
    {
        int i = s.length();
        if(i == 11)
        {
            int j = 0;
            int k = 0;
            while(k < 11) 
            {
                int l = -48 + s.charAt(k);
                byte byte0;
                if(k % 2 == 0)
                    byte0 = 3;
                else
                    byte0 = 1;
                j += byte0 * l;
                k++;
            }
            s = (new StringBuilder()).append(s).append((1000 - j) % 10).toString();
        } else
        if(i != 12)
            throw new IllegalArgumentException((new StringBuilder()).append("Requested contents should be 11 or 12 digits long, but got ").append(s.length()).toString());
        return (new StringBuilder()).append('0').append(s).toString();
    }

    public BitMatrix encode(String s, BarcodeFormat barcodeformat, int i, int j)
        throws WriterException
    {
        return encode(s, barcodeformat, i, j, null);
    }

    public BitMatrix encode(String s, BarcodeFormat barcodeformat, int i, int j, Map map)
        throws WriterException
    {
        if(barcodeformat != BarcodeFormat.UPC_A)
            throw new IllegalArgumentException((new StringBuilder()).append("Can only encode UPC-A, but got ").append(barcodeformat).toString());
        else
            return subWriter.encode(preencode(s), BarcodeFormat.EAN_13, i, j, map);
    }
}
