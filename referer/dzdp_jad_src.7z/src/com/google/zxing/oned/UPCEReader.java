// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.oned;

import com.google.zxing.*;
import com.google.zxing.common.BitArray;

// Referenced classes of package com.google.zxing.oned:
//            UPCEANReader

public final class UPCEReader extends UPCEANReader
{

    private static final int MIDDLE_END_PATTERN[];
    private static final int NUMSYS_AND_CHECK_DIGIT_PATTERNS[][];
    private final int decodeMiddleCounters[] = new int[4];

    public UPCEReader()
    {
    }

    public static String convertUPCEtoUPCA(String s)
    {
        char ac[];
        StringBuilder stringbuilder;
        char c;
        ac = new char[6];
        s.getChars(1, 7, ac, 0);
        stringbuilder = new StringBuilder(12);
        stringbuilder.append(s.charAt(0));
        c = ac[5];
        c;
        JVM INSTR tableswitch 48 52: default 76
    //                   48 114
    //                   49 114
    //                   50 114
    //                   51 147
    //                   52 173;
           goto _L1 _L2 _L2 _L2 _L3 _L4
_L1:
        stringbuilder.append(ac, 0, 5);
        stringbuilder.append("0000");
        stringbuilder.append(c);
_L6:
        stringbuilder.append(s.charAt(7));
        return stringbuilder.toString();
_L2:
        stringbuilder.append(ac, 0, 2);
        stringbuilder.append(c);
        stringbuilder.append("0000");
        stringbuilder.append(ac, 2, 3);
        continue; /* Loop/switch isn't completed */
_L3:
        stringbuilder.append(ac, 0, 3);
        stringbuilder.append("00000");
        stringbuilder.append(ac, 3, 2);
        continue; /* Loop/switch isn't completed */
_L4:
        stringbuilder.append(ac, 0, 4);
        stringbuilder.append("00000");
        stringbuilder.append(ac[4]);
        if(true) goto _L6; else goto _L5
_L5:
    }

    private static void determineNumSysAndCheckDigit(StringBuilder stringbuilder, int i)
        throws NotFoundException
    {
        for(int j = 0; j <= 1; j++)
        {
            for(int k = 0; k < 10; k++)
                if(i == NUMSYS_AND_CHECK_DIGIT_PATTERNS[j][k])
                {
                    stringbuilder.insert(0, (char)(j + 48));
                    stringbuilder.append((char)(k + 48));
                    return;
                }

        }

        throw NotFoundException.getNotFoundInstance();
    }

    protected boolean checkChecksum(String s)
        throws FormatException
    {
        return super.checkChecksum(convertUPCEtoUPCA(s));
    }

    protected int[] decodeEnd(BitArray bitarray, int i)
        throws NotFoundException
    {
        return findGuardPattern(bitarray, i, true, MIDDLE_END_PATTERN);
    }

    protected int decodeMiddle(BitArray bitarray, int ai[], StringBuilder stringbuilder)
        throws NotFoundException
    {
        int ai1[] = decodeMiddleCounters;
        ai1[0] = 0;
        ai1[1] = 0;
        ai1[2] = 0;
        ai1[3] = 0;
        int i = bitarray.getSize();
        int j = ai[1];
        int k = 0;
        for(int l = 0; l < 6 && j < i; l++)
        {
            int i1 = decodeDigit(bitarray, ai1, j, L_AND_G_PATTERNS);
            stringbuilder.append((char)(48 + i1 % 10));
            int j1 = ai1.length;
            for(int k1 = 0; k1 < j1; k1++)
                j += ai1[k1];

            if(i1 >= 10)
                k |= 1 << 5 - l;
        }

        determineNumSysAndCheckDigit(stringbuilder, k);
        return j;
    }

    BarcodeFormat getBarcodeFormat()
    {
        return BarcodeFormat.UPC_E;
    }

    static 
    {
        int ai[] = new int[6];
        ai[0] = 1;
        ai[1] = 1;
        ai[2] = 1;
        ai[3] = 1;
        ai[4] = 1;
        ai[5] = 1;
        MIDDLE_END_PATTERN = ai;
        int ai1[][] = new int[2][];
        int ai2[] = new int[10];
        ai2[0] = 56;
        ai2[1] = 52;
        ai2[2] = 50;
        ai2[3] = 49;
        ai2[4] = 44;
        ai2[5] = 38;
        ai2[6] = 35;
        ai2[7] = 42;
        ai2[8] = 41;
        ai2[9] = 37;
        ai1[0] = ai2;
        int ai3[] = new int[10];
        ai3[0] = 7;
        ai3[1] = 11;
        ai3[2] = 13;
        ai3[3] = 14;
        ai3[4] = 19;
        ai3[5] = 25;
        ai3[6] = 28;
        ai3[7] = 21;
        ai3[8] = 22;
        ai3[9] = 26;
        ai1[1] = ai3;
        NUMSYS_AND_CHECK_DIGIT_PATTERNS = ai1;
    }
}
