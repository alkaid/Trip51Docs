// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.oned;

import com.google.zxing.*;
import com.google.zxing.common.BitArray;
import java.util.Arrays;
import java.util.Map;

// Referenced classes of package com.google.zxing.oned:
//            OneDReader

public final class Code39Reader extends OneDReader
{

    private static final char ALPHABET[] = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ-. *$/+%".toCharArray();
    static final String ALPHABET_STRING = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ-. *$/+%";
    private static final int ASTERISK_ENCODING;
    static final int CHARACTER_ENCODINGS[];
    private final int counters[];
    private final StringBuilder decodeRowResult;
    private final boolean extendedMode;
    private final boolean usingCheckDigit;

    public Code39Reader()
    {
        this(false);
    }

    public Code39Reader(boolean flag)
    {
        this(flag, false);
    }

    public Code39Reader(boolean flag, boolean flag1)
    {
        usingCheckDigit = flag;
        extendedMode = flag1;
        decodeRowResult = new StringBuilder(20);
        counters = new int[9];
    }

    private static String decodeExtended(CharSequence charsequence)
        throws FormatException
    {
        int i;
        StringBuilder stringbuilder;
        int j;
        i = charsequence.length();
        stringbuilder = new StringBuilder(i);
        j = 0;
_L8:
        char c;
        char c1;
        int k;
        if(j >= i)
            break MISSING_BLOCK_LABEL_296;
        c = charsequence.charAt(j);
        if(c != '+' && c != '$' && c != '%' && c != '/')
            break MISSING_BLOCK_LABEL_286;
        c1 = charsequence.charAt(j + 1);
        k = 0;
        c;
        JVM INSTR lookupswitch 4: default 120
    //                   36: 164
    //                   37: 192
    //                   43: 136
    //                   47: 244;
           goto _L1 _L2 _L3 _L4 _L5
_L1:
        stringbuilder.append(k);
        j++;
_L6:
        j++;
        continue; /* Loop/switch isn't completed */
_L4:
        if(c1 >= 'A' && c1 <= 'Z')
            k = c1 + 32;
        else
            throw FormatException.getFormatInstance();
          goto _L1
_L2:
        if(c1 >= 'A' && c1 <= 'Z')
            k = c1 + -64;
        else
            throw FormatException.getFormatInstance();
          goto _L1
_L3:
        if(c1 >= 'A' && c1 <= 'E')
            k = c1 + -38;
        else
        if(c1 >= 'F' && c1 <= 'W')
            k = c1 + -11;
        else
            throw FormatException.getFormatInstance();
          goto _L1
_L5:
        if(c1 >= 'A' && c1 <= 'O')
            k = c1 + -32;
        else
        if(c1 == 'Z')
            k = 58;
        else
            throw FormatException.getFormatInstance();
          goto _L1
        stringbuilder.append(c);
          goto _L6
        return stringbuilder.toString();
        if(true) goto _L8; else goto _L7
_L7:
    }

    private static int[] findAsteriskPattern(BitArray bitarray, int ai[])
        throws NotFoundException
    {
        int i = bitarray.getSize();
        int j = bitarray.getNextSet(0);
        int k = 0;
        int l = j;
        boolean flag = false;
        int i1 = ai.length;
        int j1 = j;
        while(j1 < i) 
        {
            if(flag ^ bitarray.get(j1))
            {
                ai[k] = 1 + ai[k];
            } else
            {
                if(k == i1 - 1)
                {
                    if(toNarrowWidePattern(ai) == ASTERISK_ENCODING && bitarray.isRange(Math.max(0, l - (j1 - l) / 2), l, false))
                    {
                        int ai1[] = new int[2];
                        ai1[0] = l;
                        ai1[1] = j1;
                        return ai1;
                    }
                    l += ai[0] + ai[1];
                    System.arraycopy(ai, 2, ai, 0, i1 - 2);
                    ai[i1 - 2] = 0;
                    ai[i1 - 1] = 0;
                    k--;
                } else
                {
                    k++;
                }
                ai[k] = 1;
                if(!flag)
                    flag = true;
                else
                    flag = false;
            }
            j1++;
        }
        throw NotFoundException.getNotFoundInstance();
    }

    private static char patternToChar(int i)
        throws NotFoundException
    {
        for(int j = 0; j < CHARACTER_ENCODINGS.length; j++)
            if(CHARACTER_ENCODINGS[j] == i)
                return ALPHABET[j];

        throw NotFoundException.getNotFoundInstance();
    }

    private static int toNarrowWidePattern(int ai[])
    {
        int i;
        int j;
        i = ai.length;
        j = 0;
_L8:
        int j1;
        int k1;
        int l1;
        int j2;
        int k = 0x7fffffff;
        int l = ai.length;
        for(int i1 = 0; i1 < l; i1++)
        {
            int i3 = ai[i1];
            if(i3 < k && i3 > j)
                k = i3;
        }

        j = k;
        j1 = 0;
        k1 = 0;
        l1 = 0;
        for(int i2 = 0; i2 < i; i2++)
        {
            int l2 = ai[i2];
            if(l2 > j)
            {
                l1 |= 1 << i - 1 - i2;
                j1++;
                k1 += l2;
            }
        }

        if(j1 != 3)
            continue; /* Loop/switch isn't completed */
        j2 = 0;
_L6:
        if(j2 >= i || j1 <= 0) goto _L2; else goto _L1
_L1:
        int k2 = ai[j2];
        if(k2 <= j) goto _L4; else goto _L3
_L3:
        j1--;
        if(k2 * 2 < k1) goto _L4; else goto _L5
_L5:
        l1 = -1;
_L2:
        return l1;
_L4:
        j2++;
          goto _L6
        if(j1 > 3) goto _L8; else goto _L7
_L7:
        l1 = -1;
          goto _L2
    }

    public Result decodeRow(int i, BitArray bitarray, Map map)
        throws NotFoundException, ChecksumException, FormatException
    {
        int ai[] = counters;
        Arrays.fill(ai, 0);
        StringBuilder stringbuilder = decodeRowResult;
        stringbuilder.setLength(0);
        int ai1[] = findAsteriskPattern(bitarray, ai);
        int j = bitarray.getNextSet(ai1[1]);
        int k = bitarray.getSize();
        char c;
        int i1;
        do
        {
            recordPattern(bitarray, j, ai);
            int l = toNarrowWidePattern(ai);
            if(l < 0)
                throw NotFoundException.getNotFoundInstance();
            c = patternToChar(l);
            stringbuilder.append(c);
            i1 = j;
            int j1 = ai.length;
            for(int k1 = 0; k1 < j1; k1++)
                j += ai[k1];

            j = bitarray.getNextSet(j);
        } while(c != '*');
        stringbuilder.setLength(-1 + stringbuilder.length());
        int l1 = 0;
        int i2 = ai.length;
        for(int j2 = 0; j2 < i2; j2++)
            l1 += ai[j2];

        int k2 = j - i1 - l1;
        if(j != k && k2 * 2 < l1)
            throw NotFoundException.getNotFoundInstance();
        if(usingCheckDigit)
        {
            int l2 = -1 + stringbuilder.length();
            int i3 = 0;
            for(int j3 = 0; j3 < l2; j3++)
                i3 += "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ-. *$/+%".indexOf(decodeRowResult.charAt(j3));

            if(stringbuilder.charAt(l2) != ALPHABET[i3 % 43])
                throw ChecksumException.getChecksumInstance();
            stringbuilder.setLength(l2);
        }
        if(stringbuilder.length() == 0)
            throw NotFoundException.getNotFoundInstance();
        String s;
        float f;
        float f1;
        ResultPoint aresultpoint[];
        ResultPoint resultpoint;
        ResultPoint resultpoint1;
        Result result;
        if(extendedMode)
            s = decodeExtended(stringbuilder);
        else
            s = stringbuilder.toString();
        f = (float)(ai1[1] + ai1[0]) / 2.0F;
        f1 = (float)i1 + (float)l1 / 2.0F;
        aresultpoint = new ResultPoint[2];
        resultpoint = new ResultPoint(f, i);
        aresultpoint[0] = resultpoint;
        resultpoint1 = new ResultPoint(f1, i);
        aresultpoint[1] = resultpoint1;
        result = new Result(s, null, aresultpoint, BarcodeFormat.CODE_39);
        return result;
    }

    static 
    {
        int ai[] = new int[44];
        ai[0] = 52;
        ai[1] = 289;
        ai[2] = 97;
        ai[3] = 352;
        ai[4] = 49;
        ai[5] = 304;
        ai[6] = 112;
        ai[7] = 37;
        ai[8] = 292;
        ai[9] = 100;
        ai[10] = 265;
        ai[11] = 73;
        ai[12] = 328;
        ai[13] = 25;
        ai[14] = 280;
        ai[15] = 88;
        ai[16] = 13;
        ai[17] = 268;
        ai[18] = 76;
        ai[19] = 28;
        ai[20] = 259;
        ai[21] = 67;
        ai[22] = 322;
        ai[23] = 19;
        ai[24] = 274;
        ai[25] = 82;
        ai[26] = 7;
        ai[27] = 262;
        ai[28] = 70;
        ai[29] = 22;
        ai[30] = 385;
        ai[31] = 193;
        ai[32] = 448;
        ai[33] = 145;
        ai[34] = 400;
        ai[35] = 208;
        ai[36] = 133;
        ai[37] = 388;
        ai[38] = 196;
        ai[39] = 148;
        ai[40] = 168;
        ai[41] = 162;
        ai[42] = 138;
        ai[43] = 42;
        CHARACTER_ENCODINGS = ai;
        ASTERISK_ENCODING = CHARACTER_ENCODINGS[39];
    }
}
