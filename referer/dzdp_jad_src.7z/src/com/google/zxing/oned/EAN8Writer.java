// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.oned;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import java.util.Map;

// Referenced classes of package com.google.zxing.oned:
//            UPCEANWriter, UPCEANReader

public final class EAN8Writer extends UPCEANWriter
{

    private static final int CODE_WIDTH = 67;

    public EAN8Writer()
    {
    }

    public BitMatrix encode(String s, BarcodeFormat barcodeformat, int i, int j, Map map)
        throws WriterException
    {
        if(barcodeformat != BarcodeFormat.EAN_8)
            throw new IllegalArgumentException((new StringBuilder()).append("Can only encode EAN_8, but got ").append(barcodeformat).toString());
        else
            return super.encode(s, barcodeformat, i, j, map);
    }

    public boolean[] encode(String s)
    {
        if(s.length() != 8)
            throw new IllegalArgumentException((new StringBuilder()).append("Requested contents should be 8 digits long, but got ").append(s.length()).toString());
        boolean aflag[] = new boolean[67];
        int i = 0 + appendPattern(aflag, 0, UPCEANReader.START_END_PATTERN, true);
        for(int j = 0; j <= 3; j++)
        {
            int j1 = Integer.parseInt(s.substring(j, j + 1));
            i += appendPattern(aflag, i, UPCEANReader.L_PATTERNS[j1], false);
        }

        int k = i + appendPattern(aflag, i, UPCEANReader.MIDDLE_PATTERN, false);
        for(int l = 4; l <= 7; l++)
        {
            int i1 = Integer.parseInt(s.substring(l, l + 1));
            k += appendPattern(aflag, k, UPCEANReader.L_PATTERNS[i1], true);
        }

        appendPattern(aflag, k, UPCEANReader.START_END_PATTERN, true);
        return aflag;
    }
}
