// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.oned;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.NotFoundException;
import com.google.zxing.common.BitArray;

// Referenced classes of package com.google.zxing.oned:
//            UPCEANReader

public final class EAN13Reader extends UPCEANReader
{

    static final int FIRST_DIGIT_ENCODINGS[];
    private final int decodeMiddleCounters[] = new int[4];

    public EAN13Reader()
    {
    }

    private static void determineFirstDigit(StringBuilder stringbuilder, int i)
        throws NotFoundException
    {
        for(int j = 0; j < 10; j++)
            if(i == FIRST_DIGIT_ENCODINGS[j])
            {
                stringbuilder.insert(0, (char)(j + 48));
                return;
            }

        throw NotFoundException.getNotFoundInstance();
    }

    protected int decodeMiddle(BitArray bitarray, int ai[], StringBuilder stringbuilder)
        throws NotFoundException
    {
        int ai1[] = decodeMiddleCounters;
        ai1[0] = 0;
        ai1[1] = 0;
        ai1[2] = 0;
        ai1[3] = 0;
        int i = bitarray.getSize();
        int j = ai[1];
        int k = 0;
        for(int l = 0; l < 6 && j < i; l++)
        {
            int i2 = decodeDigit(bitarray, ai1, j, L_AND_G_PATTERNS);
            stringbuilder.append((char)(48 + i2 % 10));
            int j2 = ai1.length;
            for(int k2 = 0; k2 < j2; k2++)
                j += ai1[k2];

            if(i2 >= 10)
                k |= 1 << 5 - l;
        }

        determineFirstDigit(stringbuilder, k);
        int i1 = findGuardPattern(bitarray, j, true, MIDDLE_PATTERN)[1];
        for(int j1 = 0; j1 < 6 && i1 < i; j1++)
        {
            stringbuilder.append((char)(48 + decodeDigit(bitarray, ai1, i1, L_PATTERNS)));
            int k1 = ai1.length;
            for(int l1 = 0; l1 < k1; l1++)
                i1 += ai1[l1];

        }

        return i1;
    }

    BarcodeFormat getBarcodeFormat()
    {
        return BarcodeFormat.EAN_13;
    }

    static 
    {
        int ai[] = new int[10];
        ai[0] = 0;
        ai[1] = 11;
        ai[2] = 13;
        ai[3] = 14;
        ai[4] = 19;
        ai[5] = 25;
        ai[6] = 28;
        ai[7] = 21;
        ai[8] = 22;
        ai[9] = 26;
        FIRST_DIGIT_ENCODINGS = ai;
    }
}
