// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.oned.rss.expanded.decoders;

import com.google.zxing.common.BitArray;

// Referenced classes of package com.google.zxing.oned.rss.expanded.decoders:
//            AbstractExpandedDecoder, GeneralAppIdDecoder

abstract class AI01decoder extends AbstractExpandedDecoder
{

    protected static final int GTIN_SIZE = 40;

    AI01decoder(BitArray bitarray)
    {
        super(bitarray);
    }

    private static void appendCheckDigit(StringBuilder stringbuilder, int i)
    {
        int j = 0;
        for(int k = 0; k < 13; k++)
        {
            int i1 = -48 + stringbuilder.charAt(k + i);
            if((k & 1) == 0)
                i1 *= 3;
            j += i1;
        }

        int l = 10 - j % 10;
        if(l == 10)
            l = 0;
        stringbuilder.append(l);
    }

    protected final void encodeCompressedGtin(StringBuilder stringbuilder, int i)
    {
        stringbuilder.append("(01)");
        int j = stringbuilder.length();
        stringbuilder.append('9');
        encodeCompressedGtinWithoutAI(stringbuilder, i, j);
    }

    protected final void encodeCompressedGtinWithoutAI(StringBuilder stringbuilder, int i, int j)
    {
        for(int k = 0; k < 4; k++)
        {
            int l = getGeneralDecoder().extractNumericValueFromBitArray(i + k * 10, 10);
            if(l / 100 == 0)
                stringbuilder.append('0');
            if(l / 10 == 0)
                stringbuilder.append('0');
            stringbuilder.append(l);
        }

        appendCheckDigit(stringbuilder, j);
    }
}
