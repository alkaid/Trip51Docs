// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.oned.rss;

import com.google.zxing.NotFoundException;
import com.google.zxing.oned.OneDReader;

public abstract class AbstractRSSReader extends OneDReader
{

    private static final float MAX_AVG_VARIANCE = 0.2F;
    private static final float MAX_FINDER_PATTERN_RATIO = 0.8928571F;
    private static final float MAX_INDIVIDUAL_VARIANCE = 0.45F;
    private static final float MIN_FINDER_PATTERN_RATIO = 0.7916667F;
    private final int dataCharacterCounters[] = new int[8];
    private final int decodeFinderCounters[] = new int[4];
    private final int evenCounts[];
    private final float evenRoundingErrors[] = new float[4];
    private final int oddCounts[];
    private final float oddRoundingErrors[] = new float[4];

    protected AbstractRSSReader()
    {
        oddCounts = new int[dataCharacterCounters.length / 2];
        evenCounts = new int[dataCharacterCounters.length / 2];
    }

    protected static int count(int ai[])
    {
        int i = 0;
        int j = ai.length;
        for(int k = 0; k < j; k++)
            i += ai[k];

        return i;
    }

    protected static void decrement(int ai[], float af[])
    {
        int i = 0;
        float f = af[0];
        for(int j = 1; j < ai.length; j++)
            if(af[j] < f)
            {
                f = af[j];
                i = j;
            }

        ai[i] = -1 + ai[i];
    }

    protected static void increment(int ai[], float af[])
    {
        int i = 0;
        float f = af[0];
        for(int j = 1; j < ai.length; j++)
            if(af[j] > f)
            {
                f = af[j];
                i = j;
            }

        ai[i] = 1 + ai[i];
    }

    protected static boolean isFinderPattern(int ai[])
    {
        boolean flag = true;
        int i = ai[0] + ai[flag];
        int j = i + ai[2] + ai[3];
        float f = (float)i / (float)j;
        if(f >= 0.7916667F && f <= 0.8928571F)
        {
            int k = 0x7fffffff;
            int l = 0x80000000;
            int i1 = ai.length;
            for(int j1 = 0; j1 < i1; j1++)
            {
                int k1 = ai[j1];
                if(k1 > l)
                    l = k1;
                if(k1 < k)
                    k = k1;
            }

            if(l >= k * 10)
                flag = false;
        } else
        {
            flag = false;
        }
        return flag;
    }

    protected static int parseFinderValue(int ai[], int ai1[][])
        throws NotFoundException
    {
        for(int i = 0; i < ai1.length; i++)
            if(patternMatchVariance(ai, ai1[i], 0.45F) < 0.2F)
                return i;

        throw NotFoundException.getNotFoundInstance();
    }

    protected final int[] getDataCharacterCounters()
    {
        return dataCharacterCounters;
    }

    protected final int[] getDecodeFinderCounters()
    {
        return decodeFinderCounters;
    }

    protected final int[] getEvenCounts()
    {
        return evenCounts;
    }

    protected final float[] getEvenRoundingErrors()
    {
        return evenRoundingErrors;
    }

    protected final int[] getOddCounts()
    {
        return oddCounts;
    }

    protected final float[] getOddRoundingErrors()
    {
        return oddRoundingErrors;
    }
}
