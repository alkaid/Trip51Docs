// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.oned.rss.expanded.decoders;


// Referenced classes of package com.google.zxing.oned.rss.expanded.decoders:
//            DecodedInformation

final class BlockParsedResult
{

    private final DecodedInformation decodedInformation;
    private final boolean finished;

    BlockParsedResult(DecodedInformation decodedinformation, boolean flag)
    {
        finished = flag;
        decodedInformation = decodedinformation;
    }

    BlockParsedResult(boolean flag)
    {
        this(null, flag);
    }

    DecodedInformation getDecodedInformation()
    {
        return decodedInformation;
    }

    boolean isFinished()
    {
        return finished;
    }
}
