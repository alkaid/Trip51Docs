// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.oned.rss;


public final class RSSUtils
{

    private RSSUtils()
    {
    }

    private static int combins(int i, int j)
    {
        int k;
        int l;
        int i1;
        int j1;
        if(i - j > j)
        {
            k = j;
            l = i - j;
        } else
        {
            k = i - j;
            l = j;
        }
        i1 = 1;
        j1 = 1;
        for(int k1 = i; k1 > l; k1--)
        {
            i1 *= k1;
            if(j1 <= k)
            {
                i1 /= j1;
                j1++;
            }
        }

        for(; j1 <= k; j1++)
            i1 /= j1;

        return i1;
    }

    public static int getRSSvalue(int ai[], int i, boolean flag)
    {
        int j = ai.length;
        int k = 0;
        int l = ai.length;
        for(int i1 = 0; i1 < l; i1++)
            k += ai[i1];

        int j1 = 0;
        int k1 = 0;
        int l1 = 0;
        do
        {
            if(l1 >= j - 1)
                break;
            int i2 = 1;
            k1 |= 1 << l1;
            while(i2 < ai[l1]) 
            {
                int j2 = combins(-1 + (k - i2), -2 + (j - l1));
                if(flag && k1 == 0 && k - i2 - (-1 + (j - l1)) >= -1 + (j - l1))
                    j2 -= combins(k - i2 - (j - l1), -2 + (j - l1));
                if(-1 + (j - l1) > 1)
                {
                    int k2 = 0;
                    for(int l2 = k - i2 - (-2 + (j - l1)); l2 > i; l2--)
                        k2 += combins(-1 + (k - i2 - l2), -3 + (j - l1));

                    j2 -= k2 * (j - 1 - l1);
                } else
                if(k - i2 > i)
                    j2--;
                j1 += j2;
                i2++;
                k1 &= -1 ^ 1 << l1;
            }
            k -= i2;
            l1++;
        } while(true);
        return j1;
    }
}
