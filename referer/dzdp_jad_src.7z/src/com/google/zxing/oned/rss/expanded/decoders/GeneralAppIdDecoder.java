// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.oned.rss.expanded.decoders;

import com.google.zxing.FormatException;
import com.google.zxing.NotFoundException;
import com.google.zxing.common.BitArray;

// Referenced classes of package com.google.zxing.oned.rss.expanded.decoders:
//            CurrentParsingState, DecodedChar, DecodedNumeric, BlockParsedResult, 
//            DecodedInformation, FieldParser

final class GeneralAppIdDecoder
{

    private final StringBuilder buffer = new StringBuilder();
    private final CurrentParsingState current = new CurrentParsingState();
    private final BitArray information;

    GeneralAppIdDecoder(BitArray bitarray)
    {
        information = bitarray;
    }

    private DecodedChar decodeAlphanumeric(int i)
    {
        int j = extractNumericValueFromBitArray(i, 5);
        if(j != 15) goto _L2; else goto _L1
_L1:
        DecodedChar decodedchar = new DecodedChar(i + 5, '$');
_L10:
        return decodedchar;
_L2:
        int k;
        if(j >= 5 && j < 15)
        {
            decodedchar = new DecodedChar(i + 5, (char)(-5 + (j + 48)));
            continue; /* Loop/switch isn't completed */
        }
        k = extractNumericValueFromBitArray(i, 6);
        if(k >= 32 && k < 58)
        {
            decodedchar = new DecodedChar(i + 6, (char)(k + 33));
            continue; /* Loop/switch isn't completed */
        }
        k;
        JVM INSTR tableswitch 58 62: default 140
    //                   58 168
    //                   59 189
    //                   60 196
    //                   61 203
    //                   62 210;
           goto _L3 _L4 _L5 _L6 _L7 _L8
_L8:
        break MISSING_BLOCK_LABEL_210;
_L5:
        break; /* Loop/switch isn't completed */
_L3:
        throw new IllegalStateException((new StringBuilder()).append("Decoding invalid alphanumeric value: ").append(k).toString());
_L4:
        char c = '*';
_L11:
        decodedchar = new DecodedChar(i + 6, c);
        if(true) goto _L10; else goto _L9
_L9:
        c = ',';
          goto _L11
_L6:
        c = '-';
          goto _L11
_L7:
        c = '.';
          goto _L11
        c = '/';
          goto _L11
    }

    private DecodedChar decodeIsoIec646(int i)
        throws FormatException
    {
        int j = extractNumericValueFromBitArray(i, 5);
        if(j != 15) goto _L2; else goto _L1
_L1:
        DecodedChar decodedchar = new DecodedChar(i + 5, '$');
_L26:
        return decodedchar;
_L2:
        if(j >= 5 && j < 15)
        {
            decodedchar = new DecodedChar(i + 5, (char)(-5 + (j + 48)));
            continue; /* Loop/switch isn't completed */
        }
        int k = extractNumericValueFromBitArray(i, 7);
        if(k >= 64 && k < 90)
        {
            decodedchar = new DecodedChar(i + 7, (char)(k + 1));
            continue; /* Loop/switch isn't completed */
        }
        if(k >= 90 && k < 116)
        {
            decodedchar = new DecodedChar(i + 7, (char)(k + 7));
            continue; /* Loop/switch isn't completed */
        }
        extractNumericValueFromBitArray(i, 8);
        JVM INSTR tableswitch 232 252: default 244
    //                   232 248
    //                   233 269
    //                   234 276
    //                   235 283
    //                   236 290
    //                   237 297
    //                   238 304
    //                   239 311
    //                   240 318
    //                   241 325
    //                   242 332
    //                   243 339
    //                   244 346
    //                   245 353
    //                   246 360
    //                   247 367
    //                   248 374
    //                   249 381
    //                   250 388
    //                   251 395
    //                   252 402;
           goto _L3 _L4 _L5 _L6 _L7 _L8 _L9 _L10 _L11 _L12 _L13 _L14 _L15 _L16 _L17 _L18 _L19 _L20 _L21 _L22 _L23 _L24
_L24:
        break MISSING_BLOCK_LABEL_402;
_L5:
        break; /* Loop/switch isn't completed */
_L3:
        throw FormatException.getFormatInstance();
_L4:
        char c = '!';
_L27:
        decodedchar = new DecodedChar(i + 8, c);
        if(true) goto _L26; else goto _L25
_L25:
        c = '"';
          goto _L27
_L6:
        c = '%';
          goto _L27
_L7:
        c = '&';
          goto _L27
_L8:
        c = '\'';
          goto _L27
_L9:
        c = '(';
          goto _L27
_L10:
        c = ')';
          goto _L27
_L11:
        c = '*';
          goto _L27
_L12:
        c = '+';
          goto _L27
_L13:
        c = ',';
          goto _L27
_L14:
        c = '-';
          goto _L27
_L15:
        c = '.';
          goto _L27
_L16:
        c = '/';
          goto _L27
_L17:
        c = ':';
          goto _L27
_L18:
        c = ';';
          goto _L27
_L19:
        c = '<';
          goto _L27
_L20:
        c = '=';
          goto _L27
_L21:
        c = '>';
          goto _L27
_L22:
        c = '?';
          goto _L27
_L23:
        c = '_';
          goto _L27
        c = ' ';
          goto _L27
    }

    private DecodedNumeric decodeNumeric(int i)
        throws FormatException
    {
        DecodedNumeric decodednumeric;
        if(i + 7 > information.getSize())
        {
            int i1 = extractNumericValueFromBitArray(i, 4);
            if(i1 == 0)
                decodednumeric = new DecodedNumeric(information.getSize(), 10, 10);
            else
                decodednumeric = new DecodedNumeric(information.getSize(), i1 - 1, 10);
        } else
        {
            int j = extractNumericValueFromBitArray(i, 7);
            int k = (j - 8) / 11;
            int l = (j - 8) % 11;
            decodednumeric = new DecodedNumeric(i + 7, k, l);
        }
        return decodednumeric;
    }

    static int extractNumericValueFromBitArray(BitArray bitarray, int i, int j)
    {
        int k = 0;
        for(int l = 0; l < j; l++)
            if(bitarray.get(i + l))
                k |= 1 << -1 + (j - l);

        return k;
    }

    private boolean isAlphaOr646ToNumericLatch(int i)
    {
        boolean flag = false;
        if(i + 3 <= information.getSize()) goto _L2; else goto _L1
_L1:
        return flag;
_L2:
        for(int j = i; j < i + 3; j++)
            if(information.get(j))
                continue; /* Loop/switch isn't completed */

        flag = true;
        if(true) goto _L1; else goto _L3
_L3:
    }

    private boolean isAlphaTo646ToAlphaLatch(int i)
    {
        boolean flag = false;
        if(i + 1 <= information.getSize()) goto _L2; else goto _L1
_L1:
        return flag;
_L2:
        for(int j = 0; j < 5 && j + i < information.getSize();)
            if(j != 2 ? !information.get(i + j) : information.get(i + 2))
                j++;
            else
                continue; /* Loop/switch isn't completed */

        flag = true;
        if(true) goto _L1; else goto _L3
_L3:
    }

    private boolean isNumericToAlphaNumericLatch(int i)
    {
        boolean flag = false;
        if(i + 1 <= information.getSize()) goto _L2; else goto _L1
_L1:
        return flag;
_L2:
        for(int j = 0; j < 4 && j + i < information.getSize(); j++)
            if(information.get(i + j))
                continue; /* Loop/switch isn't completed */

        flag = true;
        if(true) goto _L1; else goto _L3
_L3:
    }

    private boolean isStillAlpha(int i)
    {
        boolean flag;
        boolean flag1;
        flag = true;
        flag1 = false;
        if(i + 5 <= information.getSize()) goto _L2; else goto _L1
_L1:
        return flag1;
_L2:
        int j = extractNumericValueFromBitArray(i, 5);
        if(j >= 5 && j < 16)
            flag1 = flag;
        else
        if(i + 6 <= information.getSize())
        {
            int k = extractNumericValueFromBitArray(i, 6);
            if(k < 16 || k >= 63)
                flag = false;
            flag1 = flag;
        }
        if(true) goto _L1; else goto _L3
_L3:
    }

    private boolean isStillIsoIec646(int i)
    {
        boolean flag;
        boolean flag1;
        flag = true;
        flag1 = false;
        if(i + 5 <= information.getSize()) goto _L2; else goto _L1
_L1:
        return flag1;
_L2:
        int j = extractNumericValueFromBitArray(i, 5);
        if(j >= 5 && j < 16)
            flag1 = flag;
        else
        if(i + 7 <= information.getSize())
        {
            int k = extractNumericValueFromBitArray(i, 7);
            if(k >= 64 && k < 116)
                flag1 = flag;
            else
            if(i + 8 <= information.getSize())
            {
                int l = extractNumericValueFromBitArray(i, 8);
                if(l < 232 || l >= 253)
                    flag = false;
                flag1 = flag;
            }
        }
        if(true) goto _L1; else goto _L3
_L3:
    }

    private boolean isStillNumeric(int i)
    {
        boolean flag = true;
        if(i + 7 <= information.getSize()) goto _L2; else goto _L1
_L1:
        if(i + 4 > information.getSize())
            flag = false;
_L4:
        return flag;
_L2:
        for(int j = i; j < i + 3; j++)
            if(information.get(j))
                continue; /* Loop/switch isn't completed */

        flag = information.get(i + 3);
        if(true) goto _L4; else goto _L3
_L3:
    }

    private BlockParsedResult parseAlphaBlock()
    {
_L3:
        DecodedChar decodedchar;
        if(!isStillAlpha(current.getPosition()))
            break MISSING_BLOCK_LABEL_91;
        decodedchar = decodeAlphanumeric(current.getPosition());
        current.setPosition(decodedchar.getNewPosition());
        if(!decodedchar.isFNC1()) goto _L2; else goto _L1
_L1:
        BlockParsedResult blockparsedresult = new BlockParsedResult(new DecodedInformation(current.getPosition(), buffer.toString()), true);
_L4:
        return blockparsedresult;
_L2:
        buffer.append(decodedchar.getValue());
          goto _L3
        if(isAlphaOr646ToNumericLatch(current.getPosition()))
        {
            current.incrementPosition(3);
            current.setNumeric();
        } else
        if(isAlphaTo646ToAlphaLatch(current.getPosition()))
        {
            if(5 + current.getPosition() < information.getSize())
                current.incrementPosition(5);
            else
                current.setPosition(information.getSize());
            current.setIsoIec646();
        }
        blockparsedresult = new BlockParsedResult(false);
          goto _L4
    }

    private DecodedInformation parseBlocks()
        throws FormatException
    {
        do
        {
            int i = current.getPosition();
            BlockParsedResult blockparsedresult;
            boolean flag;
            boolean flag1;
            if(current.isAlpha())
            {
                blockparsedresult = parseAlphaBlock();
                flag = blockparsedresult.isFinished();
            } else
            if(current.isIsoIec646())
            {
                blockparsedresult = parseIsoIec646Block();
                flag = blockparsedresult.isFinished();
            } else
            {
                blockparsedresult = parseNumericBlock();
                flag = blockparsedresult.isFinished();
            }
            if(i != current.getPosition())
                flag1 = true;
            else
                flag1 = false;
            while(!flag1 && !flag || flag) 
                return blockparsedresult.getDecodedInformation();
        } while(true);
    }

    private BlockParsedResult parseIsoIec646Block()
        throws FormatException
    {
_L3:
        DecodedChar decodedchar;
        if(!isStillIsoIec646(current.getPosition()))
            break MISSING_BLOCK_LABEL_91;
        decodedchar = decodeIsoIec646(current.getPosition());
        current.setPosition(decodedchar.getNewPosition());
        if(!decodedchar.isFNC1()) goto _L2; else goto _L1
_L1:
        BlockParsedResult blockparsedresult = new BlockParsedResult(new DecodedInformation(current.getPosition(), buffer.toString()), true);
_L4:
        return blockparsedresult;
_L2:
        buffer.append(decodedchar.getValue());
          goto _L3
        if(isAlphaOr646ToNumericLatch(current.getPosition()))
        {
            current.incrementPosition(3);
            current.setNumeric();
        } else
        if(isAlphaTo646ToAlphaLatch(current.getPosition()))
        {
            if(5 + current.getPosition() < information.getSize())
                current.incrementPosition(5);
            else
                current.setPosition(information.getSize());
            current.setAlpha();
        }
        blockparsedresult = new BlockParsedResult(false);
          goto _L4
    }

    private BlockParsedResult parseNumericBlock()
        throws FormatException
    {
_L1:
        BlockParsedResult blockparsedresult;
        DecodedNumeric decodednumeric;
        if(!isStillNumeric(current.getPosition()))
            break MISSING_BLOCK_LABEL_184;
        decodednumeric = decodeNumeric(current.getPosition());
        current.setPosition(decodednumeric.getNewPosition());
        if(decodednumeric.isFirstDigitFNC1())
        {
            DecodedInformation decodedinformation;
            if(decodednumeric.isSecondDigitFNC1())
                decodedinformation = new DecodedInformation(current.getPosition(), buffer.toString());
            else
                decodedinformation = new DecodedInformation(current.getPosition(), buffer.toString(), decodednumeric.getSecondDigit());
            blockparsedresult = new BlockParsedResult(decodedinformation, true);
        } else
        {
label0:
            {
                buffer.append(decodednumeric.getFirstDigit());
                if(!decodednumeric.isSecondDigitFNC1())
                    break label0;
                blockparsedresult = new BlockParsedResult(new DecodedInformation(current.getPosition(), buffer.toString()), true);
            }
        }
_L2:
        return blockparsedresult;
        buffer.append(decodednumeric.getSecondDigit());
          goto _L1
        if(isNumericToAlphaNumericLatch(current.getPosition()))
        {
            current.setAlpha();
            current.incrementPosition(4);
        }
        blockparsedresult = new BlockParsedResult(false);
          goto _L2
    }

    String decodeAllCodes(StringBuilder stringbuilder, int i)
        throws NotFoundException, FormatException
    {
        int j = i;
        String s = null;
        do
        {
            DecodedInformation decodedinformation = decodeGeneralPurposeField(j, s);
            String s1 = FieldParser.parseFieldsInGeneralPurpose(decodedinformation.getNewString());
            if(s1 != null)
                stringbuilder.append(s1);
            if(decodedinformation.isRemaining())
                s = String.valueOf(decodedinformation.getRemainingValue());
            else
                s = null;
            if(j == decodedinformation.getNewPosition())
                return stringbuilder.toString();
            j = decodedinformation.getNewPosition();
        } while(true);
    }

    DecodedInformation decodeGeneralPurposeField(int i, String s)
        throws FormatException
    {
        buffer.setLength(0);
        if(s != null)
            buffer.append(s);
        current.setPosition(i);
        DecodedInformation decodedinformation = parseBlocks();
        DecodedInformation decodedinformation1;
        if(decodedinformation != null && decodedinformation.isRemaining())
            decodedinformation1 = new DecodedInformation(current.getPosition(), buffer.toString(), decodedinformation.getRemainingValue());
        else
            decodedinformation1 = new DecodedInformation(current.getPosition(), buffer.toString());
        return decodedinformation1;
    }

    int extractNumericValueFromBitArray(int i, int j)
    {
        return extractNumericValueFromBitArray(information, i, j);
    }
}
