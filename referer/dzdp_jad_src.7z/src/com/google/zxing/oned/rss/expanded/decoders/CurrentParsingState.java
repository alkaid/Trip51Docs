// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.oned.rss.expanded.decoders;


final class CurrentParsingState
{
    private static final class State extends Enum
    {

        private static final State $VALUES[];
        public static final State ALPHA;
        public static final State ISO_IEC_646;
        public static final State NUMERIC;

        public static State valueOf(String s)
        {
            return (State)Enum.valueOf(com/google/zxing/oned/rss/expanded/decoders/CurrentParsingState$State, s);
        }

        public static State[] values()
        {
            return (State[])$VALUES.clone();
        }

        static 
        {
            NUMERIC = new State("NUMERIC", 0);
            ALPHA = new State("ALPHA", 1);
            ISO_IEC_646 = new State("ISO_IEC_646", 2);
            State astate[] = new State[3];
            astate[0] = NUMERIC;
            astate[1] = ALPHA;
            astate[2] = ISO_IEC_646;
            $VALUES = astate;
        }

        private State(String s, int i)
        {
            super(s, i);
        }
    }


    private State encoding;
    private int position;

    CurrentParsingState()
    {
        position = 0;
        encoding = State.NUMERIC;
    }

    int getPosition()
    {
        return position;
    }

    void incrementPosition(int i)
    {
        position = i + position;
    }

    boolean isAlpha()
    {
        boolean flag;
        if(encoding == State.ALPHA)
            flag = true;
        else
            flag = false;
        return flag;
    }

    boolean isIsoIec646()
    {
        boolean flag;
        if(encoding == State.ISO_IEC_646)
            flag = true;
        else
            flag = false;
        return flag;
    }

    boolean isNumeric()
    {
        boolean flag;
        if(encoding == State.NUMERIC)
            flag = true;
        else
            flag = false;
        return flag;
    }

    void setAlpha()
    {
        encoding = State.ALPHA;
    }

    void setIsoIec646()
    {
        encoding = State.ISO_IEC_646;
    }

    void setNumeric()
    {
        encoding = State.NUMERIC;
    }

    void setPosition(int i)
    {
        position = i;
    }
}
