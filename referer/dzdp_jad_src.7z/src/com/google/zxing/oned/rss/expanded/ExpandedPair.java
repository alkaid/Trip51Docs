// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.oned.rss.expanded;

import com.google.zxing.oned.rss.DataCharacter;
import com.google.zxing.oned.rss.FinderPattern;

final class ExpandedPair
{

    private final FinderPattern finderPattern;
    private final DataCharacter leftChar;
    private final boolean mayBeLast;
    private final DataCharacter rightChar;

    ExpandedPair(DataCharacter datacharacter, DataCharacter datacharacter1, FinderPattern finderpattern, boolean flag)
    {
        leftChar = datacharacter;
        rightChar = datacharacter1;
        finderPattern = finderpattern;
        mayBeLast = flag;
    }

    private static boolean equalsOrNull(Object obj, Object obj1)
    {
        boolean flag;
        if(obj == null)
        {
            if(obj1 == null)
                flag = true;
            else
                flag = false;
        } else
        {
            flag = obj.equals(obj1);
        }
        return flag;
    }

    private static int hashNotNull(Object obj)
    {
        int i;
        if(obj == null)
            i = 0;
        else
            i = obj.hashCode();
        return i;
    }

    public boolean equals(Object obj)
    {
        boolean flag = false;
        if(obj instanceof ExpandedPair) goto _L2; else goto _L1
_L1:
        return flag;
_L2:
        ExpandedPair expandedpair = (ExpandedPair)obj;
        if(equalsOrNull(leftChar, expandedpair.leftChar) && equalsOrNull(rightChar, expandedpair.rightChar) && equalsOrNull(finderPattern, expandedpair.finderPattern))
            flag = true;
        if(true) goto _L1; else goto _L3
_L3:
    }

    FinderPattern getFinderPattern()
    {
        return finderPattern;
    }

    DataCharacter getLeftChar()
    {
        return leftChar;
    }

    DataCharacter getRightChar()
    {
        return rightChar;
    }

    public int hashCode()
    {
        return hashNotNull(leftChar) ^ hashNotNull(rightChar) ^ hashNotNull(finderPattern);
    }

    boolean mayBeLast()
    {
        return mayBeLast;
    }

    public boolean mustBeLast()
    {
        boolean flag;
        if(rightChar == null)
            flag = true;
        else
            flag = false;
        return flag;
    }

    public String toString()
    {
        StringBuilder stringbuilder = (new StringBuilder()).append("[ ").append(leftChar).append(" , ").append(rightChar).append(" : ");
        Object obj;
        if(finderPattern == null)
            obj = "null";
        else
            obj = Integer.valueOf(finderPattern.getValue());
        return stringbuilder.append(obj).append(" ]").toString();
    }
}
