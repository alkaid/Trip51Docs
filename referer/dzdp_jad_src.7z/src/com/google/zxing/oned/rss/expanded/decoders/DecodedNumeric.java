// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.oned.rss.expanded.decoders;

import com.google.zxing.FormatException;

// Referenced classes of package com.google.zxing.oned.rss.expanded.decoders:
//            DecodedObject

final class DecodedNumeric extends DecodedObject
{

    static final int FNC1 = 10;
    private final int firstDigit;
    private final int secondDigit;

    DecodedNumeric(int i, int j, int k)
        throws FormatException
    {
        super(i);
        if(j < 0 || j > 10 || k < 0 || k > 10)
        {
            throw FormatException.getFormatInstance();
        } else
        {
            firstDigit = j;
            secondDigit = k;
            return;
        }
    }

    int getFirstDigit()
    {
        return firstDigit;
    }

    int getSecondDigit()
    {
        return secondDigit;
    }

    int getValue()
    {
        return 10 * firstDigit + secondDigit;
    }

    boolean isAnyFNC1()
    {
        boolean flag;
        if(firstDigit == 10 || secondDigit == 10)
            flag = true;
        else
            flag = false;
        return flag;
    }

    boolean isFirstDigitFNC1()
    {
        boolean flag;
        if(firstDigit == 10)
            flag = true;
        else
            flag = false;
        return flag;
    }

    boolean isSecondDigitFNC1()
    {
        boolean flag;
        if(secondDigit == 10)
            flag = true;
        else
            flag = false;
        return flag;
    }
}
