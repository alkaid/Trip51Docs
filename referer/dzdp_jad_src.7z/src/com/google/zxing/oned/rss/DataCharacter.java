// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.oned.rss;


public class DataCharacter
{

    private final int checksumPortion;
    private final int value;

    public DataCharacter(int i, int j)
    {
        value = i;
        checksumPortion = j;
    }

    public final boolean equals(Object obj)
    {
        boolean flag = false;
        if(obj instanceof DataCharacter) goto _L2; else goto _L1
_L1:
        return flag;
_L2:
        DataCharacter datacharacter = (DataCharacter)obj;
        if(value == datacharacter.value && checksumPortion == datacharacter.checksumPortion)
            flag = true;
        if(true) goto _L1; else goto _L3
_L3:
    }

    public final int getChecksumPortion()
    {
        return checksumPortion;
    }

    public final int getValue()
    {
        return value;
    }

    public final int hashCode()
    {
        return value ^ checksumPortion;
    }

    public final String toString()
    {
        return (new StringBuilder()).append(value).append("(").append(checksumPortion).append(')').toString();
    }
}
