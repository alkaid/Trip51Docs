// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.oned.rss.expanded;

import java.util.ArrayList;
import java.util.List;

final class ExpandedRow
{

    private final List pairs;
    private final int rowNumber;
    private final boolean wasReversed;

    ExpandedRow(List list, int i, boolean flag)
    {
        pairs = new ArrayList(list);
        rowNumber = i;
        wasReversed = flag;
    }

    public boolean equals(Object obj)
    {
        boolean flag = false;
        if(obj instanceof ExpandedRow) goto _L2; else goto _L1
_L1:
        return flag;
_L2:
        ExpandedRow expandedrow = (ExpandedRow)obj;
        if(pairs.equals(expandedrow.getPairs()) && wasReversed == expandedrow.wasReversed)
            flag = true;
        if(true) goto _L1; else goto _L3
_L3:
    }

    List getPairs()
    {
        return pairs;
    }

    int getRowNumber()
    {
        return rowNumber;
    }

    public int hashCode()
    {
        return pairs.hashCode() ^ Boolean.valueOf(wasReversed).hashCode();
    }

    boolean isEquivalent(List list)
    {
        return pairs.equals(list);
    }

    boolean isReversed()
    {
        return wasReversed;
    }

    public String toString()
    {
        return (new StringBuilder()).append("{ ").append(pairs).append(" }").toString();
    }
}
