// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.oned.rss;

import com.google.zxing.ResultPoint;

public final class FinderPattern
{

    private final ResultPoint resultPoints[];
    private final int startEnd[];
    private final int value;

    public FinderPattern(int i, int ai[], int j, int k, int l)
    {
        value = i;
        startEnd = ai;
        ResultPoint aresultpoint[] = new ResultPoint[2];
        aresultpoint[0] = new ResultPoint(j, l);
        aresultpoint[1] = new ResultPoint(k, l);
        resultPoints = aresultpoint;
    }

    public boolean equals(Object obj)
    {
        boolean flag = false;
        if(obj instanceof FinderPattern) goto _L2; else goto _L1
_L1:
        return flag;
_L2:
        FinderPattern finderpattern = (FinderPattern)obj;
        if(value == finderpattern.value)
            flag = true;
        if(true) goto _L1; else goto _L3
_L3:
    }

    public ResultPoint[] getResultPoints()
    {
        return resultPoints;
    }

    public int[] getStartEnd()
    {
        return startEnd;
    }

    public int getValue()
    {
        return value;
    }

    public int hashCode()
    {
        return value;
    }
}
