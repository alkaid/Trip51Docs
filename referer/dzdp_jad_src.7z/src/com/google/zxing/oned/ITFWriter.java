// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.oned;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import java.util.Map;

// Referenced classes of package com.google.zxing.oned:
//            OneDimensionalCodeWriter, ITFReader

public final class ITFWriter extends OneDimensionalCodeWriter
{

    private static final int END_PATTERN[];
    private static final int START_PATTERN[];

    public ITFWriter()
    {
    }

    public BitMatrix encode(String s, BarcodeFormat barcodeformat, int i, int j, Map map)
        throws WriterException
    {
        if(barcodeformat != BarcodeFormat.ITF)
            throw new IllegalArgumentException((new StringBuilder()).append("Can only encode ITF, but got ").append(barcodeformat).toString());
        else
            return super.encode(s, barcodeformat, i, j, map);
    }

    public boolean[] encode(String s)
    {
        int i = s.length();
        if(i % 2 != 0)
            throw new IllegalArgumentException("The lenght of the input should be even");
        if(i > 80)
            throw new IllegalArgumentException((new StringBuilder()).append("Requested contents should be less than 80 digits long, but got ").append(i).toString());
        boolean aflag[] = new boolean[9 + i * 9];
        int j = appendPattern(aflag, 0, START_PATTERN, true);
        for(int k = 0; k < i; k += 2)
        {
            int l = Character.digit(s.charAt(k), 10);
            int i1 = Character.digit(s.charAt(k + 1), 10);
            int ai[] = new int[18];
            for(int j1 = 0; j1 < 5; j1++)
            {
                ai[j1 * 2] = ITFReader.PATTERNS[l][j1];
                ai[1 + j1 * 2] = ITFReader.PATTERNS[i1][j1];
            }

            j += appendPattern(aflag, j, ai, true);
        }

        appendPattern(aflag, j, END_PATTERN, true);
        return aflag;
    }

    static 
    {
        int ai[] = new int[4];
        ai[0] = 1;
        ai[1] = 1;
        ai[2] = 1;
        ai[3] = 1;
        START_PATTERN = ai;
        int ai1[] = new int[3];
        ai1[0] = 3;
        ai1[1] = 1;
        ai1[2] = 1;
        END_PATTERN = ai1;
    }
}
