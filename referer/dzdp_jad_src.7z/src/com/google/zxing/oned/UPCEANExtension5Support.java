// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.oned;

import com.google.zxing.*;
import com.google.zxing.common.BitArray;
import java.util.EnumMap;
import java.util.Map;

// Referenced classes of package com.google.zxing.oned:
//            UPCEANReader

final class UPCEANExtension5Support
{

    private static final int CHECK_DIGIT_ENCODINGS[];
    private final int decodeMiddleCounters[] = new int[4];
    private final StringBuilder decodeRowStringBuffer = new StringBuilder();

    UPCEANExtension5Support()
    {
    }

    private static int determineCheckDigit(int i)
        throws NotFoundException
    {
        for(int j = 0; j < 10; j++)
            if(i == CHECK_DIGIT_ENCODINGS[j])
                return j;

        throw NotFoundException.getNotFoundInstance();
    }

    private static int extensionChecksum(CharSequence charsequence)
    {
        int i = charsequence.length();
        int j = 0;
        for(int k = i - 2; k >= 0; k -= 2)
            j += -48 + charsequence.charAt(k);

        int l = j * 3;
        for(int i1 = i - 1; i1 >= 0; i1 -= 2)
            l += -48 + charsequence.charAt(i1);

        return (l * 3) % 10;
    }

    private static String parseExtension5String(String s)
    {
        s.charAt(0);
        JVM INSTR lookupswitch 3: default 40
    //                   48: 128
    //                   53: 134
    //                   57: 140;
           goto _L1 _L2 _L3 _L4
_L1:
        String s1 = "";
_L5:
        int i = Integer.parseInt(s.substring(1));
        String s2 = String.valueOf(i / 100);
        int j = i % 100;
        String s3;
        String s4;
        if(j < 10)
            s3 = (new StringBuilder()).append("0").append(j).toString();
        else
            s3 = String.valueOf(j);
        s4 = (new StringBuilder()).append(s1).append(s2).append('.').append(s3).toString();
_L6:
        return s4;
_L2:
        s1 = "\243";
          goto _L5
_L3:
        s1 = "$";
          goto _L5
_L4:
        if("90000".equals(s))
            s4 = null;
        else
        if("99991".equals(s))
        {
            s4 = "0.00";
        } else
        {
label0:
            {
                if(!"99990".equals(s))
                    break label0;
                s4 = "Used";
            }
        }
          goto _L6
        s1 = "";
          goto _L5
    }

    private static Map parseExtensionString(String s)
    {
        Object obj = null;
        if(s.length() == 5) goto _L2; else goto _L1
_L1:
        return ((Map) (obj));
_L2:
        String s1 = parseExtension5String(s);
        if(s1 != null)
        {
            obj = new EnumMap(com/google/zxing/ResultMetadataType);
            ((Map) (obj)).put(ResultMetadataType.SUGGESTED_PRICE, s1);
        }
        if(true) goto _L1; else goto _L3
_L3:
    }

    int decodeMiddle(BitArray bitarray, int ai[], StringBuilder stringbuilder)
        throws NotFoundException
    {
        int ai1[] = decodeMiddleCounters;
        ai1[0] = 0;
        ai1[1] = 0;
        ai1[2] = 0;
        ai1[3] = 0;
        int i = bitarray.getSize();
        int j = ai[1];
        int k = 0;
        for(int l = 0; l < 5 && j < i; l++)
        {
            int j1 = UPCEANReader.decodeDigit(bitarray, ai1, j, UPCEANReader.L_AND_G_PATTERNS);
            stringbuilder.append((char)(48 + j1 % 10));
            int k1 = ai1.length;
            for(int l1 = 0; l1 < k1; l1++)
                j += ai1[l1];

            if(j1 >= 10)
                k |= 1 << 4 - l;
            if(l != 4)
                j = bitarray.getNextUnset(bitarray.getNextSet(j));
        }

        if(stringbuilder.length() != 5)
            throw NotFoundException.getNotFoundInstance();
        int i1 = determineCheckDigit(k);
        if(extensionChecksum(stringbuilder.toString()) != i1)
            throw NotFoundException.getNotFoundInstance();
        else
            return j;
    }

    Result decodeRow(int i, BitArray bitarray, int ai[])
        throws NotFoundException
    {
        StringBuilder stringbuilder = decodeRowStringBuffer;
        stringbuilder.setLength(0);
        int j = decodeMiddle(bitarray, ai, stringbuilder);
        String s = stringbuilder.toString();
        Map map = parseExtensionString(s);
        ResultPoint aresultpoint[] = new ResultPoint[2];
        aresultpoint[0] = new ResultPoint((float)(ai[0] + ai[1]) / 2.0F, i);
        aresultpoint[1] = new ResultPoint(j, i);
        Result result = new Result(s, null, aresultpoint, BarcodeFormat.UPC_EAN_EXTENSION);
        if(map != null)
            result.putAllMetadata(map);
        return result;
    }

    static 
    {
        int ai[] = new int[10];
        ai[0] = 24;
        ai[1] = 20;
        ai[2] = 18;
        ai[3] = 17;
        ai[4] = 12;
        ai[5] = 6;
        ai[6] = 3;
        ai[7] = 10;
        ai[8] = 9;
        ai[9] = 5;
        CHECK_DIGIT_ENCODINGS = ai;
    }
}
