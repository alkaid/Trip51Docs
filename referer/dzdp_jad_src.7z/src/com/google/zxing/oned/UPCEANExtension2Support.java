// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.oned;

import com.google.zxing.*;
import com.google.zxing.common.BitArray;
import java.util.EnumMap;
import java.util.Map;

// Referenced classes of package com.google.zxing.oned:
//            UPCEANReader

final class UPCEANExtension2Support
{

    private final int decodeMiddleCounters[] = new int[4];
    private final StringBuilder decodeRowStringBuffer = new StringBuilder();

    UPCEANExtension2Support()
    {
    }

    private static Map parseExtensionString(String s)
    {
        Object obj;
        if(s.length() != 2)
        {
            obj = null;
        } else
        {
            obj = new EnumMap(com/google/zxing/ResultMetadataType);
            ((Map) (obj)).put(ResultMetadataType.ISSUE_NUMBER, Integer.valueOf(s));
        }
        return ((Map) (obj));
    }

    int decodeMiddle(BitArray bitarray, int ai[], StringBuilder stringbuilder)
        throws NotFoundException
    {
        int ai1[] = decodeMiddleCounters;
        ai1[0] = 0;
        ai1[1] = 0;
        ai1[2] = 0;
        ai1[3] = 0;
        int i = bitarray.getSize();
        int j = ai[1];
        int k = 0;
        for(int l = 0; l < 2 && j < i; l++)
        {
            int i1 = UPCEANReader.decodeDigit(bitarray, ai1, j, UPCEANReader.L_AND_G_PATTERNS);
            stringbuilder.append((char)(48 + i1 % 10));
            int j1 = ai1.length;
            for(int k1 = 0; k1 < j1; k1++)
                j += ai1[k1];

            if(i1 >= 10)
                k |= 1 << 1 - l;
            if(l != 1)
                j = bitarray.getNextUnset(bitarray.getNextSet(j));
        }

        if(stringbuilder.length() != 2)
            throw NotFoundException.getNotFoundInstance();
        if(Integer.parseInt(stringbuilder.toString()) % 4 != k)
            throw NotFoundException.getNotFoundInstance();
        else
            return j;
    }

    Result decodeRow(int i, BitArray bitarray, int ai[])
        throws NotFoundException
    {
        StringBuilder stringbuilder = decodeRowStringBuffer;
        stringbuilder.setLength(0);
        int j = decodeMiddle(bitarray, ai, stringbuilder);
        String s = stringbuilder.toString();
        Map map = parseExtensionString(s);
        ResultPoint aresultpoint[] = new ResultPoint[2];
        aresultpoint[0] = new ResultPoint((float)(ai[0] + ai[1]) / 2.0F, i);
        aresultpoint[1] = new ResultPoint(j, i);
        Result result = new Result(s, null, aresultpoint, BarcodeFormat.UPC_EAN_EXTENSION);
        if(map != null)
            result.putAllMetadata(map);
        return result;
    }
}
