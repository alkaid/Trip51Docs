// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.oned;

import com.google.zxing.*;
import com.google.zxing.common.BitArray;
import java.util.Arrays;
import java.util.Map;

// Referenced classes of package com.google.zxing.oned:
//            OneDReader

public final class Code93Reader extends OneDReader
{

    private static final char ALPHABET[] = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ-. $/+%abcd*".toCharArray();
    private static final String ALPHABET_STRING = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ-. $/+%abcd*";
    private static final int ASTERISK_ENCODING;
    private static final int CHARACTER_ENCODINGS[];
    private final int counters[] = new int[6];
    private final StringBuilder decodeRowResult = new StringBuilder(20);

    public Code93Reader()
    {
    }

    private static void checkChecksums(CharSequence charsequence)
        throws ChecksumException
    {
        int i = charsequence.length();
        checkOneChecksum(charsequence, i - 2, 20);
        checkOneChecksum(charsequence, i - 1, 15);
    }

    private static void checkOneChecksum(CharSequence charsequence, int i, int j)
        throws ChecksumException
    {
        int k = 1;
        int l = 0;
        for(int i1 = i - 1; i1 >= 0; i1--)
        {
            l += k * "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ-. $/+%abcd*".indexOf(charsequence.charAt(i1));
            if(++k > j)
                k = 1;
        }

        if(charsequence.charAt(i) != ALPHABET[l % 47])
            throw ChecksumException.getChecksumInstance();
        else
            return;
    }

    private static String decodeExtended(CharSequence charsequence)
        throws FormatException
    {
        int i;
        StringBuilder stringbuilder;
        int j;
        i = charsequence.length();
        stringbuilder = new StringBuilder(i);
        j = 0;
_L8:
        char c;
        char c1;
        int k;
        if(j >= i)
            break MISSING_BLOCK_LABEL_349;
        c = charsequence.charAt(j);
        if(c < 'a' || c > 'd')
            break MISSING_BLOCK_LABEL_339;
        if(j >= i - 1)
            throw FormatException.getFormatInstance();
        c1 = charsequence.charAt(j + 1);
        k = 0;
        c;
        JVM INSTR tableswitch 97 100: default 104
    //                   97 148
    //                   98 176
    //                   99 297
    //                   100 120;
           goto _L1 _L2 _L3 _L4 _L5
_L1:
        stringbuilder.append(k);
        j++;
_L6:
        j++;
        continue; /* Loop/switch isn't completed */
_L5:
        if(c1 >= 'A' && c1 <= 'Z')
            k = c1 + 32;
        else
            throw FormatException.getFormatInstance();
          goto _L1
_L2:
        if(c1 >= 'A' && c1 <= 'Z')
            k = c1 + -64;
        else
            throw FormatException.getFormatInstance();
          goto _L1
_L3:
        if(c1 >= 'A' && c1 <= 'E')
            k = c1 + -38;
        else
        if(c1 >= 'F' && c1 <= 'J')
            k = c1 + -11;
        else
        if(c1 >= 'K' && c1 <= 'O')
            k = c1 + 16;
        else
        if(c1 >= 'P' && c1 <= 'S')
            k = c1 + 43;
        else
        if(c1 >= 'T' && c1 <= 'Z')
            k = 127;
        else
            throw FormatException.getFormatInstance();
          goto _L1
_L4:
        if(c1 >= 'A' && c1 <= 'O')
            k = c1 + -32;
        else
        if(c1 == 'Z')
            k = 58;
        else
            throw FormatException.getFormatInstance();
          goto _L1
        stringbuilder.append(c);
          goto _L6
        return stringbuilder.toString();
        if(true) goto _L8; else goto _L7
_L7:
    }

    private int[] findAsteriskPattern(BitArray bitarray)
        throws NotFoundException
    {
        int i = bitarray.getSize();
        int j = bitarray.getNextSet(0);
        Arrays.fill(counters, 0);
        int ai[] = counters;
        int k = j;
        boolean flag = false;
        int l = ai.length;
        int i1 = 0;
        int j1 = j;
        while(j1 < i) 
        {
            if(flag ^ bitarray.get(j1))
            {
                ai[i1] = 1 + ai[i1];
            } else
            {
                if(i1 == l - 1)
                {
                    if(toPattern(ai) == ASTERISK_ENCODING)
                    {
                        int ai1[] = new int[2];
                        ai1[0] = k;
                        ai1[1] = j1;
                        return ai1;
                    }
                    k += ai[0] + ai[1];
                    System.arraycopy(ai, 2, ai, 0, l - 2);
                    ai[l - 2] = 0;
                    ai[l - 1] = 0;
                    i1--;
                } else
                {
                    i1++;
                }
                ai[i1] = 1;
                if(!flag)
                    flag = true;
                else
                    flag = false;
            }
            j1++;
        }
        throw NotFoundException.getNotFoundInstance();
    }

    private static char patternToChar(int i)
        throws NotFoundException
    {
        for(int j = 0; j < CHARACTER_ENCODINGS.length; j++)
            if(CHARACTER_ENCODINGS[j] == i)
                return ALPHABET[j];

        throw NotFoundException.getNotFoundInstance();
    }

    private static int toPattern(int ai[])
    {
        int i = ai.length;
        int j = 0;
        int k = ai.length;
        for(int l = 0; l < k; l++)
            j += ai[l];

        int i1 = 0;
        int j1 = 0;
        do
        {
            int k1;
label0:
            {
                if(j1 < i)
                {
                    k1 = Math.round((9F * (float)ai[j1]) / (float)j);
                    if(k1 >= 1 && k1 <= 4)
                        break label0;
                    i1 = -1;
                }
                return i1;
            }
            if((j1 & 1) == 0)
            {
                for(int l1 = 0; l1 < k1; l1++)
                    i1 = 1 | i1 << 1;

            } else
            {
                i1 <<= k1;
            }
            j1++;
        } while(true);
    }

    public Result decodeRow(int i, BitArray bitarray, Map map)
        throws NotFoundException, ChecksumException, FormatException
    {
        int ai[] = findAsteriskPattern(bitarray);
        int j = bitarray.getNextSet(ai[1]);
        int k = bitarray.getSize();
        int ai1[] = counters;
        Arrays.fill(ai1, 0);
        StringBuilder stringbuilder = decodeRowResult;
        stringbuilder.setLength(0);
        char c;
        int i1;
        do
        {
            recordPattern(bitarray, j, ai1);
            int l = toPattern(ai1);
            if(l < 0)
                throw NotFoundException.getNotFoundInstance();
            c = patternToChar(l);
            stringbuilder.append(c);
            i1 = j;
            int j1 = ai1.length;
            for(int k1 = 0; k1 < j1; k1++)
                j += ai1[k1];

            j = bitarray.getNextSet(j);
        } while(c != '*');
        stringbuilder.deleteCharAt(-1 + stringbuilder.length());
        int l1 = 0;
        int i2 = ai1.length;
        for(int j2 = 0; j2 < i2; j2++)
            l1 += ai1[j2];

        if(j == k || !bitarray.get(j))
            throw NotFoundException.getNotFoundInstance();
        if(stringbuilder.length() < 2)
        {
            throw NotFoundException.getNotFoundInstance();
        } else
        {
            checkChecksums(stringbuilder);
            stringbuilder.setLength(-2 + stringbuilder.length());
            String s = decodeExtended(stringbuilder);
            float f = (float)(ai[1] + ai[0]) / 2.0F;
            float f1 = (float)i1 + (float)l1 / 2.0F;
            ResultPoint aresultpoint[] = new ResultPoint[2];
            ResultPoint resultpoint = new ResultPoint(f, i);
            aresultpoint[0] = resultpoint;
            ResultPoint resultpoint1 = new ResultPoint(f1, i);
            aresultpoint[1] = resultpoint1;
            Result result = new Result(s, null, aresultpoint, BarcodeFormat.CODE_93);
            return result;
        }
    }

    static 
    {
        int ai[] = new int[48];
        ai[0] = 276;
        ai[1] = 328;
        ai[2] = 324;
        ai[3] = 322;
        ai[4] = 296;
        ai[5] = 292;
        ai[6] = 290;
        ai[7] = 336;
        ai[8] = 274;
        ai[9] = 266;
        ai[10] = 424;
        ai[11] = 420;
        ai[12] = 418;
        ai[13] = 404;
        ai[14] = 402;
        ai[15] = 394;
        ai[16] = 360;
        ai[17] = 356;
        ai[18] = 354;
        ai[19] = 308;
        ai[20] = 282;
        ai[21] = 344;
        ai[22] = 332;
        ai[23] = 326;
        ai[24] = 300;
        ai[25] = 278;
        ai[26] = 436;
        ai[27] = 434;
        ai[28] = 428;
        ai[29] = 422;
        ai[30] = 406;
        ai[31] = 410;
        ai[32] = 364;
        ai[33] = 358;
        ai[34] = 310;
        ai[35] = 314;
        ai[36] = 302;
        ai[37] = 468;
        ai[38] = 466;
        ai[39] = 458;
        ai[40] = 366;
        ai[41] = 374;
        ai[42] = 430;
        ai[43] = 294;
        ai[44] = 474;
        ai[45] = 470;
        ai[46] = 306;
        ai[47] = 350;
        CHARACTER_ENCODINGS = ai;
        ASTERISK_ENCODING = CHARACTER_ENCODINGS[47];
    }
}
