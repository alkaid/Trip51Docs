// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.oned;


// Referenced classes of package com.google.zxing.oned:
//            OneDimensionalCodeWriter, CodaBarReader

public final class CodaBarWriter extends OneDimensionalCodeWriter
{

    private static final char ALT_START_END_CHARS[];
    private static final char CHARS_WHICH_ARE_TEN_LENGTH_EACH_AFTER_DECODED[];
    private static final char DEFAULT_GUARD;
    private static final char START_END_CHARS[];

    public CodaBarWriter()
    {
    }

    public boolean[] encode(String s)
    {
        int j;
        int k;
        if(s.length() < 2)
        {
            s = (new StringBuilder()).append(DEFAULT_GUARD).append(s).append(DEFAULT_GUARD).toString();
            break MISSING_BLOCK_LABEL_35;
        } else
        {
            char c = Character.toUpperCase(s.charAt(0));
            int i = -1 + s.length();
            char c1 = Character.toUpperCase(s.charAt(i));
            boolean flag = CodaBarReader.arrayContains(START_END_CHARS, c);
            boolean flag1 = CodaBarReader.arrayContains(START_END_CHARS, c1);
            boolean flag2 = CodaBarReader.arrayContains(ALT_START_END_CHARS, c);
            boolean flag3 = CodaBarReader.arrayContains(ALT_START_END_CHARS, c1);
            if(flag)
            {
                if(!flag1)
                    throw new IllegalArgumentException((new StringBuilder()).append("Invalid start/end guards: ").append(s).toString());
            } else
            if(flag2)
            {
                if(!flag3)
                    throw new IllegalArgumentException((new StringBuilder()).append("Invalid start/end guards: ").append(s).toString());
            } else
            {
                if(flag1 || flag3)
                    throw new IllegalArgumentException((new StringBuilder()).append("Invalid start/end guards: ").append(s).toString());
                s = (new StringBuilder()).append(DEFAULT_GUARD).append(s).append(DEFAULT_GUARD).toString();
            }
            continue; /* Loop/switch isn't completed */
        }
_L12:
        boolean aflag[];
        int l;
        int i1;
        j = 20;
        k = 1;
        while(k < -1 + s.length()) 
        {
            if(Character.isDigit(s.charAt(k)) || s.charAt(k) == '-' || s.charAt(k) == '$')
                j += 9;
            else
            if(CodaBarReader.arrayContains(CHARS_WHICH_ARE_TEN_LENGTH_EACH_AFTER_DECODED, s.charAt(k)))
                j += 10;
            else
                throw new IllegalArgumentException((new StringBuilder()).append("Cannot encode : '").append(s.charAt(k)).append('\'').toString());
            k++;
        }
        aflag = new boolean[j + (-1 + s.length())];
        l = 0;
        i1 = 0;
_L10:
        if(i1 >= s.length()) goto _L2; else goto _L1
_L1:
        char c2 = Character.toUpperCase(s.charAt(i1));
        if(i1 != 0 && i1 != -1 + s.length()) goto _L4; else goto _L3
_L3:
        c2;
        JVM INSTR lookupswitch 4: default 464
    //                   42: 574
    //                   69: 581
    //                   78: 567
    //                   84: 560;
           goto _L4 _L5 _L6 _L7 _L8
_L4:
        int j1;
        int k1;
        j1 = 0;
        k1 = 0;
_L9:
        if(k1 < CodaBarReader.ALPHABET.length)
        {
            if(c2 != CodaBarReader.ALPHABET[k1])
                break MISSING_BLOCK_LABEL_588;
            j1 = CodaBarReader.CHARACTER_ENCODINGS[k1];
        }
        boolean flag4 = true;
        int l1 = 0;
        for(int i2 = 0; i2 < 7;)
        {
            aflag[l] = flag4;
            l++;
            if((1 & j1 >> 6 - i2) == 0 || l1 == 1)
            {
                if(!flag4)
                    flag4 = true;
                else
                    flag4 = false;
                i2++;
                l1 = 0;
            } else
            {
                l1++;
            }
        }

        break MISSING_BLOCK_LABEL_606;
_L8:
        c2 = 'A';
          goto _L4
_L7:
        c2 = 'B';
          goto _L4
_L5:
        c2 = 'C';
          goto _L4
_L6:
        c2 = 'D';
          goto _L4
        k1++;
          goto _L9
        if(i1 < -1 + s.length())
        {
            aflag[l] = false;
            l++;
        }
        i1++;
          goto _L10
_L2:
        return aflag;
        if(true) goto _L12; else goto _L11
_L11:
    }

    static 
    {
        char ac[] = new char[4];
        ac[0] = 'A';
        ac[1] = 'B';
        ac[2] = 'C';
        ac[3] = 'D';
        START_END_CHARS = ac;
        char ac1[] = new char[4];
        ac1[0] = 'T';
        ac1[1] = 'N';
        ac1[2] = '*';
        ac1[3] = 'E';
        ALT_START_END_CHARS = ac1;
        char ac2[] = new char[4];
        ac2[0] = '/';
        ac2[1] = ':';
        ac2[2] = '+';
        ac2[3] = '.';
        CHARS_WHICH_ARE_TEN_LENGTH_EACH_AFTER_DECODED = ac2;
        DEFAULT_GUARD = START_END_CHARS[0];
    }
}
