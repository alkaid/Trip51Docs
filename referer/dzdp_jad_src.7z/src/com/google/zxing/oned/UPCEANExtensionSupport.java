// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.oned;

import com.google.zxing.*;
import com.google.zxing.common.BitArray;

// Referenced classes of package com.google.zxing.oned:
//            UPCEANExtension2Support, UPCEANExtension5Support, UPCEANReader

final class UPCEANExtensionSupport
{

    private static final int EXTENSION_START_PATTERN[];
    private final UPCEANExtension5Support fiveSupport = new UPCEANExtension5Support();
    private final UPCEANExtension2Support twoSupport = new UPCEANExtension2Support();

    UPCEANExtensionSupport()
    {
    }

    Result decodeRow(int i, BitArray bitarray, int j)
        throws NotFoundException
    {
        int ai[] = UPCEANReader.findGuardPattern(bitarray, j, false, EXTENSION_START_PATTERN);
        Result result1 = fiveSupport.decodeRow(i, bitarray, ai);
        Result result = result1;
_L2:
        return result;
        ReaderException readerexception;
        readerexception;
        result = twoSupport.decodeRow(i, bitarray, ai);
        if(true) goto _L2; else goto _L1
_L1:
    }

    static 
    {
        int ai[] = new int[3];
        ai[0] = 1;
        ai[1] = 1;
        ai[2] = 2;
        EXTENSION_START_PATTERN = ai;
    }
}
