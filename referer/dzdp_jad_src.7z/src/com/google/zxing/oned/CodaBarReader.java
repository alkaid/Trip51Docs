// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.oned;

import com.google.zxing.*;
import com.google.zxing.common.BitArray;
import java.util.Arrays;
import java.util.Map;

// Referenced classes of package com.google.zxing.oned:
//            OneDReader

public final class CodaBarReader extends OneDReader
{

    static final char ALPHABET[] = "0123456789-$:/.+ABCD".toCharArray();
    private static final String ALPHABET_STRING = "0123456789-$:/.+ABCD";
    static final int CHARACTER_ENCODINGS[];
    private static final float MAX_ACCEPTABLE = 2F;
    private static final int MIN_CHARACTER_LENGTH = 3;
    private static final float PADDING = 1.5F;
    private static final char STARTEND_ENCODING[];
    private int counterLength;
    private int counters[];
    private final StringBuilder decodeRowResult = new StringBuilder(20);

    public CodaBarReader()
    {
        counters = new int[80];
        counterLength = 0;
    }

    static boolean arrayContains(char ac[], char c)
    {
        boolean flag = false;
        if(ac == null) goto _L2; else goto _L1
_L1:
        int i;
        int j;
        i = ac.length;
        j = 0;
_L7:
        if(j >= i) goto _L2; else goto _L3
_L3:
        if(ac[j] != c) goto _L5; else goto _L4
_L4:
        flag = true;
_L2:
        return flag;
_L5:
        j++;
        if(true) goto _L7; else goto _L6
_L6:
    }

    private void counterAppend(int i)
    {
        counters[counterLength] = i;
        counterLength = 1 + counterLength;
        if(counterLength >= counters.length)
        {
            int ai[] = new int[2 * counterLength];
            System.arraycopy(counters, 0, ai, 0, counterLength);
            counters = ai;
        }
    }

    private int findStartPattern()
        throws NotFoundException
    {
        for(int i = 1; i < counterLength; i += 2)
        {
            int j = toNarrowWidePattern(i);
            if(j == -1 || !arrayContains(STARTEND_ENCODING, ALPHABET[j]))
                continue;
            int k = 0;
            for(int l = i; l < i + 7; l++)
                k += counters[l];

            if(i == 1 || counters[i - 1] >= k / 2)
                return i;
        }

        throw NotFoundException.getNotFoundInstance();
    }

    private void setCounters(BitArray bitarray)
        throws NotFoundException
    {
        counterLength = 0;
        int i = bitarray.getNextUnset(0);
        int j = bitarray.getSize();
        if(i >= j)
            throw NotFoundException.getNotFoundInstance();
        boolean flag = true;
        int k = 0;
        while(i < j) 
        {
            if(flag ^ bitarray.get(i))
            {
                k++;
            } else
            {
                counterAppend(k);
                k = 1;
                if(!flag)
                    flag = true;
                else
                    flag = false;
            }
            i++;
        }
        counterAppend(k);
    }

    private int toNarrowWidePattern(int i)
    {
        int j = i + 7;
        if(j < counterLength) goto _L2; else goto _L1
_L1:
        int j3 = -1;
_L4:
        return j3;
_L2:
        int ai[] = counters;
        int k = 0;
        int l = 0x7fffffff;
        for(int i1 = i; i1 < j; i1 += 2)
        {
            int i4 = ai[i1];
            if(i4 < l)
                l = i4;
            if(i4 > k)
                k = i4;
        }

        int j1 = (l + k) / 2;
        int k1 = 0;
        int l1 = 0x7fffffff;
        for(int i2 = i + 1; i2 < j; i2 += 2)
        {
            int l3 = ai[i2];
            if(l3 < l1)
                l1 = l3;
            if(l3 > k1)
                k1 = l3;
        }

        int j2 = (l1 + k1) / 2;
        int k2 = 128;
        int l2 = 0;
        int i3 = 0;
        while(i3 < 7) 
        {
            int k3;
            if((i3 & 1) == 0)
                k3 = j1;
            else
                k3 = j2;
            k2 >>= 1;
            if(ai[i + i3] > k3)
                l2 |= k2;
            i3++;
        }
        for(j3 = 0; j3 < CHARACTER_ENCODINGS.length; j3++)
            if(CHARACTER_ENCODINGS[j3] == l2)
                continue; /* Loop/switch isn't completed */

        j3 = -1;
        if(true) goto _L4; else goto _L3
_L3:
    }

    public Result decodeRow(int i, BitArray bitarray, Map map)
        throws NotFoundException
    {
        Arrays.fill(counters, 0);
        setCounters(bitarray);
        int j = findStartPattern();
        int k = j;
        decodeRowResult.setLength(0);
        int l;
        int i1;
        int j1;
        do
        {
            l = toNarrowWidePattern(k);
            if(l == -1)
                throw NotFoundException.getNotFoundInstance();
            decodeRowResult.append((char)l);
            k += 8;
        } while((decodeRowResult.length() <= 1 || !arrayContains(STARTEND_ENCODING, ALPHABET[l])) && k < counterLength);
        i1 = counters[k - 1];
        j1 = 0;
        for(int k1 = -8; k1 < -1; k1++)
            j1 += counters[k + k1];

        if(k < counterLength && i1 < j1 / 2)
            throw NotFoundException.getNotFoundInstance();
        validatePattern(j);
        for(int l1 = 0; l1 < decodeRowResult.length(); l1++)
            decodeRowResult.setCharAt(l1, ALPHABET[decodeRowResult.charAt(l1)]);

        char c = decodeRowResult.charAt(0);
        if(!arrayContains(STARTEND_ENCODING, c))
            throw NotFoundException.getNotFoundInstance();
        char c1 = decodeRowResult.charAt(-1 + decodeRowResult.length());
        if(!arrayContains(STARTEND_ENCODING, c1))
            throw NotFoundException.getNotFoundInstance();
        if(decodeRowResult.length() <= 3)
            throw NotFoundException.getNotFoundInstance();
        if(map == null || !map.containsKey(DecodeHintType.RETURN_CODABAR_START_END))
        {
            decodeRowResult.deleteCharAt(-1 + decodeRowResult.length());
            decodeRowResult.deleteCharAt(0);
        }
        int i2 = 0;
        for(int j2 = 0; j2 < j; j2++)
            i2 += counters[j2];

        float f = i2;
        for(int k2 = j; k2 < k - 1; k2++)
            i2 += counters[k2];

        float f1 = i2;
        String s = decodeRowResult.toString();
        ResultPoint aresultpoint[] = new ResultPoint[2];
        ResultPoint resultpoint = new ResultPoint(f, i);
        aresultpoint[0] = resultpoint;
        ResultPoint resultpoint1 = new ResultPoint(f1, i);
        aresultpoint[1] = resultpoint1;
        return new Result(s, null, aresultpoint, BarcodeFormat.CODABAR);
    }

    void validatePattern(int i)
        throws NotFoundException
    {
        int ai[] = new int[4];
        ai[0] = 0;
        ai[1] = 0;
        ai[2] = 0;
        ai[3] = 0;
        int ai1[] = new int[4];
        ai1[0] = 0;
        ai1[1] = 0;
        ai1[2] = 0;
        ai1[3] = 0;
        int j = -1 + decodeRowResult.length();
        int k = i;
        int l = 0;
        float af[];
        float af1[];
        do
        {
            int i1 = CHARACTER_ENCODINGS[decodeRowResult.charAt(l)];
            for(int j1 = 6; j1 >= 0; j1--)
            {
                int j3 = (j1 & 1) + 2 * (i1 & 1);
                ai[j3] = ai[j3] + counters[k + j1];
                ai1[j3] = 1 + ai1[j3];
                i1 >>= 1;
            }

            if(l >= j)
            {
                af = new float[4];
                af1 = new float[4];
                for(int k1 = 0; k1 < 2; k1++)
                {
                    af1[k1] = 0.0F;
                    af1[k1 + 2] = ((float)ai[k1] / (float)ai1[k1] + (float)ai[k1 + 2] / (float)ai1[k1 + 2]) / 2.0F;
                    af[k1] = af1[k1 + 2];
                    af[k1 + 2] = (1.5F + 2.0F * (float)ai[k1 + 2]) / (float)ai1[k1 + 2];
                }

                break;
            }
            k += 8;
            l++;
        } while(true);
        int l1 = i;
        int i2 = 0;
        do
        {
            int j2 = CHARACTER_ENCODINGS[decodeRowResult.charAt(i2)];
            for(int k2 = 6; k2 >= 0; k2--)
            {
                int l2 = (k2 & 1) + 2 * (j2 & 1);
                int i3 = counters[l1 + k2];
                if((float)i3 < af1[l2] || (float)i3 > af[l2])
                    throw NotFoundException.getNotFoundInstance();
                j2 >>= 1;
            }

            if(i2 >= j)
                return;
            l1 += 8;
            i2++;
        } while(true);
    }

    static 
    {
        int ai[] = new int[20];
        ai[0] = 3;
        ai[1] = 6;
        ai[2] = 9;
        ai[3] = 96;
        ai[4] = 18;
        ai[5] = 66;
        ai[6] = 33;
        ai[7] = 36;
        ai[8] = 48;
        ai[9] = 72;
        ai[10] = 12;
        ai[11] = 24;
        ai[12] = 69;
        ai[13] = 81;
        ai[14] = 84;
        ai[15] = 21;
        ai[16] = 26;
        ai[17] = 41;
        ai[18] = 11;
        ai[19] = 14;
        CHARACTER_ENCODINGS = ai;
        char ac[] = new char[4];
        ac[0] = 'A';
        ac[1] = 'B';
        ac[2] = 'C';
        ac[3] = 'D';
        STARTEND_ENCODING = ac;
    }
}
