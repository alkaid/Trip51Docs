// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing;


public final class Dimension
{

    private final int height;
    private final int width;

    public Dimension(int i, int j)
    {
        if(i < 0 || j < 0)
        {
            throw new IllegalArgumentException();
        } else
        {
            width = i;
            height = j;
            return;
        }
    }

    public boolean equals(Object obj)
    {
        boolean flag = false;
        if(obj instanceof Dimension)
        {
            Dimension dimension = (Dimension)obj;
            if(width == dimension.width && height == dimension.height)
                flag = true;
        }
        return flag;
    }

    public int getHeight()
    {
        return height;
    }

    public int getWidth()
    {
        return width;
    }

    public int hashCode()
    {
        return 32713 * width + height;
    }

    public String toString()
    {
        return (new StringBuilder()).append(width).append("x").append(height).toString();
    }
}
