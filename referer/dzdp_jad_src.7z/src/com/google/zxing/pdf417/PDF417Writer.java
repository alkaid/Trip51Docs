// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.pdf417;

import com.google.zxing.*;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.pdf417.encoder.BarcodeMatrix;
import com.google.zxing.pdf417.encoder.Compaction;
import com.google.zxing.pdf417.encoder.Dimensions;
import com.google.zxing.pdf417.encoder.PDF417;
import java.lang.reflect.Array;
import java.nio.charset.Charset;
import java.util.Map;

public final class PDF417Writer
    implements Writer
{

    static final int DEFAULT_ERROR_CORRECTION_LEVEL = 2;
    static final int WHITE_SPACE = 30;

    public PDF417Writer()
    {
    }

    private static BitMatrix bitMatrixFromEncoder(PDF417 pdf417, String s, int i, int j, int k, int l)
        throws WriterException
    {
        pdf417.generateBarcodeLogic(s, i);
        byte abyte0[][] = pdf417.getBarcodeMatrix().getScaledMatrix(1, 4);
        boolean flag = false;
        boolean flag1;
        boolean flag2;
        int i1;
        int j1;
        int k1;
        BitMatrix bitmatrix;
        if(k > j)
            flag1 = true;
        else
            flag1 = false;
        if(abyte0[0].length < abyte0.length)
            flag2 = true;
        else
            flag2 = false;
        if(flag1 ^ flag2)
        {
            abyte0 = rotateArray(abyte0);
            flag = true;
        }
        i1 = j / abyte0[0].length;
        j1 = k / abyte0.length;
        if(i1 < j1)
            k1 = i1;
        else
            k1 = j1;
        if(k1 > 1)
        {
            byte abyte1[][] = pdf417.getBarcodeMatrix().getScaledMatrix(k1, k1 * 4);
            if(flag)
                abyte1 = rotateArray(abyte1);
            bitmatrix = bitMatrixFrombitArray(abyte1, l);
        } else
        {
            bitmatrix = bitMatrixFrombitArray(abyte0, l);
        }
        return bitmatrix;
    }

    private static BitMatrix bitMatrixFrombitArray(byte abyte0[][], int i)
    {
        BitMatrix bitmatrix = new BitMatrix(abyte0[0].length + i * 2, abyte0.length + i * 2);
        bitmatrix.clear();
        int j = 0;
        for(int k = -1 + (bitmatrix.getHeight() - i); j < abyte0.length; k--)
        {
            for(int l = 0; l < abyte0[0].length; l++)
                if(abyte0[j][l] == 1)
                    bitmatrix.set(l + i, k);

            j++;
        }

        return bitmatrix;
    }

    private static byte[][] rotateArray(byte abyte0[][])
    {
        int i = abyte0[0].length;
        int j = abyte0.length;
        int ai[] = new int[2];
        ai[0] = i;
        ai[1] = j;
        byte abyte1[][] = (byte[][])Array.newInstance(Byte.TYPE, ai);
        for(int k = 0; k < abyte0.length; k++)
        {
            int l = -1 + (abyte0.length - k);
            for(int i1 = 0; i1 < abyte0[0].length; i1++)
                abyte1[i1][l] = abyte0[k][i1];

        }

        return abyte1;
    }

    public BitMatrix encode(String s, BarcodeFormat barcodeformat, int i, int j)
        throws WriterException
    {
        return encode(s, barcodeformat, i, j, null);
    }

    public BitMatrix encode(String s, BarcodeFormat barcodeformat, int i, int j, Map map)
        throws WriterException
    {
        if(barcodeformat != BarcodeFormat.PDF_417)
            throw new IllegalArgumentException((new StringBuilder()).append("Can only encode PDF_417, but got ").append(barcodeformat).toString());
        PDF417 pdf417 = new PDF417();
        int k = 30;
        int l = 2;
        if(map != null)
        {
            if(map.containsKey(EncodeHintType.PDF417_COMPACT))
                pdf417.setCompact(((Boolean)map.get(EncodeHintType.PDF417_COMPACT)).booleanValue());
            if(map.containsKey(EncodeHintType.PDF417_COMPACTION))
                pdf417.setCompaction((Compaction)map.get(EncodeHintType.PDF417_COMPACTION));
            if(map.containsKey(EncodeHintType.PDF417_DIMENSIONS))
            {
                Dimensions dimensions = (Dimensions)map.get(EncodeHintType.PDF417_DIMENSIONS);
                pdf417.setDimensions(dimensions.getMaxCols(), dimensions.getMinCols(), dimensions.getMaxRows(), dimensions.getMinRows());
            }
            if(map.containsKey(EncodeHintType.MARGIN))
                k = ((Number)map.get(EncodeHintType.MARGIN)).intValue();
            if(map.containsKey(EncodeHintType.ERROR_CORRECTION))
                l = ((Number)map.get(EncodeHintType.ERROR_CORRECTION)).intValue();
            if(map.containsKey(EncodeHintType.CHARACTER_SET))
                pdf417.setEncoding(Charset.forName((String)map.get(EncodeHintType.CHARACTER_SET)));
        }
        return bitMatrixFromEncoder(pdf417, s, l, i, j, k);
    }
}
