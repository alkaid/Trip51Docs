// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.pdf417.encoder;


public final class Compaction extends Enum
{

    private static final Compaction $VALUES[];
    public static final Compaction AUTO;
    public static final Compaction BYTE;
    public static final Compaction NUMERIC;
    public static final Compaction TEXT;

    private Compaction(String s, int i)
    {
        super(s, i);
    }

    public static Compaction valueOf(String s)
    {
        return (Compaction)Enum.valueOf(com/google/zxing/pdf417/encoder/Compaction, s);
    }

    public static Compaction[] values()
    {
        return (Compaction[])$VALUES.clone();
    }

    static 
    {
        AUTO = new Compaction("AUTO", 0);
        TEXT = new Compaction("TEXT", 1);
        BYTE = new Compaction("BYTE", 2);
        NUMERIC = new Compaction("NUMERIC", 3);
        Compaction acompaction[] = new Compaction[4];
        acompaction[0] = AUTO;
        acompaction[1] = TEXT;
        acompaction[2] = BYTE;
        acompaction[3] = NUMERIC;
        $VALUES = acompaction;
    }
}
