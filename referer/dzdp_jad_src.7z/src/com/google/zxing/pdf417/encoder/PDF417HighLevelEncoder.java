// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.pdf417.encoder;

import com.google.zxing.WriterException;
import com.google.zxing.common.CharacterSetECI;
import java.math.BigInteger;
import java.nio.charset.Charset;
import java.nio.charset.CharsetEncoder;
import java.util.Arrays;

// Referenced classes of package com.google.zxing.pdf417.encoder:
//            Compaction

final class PDF417HighLevelEncoder
{

    private static final int BYTE_COMPACTION = 1;
    private static final Charset DEFAULT_ENCODING = Charset.forName("ISO-8859-1");
    private static final int ECI_CHARSET = 927;
    private static final int ECI_GENERAL_PURPOSE = 926;
    private static final int ECI_USER_DEFINED = 925;
    private static final int LATCH_TO_BYTE = 924;
    private static final int LATCH_TO_BYTE_PADDED = 901;
    private static final int LATCH_TO_NUMERIC = 902;
    private static final int LATCH_TO_TEXT = 900;
    private static final byte MIXED[];
    private static final int NUMERIC_COMPACTION = 2;
    private static final byte PUNCTUATION[];
    private static final int SHIFT_TO_BYTE = 913;
    private static final int SUBMODE_ALPHA = 0;
    private static final int SUBMODE_LOWER = 1;
    private static final int SUBMODE_MIXED = 2;
    private static final int SUBMODE_PUNCTUATION = 3;
    private static final int TEXT_COMPACTION;
    private static final byte TEXT_MIXED_RAW[];
    private static final byte TEXT_PUNCTUATION_RAW[];

    private PDF417HighLevelEncoder()
    {
    }

    private static int determineConsecutiveBinaryCount(String s, int i, Charset charset)
        throws WriterException
    {
        CharsetEncoder charsetencoder;
        int j;
        int k;
        charsetencoder = charset.newEncoder();
        j = s.length();
        k = i;
_L7:
        char c;
        int i1;
        if(k >= j)
            break MISSING_BLOCK_LABEL_157;
        c = s.charAt(k);
        i1 = 0;
_L6:
        if(i1 >= 13 || !isDigit(c)) goto _L2; else goto _L1
_L1:
        int j1;
        i1++;
        j1 = k + i1;
        if(j1 < j) goto _L3; else goto _L2
_L2:
        if(i1 < 13) goto _L5; else goto _L4
_L4:
        int l = k - i;
_L8:
        return l;
_L3:
        c = s.charAt(j1);
          goto _L6
_L5:
        char c1 = s.charAt(k);
        if(!charsetencoder.canEncode(c1))
            throw new WriterException((new StringBuilder()).append("Non-encodable character detected: ").append(c1).append(" (Unicode: ").append(c1).append(')').toString());
        k++;
          goto _L7
        l = k - i;
          goto _L8
    }

    private static int determineConsecutiveDigitCount(CharSequence charsequence, int i)
    {
        int j = 0;
        int k = charsequence.length();
        int l = i;
        if(l < k)
        {
            char c = charsequence.charAt(l);
            do
            {
                if(!isDigit(c) || l >= k)
                    break;
                j++;
                if(++l < k)
                    c = charsequence.charAt(l);
            } while(true);
        }
        return j;
    }

    private static int determineConsecutiveTextCount(CharSequence charsequence, int i)
    {
        int j;
        int k;
        j = charsequence.length();
        k = i;
_L8:
        if(k >= j) goto _L2; else goto _L1
_L1:
        int i1;
        char c = charsequence.charAt(k);
        i1 = 0;
        do
        {
            if(i1 >= 13 || !isDigit(c) || k >= j)
                break;
            i1++;
            if(++k < j)
                c = charsequence.charAt(k);
        } while(true);
        if(i1 < 13) goto _L4; else goto _L3
_L3:
        int l = k - i - i1;
_L6:
        return l;
_L4:
        if(i1 > 0)
            continue; /* Loop/switch isn't completed */
        if(isText(charsequence.charAt(k)))
            break; /* Loop/switch isn't completed */
_L2:
        l = k - i;
        if(true) goto _L6; else goto _L5
_L5:
        k++;
        if(true) goto _L8; else goto _L7
_L7:
    }

    private static void encodeBinary(byte abyte0[], int i, int j, int k, StringBuilder stringbuilder)
    {
        int l;
        if(j == 1 && k == 0)
        {
            stringbuilder.append('\u0391');
        } else
        {
            boolean flag;
            if(j % 6 == 0)
                flag = true;
            else
                flag = false;
            if(flag)
                stringbuilder.append('\u039C');
            else
                stringbuilder.append('\u0385');
        }
        l = i;
        if(j >= 6)
        {
            char ac[] = new char[5];
            for(; (i + j) - l >= 6; l += 6)
            {
                long l1 = 0L;
                for(int j1 = 0; j1 < 6; j1++)
                    l1 = (l1 << 8) + (long)(0xff & abyte0[l + j1]);

                for(int k1 = 0; k1 < 5; k1++)
                {
                    ac[k1] = (char)(int)(l1 % 900L);
                    l1 /= 900L;
                }

                for(int i2 = -1 + ac.length; i2 >= 0; i2--)
                    stringbuilder.append(ac[i2]);

            }

        }
        for(int i1 = l; i1 < i + j; i1++)
            stringbuilder.append((char)(0xff & abyte0[i1]));

    }

    static String encodeHighLevel(String s, Compaction compaction, Charset charset)
        throws WriterException
    {
        StringBuilder stringbuilder = new StringBuilder(s.length());
        int i;
        int j;
        int k;
        if(charset == null)
            charset = DEFAULT_ENCODING;
        else
        if(!DEFAULT_ENCODING.equals(charset))
        {
            CharacterSetECI characterseteci = CharacterSetECI.getCharacterSetECIByName(charset.name());
            if(characterseteci != null)
                encodingECI(characterseteci.getValue(), stringbuilder);
        }
        i = s.length();
        j = 0;
        k = 0;
        if(compaction == Compaction.TEXT)
            encodeText(s, 0, i, stringbuilder, 0);
        else
        if(compaction == Compaction.BYTE)
        {
            byte abyte1[] = s.getBytes(charset);
            encodeBinary(abyte1, 0, abyte1.length, 1, stringbuilder);
        } else
        if(compaction == Compaction.NUMERIC)
        {
            stringbuilder.append('\u0386');
            encodeNumeric(s, 0, i, stringbuilder);
        } else
        {
            byte byte0 = 0;
            while(j < i) 
            {
                int l = determineConsecutiveDigitCount(s, j);
                if(l >= 13)
                {
                    stringbuilder.append('\u0386');
                    byte0 = 2;
                    k = 0;
                    encodeNumeric(s, j, l, stringbuilder);
                    j += l;
                } else
                {
                    int i1 = determineConsecutiveTextCount(s, j);
                    if(i1 >= 5 || l == i)
                    {
                        if(byte0 != 0)
                        {
                            stringbuilder.append('\u0384');
                            byte0 = 0;
                            k = 0;
                        }
                        k = encodeText(s, j, i1, stringbuilder, k);
                        j += i1;
                    } else
                    {
                        int j1 = determineConsecutiveBinaryCount(s, j, charset);
                        if(j1 == 0)
                            j1 = 1;
                        byte abyte0[] = s.substring(j, j + j1).getBytes(charset);
                        if(abyte0.length == 1 && byte0 == 0)
                        {
                            encodeBinary(abyte0, 0, 1, 0, stringbuilder);
                        } else
                        {
                            encodeBinary(abyte0, 0, abyte0.length, byte0, stringbuilder);
                            byte0 = 1;
                            k = 0;
                        }
                        j += j1;
                    }
                }
            }
        }
        return stringbuilder.toString();
    }

    private static void encodeNumeric(String s, int i, int j, StringBuilder stringbuilder)
    {
        int k = 0;
        StringBuilder stringbuilder1 = new StringBuilder(1 + j / 3);
        BigInteger biginteger = BigInteger.valueOf(900L);
        BigInteger biginteger1 = BigInteger.valueOf(0L);
        int l;
        for(; k < j; k += l)
        {
            stringbuilder1.setLength(0);
            l = Math.min(44, j - k);
            BigInteger biginteger2 = new BigInteger((new StringBuilder()).append('1').append(s.substring(i + k, l + (i + k))).toString());
            do
            {
                stringbuilder1.append((char)biginteger2.mod(biginteger).intValue());
                biginteger2 = biginteger2.divide(biginteger);
            } while(!biginteger2.equals(biginteger1));
            for(int i1 = -1 + stringbuilder1.length(); i1 >= 0; i1--)
                stringbuilder.append(stringbuilder1.charAt(i1));

        }

    }

    private static int encodeText(CharSequence charsequence, int i, int j, StringBuilder stringbuilder, int k)
    {
        StringBuilder stringbuilder1;
        int l;
        int i1;
        stringbuilder1 = new StringBuilder(j);
        l = k;
        i1 = 0;
_L10:
        char c = charsequence.charAt(i + i1);
        l;
        JVM INSTR tableswitch 0 2: default 56
    //                   0 149
    //                   1 257
    //                   2 373;
           goto _L1 _L2 _L3 _L4
_L1:
        if(!isPunctuation(c)) goto _L6; else goto _L5
_L5:
        stringbuilder1.append((char)PUNCTUATION[c]);
_L8:
        int j1;
        int k1;
        if(++i1 >= j)
        {
            j1 = 0;
            k1 = stringbuilder1.length();
            int l1 = 0;
            while(l1 < k1) 
            {
                boolean flag;
                if(l1 % 2 != 0)
                    flag = true;
                else
                    flag = false;
                if(flag)
                {
                    j1 = j1 * 30 + stringbuilder1.charAt(l1);
                    stringbuilder.append(j1);
                } else
                {
                    j1 = stringbuilder1.charAt(l1);
                }
                l1++;
            }
            break; /* Loop/switch isn't completed */
        }
        continue; /* Loop/switch isn't completed */
_L2:
        if(isAlphaUpper(c))
        {
            if(c == ' ')
                stringbuilder1.append('\032');
            else
                stringbuilder1.append(c + -65);
            continue; /* Loop/switch isn't completed */
        }
        if(isAlphaLower(c))
        {
            l = 1;
            stringbuilder1.append('\033');
        } else
        if(isMixed(c))
        {
            l = 2;
            stringbuilder1.append('\034');
        } else
        {
            stringbuilder1.append('\035');
            stringbuilder1.append((char)PUNCTUATION[c]);
            continue; /* Loop/switch isn't completed */
        }
        continue; /* Loop/switch isn't completed */
_L3:
        if(isAlphaLower(c))
        {
            if(c == ' ')
                stringbuilder1.append('\032');
            else
                stringbuilder1.append(c + -97);
            continue; /* Loop/switch isn't completed */
        }
        if(isAlphaUpper(c))
        {
            stringbuilder1.append('\033');
            stringbuilder1.append(c + -65);
            continue; /* Loop/switch isn't completed */
        }
        if(isMixed(c))
        {
            l = 2;
            stringbuilder1.append('\034');
        } else
        {
            stringbuilder1.append('\035');
            stringbuilder1.append((char)PUNCTUATION[c]);
            continue; /* Loop/switch isn't completed */
        }
        continue; /* Loop/switch isn't completed */
_L4:
        if(isMixed(c))
        {
            stringbuilder1.append((char)MIXED[c]);
            continue; /* Loop/switch isn't completed */
        }
        if(isAlphaUpper(c))
        {
            l = 0;
            stringbuilder1.append('\034');
            continue; /* Loop/switch isn't completed */
        }
        if(isAlphaLower(c))
        {
            l = 1;
            stringbuilder1.append('\033');
            continue; /* Loop/switch isn't completed */
        }
        if(1 + (i + i1) < j && isPunctuation(charsequence.charAt(1 + (i + i1))))
        {
            l = 3;
            stringbuilder1.append('\031');
            continue; /* Loop/switch isn't completed */
        }
        stringbuilder1.append('\035');
        stringbuilder1.append((char)PUNCTUATION[c]);
        if(true) goto _L8; else goto _L7
_L7:
        break; /* Loop/switch isn't completed */
_L6:
        l = 0;
        stringbuilder1.append('\035');
        if(true) goto _L10; else goto _L9
_L9:
        if(k1 % 2 != 0)
            stringbuilder.append(29 + j1 * 30);
        return l;
    }

    private static void encodingECI(int i, StringBuilder stringbuilder)
        throws WriterException
    {
        if(i >= 0 && i < 900)
        {
            stringbuilder.append('\u039F');
            stringbuilder.append((char)i);
        } else
        if(i < 0xc5f94)
        {
            stringbuilder.append('\u039E');
            stringbuilder.append((char)(-1 + i / 900));
            stringbuilder.append((char)(i % 900));
        } else
        if(i < 0xc6318)
        {
            stringbuilder.append('\u039D');
            stringbuilder.append((char)(0xc5f94 - i));
        } else
        {
            throw new WriterException((new StringBuilder()).append("ECI number not in valid range from 0..811799, but was ").append(i).toString());
        }
    }

    private static boolean isAlphaLower(char c)
    {
        boolean flag;
        if(c == ' ' || c >= 'a' && c <= 'z')
            flag = true;
        else
            flag = false;
        return flag;
    }

    private static boolean isAlphaUpper(char c)
    {
        boolean flag;
        if(c == ' ' || c >= 'A' && c <= 'Z')
            flag = true;
        else
            flag = false;
        return flag;
    }

    private static boolean isDigit(char c)
    {
        boolean flag;
        if(c >= '0' && c <= '9')
            flag = true;
        else
            flag = false;
        return flag;
    }

    private static boolean isMixed(char c)
    {
        boolean flag;
        if(MIXED[c] != -1)
            flag = true;
        else
            flag = false;
        return flag;
    }

    private static boolean isPunctuation(char c)
    {
        boolean flag;
        if(PUNCTUATION[c] != -1)
            flag = true;
        else
            flag = false;
        return flag;
    }

    private static boolean isText(char c)
    {
        boolean flag;
        if(c == '\t' || c == '\n' || c == '\r' || c >= ' ' && c <= '~')
            flag = true;
        else
            flag = false;
        return flag;
    }

    static 
    {
        byte abyte0[] = new byte[30];
        abyte0[0] = 48;
        abyte0[1] = 49;
        abyte0[2] = 50;
        abyte0[3] = 51;
        abyte0[4] = 52;
        abyte0[5] = 53;
        abyte0[6] = 54;
        abyte0[7] = 55;
        abyte0[8] = 56;
        abyte0[9] = 57;
        abyte0[10] = 38;
        abyte0[11] = 13;
        abyte0[12] = 9;
        abyte0[13] = 44;
        abyte0[14] = 58;
        abyte0[15] = 35;
        abyte0[16] = 45;
        abyte0[17] = 46;
        abyte0[18] = 36;
        abyte0[19] = 47;
        abyte0[20] = 43;
        abyte0[21] = 37;
        abyte0[22] = 42;
        abyte0[23] = 61;
        abyte0[24] = 94;
        abyte0[25] = 0;
        abyte0[26] = 32;
        abyte0[27] = 0;
        abyte0[28] = 0;
        abyte0[29] = 0;
        TEXT_MIXED_RAW = abyte0;
        byte abyte1[] = new byte[30];
        abyte1[0] = 59;
        abyte1[1] = 60;
        abyte1[2] = 62;
        abyte1[3] = 64;
        abyte1[4] = 91;
        abyte1[5] = 92;
        abyte1[6] = 93;
        abyte1[7] = 95;
        abyte1[8] = 96;
        abyte1[9] = 126;
        abyte1[10] = 33;
        abyte1[11] = 13;
        abyte1[12] = 9;
        abyte1[13] = 44;
        abyte1[14] = 58;
        abyte1[15] = 10;
        abyte1[16] = 45;
        abyte1[17] = 46;
        abyte1[18] = 36;
        abyte1[19] = 47;
        abyte1[20] = 34;
        abyte1[21] = 124;
        abyte1[22] = 42;
        abyte1[23] = 40;
        abyte1[24] = 41;
        abyte1[25] = 63;
        abyte1[26] = 123;
        abyte1[27] = 125;
        abyte1[28] = 39;
        abyte1[29] = 0;
        TEXT_PUNCTUATION_RAW = abyte1;
        MIXED = new byte[128];
        PUNCTUATION = new byte[128];
        Arrays.fill(MIXED, (byte)-1);
        for(byte byte0 = 0; byte0 < TEXT_MIXED_RAW.length; byte0++)
        {
            byte byte3 = TEXT_MIXED_RAW[byte0];
            if(byte3 > 0)
                MIXED[byte3] = byte0;
        }

        Arrays.fill(PUNCTUATION, (byte)-1);
        for(byte byte1 = 0; byte1 < TEXT_PUNCTUATION_RAW.length; byte1++)
        {
            byte byte2 = TEXT_PUNCTUATION_RAW[byte1];
            if(byte2 > 0)
                PUNCTUATION[byte2] = byte1;
        }

    }
}
