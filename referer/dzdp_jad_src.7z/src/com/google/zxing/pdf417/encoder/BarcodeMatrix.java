// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.pdf417.encoder;

import java.lang.reflect.Array;

// Referenced classes of package com.google.zxing.pdf417.encoder:
//            BarcodeRow

public final class BarcodeMatrix
{

    private int currentRow;
    private final int height;
    private final BarcodeRow matrix[];
    private final int width;

    BarcodeMatrix(int i, int j)
    {
        matrix = new BarcodeRow[i];
        int k = 0;
        for(int l = matrix.length; k < l; k++)
            matrix[k] = new BarcodeRow(1 + 17 * (j + 4));

        width = j * 17;
        height = i;
        currentRow = -1;
    }

    BarcodeRow getCurrentRow()
    {
        return matrix[currentRow];
    }

    public byte[][] getMatrix()
    {
        return getScaledMatrix(1, 1);
    }

    public byte[][] getScaledMatrix(int i, int j)
    {
        int k = j * height;
        int l = i * width;
        int ai[] = new int[2];
        ai[0] = k;
        ai[1] = l;
        byte abyte0[][] = (byte[][])Array.newInstance(Byte.TYPE, ai);
        int i1 = j * height;
        for(int j1 = 0; j1 < i1; j1++)
            abyte0[-1 + (i1 - j1)] = matrix[j1 / j].getScaledRow(i);

        return abyte0;
    }

    void set(int i, int j, byte byte0)
    {
        matrix[j].set(i, byte0);
    }

    void startRow()
    {
        currentRow = 1 + currentRow;
    }
}
