// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.pdf417;

import com.google.zxing.*;
import com.google.zxing.common.DecoderResult;
import com.google.zxing.multi.MultipleBarcodeReader;
import com.google.zxing.pdf417.decoder.PDF417ScanningDecoder;
import com.google.zxing.pdf417.detector.Detector;
import com.google.zxing.pdf417.detector.PDF417DetectorResult;
import java.util.*;

// Referenced classes of package com.google.zxing.pdf417:
//            PDF417ResultMetadata

public final class PDF417Reader
    implements Reader, MultipleBarcodeReader
{

    public PDF417Reader()
    {
    }

    private static Result[] decode(BinaryBitmap binarybitmap, Map map, boolean flag)
        throws NotFoundException, FormatException, ChecksumException
    {
        ArrayList arraylist = new ArrayList();
        PDF417DetectorResult pdf417detectorresult = Detector.detect(binarybitmap, map, flag);
        Result result;
        for(Iterator iterator = pdf417detectorresult.getPoints().iterator(); iterator.hasNext(); arraylist.add(result))
        {
            ResultPoint aresultpoint[] = (ResultPoint[])iterator.next();
            DecoderResult decoderresult = PDF417ScanningDecoder.decode(pdf417detectorresult.getBits(), aresultpoint[4], aresultpoint[5], aresultpoint[6], aresultpoint[7], getMinCodewordWidth(aresultpoint), getMaxCodewordWidth(aresultpoint));
            result = new Result(decoderresult.getText(), decoderresult.getRawBytes(), aresultpoint, BarcodeFormat.PDF_417);
            result.putMetadata(ResultMetadataType.ERROR_CORRECTION_LEVEL, decoderresult.getECLevel());
            PDF417ResultMetadata pdf417resultmetadata = (PDF417ResultMetadata)decoderresult.getOther();
            if(pdf417resultmetadata != null)
                result.putMetadata(ResultMetadataType.PDF417_EXTRA_METADATA, pdf417resultmetadata);
        }

        return (Result[])arraylist.toArray(new Result[arraylist.size()]);
    }

    private static int getMaxCodewordWidth(ResultPoint aresultpoint[])
    {
        return Math.max(Math.max(getMaxWidth(aresultpoint[0], aresultpoint[4]), (17 * getMaxWidth(aresultpoint[6], aresultpoint[2])) / 18), Math.max(getMaxWidth(aresultpoint[1], aresultpoint[5]), (17 * getMaxWidth(aresultpoint[7], aresultpoint[3])) / 18));
    }

    private static int getMaxWidth(ResultPoint resultpoint, ResultPoint resultpoint1)
    {
        int i;
        if(resultpoint == null || resultpoint1 == null)
            i = 0;
        else
            i = (int)Math.abs(resultpoint.getX() - resultpoint1.getX());
        return i;
    }

    private static int getMinCodewordWidth(ResultPoint aresultpoint[])
    {
        return Math.min(Math.min(getMinWidth(aresultpoint[0], aresultpoint[4]), (17 * getMinWidth(aresultpoint[6], aresultpoint[2])) / 18), Math.min(getMinWidth(aresultpoint[1], aresultpoint[5]), (17 * getMinWidth(aresultpoint[7], aresultpoint[3])) / 18));
    }

    private static int getMinWidth(ResultPoint resultpoint, ResultPoint resultpoint1)
    {
        int i;
        if(resultpoint == null || resultpoint1 == null)
            i = 0x7fffffff;
        else
            i = (int)Math.abs(resultpoint.getX() - resultpoint1.getX());
        return i;
    }

    public Result decode(BinaryBitmap binarybitmap)
        throws NotFoundException, FormatException, ChecksumException
    {
        return decode(binarybitmap, null);
    }

    public Result decode(BinaryBitmap binarybitmap, Map map)
        throws NotFoundException, FormatException, ChecksumException
    {
        Result aresult[] = decode(binarybitmap, map, false);
        if(aresult == null || aresult.length == 0 || aresult[0] == null)
            throw NotFoundException.getNotFoundInstance();
        else
            return aresult[0];
    }

    public Result[] decodeMultiple(BinaryBitmap binarybitmap)
        throws NotFoundException
    {
        return decodeMultiple(binarybitmap, null);
    }

    public Result[] decodeMultiple(BinaryBitmap binarybitmap, Map map)
        throws NotFoundException
    {
        Result aresult[] = decode(binarybitmap, map, true);
        return aresult;
        FormatException formatexception;
        formatexception;
_L2:
        throw NotFoundException.getNotFoundInstance();
        ChecksumException checksumexception;
        checksumexception;
        if(true) goto _L2; else goto _L1
_L1:
    }

    public void reset()
    {
    }
}
