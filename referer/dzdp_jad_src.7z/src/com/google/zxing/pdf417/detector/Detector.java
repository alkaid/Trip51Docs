// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.pdf417.detector;

import com.google.zxing.*;
import com.google.zxing.common.BitMatrix;
import java.util.*;

// Referenced classes of package com.google.zxing.pdf417.detector:
//            PDF417DetectorResult

public final class Detector
{

    private static final int BARCODE_MIN_HEIGHT = 10;
    private static final int INDEXES_START_PATTERN[];
    private static final int INDEXES_STOP_PATTERN[];
    private static final float MAX_AVG_VARIANCE = 0.42F;
    private static final float MAX_INDIVIDUAL_VARIANCE = 0.8F;
    private static final int MAX_PATTERN_DRIFT = 5;
    private static final int MAX_PIXEL_DRIFT = 3;
    private static final int ROW_STEP = 5;
    private static final int SKIPPED_ROW_COUNT_MAX = 25;
    private static final int START_PATTERN[];
    private static final int STOP_PATTERN[];

    private Detector()
    {
    }

    private static void copyToResult(ResultPoint aresultpoint[], ResultPoint aresultpoint1[], int ai[])
    {
        for(int i = 0; i < ai.length; i++)
            aresultpoint[ai[i]] = aresultpoint1[i];

    }

    public static PDF417DetectorResult detect(BinaryBitmap binarybitmap, Map map, boolean flag)
        throws NotFoundException
    {
        BitMatrix bitmatrix = binarybitmap.getBlackMatrix();
        List list = detect(flag, bitmatrix);
        if(list.isEmpty())
        {
            bitmatrix = bitmatrix.clone();
            bitmatrix.rotate180();
            list = detect(flag, bitmatrix);
        }
        return new PDF417DetectorResult(bitmatrix, list);
    }

    private static List detect(boolean flag, BitMatrix bitmatrix)
    {
        ArrayList arraylist;
        int i;
        int j;
        boolean flag1;
        arraylist = new ArrayList();
        i = 0;
        j = 0;
        flag1 = false;
_L8:
        if(i >= bitmatrix.getHeight()) goto _L2; else goto _L1
_L1:
        ResultPoint aresultpoint[] = findVertices(bitmatrix, i, j);
        if(aresultpoint[0] != null || aresultpoint[3] != null) goto _L4; else goto _L3
_L3:
        if(flag1) goto _L5; else goto _L2
_L2:
        return arraylist;
_L5:
        flag1 = false;
        j = 0;
        Iterator iterator = arraylist.iterator();
        do
        {
            if(!iterator.hasNext())
                break;
            ResultPoint aresultpoint1[] = (ResultPoint[])iterator.next();
            if(aresultpoint1[1] != null)
                i = (int)Math.max(i, aresultpoint1[1].getY());
            if(aresultpoint1[3] != null)
                i = Math.max(i, (int)aresultpoint1[3].getY());
        } while(true);
        i += 5;
        continue; /* Loop/switch isn't completed */
_L4:
        flag1 = true;
        arraylist.add(aresultpoint);
        if(!flag) goto _L2; else goto _L6
_L6:
        if(aresultpoint[2] != null)
        {
            j = (int)aresultpoint[2].getX();
            i = (int)aresultpoint[2].getY();
        } else
        {
            j = (int)aresultpoint[4].getX();
            i = (int)aresultpoint[4].getY();
        }
        if(true) goto _L8; else goto _L7
_L7:
    }

    private static int[] findGuardPattern(BitMatrix bitmatrix, int i, int j, int k, boolean flag, int ai[], int ai1[])
    {
        int l;
        boolean flag1;
        int i1;
        int k1;
        int l1;
        Arrays.fill(ai1, 0, ai1.length, 0);
        l = ai.length;
        flag1 = flag;
        i1 = i;
        int j1 = 0;
        do
        {
            if(!bitmatrix.get(i1, j) || i1 <= 0)
                break;
            int i2 = j1 + 1;
            if(j1 >= 3)
                break;
            i1--;
            j1 = i2;
        } while(true);
        k1 = i1;
        l1 = 0;
_L2:
        if(k1 >= k)
            break MISSING_BLOCK_LABEL_225;
        if(!(flag1 ^ bitmatrix.get(k1, j)))
            break; /* Loop/switch isn't completed */
        ai1[l1] = 1 + ai1[l1];
_L7:
        k1++;
        if(true) goto _L2; else goto _L1
_L1:
        if(l1 != l - 1) goto _L4; else goto _L3
_L3:
        if(patternMatchVariance(ai1, ai, 0.8F) >= 0.42F) goto _L6; else goto _L5
_L5:
        int ai2[];
        ai2 = new int[2];
        ai2[0] = i1;
        ai2[1] = k1;
_L9:
        return ai2;
_L6:
        i1 += ai1[0] + ai1[1];
        System.arraycopy(ai1, 2, ai1, 0, l - 2);
        ai1[l - 2] = 0;
        ai1[l - 1] = 0;
        l1--;
_L8:
        ai1[l1] = 1;
        if(!flag1)
            flag1 = true;
        else
            flag1 = false;
          goto _L7
_L4:
        l1++;
          goto _L8
        if(l1 == l - 1 && patternMatchVariance(ai1, ai, 0.8F) < 0.42F)
        {
            ai2 = new int[2];
            ai2[0] = i1;
            ai2[1] = k1 - 1;
        } else
        {
            ai2 = null;
        }
          goto _L9
    }

    private static ResultPoint[] findRowsWithPattern(BitMatrix bitmatrix, int i, int j, int k, int l, int ai[])
    {
        ResultPoint aresultpoint[];
        boolean flag;
        int ai1[];
        aresultpoint = new ResultPoint[4];
        flag = false;
        ai1 = new int[ai.length];
_L14:
        if(k >= i) goto _L2; else goto _L1
_L1:
        int ai4[] = findGuardPattern(bitmatrix, l, k, j, false, ai, ai1);
        if(ai4 == null) goto _L4; else goto _L3
_L3:
label0:
        {
            do
            {
                if(k <= 0)
                    break label0;
                k--;
                int ai5[] = findGuardPattern(bitmatrix, l, k, j, false, ai, ai1);
                if(ai5 == null)
                    break;
                ai4 = ai5;
            } while(true);
            k++;
        }
        aresultpoint[0] = new ResultPoint(ai4[0], k);
        aresultpoint[1] = new ResultPoint(ai4[1], k);
        flag = true;
_L2:
        int i1 = k + 1;
        if(!flag) goto _L6; else goto _L5
_L5:
        int k1;
        int ai2[];
        k1 = 0;
        ai2 = new int[2];
        ai2[0] = (int)aresultpoint[0].getX();
        ai2[1] = (int)aresultpoint[1].getX();
_L11:
        if(i1 >= i) goto _L8; else goto _L7
_L7:
        int ai3[] = findGuardPattern(bitmatrix, ai2[0], i1, j, false, ai, ai1);
        if(ai3 == null || Math.abs(ai2[0] - ai3[0]) >= 5 || Math.abs(ai2[1] - ai3[1]) >= 5) goto _L10; else goto _L9
_L9:
        ai2 = ai3;
        k1 = 0;
_L12:
        i1++;
          goto _L11
_L4:
        k += 5;
        continue; /* Loop/switch isn't completed */
_L10:
        if(k1 <= 25)
            break MISSING_BLOCK_LABEL_325;
_L8:
        i1 -= k1 + 1;
        aresultpoint[2] = new ResultPoint(ai2[0], i1);
        aresultpoint[3] = new ResultPoint(ai2[1], i1);
_L6:
        if(i1 - k < 10)
        {
            for(int j1 = 0; j1 < aresultpoint.length; j1++)
                aresultpoint[j1] = null;

        }
        break MISSING_BLOCK_LABEL_331;
        k1++;
          goto _L12
        return aresultpoint;
        if(true) goto _L14; else goto _L13
_L13:
    }

    private static ResultPoint[] findVertices(BitMatrix bitmatrix, int i, int j)
    {
        int k = bitmatrix.getHeight();
        int l = bitmatrix.getWidth();
        ResultPoint aresultpoint[] = new ResultPoint[8];
        int ai[] = START_PATTERN;
        copyToResult(aresultpoint, findRowsWithPattern(bitmatrix, k, l, i, j, ai), INDEXES_START_PATTERN);
        if(aresultpoint[4] != null)
        {
            j = (int)aresultpoint[4].getX();
            i = (int)aresultpoint[4].getY();
        }
        int ai1[] = STOP_PATTERN;
        copyToResult(aresultpoint, findRowsWithPattern(bitmatrix, k, l, i, j, ai1), INDEXES_STOP_PATTERN);
        return aresultpoint;
    }

    private static float patternMatchVariance(int ai[], int ai1[], float f)
    {
        float f1;
        int i;
        int j;
        int k;
        f1 = (1.0F / 0.0F);
        i = ai.length;
        j = 0;
        k = 0;
        for(int l = 0; l < i; l++)
        {
            j += ai[l];
            k += ai1[l];
        }

        if(j >= k) goto _L2; else goto _L1
_L1:
        return f1;
_L2:
        float f2 = (float)j / (float)k;
        float f3 = f * f2;
        float f4 = 0.0F;
        int i1 = 0;
        while(i1 < i) 
        {
            int j1 = ai[i1];
            float f5 = f2 * (float)ai1[i1];
            float f6;
            if((float)j1 > f5)
                f6 = (float)j1 - f5;
            else
                f6 = f5 - (float)j1;
            if(f6 > f3)
                continue; /* Loop/switch isn't completed */
            f4 += f6;
            i1++;
        }
        f1 = f4 / (float)j;
        if(true) goto _L1; else goto _L3
_L3:
    }

    static 
    {
        int ai[] = new int[4];
        ai[0] = 0;
        ai[1] = 4;
        ai[2] = 1;
        ai[3] = 5;
        INDEXES_START_PATTERN = ai;
        int ai1[] = new int[4];
        ai1[0] = 6;
        ai1[1] = 2;
        ai1[2] = 7;
        ai1[3] = 3;
        INDEXES_STOP_PATTERN = ai1;
        int ai2[] = new int[8];
        ai2[0] = 8;
        ai2[1] = 1;
        ai2[2] = 1;
        ai2[3] = 1;
        ai2[4] = 1;
        ai2[5] = 1;
        ai2[6] = 1;
        ai2[7] = 3;
        START_PATTERN = ai2;
        int ai3[] = new int[9];
        ai3[0] = 7;
        ai3[1] = 1;
        ai3[2] = 1;
        ai3[3] = 3;
        ai3[4] = 1;
        ai3[5] = 1;
        ai3[6] = 1;
        ai3[7] = 2;
        ai3[8] = 1;
        STOP_PATTERN = ai3;
    }
}
