// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.pdf417.detector;

import com.google.zxing.common.BitMatrix;
import java.util.List;

public final class PDF417DetectorResult
{

    private final BitMatrix bits;
    private final List points;

    public PDF417DetectorResult(BitMatrix bitmatrix, List list)
    {
        bits = bitmatrix;
        points = list;
    }

    public BitMatrix getBits()
    {
        return bits;
    }

    public List getPoints()
    {
        return points;
    }
}
