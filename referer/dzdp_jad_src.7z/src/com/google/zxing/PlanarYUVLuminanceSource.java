// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing;


// Referenced classes of package com.google.zxing:
//            LuminanceSource

public final class PlanarYUVLuminanceSource extends LuminanceSource
{

    private static final int THUMBNAIL_SCALE_FACTOR = 2;
    private final int dataHeight;
    private final int dataWidth;
    private final int left;
    private final int top;
    private final byte yuvData[];

    public PlanarYUVLuminanceSource(byte abyte0[], int i, int j, int k, int l, int i1, int j1, 
            boolean flag)
    {
        super(i1, j1);
        if(k + i1 > i || l + j1 > j)
            throw new IllegalArgumentException("Crop rectangle does not fit within image data.");
        yuvData = abyte0;
        dataWidth = i;
        dataHeight = j;
        left = k;
        top = l;
        if(flag)
            reverseHorizontal(i1, j1);
    }

    private void reverseHorizontal(int i, int j)
    {
        byte abyte0[] = yuvData;
        int k = 0;
        for(int l = top * dataWidth + left; k < j; l += dataWidth)
        {
            int i1 = l + i / 2;
            int j1 = l;
            for(int k1 = -1 + (l + i); j1 < i1; k1--)
            {
                byte byte0 = abyte0[j1];
                abyte0[j1] = abyte0[k1];
                abyte0[k1] = byte0;
                j1++;
            }

            k++;
        }

    }

    public LuminanceSource crop(int i, int j, int k, int l)
    {
        return new PlanarYUVLuminanceSource(yuvData, dataWidth, dataHeight, i + left, j + top, k, l, false);
    }

    public byte[] getMatrix()
    {
        int i;
        int j;
        i = getWidth();
        j = getHeight();
        if(i != dataWidth || j != dataHeight) goto _L2; else goto _L1
_L1:
        byte abyte0[] = yuvData;
_L4:
        return abyte0;
_L2:
        int l;
        int k = i * j;
        abyte0 = new byte[k];
        l = top * dataWidth + left;
        if(i != dataWidth)
            break; /* Loop/switch isn't completed */
        System.arraycopy(yuvData, l, abyte0, 0, k);
        if(true) goto _L4; else goto _L3
_L3:
        byte abyte1[] = yuvData;
        int i1 = 0;
        while(i1 < j) 
        {
            System.arraycopy(abyte1, l, abyte0, i1 * i, i);
            l += dataWidth;
            i1++;
        }
        if(true) goto _L4; else goto _L5
_L5:
    }

    public byte[] getRow(int i, byte abyte0[])
    {
        if(i < 0 || i >= getHeight())
            throw new IllegalArgumentException((new StringBuilder()).append("Requested row is outside the image: ").append(i).toString());
        int j = getWidth();
        if(abyte0 == null || abyte0.length < j)
            abyte0 = new byte[j];
        int k = (i + top) * dataWidth + left;
        System.arraycopy(yuvData, k, abyte0, 0, j);
        return abyte0;
    }

    public int getThumbnailHeight()
    {
        return getHeight() / 2;
    }

    public int getThumbnailWidth()
    {
        return getWidth() / 2;
    }

    public boolean isCropSupported()
    {
        return true;
    }

    public int[] renderThumbnail()
    {
        int i = getWidth() / 2;
        int j = getHeight() / 2;
        int ai[] = new int[i * j];
        byte abyte0[] = yuvData;
        int k = top * dataWidth + left;
        for(int l = 0; l < j; l++)
        {
            int i1 = l * i;
            for(int j1 = 0; j1 < i; j1++)
            {
                int k1 = 0xff & abyte0[k + j1 * 2];
                ai[i1 + j1] = 0xff000000 | 0x10101 * k1;
            }

            k += 2 * dataWidth;
        }

        return ai;
    }
}
