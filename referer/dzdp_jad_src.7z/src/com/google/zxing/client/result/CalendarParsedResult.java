// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.client.result;

import java.text.*;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

// Referenced classes of package com.google.zxing.client.result:
//            ParsedResult, ParsedResultType

public final class CalendarParsedResult extends ParsedResult
{

    private static final Pattern DATE_TIME = Pattern.compile("[0-9]{8}(T[0-9]{6}Z?)?");
    private static final Pattern RFC2445_DURATION = Pattern.compile("P(?:(\\d+)W)?(?:(\\d+)D)?(?:T(?:(\\d+)H)?(?:(\\d+)M)?(?:(\\d+)S)?)?");
    private static final long RFC2445_DURATION_FIELD_UNITS[];
    private final String attendees[];
    private final String description;
    private final Date end;
    private final boolean endAllDay;
    private final double latitude;
    private final String location;
    private final double longitude;
    private final String organizer;
    private final Date start;
    private final boolean startAllDay;
    private final String summary;

    public CalendarParsedResult(String s, String s1, String s2, String s3, String s4, String s5, String as[], 
            String s6, double d, double d1)
    {
        super(ParsedResultType.CALENDAR);
        summary = s;
        boolean flag;
        boolean flag1;
        try
        {
            start = parseDate(s1);
        }
        catch(ParseException parseexception)
        {
            throw new IllegalArgumentException(parseexception.toString());
        }
        if(s2 == null)
        {
            long l = parseDurationMS(s3);
            Date date;
            if(l < 0L)
                date = null;
            else
                date = new Date(l + start.getTime());
            end = date;
        } else
        {
            try
            {
                end = parseDate(s2);
            }
            catch(ParseException parseexception1)
            {
                throw new IllegalArgumentException(parseexception1.toString());
            }
        }
        if(s1.length() == 8)
            flag = true;
        else
            flag = false;
        startAllDay = flag;
        if(s2 != null && s2.length() == 8)
            flag1 = true;
        else
            flag1 = false;
        endAllDay = flag1;
        location = s4;
        organizer = s5;
        attendees = as;
        description = s6;
        latitude = d;
        longitude = d1;
    }

    private static DateFormat buildDateFormat()
    {
        SimpleDateFormat simpledateformat = new SimpleDateFormat("yyyyMMdd", Locale.ENGLISH);
        simpledateformat.setTimeZone(TimeZone.getTimeZone("GMT"));
        return simpledateformat;
    }

    private static DateFormat buildDateTimeFormat()
    {
        return new SimpleDateFormat("yyyyMMdd'T'HHmmss", Locale.ENGLISH);
    }

    private static String format(boolean flag, Date date)
    {
        String s;
        if(date == null)
        {
            s = null;
        } else
        {
            DateFormat dateformat;
            if(flag)
                dateformat = DateFormat.getDateInstance(2);
            else
                dateformat = DateFormat.getDateTimeInstance(2, 2);
            s = dateformat.format(date);
        }
        return s;
    }

    private static Date parseDate(String s)
        throws ParseException
    {
        if(!DATE_TIME.matcher(s).matches())
            throw new ParseException(s, 0);
        Date date;
        if(s.length() == 8)
            date = buildDateFormat().parse(s);
        else
        if(s.length() == 16 && s.charAt(15) == 'Z')
        {
            Date date1 = buildDateTimeFormat().parse(s.substring(0, 15));
            GregorianCalendar gregoriancalendar = new GregorianCalendar();
            long l = date1.getTime() + (long)gregoriancalendar.get(15);
            gregoriancalendar.setTime(new Date(l));
            date = new Date(l + (long)gregoriancalendar.get(16));
        } else
        {
            date = buildDateTimeFormat().parse(s);
        }
        return date;
    }

    private static long parseDurationMS(CharSequence charsequence)
    {
        long l = -1L;
        if(charsequence != null) goto _L2; else goto _L1
_L1:
        Matcher matcher;
        return l;
_L2:
        if((matcher = RFC2445_DURATION.matcher(charsequence)).matches())
        {
            l = 0L;
            int i = 0;
            while(i < RFC2445_DURATION_FIELD_UNITS.length) 
            {
                String s = matcher.group(i + 1);
                if(s != null)
                    l += RFC2445_DURATION_FIELD_UNITS[i] * (long)Integer.parseInt(s);
                i++;
            }
        }
        if(true) goto _L1; else goto _L3
_L3:
    }

    public String[] getAttendees()
    {
        return attendees;
    }

    public String getDescription()
    {
        return description;
    }

    public String getDisplayResult()
    {
        StringBuilder stringbuilder = new StringBuilder(100);
        maybeAppend(summary, stringbuilder);
        maybeAppend(format(startAllDay, start), stringbuilder);
        maybeAppend(format(endAllDay, end), stringbuilder);
        maybeAppend(location, stringbuilder);
        maybeAppend(organizer, stringbuilder);
        maybeAppend(attendees, stringbuilder);
        maybeAppend(description, stringbuilder);
        return stringbuilder.toString();
    }

    public Date getEnd()
    {
        return end;
    }

    public double getLatitude()
    {
        return latitude;
    }

    public String getLocation()
    {
        return location;
    }

    public double getLongitude()
    {
        return longitude;
    }

    public String getOrganizer()
    {
        return organizer;
    }

    public Date getStart()
    {
        return start;
    }

    public String getSummary()
    {
        return summary;
    }

    public boolean isEndAllDay()
    {
        return endAllDay;
    }

    public boolean isStartAllDay()
    {
        return startAllDay;
    }

    static 
    {
        long al[] = new long[5];
        al[0] = 0x240c8400L;
        al[1] = 0x5265c00L;
        al[2] = 0x36ee80L;
        al[3] = 60000L;
        al[4] = 1000L;
        RFC2445_DURATION_FIELD_UNITS = al;
    }
}
