// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.client.result;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.Result;

// Referenced classes of package com.google.zxing.client.result:
//            ResultParser, ISBNParsedResult, ParsedResult

public final class ISBNResultParser extends ResultParser
{

    public ISBNResultParser()
    {
    }

    public ISBNParsedResult parse(Result result)
    {
        ISBNParsedResult isbnparsedresult = null;
        if(result.getBarcodeFormat() == BarcodeFormat.EAN_13) goto _L2; else goto _L1
_L1:
        return isbnparsedresult;
_L2:
        String s = getMassagedText(result);
        if(s.length() == 13 && (s.startsWith("978") || s.startsWith("979")))
            isbnparsedresult = new ISBNParsedResult(s);
        if(true) goto _L1; else goto _L3
_L3:
    }

    public volatile ParsedResult parse(Result result)
    {
        return parse(result);
    }
}
