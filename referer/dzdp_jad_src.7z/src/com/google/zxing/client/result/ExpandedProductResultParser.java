// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.client.result;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.Result;
import java.util.HashMap;
import java.util.Map;

// Referenced classes of package com.google.zxing.client.result:
//            ResultParser, ExpandedProductParsedResult, ParsedResult

public final class ExpandedProductResultParser extends ResultParser
{

    public ExpandedProductResultParser()
    {
    }

    private static String findAIvalue(int i, String s)
    {
        String s1 = null;
        if(s.charAt(i) == '(') goto _L2; else goto _L1
_L1:
        return s1;
_L2:
        String s2 = s.substring(i + 1);
        StringBuilder stringbuilder = new StringBuilder();
        for(int j = 0; j < s2.length(); j++)
        {
            char c = s2.charAt(j);
            if(c == ')')
            {
                s1 = stringbuilder.toString();
                continue; /* Loop/switch isn't completed */
            }
            if(c < '0' || c > '9')
                continue; /* Loop/switch isn't completed */
            stringbuilder.append(c);
        }

        s1 = stringbuilder.toString();
        if(true) goto _L1; else goto _L3
_L3:
    }

    private static String findValue(int i, String s)
    {
        StringBuilder stringbuilder;
        String s1;
        int j;
        stringbuilder = new StringBuilder();
        s1 = s.substring(i);
        j = 0;
_L8:
        if(j >= s1.length()) goto _L2; else goto _L1
_L1:
        char c = s1.charAt(j);
        if(c != '(') goto _L4; else goto _L3
_L3:
        if(findAIvalue(j, s1) != null) goto _L2; else goto _L5
_L5:
        stringbuilder.append('(');
_L6:
        j++;
        continue; /* Loop/switch isn't completed */
_L4:
        stringbuilder.append(c);
        if(true) goto _L6; else goto _L2
_L2:
        return stringbuilder.toString();
        if(true) goto _L8; else goto _L7
_L7:
    }

    public ExpandedProductParsedResult parse(Result result)
    {
        if(result.getBarcodeFormat() == BarcodeFormat.RSS_EXPANDED) goto _L2; else goto _L1
_L1:
        ExpandedProductParsedResult expandedproductparsedresult = null;
_L43:
        return expandedproductparsedresult;
_L2:
        String s;
        String s1;
        String s2;
        String s3;
        String s4;
        String s5;
        String s6;
        String s7;
        String s8;
        String s9;
        String s10;
        String s11;
        String s12;
        String s13;
        HashMap hashmap;
        int i;
        s = getMassagedText(result);
        s1 = null;
        s2 = null;
        s3 = null;
        s4 = null;
        s5 = null;
        s6 = null;
        s7 = null;
        s8 = null;
        s9 = null;
        s10 = null;
        s11 = null;
        s12 = null;
        s13 = null;
        hashmap = new HashMap();
        i = 0;
_L41:
        String s14;
        String s15;
        byte byte0;
        int j = s.length();
        if(i >= j)
            break; /* Loop/switch isn't completed */
        s14 = findAIvalue(i, s);
        if(s14 == null)
        {
            expandedproductparsedresult = null;
            continue; /* Loop/switch isn't completed */
        }
        int k = i + (2 + s14.length());
        s15 = findValue(k, s);
        i = k + s15.length();
        byte0 = -1;
        s14.hashCode();
        JVM INSTR lookupswitch 35: default 432
    //                   1536: 603
    //                   1537: 619
    //                   1567: 635
    //                   1568: 651
    //                   1570: 667
    //                   1572: 683
    //                   1574: 699
    //                   1567966: 716
    //                   1567967: 733
    //                   1567968: 750
    //                   1567969: 767
    //                   1567970: 784
    //                   1567971: 801
    //                   1567972: 818
    //                   1567973: 835
    //                   1567974: 852
    //                   1567975: 869
    //                   1568927: 886
    //                   1568928: 903
    //                   1568929: 920
    //                   1568930: 937
    //                   1568931: 954
    //                   1568932: 971
    //                   1568933: 988
    //                   1568934: 1005
    //                   1568935: 1022
    //                   1568936: 1039
    //                   1575716: 1056
    //                   1575717: 1073
    //                   1575718: 1090
    //                   1575719: 1107
    //                   1575747: 1124
    //                   1575748: 1141
    //                   1575749: 1158
    //                   1575750: 1175;
           goto _L3 _L4 _L5 _L6 _L7 _L8 _L9 _L10 _L11 _L12 _L13 _L14 _L15 _L16 _L17 _L18 _L19 _L20 _L21 _L22 _L23 _L24 _L25 _L26 _L27 _L28 _L29 _L30 _L31 _L32 _L33 _L34 _L35 _L36 _L37 _L38
_L3:
        break; /* Loop/switch isn't completed */
_L38:
        break MISSING_BLOCK_LABEL_1175;
_L39:
        switch(byte0)
        {
        default:
            hashmap.put(s14, s15);
            continue; /* Loop/switch isn't completed */

        case 0: // '\0'
            s2 = s15;
            continue; /* Loop/switch isn't completed */

        case 1: // '\001'
            s1 = s15;
            continue; /* Loop/switch isn't completed */

        case 2: // '\002'
            s3 = s15;
            continue; /* Loop/switch isn't completed */

        case 3: // '\003'
            s4 = s15;
            continue; /* Loop/switch isn't completed */

        case 4: // '\004'
            s5 = s15;
            continue; /* Loop/switch isn't completed */

        case 5: // '\005'
            s6 = s15;
            continue; /* Loop/switch isn't completed */

        case 6: // '\006'
            s7 = s15;
            continue; /* Loop/switch isn't completed */

        case 7: // '\007'
        case 8: // '\b'
        case 9: // '\t'
        case 10: // '\n'
        case 11: // '\013'
        case 12: // '\f'
        case 13: // '\r'
        case 14: // '\016'
        case 15: // '\017'
        case 16: // '\020'
            s8 = s15;
            s9 = "KG";
            s10 = s14.substring(3);
            continue; /* Loop/switch isn't completed */

        case 17: // '\021'
        case 18: // '\022'
        case 19: // '\023'
        case 20: // '\024'
        case 21: // '\025'
        case 22: // '\026'
        case 23: // '\027'
        case 24: // '\030'
        case 25: // '\031'
        case 26: // '\032'
            s8 = s15;
            s9 = "LB";
            s10 = s14.substring(3);
            continue; /* Loop/switch isn't completed */

        case 27: // '\033'
        case 28: // '\034'
        case 29: // '\035'
        case 30: // '\036'
            s11 = s15;
            s12 = s14.substring(3);
            continue; /* Loop/switch isn't completed */

        case 31: // '\037'
        case 32: // ' '
        case 33: // '!'
        case 34: // '"'
            break;
        }
        break MISSING_BLOCK_LABEL_1293;
_L4:
        if(s14.equals("00"))
            byte0 = 0;
          goto _L39
_L5:
        if(s14.equals("01"))
            byte0 = 1;
          goto _L39
_L6:
        if(s14.equals("10"))
            byte0 = 2;
          goto _L39
_L7:
        if(s14.equals("11"))
            byte0 = 3;
          goto _L39
_L8:
        if(s14.equals("13"))
            byte0 = 4;
          goto _L39
_L9:
        if(s14.equals("15"))
            byte0 = 5;
          goto _L39
_L10:
        if(s14.equals("17"))
            byte0 = 6;
          goto _L39
_L11:
        if(s14.equals("3100"))
            byte0 = 7;
          goto _L39
_L12:
        if(s14.equals("3101"))
            byte0 = 8;
          goto _L39
_L13:
        if(s14.equals("3102"))
            byte0 = 9;
          goto _L39
_L14:
        if(s14.equals("3103"))
            byte0 = 10;
          goto _L39
_L15:
        if(s14.equals("3104"))
            byte0 = 11;
          goto _L39
_L16:
        if(s14.equals("3105"))
            byte0 = 12;
          goto _L39
_L17:
        if(s14.equals("3106"))
            byte0 = 13;
          goto _L39
_L18:
        if(s14.equals("3107"))
            byte0 = 14;
          goto _L39
_L19:
        if(s14.equals("3108"))
            byte0 = 15;
          goto _L39
_L20:
        if(s14.equals("3109"))
            byte0 = 16;
          goto _L39
_L21:
        if(s14.equals("3200"))
            byte0 = 17;
          goto _L39
_L22:
        if(s14.equals("3201"))
            byte0 = 18;
          goto _L39
_L23:
        if(s14.equals("3202"))
            byte0 = 19;
          goto _L39
_L24:
        if(s14.equals("3203"))
            byte0 = 20;
          goto _L39
_L25:
        if(s14.equals("3204"))
            byte0 = 21;
          goto _L39
_L26:
        if(s14.equals("3205"))
            byte0 = 22;
          goto _L39
_L27:
        if(s14.equals("3206"))
            byte0 = 23;
          goto _L39
_L28:
        if(s14.equals("3207"))
            byte0 = 24;
          goto _L39
_L29:
        if(s14.equals("3208"))
            byte0 = 25;
          goto _L39
_L30:
        if(s14.equals("3209"))
            byte0 = 26;
          goto _L39
_L31:
        if(s14.equals("3920"))
            byte0 = 27;
          goto _L39
_L32:
        if(s14.equals("3921"))
            byte0 = 28;
          goto _L39
_L33:
        if(s14.equals("3922"))
            byte0 = 29;
          goto _L39
_L34:
        if(s14.equals("3923"))
            byte0 = 30;
          goto _L39
_L35:
        if(s14.equals("3930"))
            byte0 = 31;
          goto _L39
_L36:
        if(s14.equals("3931"))
            byte0 = 32;
          goto _L39
_L37:
        if(s14.equals("3932"))
            byte0 = 33;
          goto _L39
        if(s14.equals("3933"))
            byte0 = 34;
          goto _L39
        if(s15.length() < 4)
        {
            expandedproductparsedresult = null;
            continue; /* Loop/switch isn't completed */
        }
        s11 = s15.substring(3);
        s13 = s15.substring(0, 3);
        s12 = s14.substring(3);
        if(true) goto _L41; else goto _L40
_L40:
        expandedproductparsedresult = new ExpandedProductParsedResult(s, s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12, s13, hashmap);
        if(true) goto _L43; else goto _L42
_L42:
    }

    public volatile ParsedResult parse(Result result)
    {
        return parse(result);
    }
}
