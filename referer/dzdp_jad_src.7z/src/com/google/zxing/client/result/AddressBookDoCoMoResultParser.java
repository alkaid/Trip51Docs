// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.client.result;

import com.google.zxing.Result;

// Referenced classes of package com.google.zxing.client.result:
//            AbstractDoCoMoResultParser, AddressBookParsedResult, ParsedResult

public final class AddressBookDoCoMoResultParser extends AbstractDoCoMoResultParser
{

    public AddressBookDoCoMoResultParser()
    {
    }

    private static String parseName(String s)
    {
        int i = s.indexOf(',');
        if(i >= 0)
            s = (new StringBuilder()).append(s.substring(i + 1)).append(' ').append(s.substring(0, i)).toString();
        return s;
    }

    public AddressBookParsedResult parse(Result result)
    {
        String s = getMassagedText(result);
        AddressBookParsedResult addressbookparsedresult;
        if(!s.startsWith("MECARD:"))
        {
            addressbookparsedresult = null;
        } else
        {
            String as[] = matchDoCoMoPrefixedField("N:", s, true);
            if(as == null)
            {
                addressbookparsedresult = null;
            } else
            {
                String s1 = parseName(as[0]);
                String s2 = matchSingleDoCoMoPrefixedField("SOUND:", s, true);
                String as1[] = matchDoCoMoPrefixedField("TEL:", s, true);
                String as2[] = matchDoCoMoPrefixedField("EMAIL:", s, true);
                String s3 = matchSingleDoCoMoPrefixedField("NOTE:", s, false);
                String as3[] = matchDoCoMoPrefixedField("ADR:", s, true);
                String s4 = matchSingleDoCoMoPrefixedField("BDAY:", s, true);
                if(!isStringOfDigits(s4, 8))
                    s4 = null;
                String as4[] = matchDoCoMoPrefixedField("URL:", s, true);
                String s5 = matchSingleDoCoMoPrefixedField("ORG:", s, true);
                addressbookparsedresult = new AddressBookParsedResult(maybeWrap(s1), null, s2, as1, null, as2, null, null, s3, as3, null, s5, s4, null, as4, null);
            }
        }
        return addressbookparsedresult;
    }

    public volatile ParsedResult parse(Result result)
    {
        return parse(result);
    }
}
