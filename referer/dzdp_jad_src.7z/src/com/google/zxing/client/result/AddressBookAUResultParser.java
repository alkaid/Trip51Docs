// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.client.result;

import com.google.zxing.Result;
import java.util.ArrayList;
import java.util.List;

// Referenced classes of package com.google.zxing.client.result:
//            ResultParser, AddressBookParsedResult, ParsedResult

public final class AddressBookAUResultParser extends ResultParser
{

    public AddressBookAUResultParser()
    {
    }

    private static String[] matchMultipleValuePrefix(String s, int i, String s1, boolean flag)
    {
        ArrayList arraylist = null;
        int j = 1;
        do
        {
label0:
            {
                String s2;
                if(j <= i)
                {
                    s2 = matchSinglePrefixedField((new StringBuilder()).append(s).append(j).append(':').toString(), s1, '\r', flag);
                    if(s2 != null)
                        break label0;
                }
                String as[];
                if(arraylist == null)
                    as = null;
                else
                    as = (String[])arraylist.toArray(new String[arraylist.size()]);
                return as;
            }
            if(arraylist == null)
                arraylist = new ArrayList(i);
            arraylist.add(s2);
            j++;
        } while(true);
    }

    public AddressBookParsedResult parse(Result result)
    {
        String s = getMassagedText(result);
        AddressBookParsedResult addressbookparsedresult;
        if(!s.contains("MEMORY") || !s.contains("\r\n"))
        {
            addressbookparsedresult = null;
        } else
        {
            String s1 = matchSinglePrefixedField("NAME1:", s, '\r', true);
            String s2 = matchSinglePrefixedField("NAME2:", s, '\r', true);
            String as[] = matchMultipleValuePrefix("TEL", 3, s, true);
            String as1[] = matchMultipleValuePrefix("MAIL", 3, s, true);
            String s3 = matchSinglePrefixedField("MEMORY:", s, '\r', false);
            String s4 = matchSinglePrefixedField("ADD:", s, '\r', true);
            String as2[];
            if(s4 == null)
            {
                as2 = null;
            } else
            {
                as2 = new String[1];
                as2[0] = s4;
            }
            addressbookparsedresult = new AddressBookParsedResult(maybeWrap(s1), null, s2, as, null, as1, null, null, s3, as2, null, null, null, null, null, null);
        }
        return addressbookparsedresult;
    }

    public volatile ParsedResult parse(Result result)
    {
        return parse(result);
    }
}
