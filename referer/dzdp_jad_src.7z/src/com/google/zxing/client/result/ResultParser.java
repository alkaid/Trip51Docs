// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.client.result;

import com.google.zxing.Result;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

// Referenced classes of package com.google.zxing.client.result:
//            BookmarkDoCoMoResultParser, AddressBookDoCoMoResultParser, EmailDoCoMoResultParser, AddressBookAUResultParser, 
//            VCardResultParser, BizcardResultParser, VEventResultParser, EmailAddressResultParser, 
//            SMTPResultParser, TelResultParser, SMSMMSResultParser, SMSTOMMSTOResultParser, 
//            GeoResultParser, WifiResultParser, URLTOResultParser, URIResultParser, 
//            ISBNResultParser, ProductResultParser, ExpandedProductResultParser, VINResultParser, 
//            TextParsedResult, ParsedResult

public abstract class ResultParser
{

    private static final Pattern AMPERSAND = Pattern.compile("&");
    private static final String BYTE_ORDER_MARK = "\uFEFF";
    private static final Pattern DIGITS = Pattern.compile("\\d+");
    private static final Pattern EQUALS = Pattern.compile("=");
    private static final ResultParser PARSERS[];

    public ResultParser()
    {
    }

    private static void appendKeyValue(CharSequence charsequence, Map map)
    {
        String s;
        String s1;
        String as[] = EQUALS.split(charsequence, 2);
        if(as.length != 2)
            break MISSING_BLOCK_LABEL_37;
        s = as[0];
        s1 = as[1];
        map.put(s, urlDecode(s1));
_L2:
        return;
        IllegalArgumentException illegalargumentexception;
        illegalargumentexception;
        if(true) goto _L2; else goto _L1
_L1:
    }

    private static int countPrecedingBackslashes(CharSequence charsequence, int i)
    {
        int j = 0;
        for(int k = i - 1; k >= 0 && charsequence.charAt(k) == '\\'; k--)
            j++;

        return j;
    }

    protected static String getMassagedText(Result result)
    {
        String s = result.getText();
        if(s.startsWith("\uFEFF"))
            s = s.substring(1);
        return s;
    }

    protected static boolean isStringOfDigits(CharSequence charsequence, int i)
    {
        boolean flag;
        if(charsequence != null && i > 0 && i == charsequence.length() && DIGITS.matcher(charsequence).matches())
            flag = true;
        else
            flag = false;
        return flag;
    }

    protected static boolean isSubstringOfDigits(CharSequence charsequence, int i, int j)
    {
        boolean flag = false;
        if(charsequence != null && j > 0) goto _L2; else goto _L1
_L1:
        return flag;
_L2:
        int k = i + j;
        if(charsequence.length() >= k && DIGITS.matcher(charsequence.subSequence(i, k)).matches())
            flag = true;
        if(true) goto _L1; else goto _L3
_L3:
    }

    static String[] matchPrefixedField(String s, String s1, char c, boolean flag)
    {
        ArrayList arraylist = null;
        int i = 0;
        int j = s1.length();
        do
        {
label0:
            {
                int k;
                if(i < j)
                {
                    k = s1.indexOf(s, i);
                    if(k >= 0)
                        break label0;
                }
                String as[];
                int l;
                boolean flag1;
                int i1;
                String s2;
                if(arraylist == null || arraylist.isEmpty())
                    as = null;
                else
                    as = (String[])arraylist.toArray(new String[arraylist.size()]);
                return as;
            }
            i = k + s.length();
            l = i;
            flag1 = true;
            while(flag1) 
            {
                i1 = s1.indexOf(c, i);
                if(i1 < 0)
                {
                    i = s1.length();
                    flag1 = false;
                } else
                if(countPrecedingBackslashes(s1, i1) % 2 != 0)
                {
                    i = i1 + 1;
                } else
                {
                    if(arraylist == null)
                        arraylist = new ArrayList(3);
                    s2 = unescapeBackslash(s1.substring(l, i1));
                    if(flag)
                        s2 = s2.trim();
                    if(!s2.isEmpty())
                        arraylist.add(s2);
                    i = i1 + 1;
                    flag1 = false;
                }
            }
        } while(true);
    }

    static String matchSinglePrefixedField(String s, String s1, char c, boolean flag)
    {
        String as[] = matchPrefixedField(s, s1, c, flag);
        String s2;
        if(as == null)
            s2 = null;
        else
            s2 = as[0];
        return s2;
    }

    protected static void maybeAppend(String s, StringBuilder stringbuilder)
    {
        if(s != null)
        {
            stringbuilder.append('\n');
            stringbuilder.append(s);
        }
    }

    protected static void maybeAppend(String as[], StringBuilder stringbuilder)
    {
        if(as != null)
        {
            int i = as.length;
            for(int j = 0; j < i; j++)
            {
                String s = as[j];
                stringbuilder.append('\n');
                stringbuilder.append(s);
            }

        }
    }

    protected static String[] maybeWrap(String s)
    {
        String as[];
        if(s == null)
        {
            as = null;
        } else
        {
            as = new String[1];
            as[0] = s;
        }
        return as;
    }

    protected static int parseHexDigit(char c)
    {
        int i;
        if(c >= '0' && c <= '9')
            i = c + -48;
        else
        if(c >= 'a' && c <= 'f')
            i = 10 + (c + -97);
        else
        if(c >= 'A' && c <= 'F')
            i = 10 + (c + -65);
        else
            i = -1;
        return i;
    }

    static Map parseNameValuePairs(String s)
    {
        int i = s.indexOf('?');
        Object obj;
        if(i < 0)
        {
            obj = null;
        } else
        {
            obj = new HashMap(3);
            String as[] = AMPERSAND.split(s.substring(i + 1));
            int j = as.length;
            int k = 0;
            while(k < j) 
            {
                appendKeyValue(as[k], ((Map) (obj)));
                k++;
            }
        }
        return ((Map) (obj));
    }

    public static ParsedResult parseResult(Result result)
    {
        ResultParser aresultparser[];
        int i;
        int j;
        aresultparser = PARSERS;
        i = aresultparser.length;
        j = 0;
_L3:
        Object obj;
        if(j >= i)
            break MISSING_BLOCK_LABEL_37;
        obj = aresultparser[j].parse(result);
        if(obj == null) goto _L2; else goto _L1
_L1:
        return ((ParsedResult) (obj));
_L2:
        j++;
          goto _L3
        obj = new TextParsedResult(result.getText(), null);
          goto _L1
    }

    protected static String unescapeBackslash(String s)
    {
        int i = s.indexOf('\\');
        if(i >= 0)
        {
            int j = s.length();
            StringBuilder stringbuilder = new StringBuilder(j - 1);
            stringbuilder.append(s.toCharArray(), 0, i);
            boolean flag = false;
            int k = i;
            while(k < j) 
            {
                char c = s.charAt(k);
                if(flag || c != '\\')
                {
                    stringbuilder.append(c);
                    flag = false;
                } else
                {
                    flag = true;
                }
                k++;
            }
            s = stringbuilder.toString();
        }
        return s;
    }

    static String urlDecode(String s)
    {
        String s1;
        try
        {
            s1 = URLDecoder.decode(s, "UTF-8");
        }
        catch(UnsupportedEncodingException unsupportedencodingexception)
        {
            throw new IllegalStateException(unsupportedencodingexception);
        }
        return s1;
    }

    public abstract ParsedResult parse(Result result);

    static 
    {
        ResultParser aresultparser[] = new ResultParser[20];
        aresultparser[0] = new BookmarkDoCoMoResultParser();
        aresultparser[1] = new AddressBookDoCoMoResultParser();
        aresultparser[2] = new EmailDoCoMoResultParser();
        aresultparser[3] = new AddressBookAUResultParser();
        aresultparser[4] = new VCardResultParser();
        aresultparser[5] = new BizcardResultParser();
        aresultparser[6] = new VEventResultParser();
        aresultparser[7] = new EmailAddressResultParser();
        aresultparser[8] = new SMTPResultParser();
        aresultparser[9] = new TelResultParser();
        aresultparser[10] = new SMSMMSResultParser();
        aresultparser[11] = new SMSTOMMSTOResultParser();
        aresultparser[12] = new GeoResultParser();
        aresultparser[13] = new WifiResultParser();
        aresultparser[14] = new URLTOResultParser();
        aresultparser[15] = new URIResultParser();
        aresultparser[16] = new ISBNResultParser();
        aresultparser[17] = new ProductResultParser();
        aresultparser[18] = new ExpandedProductResultParser();
        aresultparser[19] = new VINResultParser();
        PARSERS = aresultparser;
    }
}
