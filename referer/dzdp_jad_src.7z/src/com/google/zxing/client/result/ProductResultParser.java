// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.client.result;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.Result;
import com.google.zxing.oned.UPCEReader;

// Referenced classes of package com.google.zxing.client.result:
//            ResultParser, ProductParsedResult, ParsedResult

public final class ProductResultParser extends ResultParser
{

    public ProductResultParser()
    {
    }

    public volatile ParsedResult parse(Result result)
    {
        return parse(result);
    }

    public ProductParsedResult parse(Result result)
    {
        ProductParsedResult productparsedresult;
        BarcodeFormat barcodeformat;
        productparsedresult = null;
        barcodeformat = result.getBarcodeFormat();
        if(barcodeformat == BarcodeFormat.UPC_A || barcodeformat == BarcodeFormat.UPC_E || barcodeformat == BarcodeFormat.EAN_8 || barcodeformat == BarcodeFormat.EAN_13) goto _L2; else goto _L1
_L1:
        return productparsedresult;
_L2:
        String s = getMassagedText(result);
        if(isStringOfDigits(s, s.length()))
        {
            String s1;
            if(barcodeformat == BarcodeFormat.UPC_E && s.length() == 8)
                s1 = UPCEReader.convertUPCEtoUPCA(s);
            else
                s1 = s;
            productparsedresult = new ProductParsedResult(s, s1);
        }
        if(true) goto _L1; else goto _L3
_L3:
    }
}
