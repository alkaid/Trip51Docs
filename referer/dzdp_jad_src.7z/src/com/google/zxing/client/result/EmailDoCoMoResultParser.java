// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.client.result;

import com.google.zxing.Result;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

// Referenced classes of package com.google.zxing.client.result:
//            AbstractDoCoMoResultParser, EmailAddressParsedResult, ParsedResult

public final class EmailDoCoMoResultParser extends AbstractDoCoMoResultParser
{

    private static final Pattern ATEXT_ALPHANUMERIC = Pattern.compile("[a-zA-Z0-9@.!#$%&'*+\\-/=?^_`{|}~]+");

    public EmailDoCoMoResultParser()
    {
    }

    static boolean isBasicallyValidEmailAddress(String s)
    {
        boolean flag;
        if(s != null && ATEXT_ALPHANUMERIC.matcher(s).matches() && s.indexOf('@') >= 0)
            flag = true;
        else
            flag = false;
        return flag;
    }

    public EmailAddressParsedResult parse(Result result)
    {
        EmailAddressParsedResult emailaddressparsedresult;
        String s;
        emailaddressparsedresult = null;
        s = getMassagedText(result);
        if(s.startsWith("MATMSG:")) goto _L2; else goto _L1
_L1:
        return emailaddressparsedresult;
_L2:
        String as[] = matchDoCoMoPrefixedField("TO:", s, true);
        if(as == null)
            continue; /* Loop/switch isn't completed */
        int i = as.length;
        for(int j = 0; j < i; j++)
            if(!isBasicallyValidEmailAddress(as[j]))
                continue; /* Loop/switch isn't completed */

        emailaddressparsedresult = new EmailAddressParsedResult(as, null, null, matchSingleDoCoMoPrefixedField("SUB:", s, false), matchSingleDoCoMoPrefixedField("BODY:", s, false));
        if(true) goto _L1; else goto _L3
_L3:
    }

    public volatile ParsedResult parse(Result result)
    {
        return parse(result);
    }

}
