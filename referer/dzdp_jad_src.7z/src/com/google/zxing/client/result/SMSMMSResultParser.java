// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.client.result;

import com.google.zxing.Result;
import java.util.*;

// Referenced classes of package com.google.zxing.client.result:
//            ResultParser, SMSParsedResult, ParsedResult

public final class SMSMMSResultParser extends ResultParser
{

    public SMSMMSResultParser()
    {
    }

    private static void addNumberVia(Collection collection, Collection collection1, String s)
    {
        int i = s.indexOf(';');
        if(i < 0)
        {
            collection.add(s);
            collection1.add(null);
        } else
        {
            collection.add(s.substring(0, i));
            String s1 = s.substring(i + 1);
            String s2;
            if(s1.startsWith("via="))
                s2 = s1.substring(4);
            else
                s2 = null;
            collection1.add(s2);
        }
    }

    public volatile ParsedResult parse(Result result)
    {
        return parse(result);
    }

    public SMSParsedResult parse(Result result)
    {
        String s = getMassagedText(result);
        SMSParsedResult smsparsedresult;
        if(!s.startsWith("sms:") && !s.startsWith("SMS:") && !s.startsWith("mms:") && !s.startsWith("MMS:"))
        {
            smsparsedresult = null;
        } else
        {
            Map map = parseNameValuePairs(s);
            String s1 = null;
            String s2 = null;
            boolean flag = false;
            if(map != null && !map.isEmpty())
            {
                s1 = (String)map.get("subject");
                s2 = (String)map.get("body");
                flag = true;
            }
            int i = s.indexOf('?', 4);
            String s3;
            int j;
            ArrayList arraylist;
            ArrayList arraylist1;
            if(i < 0 || !flag)
                s3 = s.substring(4);
            else
                s3 = s.substring(4, i);
            j = -1;
            arraylist = new ArrayList(1);
            arraylist1 = new ArrayList(1);
            do
            {
                int k = s3.indexOf(',', j + 1);
                if(k <= j)
                    break;
                addNumberVia(arraylist, arraylist1, s3.substring(j + 1, k));
                j = k;
            } while(true);
            addNumberVia(arraylist, arraylist1, s3.substring(j + 1));
            smsparsedresult = new SMSParsedResult((String[])arraylist.toArray(new String[arraylist.size()]), (String[])arraylist1.toArray(new String[arraylist1.size()]), s1, s2);
        }
        return smsparsedresult;
    }
}
