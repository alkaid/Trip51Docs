// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.client.result;

import com.google.zxing.Result;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

// Referenced classes of package com.google.zxing.client.result:
//            ResultParser, URIParsedResult, ParsedResult

public final class URIResultParser extends ResultParser
{

    private static final Pattern URL_WITHOUT_PROTOCOL_PATTERN = Pattern.compile("([a-zA-Z0-9\\-]+\\.)+[a-zA-Z]{2,}(:\\d{1,5})?(/|\\?|$)");
    private static final Pattern URL_WITH_PROTOCOL_PATTERN = Pattern.compile("[a-zA-Z][a-zA-Z0-9+-.]+:");

    public URIResultParser()
    {
    }

    static boolean isBasicallyValidURI(String s)
    {
        boolean flag = true;
        if(!s.contains(" ")) goto _L2; else goto _L1
_L1:
        flag = false;
_L4:
        return flag;
_L2:
        Matcher matcher = URL_WITH_PROTOCOL_PATTERN.matcher(s);
        if(!matcher.find() || matcher.start() != 0)
        {
            Matcher matcher1 = URL_WITHOUT_PROTOCOL_PATTERN.matcher(s);
            if(!matcher1.find() || matcher1.start() != 0)
                flag = false;
        }
        if(true) goto _L4; else goto _L3
_L3:
    }

    public volatile ParsedResult parse(Result result)
    {
        return parse(result);
    }

    public URIParsedResult parse(Result result)
    {
        String s = getMassagedText(result);
        URIParsedResult uriparsedresult;
        if(s.startsWith("URL:") || s.startsWith("URI:"))
        {
            uriparsedresult = new URIParsedResult(s.substring(4).trim(), null);
        } else
        {
            String s1 = s.trim();
            if(isBasicallyValidURI(s1))
                uriparsedresult = new URIParsedResult(s1, null);
            else
                uriparsedresult = null;
        }
        return uriparsedresult;
    }

}
