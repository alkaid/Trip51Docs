// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.client.result;

import com.google.zxing.Result;

// Referenced classes of package com.google.zxing.client.result:
//            ResultParser, WifiParsedResult, ParsedResult

public final class WifiResultParser extends ResultParser
{

    public WifiResultParser()
    {
    }

    public volatile ParsedResult parse(Result result)
    {
        return parse(result);
    }

    public WifiParsedResult parse(Result result)
    {
        WifiParsedResult wifiparsedresult;
        String s;
        wifiparsedresult = null;
        s = getMassagedText(result);
        if(s.startsWith("WIFI:")) goto _L2; else goto _L1
_L1:
        return wifiparsedresult;
_L2:
        String s1 = matchSinglePrefixedField("S:", s, ';', false);
        if(s1 != null && !s1.isEmpty())
        {
            String s2 = matchSinglePrefixedField("P:", s, ';', false);
            String s3 = matchSinglePrefixedField("T:", s, ';', false);
            if(s3 == null)
                s3 = "nopass";
            wifiparsedresult = new WifiParsedResult(s3, s1, s2, Boolean.parseBoolean(matchSinglePrefixedField("H:", s, ';', false)));
        }
        if(true) goto _L1; else goto _L3
_L3:
    }
}
