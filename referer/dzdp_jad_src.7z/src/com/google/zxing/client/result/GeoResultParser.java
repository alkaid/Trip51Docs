// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.client.result;

import com.google.zxing.Result;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

// Referenced classes of package com.google.zxing.client.result:
//            ResultParser, GeoParsedResult, ParsedResult

public final class GeoResultParser extends ResultParser
{

    private static final Pattern GEO_URL_PATTERN = Pattern.compile("geo:([\\-0-9.]+),([\\-0-9.]+)(?:,([\\-0-9.]+))?(?:\\?(.*))?", 2);

    public GeoResultParser()
    {
    }

    public GeoParsedResult parse(Result result)
    {
        GeoParsedResult geoparsedresult;
        Matcher matcher;
        geoparsedresult = null;
        String s = getMassagedText(result);
        matcher = GEO_URL_PATTERN.matcher(s);
        if(matcher.matches()) goto _L2; else goto _L1
_L1:
        return geoparsedresult;
_L2:
        String s1 = matcher.group(4);
        double d;
        double d1;
        String s2;
        d = Double.parseDouble(matcher.group(1));
        if(d > 90D || d < -90D)
            continue; /* Loop/switch isn't completed */
        d1 = Double.parseDouble(matcher.group(2));
        if(d1 > 180D || d1 < -180D)
            continue; /* Loop/switch isn't completed */
        s2 = matcher.group(3);
        if(s2 != null) goto _L4; else goto _L3
_L3:
        double d3 = 0.0D;
_L6:
        geoparsedresult = new GeoParsedResult(d, d1, d3, s1);
        break; /* Loop/switch isn't completed */
_L4:
        double d2 = Double.parseDouble(matcher.group(3));
        d3 = d2;
        if(d3 >= 0.0D) goto _L6; else goto _L5
_L5:
        continue; /* Loop/switch isn't completed */
        NumberFormatException numberformatexception;
        numberformatexception;
        if(true) goto _L1; else goto _L7
_L7:
    }

    public volatile ParsedResult parse(Result result)
    {
        return parse(result);
    }

}
