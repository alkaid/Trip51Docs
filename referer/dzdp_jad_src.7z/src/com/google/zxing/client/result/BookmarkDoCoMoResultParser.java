// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.client.result;

import com.google.zxing.Result;

// Referenced classes of package com.google.zxing.client.result:
//            AbstractDoCoMoResultParser, URIResultParser, URIParsedResult, ParsedResult

public final class BookmarkDoCoMoResultParser extends AbstractDoCoMoResultParser
{

    public BookmarkDoCoMoResultParser()
    {
    }

    public volatile ParsedResult parse(Result result)
    {
        return parse(result);
    }

    public URIParsedResult parse(Result result)
    {
        URIParsedResult uriparsedresult;
        String s;
        uriparsedresult = null;
        s = result.getText();
        if(s.startsWith("MEBKM:")) goto _L2; else goto _L1
_L1:
        return uriparsedresult;
_L2:
        String s1 = matchSingleDoCoMoPrefixedField("TITLE:", s, true);
        String as[] = matchDoCoMoPrefixedField("URL:", s, true);
        if(as != null)
        {
            String s2 = as[0];
            if(URIResultParser.isBasicallyValidURI(s2))
                uriparsedresult = new URIParsedResult(s2, s1);
        }
        if(true) goto _L1; else goto _L3
_L3:
    }
}
