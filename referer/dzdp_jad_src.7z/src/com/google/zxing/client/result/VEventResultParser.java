// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.client.result;

import com.google.zxing.Result;
import java.util.List;

// Referenced classes of package com.google.zxing.client.result:
//            ResultParser, VCardResultParser, CalendarParsedResult, ParsedResult

public final class VEventResultParser extends ResultParser
{

    public VEventResultParser()
    {
    }

    private static String matchSingleVCardPrefixedField(CharSequence charsequence, String s, boolean flag)
    {
        List list = VCardResultParser.matchSingleVCardPrefixedField(charsequence, s, flag, false);
        String s1;
        if(list == null || list.isEmpty())
            s1 = null;
        else
            s1 = (String)list.get(0);
        return s1;
    }

    private static String[] matchVCardPrefixedField(CharSequence charsequence, String s, boolean flag)
    {
        List list = VCardResultParser.matchVCardPrefixedField(charsequence, s, flag, false);
        String as[];
        if(list == null || list.isEmpty())
        {
            as = null;
        } else
        {
            int i = list.size();
            as = new String[i];
            int j = 0;
            while(j < i) 
            {
                as[j] = (String)((List)list.get(j)).get(0);
                j++;
            }
        }
        return as;
    }

    private static String stripMailto(String s)
    {
        if(s != null && (s.startsWith("mailto:") || s.startsWith("MAILTO:")))
            s = s.substring(7);
        return s;
    }

    public CalendarParsedResult parse(Result result)
    {
        String s = getMassagedText(result);
        if(s.indexOf("BEGIN:VEVENT") >= 0) goto _L2; else goto _L1
_L1:
        CalendarParsedResult calendarparsedresult = null;
_L8:
        return calendarparsedresult;
_L2:
        String s1;
        String s2;
        String s3;
        String s4;
        String s5;
        String s6;
        String as[];
        String s7;
        String s8;
        s1 = matchSingleVCardPrefixedField("SUMMARY", s, true);
        s2 = matchSingleVCardPrefixedField("DTSTART", s, true);
        if(s2 == null)
        {
            calendarparsedresult = null;
            continue; /* Loop/switch isn't completed */
        }
        s3 = matchSingleVCardPrefixedField("DTEND", s, true);
        s4 = matchSingleVCardPrefixedField("DURATION", s, true);
        s5 = matchSingleVCardPrefixedField("LOCATION", s, true);
        s6 = stripMailto(matchSingleVCardPrefixedField("ORGANIZER", s, true));
        as = matchVCardPrefixedField("ATTENDEE", s, true);
        if(as != null)
        {
            int j = 0;
            do
            {
                int k = as.length;
                if(j >= k)
                    break;
                as[j] = stripMailto(as[j]);
                j++;
            } while(true);
        }
        s7 = matchSingleVCardPrefixedField("DESCRIPTION", s, true);
        s8 = matchSingleVCardPrefixedField("GEO", s, true);
        if(s8 != null) goto _L4; else goto _L3
_L3:
        double d;
        double d2;
        d = (0.0D / 0.0D);
        d2 = (0.0D / 0.0D);
_L6:
        try
        {
            calendarparsedresult = new CalendarParsedResult(s1, s2, s3, s4, s5, s6, as, s7, d, d2);
        }
        catch(IllegalArgumentException illegalargumentexception)
        {
            calendarparsedresult = null;
        }
        continue; /* Loop/switch isn't completed */
_L4:
        int i;
        i = s8.indexOf(';');
        if(i < 0)
        {
            calendarparsedresult = null;
            continue; /* Loop/switch isn't completed */
        }
        double d1;
        d = Double.parseDouble(s8.substring(0, i));
        d1 = Double.parseDouble(s8.substring(i + 1));
        d2 = d1;
        if(true) goto _L6; else goto _L5
_L5:
        NumberFormatException numberformatexception;
        numberformatexception;
        calendarparsedresult = null;
        if(true) goto _L8; else goto _L7
_L7:
    }

    public volatile ParsedResult parse(Result result)
    {
        return parse(result);
    }
}
