// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.client.result;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.Result;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

// Referenced classes of package com.google.zxing.client.result:
//            ResultParser, VINParsedResult, ParsedResult

public final class VINResultParser extends ResultParser
{

    private static final Pattern AZ09 = Pattern.compile("[A-Z0-9]{17}");
    private static final Pattern IOQ = Pattern.compile("[IOQ]");

    public VINResultParser()
    {
    }

    private static char checkChar(int i)
    {
        char c;
        if(i < 10)
            c = (char)(i + 48);
        else
        if(i == 10)
            c = 'X';
        else
            throw new IllegalArgumentException();
        return c;
    }

    private static boolean checkChecksum(CharSequence charsequence)
    {
        int i = 0;
        for(int j = 0; j < charsequence.length(); j++)
            i += vinPositionWeight(j + 1) * vinCharValue(charsequence.charAt(j));

        boolean flag;
        if(charsequence.charAt(8) == checkChar(i % 11))
            flag = true;
        else
            flag = false;
        return flag;
    }

    private static String countryCode(CharSequence charsequence)
    {
        char c;
        char c1;
        c = charsequence.charAt(0);
        c1 = charsequence.charAt(1);
        c;
        JVM INSTR lookupswitch 15: default 148
    //                   49: 152
    //                   50: 158
    //                   51: 164
    //                   52: 152
    //                   53: 152
    //                   57: 182
    //                   74: 212
    //                   75: 230
    //                   76: 248
    //                   77: 254
    //                   83: 272
    //                   86: 308
    //                   87: 344
    //                   88: 350
    //                   90: 374;
           goto _L1 _L2 _L3 _L4 _L2 _L2 _L5 _L6 _L7 _L8 _L9 _L10 _L11 _L12 _L13 _L14
_L1:
        String s = null;
_L15:
        return s;
_L2:
        s = "US";
          goto _L15
_L3:
        s = "CA";
          goto _L15
_L4:
        if(c1 < 'A' || c1 > 'W') goto _L1; else goto _L16
_L16:
        s = "MX";
          goto _L15
_L5:
        if((c1 < 'A' || c1 > 'E') && (c1 < '3' || c1 > '9')) goto _L1; else goto _L17
_L17:
        s = "BR";
          goto _L15
_L6:
        if(c1 < 'A' || c1 > 'T') goto _L1; else goto _L18
_L18:
        s = "JP";
          goto _L15
_L7:
        if(c1 < 'L' || c1 > 'R') goto _L1; else goto _L19
_L19:
        s = "KO";
          goto _L15
_L8:
        s = "CN";
          goto _L15
_L9:
        if(c1 < 'A' || c1 > 'E') goto _L1; else goto _L20
_L20:
        s = "IN";
          goto _L15
_L10:
        if(c1 < 'A' || c1 > 'M')
            continue; /* Loop/switch isn't completed */
        s = "UK";
          goto _L15
        if(c1 < 'N' || c1 > 'T') goto _L1; else goto _L21
_L21:
        s = "DE";
          goto _L15
_L11:
        if(c1 < 'F' || c1 > 'R')
            continue; /* Loop/switch isn't completed */
        s = "FR";
          goto _L15
        if(c1 < 'S' || c1 > 'W') goto _L1; else goto _L22
_L22:
        s = "ES";
          goto _L15
_L12:
        s = "DE";
          goto _L15
_L13:
        if(c1 != '0' && (c1 < '3' || c1 > '9')) goto _L1; else goto _L23
_L23:
        s = "RU";
          goto _L15
_L14:
        if(c1 < 'A' || c1 > 'R') goto _L1; else goto _L24
_L24:
        s = "IT";
          goto _L15
    }

    private static int modelYear(char c)
    {
        int i;
        if(c >= 'E' && c <= 'H')
            i = 1984 + (c + -69);
        else
        if(c >= 'J' && c <= 'N')
            i = 1988 + (c + -74);
        else
        if(c == 'P')
            i = 1993;
        else
        if(c >= 'R' && c <= 'T')
            i = 1994 + (c + -82);
        else
        if(c >= 'V' && c <= 'Y')
            i = 1997 + (c + -86);
        else
        if(c >= '1' && c <= '9')
            i = 2001 + (c + -49);
        else
        if(c >= 'A' && c <= 'D')
            i = 2010 + (c + -65);
        else
            throw new IllegalArgumentException();
        return i;
    }

    private static int vinCharValue(char c)
    {
        int i;
        if(c >= 'A' && c <= 'I')
            i = 1 + (c + -65);
        else
        if(c >= 'J' && c <= 'R')
            i = 1 + (c + -74);
        else
        if(c >= 'S' && c <= 'Z')
            i = 2 + (c + -83);
        else
        if(c >= '0' && c <= '9')
            i = c + -48;
        else
            throw new IllegalArgumentException();
        return i;
    }

    private static int vinPositionWeight(int i)
    {
        int j = 10;
        if(i < 1 || i > 7) goto _L2; else goto _L1
_L1:
        j = 9 - i;
_L4:
        return j;
_L2:
        if(i != 8)
            if(i == 9)
                j = 0;
            else
            if(i >= j && i <= 17)
                j = 19 - i;
            else
                throw new IllegalArgumentException();
        if(true) goto _L4; else goto _L3
_L3:
    }

    public volatile ParsedResult parse(Result result)
    {
        return parse(result);
    }

    public VINParsedResult parse(Result result)
    {
        VINParsedResult vinparsedresult;
        if(result.getBarcodeFormat() != BarcodeFormat.CODE_39)
        {
            vinparsedresult = null;
        } else
        {
            String s = result.getText();
            String s1 = IOQ.matcher(s).replaceAll("").trim();
            if(!AZ09.matcher(s1).matches())
                vinparsedresult = null;
            else
                try
                {
                    if(!checkChecksum(s1))
                    {
                        vinparsedresult = null;
                    } else
                    {
                        String s2 = s1.substring(0, 3);
                        vinparsedresult = new VINParsedResult(s1, s2, s1.substring(3, 9), s1.substring(9, 17), countryCode(s2), s1.substring(3, 8), modelYear(s1.charAt(9)), s1.charAt(10), s1.substring(11));
                    }
                }
                catch(IllegalArgumentException illegalargumentexception)
                {
                    vinparsedresult = null;
                }
        }
        return vinparsedresult;
    }

}
