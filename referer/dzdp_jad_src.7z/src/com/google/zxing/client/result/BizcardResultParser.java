// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.client.result;

import com.google.zxing.Result;
import java.util.ArrayList;
import java.util.List;

// Referenced classes of package com.google.zxing.client.result:
//            AbstractDoCoMoResultParser, AddressBookParsedResult, ParsedResult

public final class BizcardResultParser extends AbstractDoCoMoResultParser
{

    public BizcardResultParser()
    {
    }

    private static String buildName(String s, String s1)
    {
        if(s != null)
        {
            if(s1 != null)
                s = (new StringBuilder()).append(s).append(' ').append(s1).toString();
            s1 = s;
        }
        return s1;
    }

    private static String[] buildPhoneNumbers(String s, String s1, String s2)
    {
        ArrayList arraylist = new ArrayList(3);
        if(s != null)
            arraylist.add(s);
        if(s1 != null)
            arraylist.add(s1);
        if(s2 != null)
            arraylist.add(s2);
        int i = arraylist.size();
        String as[];
        if(i == 0)
            as = null;
        else
            as = (String[])arraylist.toArray(new String[i]);
        return as;
    }

    public AddressBookParsedResult parse(Result result)
    {
        String s = getMassagedText(result);
        AddressBookParsedResult addressbookparsedresult;
        if(!s.startsWith("BIZCARD:"))
        {
            addressbookparsedresult = null;
        } else
        {
            String s1 = buildName(matchSingleDoCoMoPrefixedField("N:", s, true), matchSingleDoCoMoPrefixedField("X:", s, true));
            String s2 = matchSingleDoCoMoPrefixedField("T:", s, true);
            String s3 = matchSingleDoCoMoPrefixedField("C:", s, true);
            String as[] = matchDoCoMoPrefixedField("A:", s, true);
            String s4 = matchSingleDoCoMoPrefixedField("B:", s, true);
            String s5 = matchSingleDoCoMoPrefixedField("M:", s, true);
            String s6 = matchSingleDoCoMoPrefixedField("F:", s, true);
            String s7 = matchSingleDoCoMoPrefixedField("E:", s, true);
            addressbookparsedresult = new AddressBookParsedResult(maybeWrap(s1), null, null, buildPhoneNumbers(s4, s5, s6), null, maybeWrap(s7), null, null, null, as, null, s3, null, s2, null, null);
        }
        return addressbookparsedresult;
    }

    public volatile ParsedResult parse(Result result)
    {
        return parse(result);
    }
}
