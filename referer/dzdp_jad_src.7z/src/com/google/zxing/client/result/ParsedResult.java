// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.client.result;


// Referenced classes of package com.google.zxing.client.result:
//            ParsedResultType

public abstract class ParsedResult
{

    private final ParsedResultType type;

    protected ParsedResult(ParsedResultType parsedresulttype)
    {
        type = parsedresulttype;
    }

    public static void maybeAppend(String s, StringBuilder stringbuilder)
    {
        if(s != null && !s.isEmpty())
        {
            if(stringbuilder.length() > 0)
                stringbuilder.append('\n');
            stringbuilder.append(s);
        }
    }

    public static void maybeAppend(String as[], StringBuilder stringbuilder)
    {
        if(as != null)
        {
            int i = as.length;
            for(int j = 0; j < i; j++)
                maybeAppend(as[j], stringbuilder);

        }
    }

    public abstract String getDisplayResult();

    public final ParsedResultType getType()
    {
        return type;
    }

    public final String toString()
    {
        return getDisplayResult();
    }
}
