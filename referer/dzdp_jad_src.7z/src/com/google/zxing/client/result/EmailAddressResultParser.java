// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.client.result;

import com.google.zxing.Result;
import java.util.Map;
import java.util.regex.Pattern;

// Referenced classes of package com.google.zxing.client.result:
//            ResultParser, EmailAddressParsedResult, EmailDoCoMoResultParser, ParsedResult

public final class EmailAddressResultParser extends ResultParser
{

    private static final Pattern COMMA = Pattern.compile(",");

    public EmailAddressResultParser()
    {
    }

    public EmailAddressParsedResult parse(Result result)
    {
        String s = getMassagedText(result);
        EmailAddressParsedResult emailaddressparsedresult;
        if(s.startsWith("mailto:") || s.startsWith("MAILTO:"))
        {
            String s1 = s.substring(7);
            int i = s1.indexOf('?');
            if(i >= 0)
                s1 = s1.substring(0, i);
            String s2 = urlDecode(s1);
            String as[] = null;
            if(!s2.isEmpty())
                as = COMMA.split(s2);
            Map map = parseNameValuePairs(s);
            String as1[] = null;
            String as2[] = null;
            String s3 = null;
            String s4 = null;
            if(map != null)
            {
                if(as == null)
                {
                    String s7 = (String)map.get("to");
                    if(s7 != null)
                        as = COMMA.split(s7);
                }
                String s5 = (String)map.get("cc");
                if(s5 != null)
                    as1 = COMMA.split(s5);
                String s6 = (String)map.get("bcc");
                if(s6 != null)
                    as2 = COMMA.split(s6);
                s3 = (String)map.get("subject");
                s4 = (String)map.get("body");
            }
            emailaddressparsedresult = new EmailAddressParsedResult(as, as1, as2, s3, s4);
        } else
        if(!EmailDoCoMoResultParser.isBasicallyValidEmailAddress(s))
            emailaddressparsedresult = null;
        else
            emailaddressparsedresult = new EmailAddressParsedResult(s);
        return emailaddressparsedresult;
    }

    public volatile ParsedResult parse(Result result)
    {
        return parse(result);
    }

}
