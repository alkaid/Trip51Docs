// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.client.result;

import com.google.zxing.Result;

// Referenced classes of package com.google.zxing.client.result:
//            ResultParser, EmailAddressParsedResult, ParsedResult

public final class SMTPResultParser extends ResultParser
{

    public SMTPResultParser()
    {
    }

    public EmailAddressParsedResult parse(Result result)
    {
        EmailAddressParsedResult emailaddressparsedresult = null;
        String s = getMassagedText(result);
        if(s.startsWith("smtp:") || s.startsWith("SMTP:"))
        {
            String s1 = s.substring(5);
            String s2 = null;
            String s3 = null;
            int i = s1.indexOf(':');
            if(i >= 0)
            {
                s2 = s1.substring(i + 1);
                s1 = s1.substring(0, i);
                int j = s2.indexOf(':');
                if(j >= 0)
                {
                    s3 = s2.substring(j + 1);
                    s2 = s2.substring(0, j);
                }
            }
            String as[] = new String[1];
            as[0] = s1;
            emailaddressparsedresult = new EmailAddressParsedResult(as, null, null, s2, s3);
        }
        return emailaddressparsedresult;
    }

    public volatile ParsedResult parse(Result result)
    {
        return parse(result);
    }
}
