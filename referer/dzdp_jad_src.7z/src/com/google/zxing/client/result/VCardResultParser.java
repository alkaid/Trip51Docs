// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.client.result;

import com.google.zxing.Result;
import java.io.ByteArrayOutputStream;
import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

// Referenced classes of package com.google.zxing.client.result:
//            ResultParser, AddressBookParsedResult, ParsedResult

public final class VCardResultParser extends ResultParser
{

    private static final Pattern BEGIN_VCARD = Pattern.compile("BEGIN:VCARD", 2);
    private static final Pattern COMMA = Pattern.compile(",");
    private static final Pattern CR_LF_SPACE_TAB = Pattern.compile("\r\n[ \t]");
    private static final Pattern EQUALS = Pattern.compile("=");
    private static final Pattern NEWLINE_ESCAPE = Pattern.compile("\\\\[nN]");
    private static final Pattern SEMICOLON = Pattern.compile(";");
    private static final Pattern SEMICOLON_OR_COMMA = Pattern.compile("[;,]");
    private static final Pattern UNESCAPED_SEMICOLONS = Pattern.compile("(?<!\\\\);+");
    private static final Pattern VCARD_ESCAPES = Pattern.compile("\\\\([,;\\\\])");
    private static final Pattern VCARD_LIKE_DATE = Pattern.compile("\\d{4}-?\\d{2}-?\\d{2}");

    public VCardResultParser()
    {
    }

    private static String decodeQuotedPrintable(CharSequence charsequence, String s)
    {
        int i;
        StringBuilder stringbuilder;
        ByteArrayOutputStream bytearrayoutputstream;
        int j;
        i = charsequence.length();
        stringbuilder = new StringBuilder(i);
        bytearrayoutputstream = new ByteArrayOutputStream();
        j = 0;
_L8:
        if(j >= i) goto _L2; else goto _L1
_L1:
        char c = charsequence.charAt(j);
        c;
        JVM INSTR lookupswitch 3: default 80
    //                   10: 94
    //                   13: 94
    //                   61: 100;
           goto _L3 _L4 _L4 _L5
_L4:
        break; /* Loop/switch isn't completed */
_L3:
        maybeAppendFragment(bytearrayoutputstream, s, stringbuilder);
        stringbuilder.append(c);
_L6:
        j++;
        continue; /* Loop/switch isn't completed */
_L5:
        if(j < i - 2)
        {
            char c1 = charsequence.charAt(j + 1);
            if(c1 != '\r' && c1 != '\n')
            {
                char c2 = charsequence.charAt(j + 2);
                int k = parseHexDigit(c1);
                int l = parseHexDigit(c2);
                if(k >= 0 && l >= 0)
                    bytearrayoutputstream.write(l + (k << 4));
                j += 2;
            }
        }
        if(true) goto _L6; else goto _L2
_L2:
        maybeAppendFragment(bytearrayoutputstream, s, stringbuilder);
        return stringbuilder.toString();
        if(true) goto _L8; else goto _L7
_L7:
    }

    private static void formatNames(Iterable iterable)
    {
        if(iterable != null)
        {
            List list;
            StringBuilder stringbuilder;
            for(Iterator iterator = iterable.iterator(); iterator.hasNext(); list.set(0, stringbuilder.toString().trim()))
            {
                list = (List)iterator.next();
                String s = (String)list.get(0);
                String as[] = new String[5];
                int i = 0;
                int j = 0;
                do
                {
                    if(j >= -1 + as.length)
                        break;
                    int k = s.indexOf(';', i);
                    if(k < 0)
                        break;
                    as[j] = s.substring(i, k);
                    j++;
                    i = k + 1;
                } while(true);
                as[j] = s.substring(i);
                stringbuilder = new StringBuilder(100);
                maybeAppendComponent(as, 3, stringbuilder);
                maybeAppendComponent(as, 1, stringbuilder);
                maybeAppendComponent(as, 2, stringbuilder);
                maybeAppendComponent(as, 0, stringbuilder);
                maybeAppendComponent(as, 4, stringbuilder);
            }

        }
    }

    private static boolean isLikeVCardDate(CharSequence charsequence)
    {
        boolean flag;
        if(charsequence == null || VCARD_LIKE_DATE.matcher(charsequence).matches())
            flag = true;
        else
            flag = false;
        return flag;
    }

    static List matchSingleVCardPrefixedField(CharSequence charsequence, String s, boolean flag, boolean flag1)
    {
        List list = matchVCardPrefixedField(charsequence, s, flag, flag1);
        List list1;
        if(list == null || list.isEmpty())
            list1 = null;
        else
            list1 = (List)list.get(0);
        return list1;
    }

    static List matchVCardPrefixedField(CharSequence charsequence, String s, boolean flag, boolean flag1)
    {
        Object obj = null;
        int i = 0;
        int j = s.length();
        do
        {
            Matcher matcher;
label0:
            {
                if(i < j)
                {
                    matcher = Pattern.compile((new StringBuilder()).append("(?:^|\n)").append(charsequence).append("(?:;([^:]*))?:").toString(), 2).matcher(s);
                    if(i > 0)
                        i--;
                    if(matcher.find(i))
                        break label0;
                }
                return ((List) (obj));
            }
            int k = matcher.end(0);
            String s1 = matcher.group(1);
            ArrayList arraylist = null;
            boolean flag2 = false;
            String s2 = null;
            if(s1 != null)
            {
                String as[] = SEMICOLON.split(s1);
                int j1 = as.length;
                int k1 = 0;
                while(k1 < j1) 
                {
                    String s7 = as[k1];
                    if(arraylist == null)
                        arraylist = new ArrayList(1);
                    arraylist.add(s7);
                    String as1[] = EQUALS.split(s7, 2);
                    if(as1.length > 1)
                    {
                        String s8 = as1[0];
                        String s9 = as1[1];
                        if("ENCODING".equalsIgnoreCase(s8) && "QUOTED-PRINTABLE".equalsIgnoreCase(s9))
                            flag2 = true;
                        else
                        if("CHARSET".equalsIgnoreCase(s8))
                            s2 = s9;
                    }
                    k1++;
                }
            }
            int l = k;
            int i1;
            do
            {
                i1 = s.indexOf('\n', k);
                if(i1 < 0)
                    break;
                if(i1 < -1 + s.length() && (s.charAt(i1 + 1) == ' ' || s.charAt(i1 + 1) == '\t'))
                {
                    k = i1 + 2;
                    continue;
                }
                if(!flag2 || (i1 < 1 || s.charAt(i1 - 1) != '=') && (i1 < 2 || s.charAt(i1 - 2) != '='))
                    break;
                k = i1 + 1;
            } while(true);
            if(i1 < 0)
                i = j;
            else
            if(i1 > l)
            {
                if(obj == null)
                    obj = new ArrayList(1);
                if(i1 >= 1 && s.charAt(i1 - 1) == '\r')
                    i1--;
                String s3 = s.substring(l, i1);
                if(flag)
                    s3 = s3.trim();
                String s6;
                if(flag2)
                {
                    s6 = decodeQuotedPrintable(s3, s2);
                    if(flag1)
                        s6 = UNESCAPED_SEMICOLONS.matcher(s6).replaceAll("\n").trim();
                } else
                {
                    if(flag1)
                        s3 = UNESCAPED_SEMICOLONS.matcher(s3).replaceAll("\n").trim();
                    String s4 = CR_LF_SPACE_TAB.matcher(s3).replaceAll("");
                    String s5 = NEWLINE_ESCAPE.matcher(s4).replaceAll("\n");
                    s6 = VCARD_ESCAPES.matcher(s5).replaceAll("$1");
                }
                if(arraylist == null)
                {
                    ArrayList arraylist1 = new ArrayList(1);
                    arraylist1.add(s6);
                    ((List) (obj)).add(arraylist1);
                } else
                {
                    arraylist.add(0, s6);
                    ((List) (obj)).add(arraylist);
                }
                i = i1 + 1;
            } else
            {
                i = i1 + 1;
            }
        } while(true);
    }

    private static void maybeAppendComponent(String as[], int i, StringBuilder stringbuilder)
    {
        if(as[i] != null && !as[i].isEmpty())
        {
            if(stringbuilder.length() > 0)
                stringbuilder.append(' ');
            stringbuilder.append(as[i]);
        }
    }

    private static void maybeAppendFragment(ByteArrayOutputStream bytearrayoutputstream, String s, StringBuilder stringbuilder)
    {
        if(bytearrayoutputstream.size() > 0)
        {
            byte abyte0[] = bytearrayoutputstream.toByteArray();
            String s1;
            if(s == null)
                s1 = new String(abyte0, Charset.forName("UTF-8"));
            else
                try
                {
                    s1 = new String(abyte0, s);
                }
                catch(UnsupportedEncodingException unsupportedencodingexception)
                {
                    s1 = new String(abyte0, Charset.forName("UTF-8"));
                }
            bytearrayoutputstream.reset();
            stringbuilder.append(s1);
        }
    }

    private static String toPrimaryValue(List list)
    {
        String s;
        if(list == null || list.isEmpty())
            s = null;
        else
            s = (String)list.get(0);
        return s;
    }

    private static String[] toPrimaryValues(Collection collection)
    {
        String as[];
        if(collection == null || collection.isEmpty())
        {
            as = null;
        } else
        {
            ArrayList arraylist = new ArrayList(collection.size());
            Iterator iterator = collection.iterator();
            do
            {
                if(!iterator.hasNext())
                    break;
                String s = (String)((List)iterator.next()).get(0);
                if(s != null && !s.isEmpty())
                    arraylist.add(s);
            } while(true);
            as = (String[])arraylist.toArray(new String[collection.size()]);
        }
        return as;
    }

    private static String[] toTypes(Collection collection)
    {
        if(collection != null && !collection.isEmpty()) goto _L2; else goto _L1
_L1:
        String as[] = null;
_L4:
        return as;
_L2:
        ArrayList arraylist;
        arraylist = new ArrayList(collection.size());
        Iterator iterator = collection.iterator();
        do
        {
label0:
            {
                if(!iterator.hasNext())
                    break label0;
                List list = (List)iterator.next();
                String s = null;
                int i = 1;
                do
                {
                    if(i < list.size())
                    {
                        String s1 = (String)list.get(i);
                        int j = s1.indexOf('=');
                        if(j < 0)
                        {
                            s = s1;
                        } else
                        {
label1:
                            {
                                if(!"TYPE".equalsIgnoreCase(s1.substring(0, j)))
                                    break label1;
                                s = s1.substring(j + 1);
                            }
                        }
                    }
                    arraylist.add(s);
                    if(true)
                        break;
                    i++;
                } while(true);
            }
        } while(true);
        as = (String[])arraylist.toArray(new String[collection.size()]);
        if(true) goto _L4; else goto _L3
_L3:
    }

    public AddressBookParsedResult parse(Result result)
    {
        String s = getMassagedText(result);
        Matcher matcher = BEGIN_VCARD.matcher(s);
        AddressBookParsedResult addressbookparsedresult;
        if(!matcher.find() || matcher.start() != 0)
        {
            addressbookparsedresult = null;
        } else
        {
            List list = matchVCardPrefixedField("FN", s, true, false);
            if(list == null)
            {
                list = matchVCardPrefixedField("N", s, true, false);
                formatNames(list);
            }
            List list1 = matchSingleVCardPrefixedField("NICKNAME", s, true, false);
            String as[];
            List list2;
            List list3;
            List list4;
            List list5;
            List list6;
            List list7;
            List list8;
            List list9;
            List list10;
            List list11;
            String as1[];
            if(list1 == null)
                as = null;
            else
                as = COMMA.split((CharSequence)list1.get(0));
            list2 = matchVCardPrefixedField("TEL", s, true, false);
            list3 = matchVCardPrefixedField("EMAIL", s, true, false);
            list4 = matchSingleVCardPrefixedField("NOTE", s, false, false);
            list5 = matchVCardPrefixedField("ADR", s, true, true);
            list6 = matchSingleVCardPrefixedField("ORG", s, true, true);
            list7 = matchSingleVCardPrefixedField("BDAY", s, true, false);
            if(list7 != null && !isLikeVCardDate((CharSequence)list7.get(0)))
                list7 = null;
            list8 = matchSingleVCardPrefixedField("TITLE", s, true, false);
            list9 = matchVCardPrefixedField("URL", s, true, false);
            list10 = matchSingleVCardPrefixedField("IMPP", s, true, false);
            list11 = matchSingleVCardPrefixedField("GEO", s, true, false);
            if(list11 == null)
                as1 = null;
            else
                as1 = SEMICOLON_OR_COMMA.split((CharSequence)list11.get(0));
            if(as1 != null && as1.length != 2)
                as1 = null;
            addressbookparsedresult = new AddressBookParsedResult(toPrimaryValues(list), as, null, toPrimaryValues(list2), toTypes(list2), toPrimaryValues(list3), toTypes(list3), toPrimaryValue(list10), toPrimaryValue(list4), toPrimaryValues(list5), toTypes(list5), toPrimaryValue(list6), toPrimaryValue(list7), toPrimaryValue(list8), toPrimaryValues(list9), as1);
        }
        return addressbookparsedresult;
    }

    public volatile ParsedResult parse(Result result)
    {
        return parse(result);
    }

}
