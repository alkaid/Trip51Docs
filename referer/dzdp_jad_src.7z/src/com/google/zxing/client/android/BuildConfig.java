// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.client.android;


public final class BuildConfig
{

    public static final String APPLICATION_ID = "com.google.zxing.client.android";
    public static final String BUILD_TYPE = "release";
    public static final boolean DEBUG = false;
    public static final String FLAVOR = "";
    public static final int VERSION_CODE = 104;
    public static final String VERSION_NAME = "";

    public BuildConfig()
    {
    }
}
