// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.client.android.encode;

import android.telephony.PhoneNumberUtils;
import java.util.*;

// Referenced classes of package com.google.zxing.client.android.encode:
//            Formatter

final class VCardTelDisplayFormatter
    implements Formatter
{

    private final List metadataForIndex;

    VCardTelDisplayFormatter()
    {
        this(null);
    }

    VCardTelDisplayFormatter(List list)
    {
        metadataForIndex = list;
    }

    private static CharSequence formatMetadata(CharSequence charsequence, Map map)
    {
        Object obj;
        if(map == null || map.isEmpty())
        {
            obj = charsequence;
        } else
        {
            obj = new StringBuilder();
            Iterator iterator = map.entrySet().iterator();
            do
            {
                if(!iterator.hasNext())
                    break;
                Set set = (Set)((java.util.Map.Entry)iterator.next()).getValue();
                if(set != null && !set.isEmpty())
                {
                    Iterator iterator1 = set.iterator();
                    ((StringBuilder) (obj)).append((String)iterator1.next());
                    while(iterator1.hasNext()) 
                        ((StringBuilder) (obj)).append(',').append((String)iterator1.next());
                }
            } while(true);
            if(((StringBuilder) (obj)).length() > 0)
                ((StringBuilder) (obj)).append(' ');
            ((StringBuilder) (obj)).append(charsequence);
        }
        return ((CharSequence) (obj));
    }

    public CharSequence format(CharSequence charsequence, int i)
    {
        String s = PhoneNumberUtils.formatNumber(charsequence.toString());
        Map map;
        if(metadataForIndex == null || metadataForIndex.size() <= i)
            map = null;
        else
            map = (Map)metadataForIndex.get(i);
        return formatMetadata(s, map);
    }
}
