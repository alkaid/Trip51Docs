// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.client.android.encode;

import java.util.*;

// Referenced classes of package com.google.zxing.client.android.encode:
//            ContactEncoder, VCardFieldFormatter, VCardTelDisplayFormatter

final class VCardContactEncoder extends ContactEncoder
{

    private static final char TERMINATOR = 10;

    VCardContactEncoder()
    {
    }

    static List buildPhoneMetadata(Collection collection, List list)
    {
        Object obj;
        if(list == null || list.isEmpty())
        {
            obj = null;
        } else
        {
            obj = new ArrayList();
            int i = 0;
            while(i < collection.size()) 
            {
                if(list.size() <= i)
                {
                    ((List) (obj)).add(null);
                } else
                {
                    HashMap hashmap = new HashMap();
                    ((List) (obj)).add(hashmap);
                    HashSet hashset = new HashSet();
                    hashmap.put("TYPE", hashset);
                    String s = (String)list.get(i);
                    Integer integer = maybeIntValue(s);
                    if(integer == null)
                    {
                        hashset.add(s);
                    } else
                    {
                        String s1 = vCardPurposeLabelForAndroidType(integer.intValue());
                        String s2 = vCardContextLabelForAndroidType(integer.intValue());
                        if(s1 != null)
                            hashset.add(s1);
                        if(s2 != null)
                            hashset.add(s2);
                    }
                }
                i++;
            }
        }
        return ((List) (obj));
    }

    private static Integer maybeIntValue(String s)
    {
        Integer integer1 = Integer.valueOf(s);
        Integer integer = integer1;
_L2:
        return integer;
        NumberFormatException numberformatexception;
        numberformatexception;
        integer = null;
        if(true) goto _L2; else goto _L1
_L1:
    }

    private static String vCardContextLabelForAndroidType(int i)
    {
        i;
        JVM INSTR tableswitch 1 18: default 88
    //                   1 92
    //                   2 92
    //                   3 98
    //                   4 98
    //                   5 92
    //                   6 92
    //                   7 88
    //                   8 88
    //                   9 88
    //                   10 98
    //                   11 88
    //                   12 88
    //                   13 88
    //                   14 88
    //                   15 88
    //                   16 88
    //                   17 98
    //                   18 98;
           goto _L1 _L2 _L2 _L3 _L3 _L2 _L2 _L1 _L1 _L1 _L3 _L1 _L1 _L1 _L1 _L1 _L1 _L3 _L3
_L1:
        String s = null;
_L5:
        return s;
_L2:
        s = "home";
        continue; /* Loop/switch isn't completed */
_L3:
        s = "work";
        if(true) goto _L5; else goto _L4
_L4:
    }

    private static String vCardPurposeLabelForAndroidType(int i)
    {
        i;
        JVM INSTR lookupswitch 7: default 68
    //                   4: 72
    //                   5: 72
    //                   6: 78
    //                   13: 72
    //                   16: 84
    //                   18: 78
    //                   20: 90;
           goto _L1 _L2 _L2 _L3 _L2 _L4 _L3 _L5
_L1:
        String s = null;
_L7:
        return s;
_L2:
        s = "fax";
        continue; /* Loop/switch isn't completed */
_L3:
        s = "pager";
        continue; /* Loop/switch isn't completed */
_L4:
        s = "textphone";
        continue; /* Loop/switch isn't completed */
_L5:
        s = "text";
        if(true) goto _L7; else goto _L6
_L6:
    }

    public String[] encode(List list, String s, List list1, List list2, List list3, List list4, List list5, 
            String s1)
    {
        StringBuilder stringbuilder = new StringBuilder(100);
        stringbuilder.append("BEGIN:VCARD").append('\n');
        stringbuilder.append("VERSION:3.0").append('\n');
        StringBuilder stringbuilder1 = new StringBuilder(100);
        VCardFieldFormatter vcardfieldformatter = new VCardFieldFormatter();
        appendUpToUnique(stringbuilder, stringbuilder1, "N", list, 1, null, vcardfieldformatter, '\n');
        append(stringbuilder, stringbuilder1, "ORG", s, vcardfieldformatter, '\n');
        appendUpToUnique(stringbuilder, stringbuilder1, "ADR", list1, 1, null, vcardfieldformatter, '\n');
        List list6 = buildPhoneMetadata(list2, list3);
        appendUpToUnique(stringbuilder, stringbuilder1, "TEL", list2, 0x7fffffff, new VCardTelDisplayFormatter(list6), new VCardFieldFormatter(list6), '\n');
        appendUpToUnique(stringbuilder, stringbuilder1, "EMAIL", list4, 0x7fffffff, null, vcardfieldformatter, '\n');
        appendUpToUnique(stringbuilder, stringbuilder1, "URL", list5, 0x7fffffff, null, vcardfieldformatter, '\n');
        append(stringbuilder, stringbuilder1, "NOTE", s1, vcardfieldformatter, '\n');
        stringbuilder.append("END:VCARD").append('\n');
        String as[] = new String[2];
        as[0] = stringbuilder.toString();
        as[1] = stringbuilder1.toString();
        return as;
    }
}
