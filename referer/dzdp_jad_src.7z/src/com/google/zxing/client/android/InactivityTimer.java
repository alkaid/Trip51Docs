// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.client.android;

import android.app.Activity;
import android.content.*;
import android.os.AsyncTask;
import android.util.Log;
import com.google.zxing.client.android.common.executor.AsyncTaskExecInterface;
import com.google.zxing.client.android.common.executor.AsyncTaskExecManager;

final class InactivityTimer
{
    class InactivityAsyncTask extends AsyncTask
    {

        final InactivityTimer this$0;

        protected transient Object doInBackground(Object aobj[])
        {
            try
            {
                Thread.sleep(0x493e0L);
                Log.i(InactivityTimer.TAG, "Finishing activity due to inactivity");
                activity.finish();
            }
            catch(InterruptedException interruptedexception) { }
            return null;
        }

        private InactivityAsyncTask()
        {
            this$0 = InactivityTimer.this;
            super();
        }

    }

    class PowerStatusReceiver extends BroadcastReceiver
    {

        final InactivityTimer this$0;

        public void onReceive(Context context, Intent intent)
        {
            if("android.intent.action.BATTERY_CHANGED".equals(intent.getAction()))
            {
                boolean flag;
                if(intent.getIntExtra("plugged", -1) <= 0)
                    flag = true;
                else
                    flag = false;
                if(flag)
                    onActivity();
                else
                    cancel();
            }
        }

        private PowerStatusReceiver()
        {
            this$0 = InactivityTimer.this;
            super();
        }

    }


    private static final long INACTIVITY_DELAY_MS = 0x493e0L;
    private static final String TAG = com/google/zxing/client/android/InactivityTimer.getSimpleName();
    private final Activity activity;
    private AsyncTask inactivityTask;
    private final BroadcastReceiver powerStatusReceiver = new PowerStatusReceiver();
    private boolean registered;
    private final AsyncTaskExecInterface taskExec = (AsyncTaskExecInterface)(new AsyncTaskExecManager()).build();

    InactivityTimer(Activity activity1)
    {
        activity = activity1;
        registered = false;
        onActivity();
    }

    /**
     * @deprecated Method cancel is deprecated
     */

    private void cancel()
    {
        this;
        JVM INSTR monitorenter ;
        AsyncTask asynctask = inactivityTask;
        if(asynctask != null)
        {
            asynctask.cancel(true);
            inactivityTask = null;
        }
        this;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    /**
     * @deprecated Method onActivity is deprecated
     */

    void onActivity()
    {
        this;
        JVM INSTR monitorenter ;
        cancel();
        inactivityTask = new InactivityAsyncTask();
        taskExec.execute(inactivityTask, new Object[0]);
        this;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    /**
     * @deprecated Method onPause is deprecated
     */

    public void onPause()
    {
        this;
        JVM INSTR monitorenter ;
        cancel();
        if(!registered)
            break MISSING_BLOCK_LABEL_32;
        activity.unregisterReceiver(powerStatusReceiver);
        registered = false;
_L1:
        this;
        JVM INSTR monitorexit ;
        return;
        Log.w(TAG, "PowerStatusReceiver was never registered?");
          goto _L1
        Exception exception;
        exception;
        throw exception;
    }

    /**
     * @deprecated Method onResume is deprecated
     */

    public void onResume()
    {
        this;
        JVM INSTR monitorenter ;
        if(!registered)
            break MISSING_BLOCK_LABEL_25;
        Log.w(TAG, "PowerStatusReceiver was already registered?");
_L1:
        onActivity();
        this;
        JVM INSTR monitorexit ;
        return;
        activity.registerReceiver(powerStatusReceiver, new IntentFilter("android.intent.action.BATTERY_CHANGED"));
        registered = true;
          goto _L1
        Exception exception;
        exception;
        throw exception;
    }

    void shutdown()
    {
        cancel();
    }




}
