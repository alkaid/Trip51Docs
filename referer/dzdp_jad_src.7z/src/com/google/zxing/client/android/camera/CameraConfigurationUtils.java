// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.client.android.camera;

import android.graphics.Point;
import android.graphics.Rect;
import android.os.Build;
import android.util.Log;
import java.util.*;
import java.util.regex.Pattern;

public final class CameraConfigurationUtils
{

    private static final int AREA_PER_1000 = 400;
    private static final double MAX_ASPECT_DISTORTION = 0.14999999999999999D;
    private static final float MAX_EXPOSURE_COMPENSATION = 1.5F;
    private static final int MAX_FPS = 20;
    private static final float MIN_EXPOSURE_COMPENSATION = 0F;
    private static final int MIN_FPS = 10;
    private static final int MIN_PREVIEW_PIXELS = 0x25800;
    private static final Pattern SEMICOLON = Pattern.compile(";");
    private static final String TAG = "CameraConfiguration";

    private CameraConfigurationUtils()
    {
    }

    private static List buildMiddleArea(int i)
    {
        List list;
        if(android.os.Build.VERSION.SDK_INT >= 14)
            list = Collections.singletonList(new android.hardware.Camera.Area(new Rect(-i, -i, i, i), 1));
        else
            list = null;
        return list;
    }

    public static String collectStats(android.hardware.Camera.Parameters parameters)
    {
        return collectStats(((CharSequence) (parameters.flatten())));
    }

    public static String collectStats(CharSequence charsequence)
    {
        StringBuilder stringbuilder = new StringBuilder(1000);
        stringbuilder.append("BOARD=").append(Build.BOARD).append('\n');
        stringbuilder.append("BRAND=").append(Build.BRAND).append('\n');
        stringbuilder.append("CPU_ABI=").append(Build.CPU_ABI).append('\n');
        stringbuilder.append("DEVICE=").append(Build.DEVICE).append('\n');
        stringbuilder.append("DISPLAY=").append(Build.DISPLAY).append('\n');
        stringbuilder.append("FINGERPRINT=").append(Build.FINGERPRINT).append('\n');
        stringbuilder.append("HOST=").append(Build.HOST).append('\n');
        stringbuilder.append("ID=").append(Build.ID).append('\n');
        stringbuilder.append("MANUFACTURER=").append(Build.MANUFACTURER).append('\n');
        stringbuilder.append("MODEL=").append(Build.MODEL).append('\n');
        stringbuilder.append("PRODUCT=").append(Build.PRODUCT).append('\n');
        stringbuilder.append("TAGS=").append(Build.TAGS).append('\n');
        stringbuilder.append("TIME=").append(Build.TIME).append('\n');
        stringbuilder.append("TYPE=").append(Build.TYPE).append('\n');
        stringbuilder.append("USER=").append(Build.USER).append('\n');
        stringbuilder.append("VERSION.CODENAME=").append(android.os.Build.VERSION.CODENAME).append('\n');
        stringbuilder.append("VERSION.INCREMENTAL=").append(android.os.Build.VERSION.INCREMENTAL).append('\n');
        stringbuilder.append("VERSION.RELEASE=").append(android.os.Build.VERSION.RELEASE).append('\n');
        stringbuilder.append("VERSION.SDK_INT=").append(android.os.Build.VERSION.SDK_INT).append('\n');
        if(charsequence != null)
        {
            String as[] = SEMICOLON.split(charsequence);
            Arrays.sort(as);
            int i = as.length;
            for(int j = 0; j < i; j++)
                stringbuilder.append(as[j]).append('\n');

        }
        return stringbuilder.toString();
    }

    public static Point findBestPreviewSizeValue(android.hardware.Camera.Parameters parameters, Point point)
    {
        List list = parameters.getSupportedPreviewSizes();
        if(list != null) goto _L2; else goto _L1
_L1:
        Point point2;
        Log.w("CameraConfiguration", "Device returned no supported preview sizes; using default");
        android.hardware.Camera.Size size4 = parameters.getPreviewSize();
        if(size4 == null)
            throw new IllegalStateException("Parameters contained no preview size!");
        point2 = new Point(size4.width, size4.height);
_L4:
        return point2;
_L2:
        ArrayList arraylist;
label0:
        {
            arraylist = new ArrayList(list);
            Collections.sort(arraylist, new Comparator() {

                public int compare(android.hardware.Camera.Size size5, android.hardware.Camera.Size size6)
                {
                    int i1 = size5.height * size5.width;
                    int j1 = size6.height * size6.width;
                    byte byte0;
                    if(j1 < i1)
                        byte0 = -1;
                    else
                    if(j1 > i1)
                        byte0 = 1;
                    else
                        byte0 = 0;
                    return byte0;
                }

                public volatile int compare(Object obj, Object obj1)
                {
                    return compare((android.hardware.Camera.Size)obj, (android.hardware.Camera.Size)obj1);
                }

            }
);
            if(Log.isLoggable("CameraConfiguration", 4))
            {
                StringBuilder stringbuilder = new StringBuilder();
                android.hardware.Camera.Size size3;
                for(Iterator iterator = arraylist.iterator(); iterator.hasNext(); stringbuilder.append(size3.width).append('x').append(size3.height).append(' '))
                    size3 = (android.hardware.Camera.Size)iterator.next();

                Log.i("CameraConfiguration", (new StringBuilder()).append("Supported preview sizes: ").append(stringbuilder).toString());
            }
            double d = (double)point.y / (double)point.x;
            int i;
            int j;
            int k;
            int l;
label1:
            do
            {
                for(Iterator iterator1 = arraylist.iterator(); iterator1.hasNext();)
                {
                    android.hardware.Camera.Size size2 = (android.hardware.Camera.Size)iterator1.next();
                    i = size2.width;
                    j = size2.height;
                    if(i * j < 0x25800)
                    {
                        iterator1.remove();
                    } else
                    {
                        boolean flag;
                        if(i < j)
                            flag = true;
                        else
                            flag = false;
                        if(flag)
                            k = j;
                        else
                            k = i;
                        if(flag)
                            l = i;
                        else
                            l = j;
                        if(Math.abs((double)k / (double)l - d) <= 0.14999999999999999D)
                            continue label1;
                        iterator1.remove();
                    }
                }

                break label0;
            } while(k != point.x || l != point.y);
            point2 = new Point(i, j);
            Log.i("CameraConfiguration", (new StringBuilder()).append("Found preview size exactly matching screen size: ").append(point2).toString());
            continue; /* Loop/switch isn't completed */
        }
        if(!arraylist.isEmpty() && android.os.Build.VERSION.SDK_INT >= 11)
        {
            android.hardware.Camera.Size size1 = (android.hardware.Camera.Size)arraylist.get(0);
            Point point3 = new Point(size1.width, size1.height);
            Log.i("CameraConfiguration", (new StringBuilder()).append("Using largest suitable preview size: ").append(point3).toString());
            point2 = point3;
        } else
        {
            android.hardware.Camera.Size size = parameters.getPreviewSize();
            if(size == null)
                throw new IllegalStateException("Parameters contained no preview size!");
            Point point1 = new Point(size.width, size.height);
            Log.i("CameraConfiguration", (new StringBuilder()).append("No suitable preview sizes, using default: ").append(point1).toString());
            point2 = point1;
        }
        if(true) goto _L4; else goto _L3
_L3:
    }

    private static transient String findSettableValue(String s, Collection collection, String as[])
    {
        int i;
        int j;
        Log.i("CameraConfiguration", (new StringBuilder()).append("Requesting ").append(s).append(" value from among: ").append(Arrays.toString(as)).toString());
        Log.i("CameraConfiguration", (new StringBuilder()).append("Supported ").append(s).append(" values: ").append(collection).toString());
        if(collection == null)
            break MISSING_BLOCK_LABEL_156;
        i = as.length;
        j = 0;
_L3:
        String s1;
        if(j >= i)
            break MISSING_BLOCK_LABEL_156;
        s1 = as[j];
        if(!collection.contains(s1)) goto _L2; else goto _L1
_L1:
        Log.i("CameraConfiguration", (new StringBuilder()).append("Can set ").append(s).append(" to: ").append(s1).toString());
_L4:
        return s1;
_L2:
        j++;
          goto _L3
        Log.i("CameraConfiguration", "No supported values match");
        s1 = null;
          goto _L4
    }

    private static Integer indexOfClosestZoom(android.hardware.Camera.Parameters parameters, double d)
    {
        List list = parameters.getZoomRatios();
        Log.i("CameraConfiguration", (new StringBuilder()).append("Zoom ratios: ").append(list).toString());
        int i = parameters.getMaxZoom();
        Integer integer;
        if(list == null || list.isEmpty() || list.size() != i + 1)
        {
            Log.w("CameraConfiguration", "Invalid zoom ratios!");
            integer = null;
        } else
        {
            double d1 = 100D * d;
            double d2 = (1.0D / 0.0D);
            int j = 0;
            for(int k = 0; k < list.size(); k++)
            {
                double d3 = Math.abs((double)((Integer)list.get(k)).intValue() - d1);
                if(d3 < d2)
                {
                    d2 = d3;
                    j = k;
                }
            }

            Log.i("CameraConfiguration", (new StringBuilder()).append("Chose zoom ratio of ").append((double)((Integer)list.get(j)).intValue() / 100D).toString());
            integer = Integer.valueOf(j);
        }
        return integer;
    }

    public static void setBarcodeSceneMode(android.hardware.Camera.Parameters parameters)
    {
        if(!"barcode".equals(parameters.getSceneMode())) goto _L2; else goto _L1
_L1:
        Log.i("CameraConfiguration", "Barcode scene mode already set");
_L4:
        return;
_L2:
        List list = parameters.getSupportedSceneModes();
        String as[] = new String[1];
        as[0] = "barcode";
        String s = findSettableValue("scene mode", list, as);
        if(s != null)
            parameters.setSceneMode(s);
        if(true) goto _L4; else goto _L3
_L3:
    }

    public static void setBestExposure(android.hardware.Camera.Parameters parameters, boolean flag)
    {
        float f = 0.0F;
        int i = parameters.getMinExposureCompensation();
        int j = parameters.getMaxExposureCompensation();
        float f1 = parameters.getExposureCompensationStep();
        if((i != 0 || j != 0) && f1 > 0.0F)
        {
            int k;
            float f2;
            int l;
            if(!flag)
                f = 1.5F;
            k = Math.round(f / f1);
            f2 = f1 * (float)k;
            l = Math.max(Math.min(k, j), i);
            if(parameters.getExposureCompensation() == l)
            {
                Log.i("CameraConfiguration", (new StringBuilder()).append("Exposure compensation already set to ").append(l).append(" / ").append(f2).toString());
            } else
            {
                Log.i("CameraConfiguration", (new StringBuilder()).append("Setting exposure compensation to ").append(l).append(" / ").append(f2).toString());
                parameters.setExposureCompensation(l);
            }
        } else
        {
            Log.i("CameraConfiguration", "Camera does not support exposure compensation");
        }
    }

    public static void setBestPreviewFPS(android.hardware.Camera.Parameters parameters)
    {
        setBestPreviewFPS(parameters, 10, 20);
    }

    public static void setBestPreviewFPS(android.hardware.Camera.Parameters parameters, int i, int j)
    {
        List list = parameters.getSupportedPreviewFpsRange();
        Log.i("CameraConfiguration", (new StringBuilder()).append("Supported FPS ranges: ").append(toString(list)).toString());
        if(list != null && !list.isEmpty())
        {
            int ai[] = null;
            Iterator iterator = list.iterator();
            do
            {
                if(!iterator.hasNext())
                    break;
                int ai2[] = (int[])iterator.next();
                int k = ai2[0];
                int l = ai2[1];
                if(k < i * 1000 || l > j * 1000)
                    continue;
                ai = ai2;
                break;
            } while(true);
            if(ai == null)
            {
                Log.i("CameraConfiguration", "No suitable FPS range?");
            } else
            {
                int ai1[] = new int[2];
                parameters.getPreviewFpsRange(ai1);
                if(Arrays.equals(ai1, ai))
                {
                    Log.i("CameraConfiguration", (new StringBuilder()).append("FPS range already set to ").append(Arrays.toString(ai)).toString());
                } else
                {
                    Log.i("CameraConfiguration", (new StringBuilder()).append("Setting FPS range to ").append(Arrays.toString(ai)).toString());
                    parameters.setPreviewFpsRange(ai[0], ai[1]);
                }
            }
        }
    }

    public static void setFocus(android.hardware.Camera.Parameters parameters, boolean flag, boolean flag1, boolean flag2)
    {
        List list = parameters.getSupportedFocusModes();
        String s = null;
        if(flag)
            if(flag2 || flag1)
            {
                String as1[] = new String[1];
                as1[0] = "auto";
                s = findSettableValue("focus mode", list, as1);
            } else
            {
                String as2[] = new String[3];
                as2[0] = "continuous-picture";
                as2[1] = "continuous-video";
                as2[2] = "auto";
                s = findSettableValue("focus mode", list, as2);
            }
        if(!flag2 && s == null)
        {
            String as[] = new String[2];
            as[0] = "macro";
            as[1] = "edof";
            s = findSettableValue("focus mode", list, as);
        }
        if(s != null)
            if(s.equals(parameters.getFocusMode()))
                Log.i("CameraConfiguration", (new StringBuilder()).append("Focus mode already set to ").append(s).toString());
            else
                parameters.setFocusMode(s);
    }

    public static void setFocusArea(android.hardware.Camera.Parameters parameters)
    {
        if(android.os.Build.VERSION.SDK_INT >= 14 && parameters.getMaxNumFocusAreas() > 0)
        {
            Log.i("CameraConfiguration", (new StringBuilder()).append("Old focus areas: ").append(toString(parameters.getFocusAreas())).toString());
            List list = buildMiddleArea(400);
            Log.i("CameraConfiguration", (new StringBuilder()).append("Setting focus area to : ").append(toString(list)).toString());
            parameters.setFocusAreas(list);
        } else
        {
            Log.i("CameraConfiguration", "Device does not support focus areas");
        }
    }

    public static void setInvertColor(android.hardware.Camera.Parameters parameters)
    {
        if(!"negative".equals(parameters.getColorEffect())) goto _L2; else goto _L1
_L1:
        Log.i("CameraConfiguration", "Negative effect already set");
_L4:
        return;
_L2:
        List list = parameters.getSupportedColorEffects();
        String as[] = new String[1];
        as[0] = "negative";
        String s = findSettableValue("color effect", list, as);
        if(s != null)
            parameters.setColorEffect(s);
        if(true) goto _L4; else goto _L3
_L3:
    }

    public static void setMetering(android.hardware.Camera.Parameters parameters)
    {
        if(android.os.Build.VERSION.SDK_INT >= 14 && parameters.getMaxNumMeteringAreas() > 0)
        {
            Log.i("CameraConfiguration", (new StringBuilder()).append("Old metering areas: ").append(parameters.getMeteringAreas()).toString());
            List list = buildMiddleArea(400);
            Log.i("CameraConfiguration", (new StringBuilder()).append("Setting metering area to : ").append(toString(list)).toString());
            parameters.setMeteringAreas(list);
        } else
        {
            Log.i("CameraConfiguration", "Device does not support metering areas");
        }
    }

    public static void setTorch(android.hardware.Camera.Parameters parameters, boolean flag)
    {
        List list = parameters.getSupportedFlashModes();
        String s;
        if(flag)
        {
            String as1[] = new String[2];
            as1[0] = "torch";
            as1[1] = "on";
            s = findSettableValue("flash mode", list, as1);
        } else
        {
            String as[] = new String[1];
            as[0] = "off";
            s = findSettableValue("flash mode", list, as);
        }
        if(s != null)
            if(s.equals(parameters.getFlashMode()))
            {
                Log.i("CameraConfiguration", (new StringBuilder()).append("Flash mode already set to ").append(s).toString());
            } else
            {
                Log.i("CameraConfiguration", (new StringBuilder()).append("Setting flash mode to ").append(s).toString());
                parameters.setFlashMode(s);
            }
    }

    public static void setVideoStabilization(android.hardware.Camera.Parameters parameters)
    {
        if(android.os.Build.VERSION.SDK_INT >= 15 && parameters.isVideoStabilizationSupported())
        {
            if(parameters.getVideoStabilization())
            {
                Log.i("CameraConfiguration", "Video stabilization already enabled");
            } else
            {
                Log.i("CameraConfiguration", "Enabling video stabilization...");
                parameters.setVideoStabilization(true);
            }
        } else
        {
            Log.i("CameraConfiguration", "This device does not support video stabilization");
        }
    }

    public static void setZoom(android.hardware.Camera.Parameters parameters, double d)
    {
        if(parameters.isZoomSupported())
        {
            Integer integer = indexOfClosestZoom(parameters, d);
            if(integer != null)
                if(parameters.getZoom() == integer.intValue())
                {
                    Log.i("CameraConfiguration", (new StringBuilder()).append("Zoom is already set to ").append(integer).toString());
                } else
                {
                    Log.i("CameraConfiguration", (new StringBuilder()).append("Setting zoom to ").append(integer).toString());
                    parameters.setZoom(integer.intValue());
                }
        } else
        {
            Log.i("CameraConfiguration", "Zoom is not supported");
        }
    }

    private static String toString(Iterable iterable)
    {
        String s;
        if(iterable == null)
        {
            s = null;
        } else
        {
            StringBuilder stringbuilder = new StringBuilder();
            if(android.os.Build.VERSION.SDK_INT >= 14)
            {
                android.hardware.Camera.Area area;
                for(Iterator iterator1 = iterable.iterator(); iterator1.hasNext(); stringbuilder.append(area.rect).append(':').append(area.weight).append(' '))
                    area = (android.hardware.Camera.Area)iterator1.next();

            } else
            {
                for(Iterator iterator = iterable.iterator(); iterator.hasNext(); stringbuilder.append((android.hardware.Camera.Area)iterator.next()).append(' '));
            }
            s = stringbuilder.toString();
        }
        return s;
    }

    private static String toString(Collection collection)
    {
        String s;
        if(collection == null || collection.isEmpty())
        {
            s = "[]";
        } else
        {
            StringBuilder stringbuilder = new StringBuilder();
            stringbuilder.append('[');
            Iterator iterator = collection.iterator();
            do
            {
                if(!iterator.hasNext())
                    break;
                stringbuilder.append(Arrays.toString((int[])iterator.next()));
                if(iterator.hasNext())
                    stringbuilder.append(", ");
            } while(true);
            stringbuilder.append(']');
            s = stringbuilder.toString();
        }
        return s;
    }

}
