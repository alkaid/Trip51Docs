// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.client.android;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.AssetFileDescriptor;
import android.content.res.Resources;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Vibrator;
import android.preference.PreferenceManager;
import android.util.Log;
import java.io.Closeable;
import java.io.IOException;

final class BeepManager
    implements android.media.MediaPlayer.OnCompletionListener, android.media.MediaPlayer.OnErrorListener, Closeable
{

    private static final float BEEP_VOLUME = 0.1F;
    private static final String TAG = com/google/zxing/client/android/BeepManager.getSimpleName();
    private static final long VIBRATE_DURATION = 200L;
    private final Activity activity;
    private MediaPlayer mediaPlayer;
    private boolean playBeep;
    private boolean vibrate;

    BeepManager(Activity activity1)
    {
        activity = activity1;
        mediaPlayer = null;
        updatePrefs();
    }

    private MediaPlayer buildMediaPlayer(Context context)
    {
        MediaPlayer mediaplayer;
        mediaplayer = new MediaPlayer();
        mediaplayer.setAudioStreamType(3);
        mediaplayer.setOnCompletionListener(this);
        mediaplayer.setOnErrorListener(this);
        AssetFileDescriptor assetfiledescriptor = context.getResources().openRawResourceFd(R.raw.beep);
        mediaplayer.setDataSource(assetfiledescriptor.getFileDescriptor(), assetfiledescriptor.getStartOffset(), assetfiledescriptor.getLength());
        assetfiledescriptor.close();
        mediaplayer.setVolume(0.1F, 0.1F);
        mediaplayer.prepare();
        break MISSING_BLOCK_LABEL_99;
        Exception exception;
        exception;
        assetfiledescriptor.close();
        throw exception;
        IOException ioexception;
        ioexception;
        Log.w(TAG, ioexception);
        mediaplayer.release();
        mediaplayer = null;
        return mediaplayer;
    }

    private static boolean shouldBeep(SharedPreferences sharedpreferences, Context context)
    {
        boolean flag = sharedpreferences.getBoolean("preferences_play_beep", true);
        if(flag && ((AudioManager)context.getSystemService("audio")).getRingerMode() != 2)
            flag = false;
        return flag;
    }

    /**
     * @deprecated Method close is deprecated
     */

    public void close()
    {
        this;
        JVM INSTR monitorenter ;
        if(mediaPlayer != null)
        {
            mediaPlayer.release();
            mediaPlayer = null;
        }
        this;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public void onCompletion(MediaPlayer mediaplayer)
    {
        mediaplayer.seekTo(0);
    }

    /**
     * @deprecated Method onError is deprecated
     */

    public boolean onError(MediaPlayer mediaplayer, int i, int j)
    {
        this;
        JVM INSTR monitorenter ;
        if(i != 100)
            break MISSING_BLOCK_LABEL_19;
        activity.finish();
_L1:
        this;
        JVM INSTR monitorexit ;
        return true;
        mediaplayer.release();
        mediaPlayer = null;
        updatePrefs();
          goto _L1
        Exception exception;
        exception;
        throw exception;
    }

    /**
     * @deprecated Method playBeepSoundAndVibrate is deprecated
     */

    void playBeepSoundAndVibrate()
    {
        this;
        JVM INSTR monitorenter ;
        if(playBeep && mediaPlayer != null)
            mediaPlayer.start();
        if(vibrate)
            ((Vibrator)activity.getSystemService("vibrator")).vibrate(200L);
        this;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    /**
     * @deprecated Method updatePrefs is deprecated
     */

    void updatePrefs()
    {
        this;
        JVM INSTR monitorenter ;
        SharedPreferences sharedpreferences = PreferenceManager.getDefaultSharedPreferences(activity);
        playBeep = shouldBeep(sharedpreferences, activity);
        vibrate = sharedpreferences.getBoolean("preferences_vibrate", false);
        if(playBeep && mediaPlayer == null)
        {
            activity.setVolumeControlStream(3);
            mediaPlayer = buildMediaPlayer(activity);
        }
        this;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

}
