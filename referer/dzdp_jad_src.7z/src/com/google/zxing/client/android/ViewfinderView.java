// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.client.android;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.*;
import android.util.AttributeSet;
import android.view.View;
import com.google.zxing.ResultPoint;
import com.google.zxing.client.android.camera.CameraManager;
import java.util.*;

public class ViewfinderView extends View
{

    protected static final long ANIMATION_DELAY = 80L;
    protected static final int CURRENT_POINT_OPACITY = 160;
    protected static final int MAX_RESULT_POINTS = 20;
    protected static final int POINT_SIZE = 6;
    protected static final int SCANNER_ALPHA[];
    protected CameraManager cameraManager;
    protected final int laserColor;
    protected List lastPossibleResultPoints;
    protected final int maskColor;
    protected final Paint paint = new Paint(1);
    protected List possibleResultPoints;
    protected Bitmap resultBitmap;
    protected final int resultColor;
    protected final int resultPointColor;
    protected int scannerAlpha;

    public ViewfinderView(Context context, AttributeSet attributeset)
    {
        super(context, attributeset);
        Resources resources = getResources();
        maskColor = resources.getColor(R.color.viewfinder_mask);
        resultColor = resources.getColor(R.color.result_view);
        laserColor = resources.getColor(R.color.viewfinder_laser);
        resultPointColor = resources.getColor(R.color.possible_result_points);
        scannerAlpha = 0;
        possibleResultPoints = new ArrayList(5);
        lastPossibleResultPoints = null;
    }

    public void addPossibleResultPoint(ResultPoint resultpoint)
    {
        List list = possibleResultPoints;
        list;
        JVM INSTR monitorenter ;
        list.add(resultpoint);
        int i = list.size();
        if(i > 20)
            list.subList(0, i - 10).clear();
        return;
    }

    public void drawResultBitmap(Bitmap bitmap)
    {
        resultBitmap = bitmap;
        invalidate();
    }

    public void drawViewfinder()
    {
        Bitmap bitmap = resultBitmap;
        resultBitmap = null;
        if(bitmap != null)
            bitmap.recycle();
        invalidate();
    }

    public void onDraw(Canvas canvas)
    {
        if(cameraManager != null) goto _L2; else goto _L1
_L1:
        return;
_L2:
        Rect rect;
        float f;
        float f1;
        List list;
        List list1;
        int i1;
        int j1;
        rect = cameraManager.getFramingRect();
        Rect rect1 = cameraManager.getFramingRectInPreview();
        if(rect == null || rect1 == null)
            continue; /* Loop/switch isn't completed */
        int i = canvas.getWidth();
        int j = canvas.getHeight();
        Paint paint1 = paint;
        int k;
        if(resultBitmap != null)
            k = resultColor;
        else
            k = maskColor;
        paint1.setColor(k);
        canvas.drawRect(0.0F, 0.0F, i, rect.top, paint);
        canvas.drawRect(0.0F, rect.top, rect.left, 1 + rect.bottom, paint);
        canvas.drawRect(1 + rect.right, rect.top, i, 1 + rect.bottom, paint);
        canvas.drawRect(0.0F, 1 + rect.bottom, i, j, paint);
        if(resultBitmap != null)
        {
            paint.setAlpha(160);
            canvas.drawBitmap(resultBitmap, null, rect, paint);
            continue; /* Loop/switch isn't completed */
        }
        paint.setColor(laserColor);
        paint.setAlpha(SCANNER_ALPHA[scannerAlpha]);
        scannerAlpha = (1 + scannerAlpha) % SCANNER_ALPHA.length;
        int l = rect.height() / 2 + rect.top;
        canvas.drawRect(2 + rect.left, l - 1, -1 + rect.right, l + 2, paint);
        f = (float)rect.width() / (float)rect1.width();
        f1 = (float)rect.height() / (float)rect1.height();
        list = possibleResultPoints;
        list1 = lastPossibleResultPoints;
        i1 = rect.left;
        j1 = rect.top;
        if(!list.isEmpty()) goto _L4; else goto _L3
_L3:
        lastPossibleResultPoints = null;
_L8:
        if(list1 == null) goto _L6; else goto _L5
_L5:
        paint.setAlpha(80);
        paint.setColor(resultPointColor);
        list1;
        JVM INSTR monitorenter ;
        ResultPoint resultpoint;
        for(Iterator iterator1 = list1.iterator(); iterator1.hasNext(); canvas.drawCircle(i1 + (int)(f * resultpoint.getX()), j1 + (int)(f1 * resultpoint.getY()), 3F, paint))
            resultpoint = (ResultPoint)iterator1.next();

          goto _L7
        Exception exception1;
        exception1;
        throw exception1;
_L4:
        possibleResultPoints = new ArrayList(5);
        lastPossibleResultPoints = list;
        paint.setAlpha(160);
        paint.setColor(resultPointColor);
        list;
        JVM INSTR monitorenter ;
        ResultPoint resultpoint1;
        for(Iterator iterator = list.iterator(); iterator.hasNext(); canvas.drawCircle(i1 + (int)(f * resultpoint1.getX()), j1 + (int)(f1 * resultpoint1.getY()), 6F, paint))
            resultpoint1 = (ResultPoint)iterator.next();

        break MISSING_BLOCK_LABEL_587;
        Exception exception;
        exception;
        throw exception;
        list;
        JVM INSTR monitorexit ;
          goto _L8
_L7:
        list1;
        JVM INSTR monitorexit ;
_L6:
        postInvalidateDelayed(80L, -6 + rect.left, -6 + rect.top, 6 + rect.right, 6 + rect.bottom);
        if(true) goto _L1; else goto _L9
_L9:
    }

    public void setCameraManager(CameraManager cameramanager)
    {
        cameraManager = cameramanager;
    }

    static 
    {
        int ai[] = new int[8];
        ai[0] = 0;
        ai[1] = 64;
        ai[2] = 128;
        ai[3] = 192;
        ai[4] = 255;
        ai[5] = 192;
        ai[6] = 128;
        ai[7] = 64;
        SCANNER_ALPHA = ai;
    }
}
