// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.client.android.camera;

import android.content.Context;
import android.graphics.Point;
import android.graphics.Rect;
import android.hardware.Camera;
import android.os.Handler;
import android.util.Log;
import android.view.SurfaceHolder;
import com.google.zxing.PlanarYUVLuminanceSource;
import com.google.zxing.client.android.camera.open.OpenCameraInterface;
import java.io.IOException;

// Referenced classes of package com.google.zxing.client.android.camera:
//            CameraConfigurationManager, PreviewCallback, AutoFocusManager

public final class CameraManager
{

    private static final int MAX_FRAME_HEIGHT = 675;
    private static final int MAX_FRAME_WIDTH = 1200;
    private static final int MIN_FRAME_HEIGHT = 240;
    private static final int MIN_FRAME_WIDTH = 240;
    private static final String TAG = com/google/zxing/client/android/camera/CameraManager.getSimpleName();
    private AutoFocusManager autoFocusManager;
    private Camera camera;
    private final CameraConfigurationManager configManager;
    private final Context context;
    private Rect framingRect;
    private Rect framingRectInPreview;
    private boolean initialized;
    private final PreviewCallback previewCallback;
    private boolean previewing;
    private int requestedCameraId;
    private int requestedFramingRectHeight;
    private int requestedFramingRectWidth;

    public CameraManager(Context context1)
    {
        requestedCameraId = -1;
        context = context1;
        configManager = new CameraConfigurationManager(context1);
        previewCallback = new PreviewCallback(configManager);
    }

    private static int findDesiredDimensionInRange(int i, int j, int k)
    {
        int l = (i * 5) / 8;
        if(l >= j)
            if(l > k)
                j = k;
            else
                j = l;
        return j;
    }

    public PlanarYUVLuminanceSource buildLuminanceSource(byte abyte0[], int i, int j)
    {
        Rect rect = getFramingRectInPreview();
        PlanarYUVLuminanceSource planaryuvluminancesource;
        if(rect == null)
            planaryuvluminancesource = null;
        else
            planaryuvluminancesource = new PlanarYUVLuminanceSource(abyte0, i, j, rect.left, rect.top, rect.width(), rect.height(), false);
        return planaryuvluminancesource;
    }

    /**
     * @deprecated Method closeDriver is deprecated
     */

    public void closeDriver()
    {
        this;
        JVM INSTR monitorenter ;
        if(camera != null)
        {
            camera.release();
            camera = null;
            framingRect = null;
            framingRectInPreview = null;
        }
        this;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    /**
     * @deprecated Method getFramingRect is deprecated
     */

    public Rect getFramingRect()
    {
        Rect rect = null;
        this;
        JVM INSTR monitorenter ;
        if(framingRect != null) goto _L2; else goto _L1
_L1:
        Camera camera1 = camera;
        if(camera1 != null) goto _L4; else goto _L3
_L3:
        this;
        JVM INSTR monitorexit ;
        return rect;
_L4:
        Point point = configManager.getScreenResolution();
        if(point == null)
            continue; /* Loop/switch isn't completed */
        int i = Math.min(findDesiredDimensionInRange(point.x, 240, 1200), findDesiredDimensionInRange(point.y, 240, 675));
        int j = (point.x - i) / 2;
        int k = (point.y - i) / 2;
        framingRect = new Rect(j, k, j + i, k + i);
        Log.d(TAG, (new StringBuilder()).append("Calculated framing rect: ").append(framingRect).toString());
_L2:
        rect = framingRect;
        if(true) goto _L3; else goto _L5
_L5:
        Exception exception;
        exception;
        throw exception;
    }

    /**
     * @deprecated Method getFramingRectInPreview is deprecated
     */

    public Rect getFramingRectInPreview()
    {
        Rect rect = null;
        this;
        JVM INSTR monitorenter ;
        if(framingRectInPreview != null) goto _L2; else goto _L1
_L1:
        Rect rect1 = getFramingRect();
        if(rect1 != null) goto _L4; else goto _L3
_L3:
        this;
        JVM INSTR monitorexit ;
        return rect;
_L4:
        Rect rect2 = new Rect(rect1);
        Point point = configManager.getCameraResolution();
        Point point1 = configManager.getScreenResolution();
        if(point == null || point1 == null)
            continue; /* Loop/switch isn't completed */
        rect2.left = (rect2.left * point.y) / point1.x;
        rect2.right = (rect2.right * point.y) / point1.x;
        rect2.top = (rect2.top * point.x) / point1.y;
        rect2.bottom = (rect2.bottom * point.x) / point1.y;
        framingRectInPreview = rect2;
_L2:
        rect = framingRectInPreview;
        if(true) goto _L3; else goto _L5
_L5:
        Exception exception;
        exception;
        throw exception;
    }

    /**
     * @deprecated Method isOpen is deprecated
     */

    public boolean isOpen()
    {
        this;
        JVM INSTR monitorenter ;
        Camera camera1 = camera;
        boolean flag;
        if(camera1 != null)
            flag = true;
        else
            flag = false;
        this;
        JVM INSTR monitorexit ;
        return flag;
        Exception exception;
        exception;
        throw exception;
    }

    /**
     * @deprecated Method openDriver is deprecated
     */

    public void openDriver(SurfaceHolder surfaceholder)
        throws IOException
    {
        this;
        JVM INSTR monitorenter ;
        Camera camera1;
        camera1 = camera;
        if(camera1 != null)
            break MISSING_BLOCK_LABEL_41;
        camera1 = OpenCameraInterface.open(requestedCameraId);
        if(camera1 == null)
            throw new IOException();
        break MISSING_BLOCK_LABEL_36;
        Exception exception;
        exception;
        this;
        JVM INSTR monitorexit ;
        throw exception;
        camera = camera1;
        android.hardware.Camera.Parameters parameters;
        camera1.setPreviewDisplay(surfaceholder);
        if(!initialized)
        {
            initialized = true;
            configManager.initFromCameraParameters(camera1);
            if(requestedFramingRectWidth > 0 && requestedFramingRectHeight > 0)
            {
                setManualFramingRect(requestedFramingRectWidth, requestedFramingRectHeight);
                requestedFramingRectWidth = 0;
                requestedFramingRectHeight = 0;
            }
        }
        parameters = camera1.getParameters();
        if(parameters != null) goto _L2; else goto _L1
_L1:
        String s = null;
_L3:
        configManager.setDesiredCameraParameters(camera1, false);
_L5:
        this;
        JVM INSTR monitorexit ;
        return;
_L2:
        s = parameters.flatten();
          goto _L3
        RuntimeException runtimeexception;
        runtimeexception;
        Log.w(TAG, "Camera rejected parameters. Setting only minimal safe-mode parameters");
        Log.i(TAG, (new StringBuilder()).append("Resetting to saved camera params: ").append(s).toString());
        if(s == null) goto _L5; else goto _L4
_L4:
        android.hardware.Camera.Parameters parameters1;
        parameters1 = camera1.getParameters();
        parameters1.unflatten(s);
        camera1.setParameters(parameters1);
        configManager.setDesiredCameraParameters(camera1, true);
          goto _L5
        RuntimeException runtimeexception1;
        runtimeexception1;
        Log.w(TAG, "Camera rejected even safe-mode parameters! No configuration");
          goto _L5
    }

    /**
     * @deprecated Method requestPreviewFrame is deprecated
     */

    public void requestPreviewFrame(Handler handler, int i)
    {
        this;
        JVM INSTR monitorenter ;
        Camera camera1 = camera;
        if(camera1 != null && previewing)
        {
            previewCallback.setHandler(handler, i);
            camera1.setOneShotPreviewCallback(previewCallback);
        }
        this;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    /**
     * @deprecated Method setManualCameraId is deprecated
     */

    public void setManualCameraId(int i)
    {
        this;
        JVM INSTR monitorenter ;
        requestedCameraId = i;
        this;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    /**
     * @deprecated Method setManualFramingRect is deprecated
     */

    public void setManualFramingRect(int i, int j)
    {
        this;
        JVM INSTR monitorenter ;
        if(!initialized)
            break MISSING_BLOCK_LABEL_130;
        Point point = configManager.getScreenResolution();
        if(i > point.x)
            i = point.x;
        if(j > point.y)
            j = point.y;
        int k = (point.x - i) / 2;
        int l = (point.y - j) / 2;
        framingRect = new Rect(k, l, k + i, l + j);
        Log.d(TAG, (new StringBuilder()).append("Calculated manual framing rect: ").append(framingRect).toString());
        framingRectInPreview = null;
_L1:
        this;
        JVM INSTR monitorexit ;
        return;
        requestedFramingRectWidth = i;
        requestedFramingRectHeight = j;
          goto _L1
        Exception exception;
        exception;
        throw exception;
    }

    /**
     * @deprecated Method setTorch is deprecated
     */

    public void setTorch(boolean flag)
    {
        this;
        JVM INSTR monitorenter ;
        if(flag != configManager.getTorchState(camera) && camera != null)
        {
            if(autoFocusManager != null)
                autoFocusManager.stop();
            configManager.setTorch(camera, flag);
            if(autoFocusManager != null)
                autoFocusManager.start();
        }
        this;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    /**
     * @deprecated Method startPreview is deprecated
     */

    public void startPreview()
    {
        this;
        JVM INSTR monitorenter ;
        Camera camera1 = camera;
        if(camera1 != null && !previewing)
        {
            camera1.startPreview();
            previewing = true;
            autoFocusManager = new AutoFocusManager(context, camera);
        }
        this;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    /**
     * @deprecated Method stopPreview is deprecated
     */

    public void stopPreview()
    {
        this;
        JVM INSTR monitorenter ;
        if(autoFocusManager != null)
        {
            autoFocusManager.stop();
            autoFocusManager = null;
        }
        if(camera != null && previewing)
        {
            camera.stopPreview();
            previewCallback.setHandler(null, 0);
            previewing = false;
        }
        this;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

}
