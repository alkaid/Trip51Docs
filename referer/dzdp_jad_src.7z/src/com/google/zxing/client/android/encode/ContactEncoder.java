// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.client.android.encode;

import java.util.*;

// Referenced classes of package com.google.zxing.client.android.encode:
//            Formatter

abstract class ContactEncoder
{

    ContactEncoder()
    {
    }

    static void append(StringBuilder stringbuilder, StringBuilder stringbuilder1, String s, String s1, Formatter formatter, char c)
    {
        String s2 = trim(s1);
        if(s2 != null)
        {
            stringbuilder.append(s).append(formatter.format(s2, 0)).append(c);
            stringbuilder1.append(s2).append('\n');
        }
    }

    static void appendUpToUnique(StringBuilder stringbuilder, StringBuilder stringbuilder1, String s, List list, int i, Formatter formatter, Formatter formatter1, char c)
    {
        if(list != null) goto _L2; else goto _L1
_L1:
        return;
_L2:
        int j;
        HashSet hashset;
        int k;
        j = 0;
        hashset = new HashSet(2);
        k = 0;
_L5:
        if(k >= list.size()) goto _L1; else goto _L3
_L3:
        String s1 = trim((String)list.get(k));
        if(s1 == null || s1.isEmpty() || hashset.contains(s1))
            break MISSING_BLOCK_LABEL_139;
        stringbuilder.append(s).append(formatter1.format(s1, k)).append(c);
        Object obj;
        if(formatter == null)
            obj = s1;
        else
            obj = formatter.format(s1, k);
        stringbuilder1.append(((CharSequence) (obj))).append('\n');
        if(++j == i) goto _L1; else goto _L4
_L4:
        hashset.add(s1);
        k++;
          goto _L5
    }

    static String trim(String s)
    {
        String s1 = null;
        if(s != null)
        {
            String s2 = s.trim();
            if(s2.isEmpty())
                s2 = null;
            s1 = s2;
        }
        return s1;
    }

    abstract String[] encode(List list, String s, List list1, List list2, List list3, List list4, List list5, 
            String s1);
}
