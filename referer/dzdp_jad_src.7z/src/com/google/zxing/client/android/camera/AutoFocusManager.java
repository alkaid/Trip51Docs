// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.client.android.camera;

import android.content.Context;
import android.content.SharedPreferences;
import android.hardware.Camera;
import android.os.AsyncTask;
import android.preference.PreferenceManager;
import android.util.Log;
import com.google.zxing.client.android.common.executor.AsyncTaskExecInterface;
import com.google.zxing.client.android.common.executor.AsyncTaskExecManager;
import java.util.ArrayList;
import java.util.Collection;
import java.util.concurrent.RejectedExecutionException;

final class AutoFocusManager
    implements android.hardware.Camera.AutoFocusCallback
{
    private final class AutoFocusTask extends AsyncTask
    {

        final AutoFocusManager this$0;

        protected transient Object doInBackground(Object aobj[])
        {
            try
            {
                Thread.sleep(2000L);
            }
            catch(InterruptedException interruptedexception) { }
            start();
            return null;
        }

        private AutoFocusTask()
        {
            this$0 = AutoFocusManager.this;
            super();
        }

    }


    private static final long AUTO_FOCUS_INTERVAL_MS = 2000L;
    private static final Collection FOCUS_MODES_CALLING_AF;
    private static final String TAG = com/google/zxing/client/android/camera/AutoFocusManager.getSimpleName();
    private final Camera camera;
    private boolean focusing;
    private AsyncTask outstandingTask;
    private boolean stopped;
    private final AsyncTaskExecInterface taskExec = (AsyncTaskExecInterface)(new AsyncTaskExecManager()).build();
    private final boolean useAutoFocus;

    AutoFocusManager(Context context, Camera camera1)
    {
        camera = camera1;
        SharedPreferences sharedpreferences = PreferenceManager.getDefaultSharedPreferences(context);
        String s = camera1.getParameters().getFocusMode();
        boolean flag;
        if(sharedpreferences.getBoolean("preferences_auto_focus", true) && FOCUS_MODES_CALLING_AF.contains(s))
            flag = true;
        else
            flag = false;
        useAutoFocus = flag;
        Log.i(TAG, (new StringBuilder()).append("Current focus mode '").append(s).append("'; use auto focus? ").append(useAutoFocus).toString());
        start();
    }

    /**
     * @deprecated Method autoFocusAgainLater is deprecated
     */

    private void autoFocusAgainLater()
    {
        this;
        JVM INSTR monitorenter ;
        AutoFocusTask autofocustask;
        if(stopped || outstandingTask != null)
            break MISSING_BLOCK_LABEL_45;
        autofocustask = new AutoFocusTask();
        taskExec.execute(autofocustask, new Object[0]);
        outstandingTask = autofocustask;
_L1:
        this;
        JVM INSTR monitorexit ;
        return;
        RejectedExecutionException rejectedexecutionexception;
        rejectedexecutionexception;
        Log.w(TAG, "Could not request auto focus", rejectedexecutionexception);
          goto _L1
        Exception exception;
        exception;
        throw exception;
    }

    /**
     * @deprecated Method cancelOutstandingTask is deprecated
     */

    private void cancelOutstandingTask()
    {
        this;
        JVM INSTR monitorenter ;
        if(outstandingTask != null)
        {
            if(outstandingTask.getStatus() != android.os.AsyncTask.Status.FINISHED)
                outstandingTask.cancel(true);
            outstandingTask = null;
        }
        this;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    /**
     * @deprecated Method onAutoFocus is deprecated
     */

    public void onAutoFocus(boolean flag, Camera camera1)
    {
        this;
        JVM INSTR monitorenter ;
        focusing = false;
        autoFocusAgainLater();
        this;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    /**
     * @deprecated Method start is deprecated
     */

    void start()
    {
        this;
        JVM INSTR monitorenter ;
        boolean flag;
        if(!useAutoFocus)
            break MISSING_BLOCK_LABEL_43;
        outstandingTask = null;
        if(stopped)
            break MISSING_BLOCK_LABEL_43;
        flag = focusing;
        if(flag)
            break MISSING_BLOCK_LABEL_43;
        camera.autoFocus(this);
        focusing = true;
_L1:
        this;
        JVM INSTR monitorexit ;
        return;
        RuntimeException runtimeexception;
        runtimeexception;
        Log.w(TAG, "Unexpected exception while focusing", runtimeexception);
        autoFocusAgainLater();
          goto _L1
        Exception exception;
        exception;
        throw exception;
    }

    /**
     * @deprecated Method stop is deprecated
     */

    void stop()
    {
        this;
        JVM INSTR monitorenter ;
        stopped = true;
        if(!useAutoFocus)
            break MISSING_BLOCK_LABEL_25;
        cancelOutstandingTask();
        camera.cancelAutoFocus();
_L1:
        this;
        JVM INSTR monitorexit ;
        return;
        RuntimeException runtimeexception;
        runtimeexception;
        Log.w(TAG, "Unexpected exception while cancelling focusing", runtimeexception);
          goto _L1
        Exception exception;
        exception;
        throw exception;
    }

    static 
    {
        FOCUS_MODES_CALLING_AF = new ArrayList(2);
        FOCUS_MODES_CALLING_AF.add("auto");
        FOCUS_MODES_CALLING_AF.add("macro");
    }
}
