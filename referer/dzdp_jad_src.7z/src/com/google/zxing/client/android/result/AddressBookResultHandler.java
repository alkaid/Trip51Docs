// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.client.android.result;

import android.app.Activity;
import android.telephony.PhoneNumberUtils;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.StyleSpan;
import com.google.zxing.client.result.AddressBookParsedResult;
import com.google.zxing.client.result.ParsedResult;
import java.text.*;
import java.util.Date;
import java.util.Locale;

// Referenced classes of package com.google.zxing.client.android.result:
//            ResultHandler

public final class AddressBookResultHandler extends ResultHandler
{

    private static final int BUTTON_TEXTS[];
    private static final DateFormat DATE_FORMATS[];
    private int buttonCount;
    private final boolean fields[] = new boolean[4];

    public AddressBookResultHandler(Activity activity, ParsedResult parsedresult)
    {
        super(activity, parsedresult);
        AddressBookParsedResult addressbookparsedresult = (AddressBookParsedResult)parsedresult;
        String as[] = addressbookparsedresult.getAddresses();
        boolean flag;
        String as1[];
        boolean flag1;
        String as2[];
        boolean flag2;
        if(as != null && as.length > 0 && as[0] != null && !as[0].isEmpty())
            flag = true;
        else
            flag = false;
        as1 = addressbookparsedresult.getPhoneNumbers();
        if(as1 != null && as1.length > 0)
            flag1 = true;
        else
            flag1 = false;
        as2 = addressbookparsedresult.getEmails();
        if(as2 != null && as2.length > 0)
            flag2 = true;
        else
            flag2 = false;
        fields[0] = true;
        fields[1] = flag;
        fields[2] = flag1;
        fields[3] = flag2;
        buttonCount = 0;
        for(int i = 0; i < 4; i++)
            if(fields[i])
                buttonCount = 1 + buttonCount;

    }

    private int mapIndexToAction(int i)
    {
        int j;
        int k;
        if(i >= buttonCount)
            break MISSING_BLOCK_LABEL_43;
        k = -1;
        j = 0;
_L3:
        if(j >= 4)
            break MISSING_BLOCK_LABEL_43;
        if(fields[j])
            k++;
        if(k != i) goto _L2; else goto _L1
_L1:
        return j;
_L2:
        j++;
          goto _L3
        j = -1;
          goto _L1
    }

    private static Date parseDate(String s)
    {
        DateFormat adateformat[];
        int i;
        int j;
        adateformat = DATE_FORMATS;
        i = adateformat.length;
        j = 0;
_L1:
        DateFormat dateformat;
        if(j >= i)
            break MISSING_BLOCK_LABEL_42;
        dateformat = adateformat[j];
        Date date1 = dateformat.parse(s);
        Date date = date1;
_L2:
        return date;
        ParseException parseexception;
        parseexception;
        j++;
          goto _L1
        date = null;
          goto _L2
    }

    public int getButtonCount()
    {
        return buttonCount;
    }

    public int getButtonText(int i)
    {
        return BUTTON_TEXTS[mapIndexToAction(i)];
    }

    public CharSequence getDisplayContents()
    {
        AddressBookParsedResult addressbookparsedresult = (AddressBookParsedResult)getResult();
        StringBuilder stringbuilder = new StringBuilder(100);
        ParsedResult.maybeAppend(addressbookparsedresult.getNames(), stringbuilder);
        int i = stringbuilder.length();
        String s = addressbookparsedresult.getPronunciation();
        if(s != null && !s.isEmpty())
        {
            stringbuilder.append("\n(");
            stringbuilder.append(s);
            stringbuilder.append(')');
        }
        ParsedResult.maybeAppend(addressbookparsedresult.getTitle(), stringbuilder);
        ParsedResult.maybeAppend(addressbookparsedresult.getOrg(), stringbuilder);
        ParsedResult.maybeAppend(addressbookparsedresult.getAddresses(), stringbuilder);
        String as[] = addressbookparsedresult.getPhoneNumbers();
        if(as != null)
        {
            int j = as.length;
            for(int k = 0; k < j; k++)
            {
                String s2 = as[k];
                if(s2 != null)
                    ParsedResult.maybeAppend(PhoneNumberUtils.formatNumber(s2), stringbuilder);
            }

        }
        ParsedResult.maybeAppend(addressbookparsedresult.getEmails(), stringbuilder);
        ParsedResult.maybeAppend(addressbookparsedresult.getURLs(), stringbuilder);
        String s1 = addressbookparsedresult.getBirthday();
        if(s1 != null && !s1.isEmpty())
        {
            Date date = parseDate(s1);
            if(date != null)
                ParsedResult.maybeAppend(DateFormat.getDateInstance(2).format(Long.valueOf(date.getTime())), stringbuilder);
        }
        ParsedResult.maybeAppend(addressbookparsedresult.getNote(), stringbuilder);
        Object obj;
        if(i > 0)
        {
            obj = new SpannableString(stringbuilder.toString());
            ((Spannable) (obj)).setSpan(new StyleSpan(1), 0, i, 0);
        } else
        {
            obj = stringbuilder.toString();
        }
        return ((CharSequence) (obj));
    }

    public int getDisplayTitle()
    {
        return com.google.zxing.client.android.R.string.result_address_book;
    }

    public void handleButtonPress(int i)
    {
        AddressBookParsedResult addressbookparsedresult;
        String s;
        String s1;
        addressbookparsedresult = (AddressBookParsedResult)getResult();
        String as[] = addressbookparsedresult.getAddresses();
        String as1[];
        if(as == null || as.length < 1)
            s = null;
        else
            s = as[0];
        as1 = addressbookparsedresult.getAddressTypes();
        if(as1 == null || as1.length < 1)
            s1 = null;
        else
            s1 = as1[0];
        mapIndexToAction(i);
        JVM INSTR tableswitch 0 3: default 84
    //                   0 102
    //                   1 169
    //                   2 178
    //                   3 191;
           goto _L1 _L2 _L3 _L4 _L5
_L1:
        return;
_L2:
        addContact(addressbookparsedresult.getNames(), addressbookparsedresult.getNicknames(), addressbookparsedresult.getPronunciation(), addressbookparsedresult.getPhoneNumbers(), addressbookparsedresult.getPhoneTypes(), addressbookparsedresult.getEmails(), addressbookparsedresult.getEmailTypes(), addressbookparsedresult.getNote(), addressbookparsedresult.getInstantMessenger(), s, s1, addressbookparsedresult.getOrg(), addressbookparsedresult.getTitle(), addressbookparsedresult.getURLs(), addressbookparsedresult.getBirthday(), addressbookparsedresult.getGeo());
        continue; /* Loop/switch isn't completed */
_L3:
        searchMap(s);
        continue; /* Loop/switch isn't completed */
_L4:
        dialPhone(addressbookparsedresult.getPhoneNumbers()[0]);
        continue; /* Loop/switch isn't completed */
_L5:
        sendEmail(addressbookparsedresult.getEmails(), null, null, null, null);
        if(true) goto _L1; else goto _L6
_L6:
    }

    static 
    {
        DateFormat adateformat[] = new DateFormat[4];
        adateformat[0] = new SimpleDateFormat("yyyyMMdd", Locale.ENGLISH);
        adateformat[1] = new SimpleDateFormat("yyyyMMdd'T'HHmmss", Locale.ENGLISH);
        adateformat[2] = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);
        adateformat[3] = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.ENGLISH);
        DATE_FORMATS = adateformat;
        DateFormat adateformat1[] = DATE_FORMATS;
        int i = adateformat1.length;
        for(int j = 0; j < i; j++)
            adateformat1[j].setLenient(false);

        int ai[] = new int[4];
        ai[0] = com.google.zxing.client.android.R.string.button_add_contact;
        ai[1] = com.google.zxing.client.android.R.string.button_show_map;
        ai[2] = com.google.zxing.client.android.R.string.button_dial;
        ai[3] = com.google.zxing.client.android.R.string.button_email;
        BUTTON_TEXTS = ai;
    }
}
