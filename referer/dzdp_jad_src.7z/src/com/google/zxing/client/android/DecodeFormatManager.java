// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.client.android;

import android.content.Intent;
import android.net.Uri;
import com.google.zxing.BarcodeFormat;
import java.util.*;
import java.util.regex.Pattern;

final class DecodeFormatManager
{

    static final Set AZTEC_FORMATS;
    private static final Pattern COMMA_PATTERN = Pattern.compile(",");
    static final Set DATA_MATRIX_FORMATS;
    private static final Map FORMATS_FOR_MODE;
    static final Set INDUSTRIAL_FORMATS;
    private static final Set ONE_D_FORMATS;
    static final Set PDF417_FORMATS;
    static final Set PRODUCT_FORMATS;
    static final Set QR_CODE_FORMATS;

    private DecodeFormatManager()
    {
    }

    static Set parseDecodeFormats(Intent intent)
    {
        List list = null;
        String s = intent.getStringExtra("SCAN_FORMATS");
        if(s != null)
            list = Arrays.asList(COMMA_PATTERN.split(s));
        return parseDecodeFormats(((Iterable) (list)), intent.getStringExtra("SCAN_MODE"));
    }

    static Set parseDecodeFormats(Uri uri)
    {
        List list = uri.getQueryParameters("SCAN_FORMATS");
        if(list != null && list.size() == 1 && list.get(0) != null)
            list = Arrays.asList(COMMA_PATTERN.split((CharSequence)list.get(0)));
        return parseDecodeFormats(((Iterable) (list)), uri.getQueryParameter("SCAN_MODE"));
    }

    private static Set parseDecodeFormats(Iterable iterable, String s)
    {
label0:
        {
            Object obj;
            if(iterable != null)
            {
                obj = EnumSet.noneOf(com/google/zxing/BarcodeFormat);
                try
                {
                    for(Iterator iterator = iterable.iterator(); iterator.hasNext(); ((Set) (obj)).add(BarcodeFormat.valueOf((String)iterator.next())));
                    break label0;
                }
                catch(IllegalArgumentException illegalargumentexception) { }
            }
            if(s != null)
                obj = (Set)FORMATS_FOR_MODE.get(s);
            else
                obj = null;
        }
        return ((Set) (obj));
    }

    static 
    {
        QR_CODE_FORMATS = EnumSet.of(BarcodeFormat.QR_CODE);
        DATA_MATRIX_FORMATS = EnumSet.of(BarcodeFormat.DATA_MATRIX);
        AZTEC_FORMATS = EnumSet.of(BarcodeFormat.AZTEC);
        PDF417_FORMATS = EnumSet.of(BarcodeFormat.PDF_417);
        BarcodeFormat barcodeformat = BarcodeFormat.UPC_A;
        BarcodeFormat abarcodeformat[] = new BarcodeFormat[5];
        abarcodeformat[0] = BarcodeFormat.UPC_E;
        abarcodeformat[1] = BarcodeFormat.EAN_13;
        abarcodeformat[2] = BarcodeFormat.EAN_8;
        abarcodeformat[3] = BarcodeFormat.RSS_14;
        abarcodeformat[4] = BarcodeFormat.RSS_EXPANDED;
        PRODUCT_FORMATS = EnumSet.of(barcodeformat, abarcodeformat);
        INDUSTRIAL_FORMATS = EnumSet.of(BarcodeFormat.CODE_39, BarcodeFormat.CODE_93, BarcodeFormat.CODE_128, BarcodeFormat.ITF, BarcodeFormat.CODABAR);
        ONE_D_FORMATS = EnumSet.copyOf(PRODUCT_FORMATS);
        ONE_D_FORMATS.addAll(INDUSTRIAL_FORMATS);
        FORMATS_FOR_MODE = new HashMap();
        FORMATS_FOR_MODE.put("ONE_D_MODE", ONE_D_FORMATS);
        FORMATS_FOR_MODE.put("PRODUCT_MODE", PRODUCT_FORMATS);
        FORMATS_FOR_MODE.put("QR_CODE_MODE", QR_CODE_FORMATS);
        FORMATS_FOR_MODE.put("DATA_MATRIX_MODE", DATA_MATRIX_FORMATS);
        FORMATS_FOR_MODE.put("AZTEC_MODE", AZTEC_FORMATS);
        FORMATS_FOR_MODE.put("PDF417_MODE", PDF417_FORMATS);
    }
}
