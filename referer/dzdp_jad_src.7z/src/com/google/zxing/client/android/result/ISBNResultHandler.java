// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.client.android.result;

import android.app.Activity;
import com.google.zxing.Result;
import com.google.zxing.client.result.ISBNParsedResult;
import com.google.zxing.client.result.ParsedResult;

// Referenced classes of package com.google.zxing.client.android.result:
//            ResultHandler

public final class ISBNResultHandler extends ResultHandler
{

    private static final int buttons[];

    public ISBNResultHandler(Activity activity, ParsedResult parsedresult, Result result)
    {
        super(activity, parsedresult, result);
    }

    public int getButtonCount()
    {
        int i;
        if(hasCustomProductSearch())
            i = buttons.length;
        else
            i = -1 + buttons.length;
        return i;
    }

    public int getButtonText(int i)
    {
        return buttons[i];
    }

    public int getDisplayTitle()
    {
        return com.google.zxing.client.android.R.string.result_isbn;
    }

    public void handleButtonPress(int i)
    {
        ISBNParsedResult isbnparsedresult = (ISBNParsedResult)getResult();
        i;
        JVM INSTR tableswitch 0 2: default 36
    //                   0 37
    //                   1 48
    //                   2 59;
           goto _L1 _L2 _L3 _L4
_L1:
        return;
_L2:
        openProductSearch(isbnparsedresult.getISBN());
        continue; /* Loop/switch isn't completed */
_L3:
        openBookSearch(isbnparsedresult.getISBN());
        continue; /* Loop/switch isn't completed */
_L4:
        openURL(fillInCustomSearchURL(isbnparsedresult.getISBN()));
        if(true) goto _L1; else goto _L5
_L5:
    }

    static 
    {
        int ai[] = new int[3];
        ai[0] = com.google.zxing.client.android.R.string.button_product_search;
        ai[1] = com.google.zxing.client.android.R.string.button_book_search;
        ai[2] = com.google.zxing.client.android.R.string.button_custom_product_search;
        buttons = ai;
    }
}
