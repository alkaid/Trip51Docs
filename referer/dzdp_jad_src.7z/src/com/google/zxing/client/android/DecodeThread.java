// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.client.android;

import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import android.preference.PreferenceManager;
import android.util.Log;
import com.google.zxing.*;
import java.util.*;
import java.util.concurrent.CountDownLatch;

// Referenced classes of package com.google.zxing.client.android:
//            DecodeFormatManager, DecodeHandler, CaptureActivity

final class DecodeThread extends Thread
{

    public static final String BARCODE_BITMAP = "barcode_bitmap";
    public static final String BARCODE_SCALED_FACTOR = "barcode_scaled_factor";
    private final CaptureActivity activity;
    private Handler handler;
    private final CountDownLatch handlerInitLatch = new CountDownLatch(1);
    private final Map hints = new EnumMap(com/google/zxing/DecodeHintType);

    DecodeThread(CaptureActivity captureactivity, Collection collection, Map map, String s, ResultPointCallback resultpointcallback)
    {
        activity = captureactivity;
        if(map != null)
            hints.putAll(map);
        if(collection == null || collection.isEmpty())
        {
            SharedPreferences sharedpreferences = PreferenceManager.getDefaultSharedPreferences(captureactivity);
            collection = EnumSet.noneOf(com/google/zxing/BarcodeFormat);
            if(sharedpreferences.getBoolean("preferences_decode_1D_product", true))
                collection.addAll(DecodeFormatManager.PRODUCT_FORMATS);
            if(sharedpreferences.getBoolean("preferences_decode_1D_industrial", true))
                collection.addAll(DecodeFormatManager.INDUSTRIAL_FORMATS);
            if(sharedpreferences.getBoolean("preferences_decode_QR", true))
                collection.addAll(DecodeFormatManager.QR_CODE_FORMATS);
            if(sharedpreferences.getBoolean("preferences_decode_Data_Matrix", true))
                collection.addAll(DecodeFormatManager.DATA_MATRIX_FORMATS);
            if(sharedpreferences.getBoolean("preferences_decode_Aztec", false))
                collection.addAll(DecodeFormatManager.AZTEC_FORMATS);
            if(sharedpreferences.getBoolean("preferences_decode_PDF417", false))
                collection.addAll(DecodeFormatManager.PDF417_FORMATS);
        }
        hints.put(DecodeHintType.POSSIBLE_FORMATS, collection);
        if(s != null)
            hints.put(DecodeHintType.CHARACTER_SET, s);
        hints.put(DecodeHintType.NEED_RESULT_POINT_CALLBACK, resultpointcallback);
        Log.i("DecodeThread", (new StringBuilder()).append("Hints: ").append(hints).toString());
    }

    Handler getHandler()
    {
        try
        {
            handlerInitLatch.await();
        }
        catch(InterruptedException interruptedexception) { }
        return handler;
    }

    public void run()
    {
        Looper.prepare();
        handler = new DecodeHandler(activity, hints);
        handlerInitLatch.countDown();
        Looper.loop();
    }
}
