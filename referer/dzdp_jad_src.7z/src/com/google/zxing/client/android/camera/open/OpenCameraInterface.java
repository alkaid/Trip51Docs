// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.client.android.camera.open;

import android.hardware.Camera;
import android.util.Log;

public final class OpenCameraInterface
{

    public static final int NO_REQUESTED_CAMERA = -1;
    private static final String TAG = com/google/zxing/client/android/camera/open/OpenCameraInterface.getName();

    private OpenCameraInterface()
    {
    }

    public static Camera open(int i)
    {
        int j = Camera.getNumberOfCameras();
        if(j != 0) goto _L2; else goto _L1
_L1:
        Camera camera;
        Log.w(TAG, "No cameras!");
        camera = null;
_L5:
        return camera;
_L2:
        boolean flag;
        int k;
        if(i >= 0)
            flag = true;
        else
            flag = false;
        if(flag) goto _L4; else goto _L3
_L3:
        k = 0;
_L6:
        if(k < j)
        {
            android.hardware.Camera.CameraInfo camerainfo = new android.hardware.Camera.CameraInfo();
            Camera.getCameraInfo(k, camerainfo);
            if(camerainfo.facing != 0)
                break MISSING_BLOCK_LABEL_114;
        }
        i = k;
_L4:
        if(i < j)
        {
            Log.i(TAG, (new StringBuilder()).append("Opening camera #").append(i).toString());
            camera = Camera.open(i);
        } else
        if(flag)
        {
            Log.w(TAG, (new StringBuilder()).append("Requested camera does not exist: ").append(i).toString());
            camera = null;
        } else
        {
            Log.i(TAG, "No camera facing back; returning camera #0");
            camera = Camera.open(0);
        }
          goto _L5
        k++;
          goto _L6
    }

}
