// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.client.android;


public final class R
{
    public static final class xml
    {

        public static final int preferences = 0x7f050001;

        public xml()
        {
        }
    }

    public static final class string
    {

        public static final int app_name = 0x7f090000;
        public static final int app_picker_name = 0x7f090008;
        public static final int bookmark_picker_name = 0x7f090017;
        public static final int button_add_calendar = 0x7f090018;
        public static final int button_add_contact = 0x7f090019;
        public static final int button_back = 0x7f09001a;
        public static final int button_book_search = 0x7f09001b;
        public static final int button_cancel = 0x7f09001c;
        public static final int button_custom_product_search = 0x7f09001d;
        public static final int button_dial = 0x7f09001e;
        public static final int button_done = 0x7f09001f;
        public static final int button_email = 0x7f090020;
        public static final int button_get_directions = 0x7f090021;
        public static final int button_google_shopper = 0x7f090022;
        public static final int button_mms = 0x7f090023;
        public static final int button_ok = 0x7f090024;
        public static final int button_open_browser = 0x7f090025;
        public static final int button_product_search = 0x7f090026;
        public static final int button_search_book_contents = 0x7f090027;
        public static final int button_share_app = 0x7f090028;
        public static final int button_share_bookmark = 0x7f090029;
        public static final int button_share_by_email = 0x7f09002a;
        public static final int button_share_by_sms = 0x7f09002b;
        public static final int button_share_clipboard = 0x7f09002c;
        public static final int button_share_contact = 0x7f09002d;
        public static final int button_show_map = 0x7f09002e;
        public static final int button_sms = 0x7f09002f;
        public static final int button_web_search = 0x7f090030;
        public static final int button_wifi = 0x7f090031;
        public static final int contents_contact = 0x7f090039;
        public static final int contents_email = 0x7f09003a;
        public static final int contents_location = 0x7f09003b;
        public static final int contents_phone = 0x7f09003c;
        public static final int contents_sms = 0x7f09003d;
        public static final int contents_text = 0x7f09003e;
        public static final int history_clear_one_history_text = 0x7f090053;
        public static final int history_clear_text = 0x7f090054;
        public static final int history_email_title = 0x7f090055;
        public static final int history_empty = 0x7f090056;
        public static final int history_empty_detail = 0x7f090057;
        public static final int history_send = 0x7f090058;
        public static final int history_title = 0x7f090059;
        public static final int menu_encode_mecard = 0x7f09007b;
        public static final int menu_encode_vcard = 0x7f09007c;
        public static final int menu_help = 0x7f09007d;
        public static final int menu_history = 0x7f09007e;
        public static final int menu_settings = 0x7f090081;
        public static final int menu_share = 0x7f090082;
        public static final int msg_bulk_mode_scanned = 0x7f090085;
        public static final int msg_camera_framework_bug = 0x7f090086;
        public static final int msg_default_format = 0x7f090087;
        public static final int msg_default_meta = 0x7f090088;
        public static final int msg_default_mms_subject = 0x7f090089;
        public static final int msg_default_status = 0x7f09008a;
        public static final int msg_default_time = 0x7f09008b;
        public static final int msg_default_type = 0x7f09008c;
        public static final int msg_encode_contents_failed = 0x7f09008d;
        public static final int msg_error = 0x7f09008e;
        public static final int msg_google_books = 0x7f09008f;
        public static final int msg_google_product = 0x7f090090;
        public static final int msg_google_shopper_missing = 0x7f090091;
        public static final int msg_install_google_shopper = 0x7f090092;
        public static final int msg_intent_failed = 0x7f090093;
        public static final int msg_invalid_value = 0x7f090094;
        public static final int msg_redirect = 0x7f090095;
        public static final int msg_sbc_book_not_searchable = 0x7f090096;
        public static final int msg_sbc_failed = 0x7f090097;
        public static final int msg_sbc_no_page_returned = 0x7f090098;
        public static final int msg_sbc_page = 0x7f090099;
        public static final int msg_sbc_results = 0x7f09009a;
        public static final int msg_sbc_searching_book = 0x7f09009b;
        public static final int msg_sbc_snippet_unavailable = 0x7f09009c;
        public static final int msg_sbc_unknown_page = 0x7f09009d;
        public static final int msg_share_explanation = 0x7f09009e;
        public static final int msg_share_subject_line = 0x7f09009f;
        public static final int msg_share_text = 0x7f0900a0;
        public static final int msg_sure = 0x7f0900a1;
        public static final int msg_unmount_usb = 0x7f0900a2;
        public static final int preferences_actions_title = 0x7f0900b3;
        public static final int preferences_auto_focus_title = 0x7f0900b4;
        public static final int preferences_auto_open_web_title = 0x7f0900b5;
        public static final int preferences_bulk_mode_summary = 0x7f0900b6;
        public static final int preferences_bulk_mode_title = 0x7f0900b7;
        public static final int preferences_copy_to_clipboard_title = 0x7f0900b8;
        public static final int preferences_custom_product_search_summary = 0x7f0900b9;
        public static final int preferences_custom_product_search_title = 0x7f0900ba;
        public static final int preferences_decode_1D_industrial_title = 0x7f0900bb;
        public static final int preferences_decode_1D_product_title = 0x7f0900bc;
        public static final int preferences_decode_1D_title = 0x7f0900bd;
        public static final int preferences_decode_Aztec_title = 0x7f0900be;
        public static final int preferences_decode_Data_Matrix_title = 0x7f0900bf;
        public static final int preferences_decode_PDF417_title = 0x7f0900c0;
        public static final int preferences_decode_QR_title = 0x7f0900c1;
        public static final int preferences_device_bug_workarounds_title = 0x7f0900c2;
        public static final int preferences_disable_barcode_scene_mode_title = 0x7f0900c3;
        public static final int preferences_disable_continuous_focus_summary = 0x7f0900c4;
        public static final int preferences_disable_continuous_focus_title = 0x7f0900c5;
        public static final int preferences_disable_exposure_title = 0x7f0900c6;
        public static final int preferences_disable_metering_title = 0x7f0900c7;
        public static final int preferences_front_light_auto = 0x7f0900c8;
        public static final int preferences_front_light_off = 0x7f0900c9;
        public static final int preferences_front_light_on = 0x7f0900ca;
        public static final int preferences_front_light_summary = 0x7f0900cb;
        public static final int preferences_front_light_title = 0x7f0900cc;
        public static final int preferences_general_title = 0x7f0900cd;
        public static final int preferences_history_summary = 0x7f0900ce;
        public static final int preferences_history_title = 0x7f0900cf;
        public static final int preferences_invert_scan_summary = 0x7f0900d0;
        public static final int preferences_invert_scan_title = 0x7f0900d1;
        public static final int preferences_name = 0x7f0900d2;
        public static final int preferences_orientation_title = 0x7f0900d3;
        public static final int preferences_play_beep_title = 0x7f0900d4;
        public static final int preferences_remember_duplicates_summary = 0x7f0900d5;
        public static final int preferences_remember_duplicates_title = 0x7f0900d6;
        public static final int preferences_result_title = 0x7f0900d7;
        public static final int preferences_scanning_title = 0x7f0900d8;
        public static final int preferences_search_country = 0x7f0900d9;
        public static final int preferences_supplemental_summary = 0x7f0900da;
        public static final int preferences_supplemental_title = 0x7f0900db;
        public static final int preferences_try_bsplus = 0x7f0900dc;
        public static final int preferences_try_bsplus_summary = 0x7f0900dd;
        public static final int preferences_vibrate_title = 0x7f0900de;
        public static final int result_address_book = 0x7f0900ef;
        public static final int result_calendar = 0x7f0900f0;
        public static final int result_email_address = 0x7f0900f1;
        public static final int result_geo = 0x7f0900f2;
        public static final int result_isbn = 0x7f0900f3;
        public static final int result_product = 0x7f0900f4;
        public static final int result_sms = 0x7f0900f5;
        public static final int result_tel = 0x7f0900f6;
        public static final int result_text = 0x7f0900f7;
        public static final int result_uri = 0x7f0900f8;
        public static final int result_wifi = 0x7f0900f9;
        public static final int sbc_name = 0x7f0900fd;
        public static final int wifi_changing_network = 0x7f0901b1;
        public static final int wifi_ssid_label = 0x7f0901b2;
        public static final int wifi_type_label = 0x7f0901b3;

        public string()
        {
        }
    }

    class raw
    {

        public static final int beep = 0x7f060001;

        public raw()
        {
        }
    }

    public static final class layout
    {

        public static final int capture = 0x7f03007d;

        public layout()
        {
        }
    }

    public static final class id
    {

        public static final int barcode_image_view = 0x7f0c02e3;
        public static final int contents_supplement_text_view = 0x7f0c02ea;
        public static final int contents_text_view = 0x7f0c02e9;
        public static final int decode = 0x7f0c0018;
        public static final int decode_failed = 0x7f0c0019;
        public static final int decode_succeeded = 0x7f0c001a;
        public static final int format_text_view = 0x7f0c02e4;
        public static final int launch_product_query = 0x7f0c0047;
        public static final int meta_text_view = 0x7f0c02e8;
        public static final int meta_text_view_label = 0x7f0c02e7;
        public static final int preview_view = 0x7f0c02e0;
        public static final int quit = 0x7f0c006a;
        public static final int restart_preview = 0x7f0c0070;
        public static final int result_view = 0x7f0c02e2;
        public static final int return_scan_result = 0x7f0c0071;
        public static final int status_view = 0x7f0c02eb;
        public static final int time_text_view = 0x7f0c02e6;
        public static final int type_text_view = 0x7f0c02e5;
        public static final int viewfinder_view = 0x7f0c02e1;

        public id()
        {
        }
    }

    class drawable
    {

        public static final int arrow_bottom_left = 0x7f020018;
        public static final int arrow_bottom_right = 0x7f020019;
        public static final int arrow_top_left = 0x7f020022;
        public static final int arrow_top_right = 0x7f020023;
        public static final int scan_line = 0x7f02065d;

        public drawable()
        {
        }
    }

    class dimen
    {

        public static final int half_padding = 0x7f0700ab;
        public static final int standard_padding = 0x7f0700ce;
        public static final int text_size_18 = 0x7f07001b;

        public dimen()
        {
        }
    }

    public static final class color
    {

        public static final int contents_text = 0x7f0b002b;
        public static final int encode_view = 0x7f0b003d;
        public static final int possible_result_points = 0x7f0b00b8;
        public static final int result_minor_text = 0x7f0b00c8;
        public static final int result_points = 0x7f0b00c9;
        public static final int result_text = 0x7f0b00ca;
        public static final int result_view = 0x7f0b00cb;
        public static final int status_text = 0x7f0b00fe;
        public static final int transparent = 0x7f0b0122;
        public static final int viewfinder_laser = 0x7f0b0148;
        public static final int viewfinder_mask = 0x7f0b0149;

        public color()
        {
        }
    }

    class array
    {

        public static final int country_codes = 0x7f0a0001;
        public static final int preferences_front_light_options = 0x7f0a0014;
        public static final int preferences_front_light_values = 0x7f0a0015;

        public array()
        {
        }
    }


    public R()
    {
    }
}
