// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.client.android.encode;

import android.telephony.PhoneNumberUtils;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

// Referenced classes of package com.google.zxing.client.android.encode:
//            ContactEncoder, Formatter

final class MECARDContactEncoder extends ContactEncoder
{
    private static class MECARDNameDisplayFormatter
        implements Formatter
    {

        private static final Pattern COMMA = Pattern.compile(",");

        public CharSequence format(CharSequence charsequence, int i)
        {
            return COMMA.matcher(charsequence).replaceAll("");
        }


        private MECARDNameDisplayFormatter()
        {
        }

    }

    private static class MECARDTelDisplayFormatter
        implements Formatter
    {

        private static final Pattern NOT_DIGITS = Pattern.compile("[^0-9]+");

        public CharSequence format(CharSequence charsequence, int i)
        {
            return NOT_DIGITS.matcher(PhoneNumberUtils.formatNumber(charsequence.toString())).replaceAll("");
        }


        private MECARDTelDisplayFormatter()
        {
        }

    }

    private static class MECARDFieldFormatter
        implements Formatter
    {

        private static final Pattern NEWLINE = Pattern.compile("\\n");
        private static final Pattern RESERVED_MECARD_CHARS = Pattern.compile("([\\\\:;])");

        public CharSequence format(CharSequence charsequence, int i)
        {
            return (new StringBuilder()).append(':').append(NEWLINE.matcher(RESERVED_MECARD_CHARS.matcher(charsequence).replaceAll("\\\\$1")).replaceAll("")).toString();
        }


        private MECARDFieldFormatter()
        {
        }

    }


    private static final char TERMINATOR = 59;

    MECARDContactEncoder()
    {
    }

    public String[] encode(List list, String s, List list1, List list2, List list3, List list4, List list5, 
            String s1)
    {
        StringBuilder stringbuilder = new StringBuilder(100);
        stringbuilder.append("MECARD:");
        StringBuilder stringbuilder1 = new StringBuilder(100);
        MECARDFieldFormatter mecardfieldformatter = new MECARDFieldFormatter();
        appendUpToUnique(stringbuilder, stringbuilder1, "N", list, 1, new MECARDNameDisplayFormatter(), mecardfieldformatter, ';');
        append(stringbuilder, stringbuilder1, "ORG", s, mecardfieldformatter, ';');
        appendUpToUnique(stringbuilder, stringbuilder1, "ADR", list1, 1, null, mecardfieldformatter, ';');
        appendUpToUnique(stringbuilder, stringbuilder1, "TEL", list2, 0x7fffffff, new MECARDTelDisplayFormatter(), mecardfieldformatter, ';');
        appendUpToUnique(stringbuilder, stringbuilder1, "EMAIL", list4, 0x7fffffff, null, mecardfieldformatter, ';');
        appendUpToUnique(stringbuilder, stringbuilder1, "URL", list5, 0x7fffffff, null, mecardfieldformatter, ';');
        append(stringbuilder, stringbuilder1, "NOTE", s1, mecardfieldformatter, ';');
        stringbuilder.append(';');
        String as[] = new String[2];
        as[0] = stringbuilder.toString();
        as[1] = stringbuilder1.toString();
        return as;
    }
}
