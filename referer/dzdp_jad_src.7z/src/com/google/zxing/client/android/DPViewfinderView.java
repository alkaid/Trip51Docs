// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.client.android;

import android.content.Context;
import android.graphics.*;
import android.util.AttributeSet;
import com.google.zxing.client.android.camera.CameraManager;

// Referenced classes of package com.google.zxing.client.android:
//            ViewfinderView

public class DPViewfinderView extends ViewfinderView
{

    private Bitmap bottomLeftCornerBitmap;
    private Bitmap bottomRightCornerBitmap;
    private Bitmap laserScanerBitmap;
    private Rect rect;
    private Bitmap topLeftCornerBitmap;
    private Bitmap topRightCornerBitmap;

    public DPViewfinderView(Context context, AttributeSet attributeset)
    {
        super(context, attributeset);
        topLeftCornerBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.arrow_top_left);
        bottomLeftCornerBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.arrow_bottom_left);
        topRightCornerBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.arrow_top_right);
        bottomRightCornerBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.arrow_bottom_right);
        laserScanerBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.scan_line);
        rect = new Rect();
    }

    public void onDraw(Canvas canvas)
    {
        if(cameraManager != null) goto _L2; else goto _L1
_L1:
        return;
_L2:
        Rect rect1 = cameraManager.getFramingRect();
        if(rect1 != null)
        {
            int i = canvas.getWidth();
            int j = canvas.getHeight();
            Paint paint = this.paint;
            int k;
            if(resultBitmap != null)
                k = resultColor;
            else
                k = maskColor;
            paint.setColor(k);
            canvas.drawRect(0.0F, 0.0F, i, -5 + rect1.top, this.paint);
            canvas.drawRect(0.0F, -5 + rect1.top, -5 + rect1.left, 6 + rect1.bottom, this.paint);
            canvas.drawRect(6 + rect1.right, -5 + rect1.top, i, 6 + rect1.bottom, this.paint);
            canvas.drawRect(0.0F, 6 + rect1.bottom, i, j, this.paint);
            this.paint.setColor(-1);
            canvas.drawRect(-10 + rect1.left, -10 + rect1.top, -5 + rect1.left, 10 + rect1.bottom, this.paint);
            canvas.drawRect(-4 + rect1.left, -10 + rect1.top, 3 + rect1.right, -5 + rect1.top, this.paint);
            canvas.drawRect(4 + rect1.right, -10 + rect1.top, 9 + rect1.right, 10 + rect1.bottom, this.paint);
            canvas.drawRect(-4 + rect1.left, 5 + rect1.bottom, 3 + rect1.right, 10 + rect1.bottom, this.paint);
            canvas.drawBitmap(topLeftCornerBitmap, -10 + rect1.left, -10 + rect1.top, null);
            canvas.drawBitmap(topRightCornerBitmap, (10 + rect1.right) - topRightCornerBitmap.getWidth(), -10 + rect1.top, null);
            canvas.drawBitmap(bottomLeftCornerBitmap, -10 + rect1.left, 10 + (rect1.bottom - bottomLeftCornerBitmap.getHeight()), null);
            canvas.drawBitmap(bottomRightCornerBitmap, (10 + rect1.right) - bottomLeftCornerBitmap.getWidth(), (10 + rect1.bottom) - bottomLeftCornerBitmap.getHeight(), null);
            rect.left = rect1.left;
            rect.right = rect1.left + rect1.width();
            if(rect.top == 0)
                rect.top = rect1.top - laserScanerBitmap.getHeight() / 2;
            if(rect.top + laserScanerBitmap.getHeight() / 2 > rect1.bottom)
                rect.top = rect1.top - laserScanerBitmap.getHeight() / 2;
            else
                rect.top = rect.top + rect1.width() / 70;
            rect.bottom = rect.top + laserScanerBitmap.getHeight();
            canvas.drawBitmap(laserScanerBitmap, null, rect, this.paint);
            if(resultBitmap != null)
            {
                this.paint.setAlpha(160);
                canvas.drawBitmap(resultBitmap, null, rect1, this.paint);
            } else
            {
                postInvalidateDelayed(20L, -6 + rect1.left, 0, 6 + rect1.right, j);
            }
        }
        if(true) goto _L1; else goto _L3
_L3:
    }
}
