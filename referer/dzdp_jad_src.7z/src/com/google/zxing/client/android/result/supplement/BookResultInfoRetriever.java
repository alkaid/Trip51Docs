// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.client.android.result.supplement;

import android.content.Context;
import android.widget.TextView;
import com.google.zxing.client.android.HttpHelper;
import com.google.zxing.client.android.LocaleManager;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import org.json.*;

// Referenced classes of package com.google.zxing.client.android.result.supplement:
//            SupplementalInfoRetriever

final class BookResultInfoRetriever extends SupplementalInfoRetriever
{

    private final Context context;
    private final String isbn;
    private final String source;

    BookResultInfoRetriever(TextView textview, String s, Context context1)
    {
        super(textview);
        isbn = s;
        source = context1.getString(com.google.zxing.client.android.R.string.msg_google_books);
        context = context1;
    }

    void retrieveSupplementalInfo()
        throws IOException
    {
        CharSequence charsequence = HttpHelper.downloadViaHttp((new StringBuilder()).append("https://www.googleapis.com/books/v1/volumes?q=isbn:").append(isbn).toString(), com.google.zxing.client.android.HttpHelper.ContentType.JSON);
        if(charsequence.length() != 0) goto _L2; else goto _L1
_L1:
        return;
_L2:
        ArrayList arraylist = null;
        JSONArray jsonarray = ((JSONObject)(new JSONTokener(charsequence.toString())).nextValue()).optJSONArray("items");
        if(jsonarray == null || jsonarray.isNull(0)) goto _L1; else goto _L3
_L3:
        JSONObject jsonobject = ((JSONObject)jsonarray.get(0)).getJSONObject("volumeInfo");
        if(jsonobject == null) goto _L1; else goto _L4
_L4:
        String s;
        String s1;
        JSONArray jsonarray1;
        s = jsonobject.optString("title");
        s1 = jsonobject.optString("pageCount");
        jsonarray1 = jsonobject.optJSONArray("authors");
        if(jsonarray1 == null || jsonarray1.isNull(0)) goto _L6; else goto _L5
_L5:
        ArrayList arraylist2 = new ArrayList(jsonarray1.length());
        int i = 0;
_L8:
        if(i >= jsonarray1.length())
            break; /* Loop/switch isn't completed */
        arraylist2.add(jsonarray1.getString(i));
        i++;
        if(true) goto _L8; else goto _L7
        JSONException jsonexception;
        jsonexception;
_L9:
        IOException ioexception = new IOException(jsonexception);
        throw ioexception;
_L7:
        arraylist = arraylist2;
_L6:
        ArrayList arraylist1 = new ArrayList();
        maybeAddText(s, arraylist1);
        maybeAddTextSeries(arraylist, arraylist1);
        String s2;
        String s3;
        if(s1 == null || s1.isEmpty())
            s2 = null;
        else
            s2 = (new StringBuilder()).append(s1).append("pp.").toString();
        maybeAddText(s2, arraylist1);
        s3 = (new StringBuilder()).append("http://www.google.").append(LocaleManager.getBookSearchCountryTLD(context)).append("/search?tbm=bks&source=zxing&q=").toString();
        append(isbn, source, (String[])arraylist1.toArray(new String[arraylist1.size()]), (new StringBuilder()).append(s3).append(isbn).toString());
          goto _L1
        jsonexception;
          goto _L9
    }
}
