// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.client.android.encode;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

// Referenced classes of package com.google.zxing.client.android.encode:
//            Formatter

final class VCardFieldFormatter
    implements Formatter
{

    private static final Pattern NEWLINE = Pattern.compile("\\n");
    private static final Pattern RESERVED_VCARD_CHARS = Pattern.compile("([\\\\,;])");
    private final List metadataForIndex;

    VCardFieldFormatter()
    {
        this(null);
    }

    VCardFieldFormatter(List list)
    {
        metadataForIndex = list;
    }

    private static CharSequence formatMetadata(CharSequence charsequence, Map map)
    {
        StringBuilder stringbuilder = new StringBuilder();
        if(map != null)
        {
            Iterator iterator = map.entrySet().iterator();
            do
            {
                if(!iterator.hasNext())
                    break;
                java.util.Map.Entry entry = (java.util.Map.Entry)iterator.next();
                Set set = (Set)entry.getValue();
                if(set != null && !set.isEmpty())
                {
                    stringbuilder.append(';').append((String)entry.getKey()).append('=');
                    if(set.size() > 1)
                        stringbuilder.append('"');
                    Iterator iterator1 = set.iterator();
                    stringbuilder.append((String)iterator1.next());
                    for(; iterator1.hasNext(); stringbuilder.append(',').append((String)iterator1.next()));
                    if(set.size() > 1)
                        stringbuilder.append('"');
                }
            } while(true);
        }
        stringbuilder.append(':').append(charsequence);
        return stringbuilder;
    }

    public CharSequence format(CharSequence charsequence, int i)
    {
        String s = RESERVED_VCARD_CHARS.matcher(charsequence).replaceAll("\\\\$1");
        String s1 = NEWLINE.matcher(s).replaceAll("");
        Map map;
        if(metadataForIndex == null || metadataForIndex.size() <= i)
            map = null;
        else
            map = (Map)metadataForIndex.get(i);
        return formatMetadata(s1, map);
    }

}
