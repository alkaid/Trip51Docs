// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.client.android.result;

import android.app.Activity;
import android.content.*;
import android.net.Uri;
import android.preference.PreferenceManager;
import android.util.Log;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.Result;
import com.google.zxing.client.android.Contents;
import com.google.zxing.client.android.LocaleManager;
import com.google.zxing.client.result.*;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Locale;

public abstract class ResultHandler
{

    private static final String ADDRESS_TYPE_STRINGS[];
    private static final int ADDRESS_TYPE_VALUES[];
    private static final String EMAIL_TYPE_STRINGS[];
    private static final int EMAIL_TYPE_VALUES[];
    public static final int MAX_BUTTON_COUNT = 4;
    private static final int NO_TYPE = -1;
    private static final String PHONE_TYPE_STRINGS[];
    private static final int PHONE_TYPE_VALUES[];
    private static final String TAG = com/google/zxing/client/android/result/ResultHandler.getSimpleName();
    private final Activity activity;
    private final String customProductSearch;
    private final Result rawResult;
    private final ParsedResult result;

    ResultHandler(Activity activity1, ParsedResult parsedresult)
    {
        this(activity1, parsedresult, null);
    }

    ResultHandler(Activity activity1, ParsedResult parsedresult, Result result1)
    {
        result = parsedresult;
        activity = activity1;
        rawResult = result1;
        customProductSearch = parseCustomSearchURL();
    }

    private static int doToContractType(String s, String as[], int ai[])
    {
        int i = -1;
        if(s != null) goto _L2; else goto _L1
_L1:
        return i;
_L2:
        int j = 0;
        do
        {
            if(j < as.length)
            {
label0:
                {
                    String s1 = as[j];
                    if(!s.startsWith(s1) && !s.startsWith(s1.toUpperCase(Locale.ENGLISH)))
                        break label0;
                    i = ai[j];
                }
            }
            if(true)
                continue;
            j++;
        } while(true);
        if(true) goto _L1; else goto _L3
_L3:
    }

    private String parseCustomSearchURL()
    {
        String s = PreferenceManager.getDefaultSharedPreferences(activity).getString("preferences_custom_product_search", null);
        if(s != null && s.trim().isEmpty())
            s = null;
        return s;
    }

    private static void putExtra(Intent intent, String s, String s1)
    {
        if(s1 != null && !s1.isEmpty())
            intent.putExtra(s, s1);
    }

    private static int toAddressContractType(String s)
    {
        return doToContractType(s, ADDRESS_TYPE_STRINGS, ADDRESS_TYPE_VALUES);
    }

    private static int toEmailContractType(String s)
    {
        return doToContractType(s, EMAIL_TYPE_STRINGS, EMAIL_TYPE_VALUES);
    }

    private static int toPhoneContractType(String s)
    {
        return doToContractType(s, PHONE_TYPE_STRINGS, PHONE_TYPE_VALUES);
    }

    final void addContact(String as[], String as1[], String s, String as2[], String as3[], String as4[], String as5[], 
            String s1, String s2, String s3, String s4, String s5, String s6, String as6[], 
            String s7, String as7[])
    {
        Intent intent;
        ArrayList arraylist;
        intent = new Intent("android.intent.action.INSERT_OR_EDIT", android.provider.ContactsContract.Contacts.CONTENT_URI);
        intent.setType("vnd.android.cursor.item/contact");
        String s8;
        int i;
        int j;
        if(as != null)
            s8 = as[0];
        else
            s8 = null;
        putExtra(intent, "name", s8);
        putExtra(intent, "phonetic_name", s);
        if(as2 != null)
            i = as2.length;
        else
            i = 0;
        j = Math.min(i, Contents.PHONE_KEYS.length);
        for(int k = 0; k < j; k++)
        {
            putExtra(intent, Contents.PHONE_KEYS[k], as2[k]);
            if(as3 == null || k >= as3.length)
                continue;
            int i3 = toPhoneContractType(as3[k]);
            if(i3 >= 0)
                intent.putExtra(Contents.PHONE_TYPE_KEYS[k], i3);
        }

        int l;
        int i1;
        if(as4 != null)
            l = as4.length;
        else
            l = 0;
        i1 = Math.min(l, Contents.EMAIL_KEYS.length);
        for(int j1 = 0; j1 < i1; j1++)
        {
            putExtra(intent, Contents.EMAIL_KEYS[j1], as4[j1]);
            if(as5 == null || j1 >= as5.length)
                continue;
            int l2 = toEmailContractType(as5[j1]);
            if(l2 >= 0)
                intent.putExtra(Contents.EMAIL_TYPE_KEYS[j1], l2);
        }

        arraylist = new ArrayList();
        if(as6 == null) goto _L2; else goto _L1
_L1:
        int j2;
        int k2;
        j2 = as6.length;
        k2 = 0;
_L8:
        if(k2 >= j2) goto _L2; else goto _L3
_L3:
        String s10 = as6[k2];
        if(s10 == null || s10.isEmpty()) goto _L5; else goto _L4
_L4:
        ContentValues contentvalues2 = new ContentValues(2);
        contentvalues2.put("mimetype", "vnd.android.cursor.item/website");
        contentvalues2.put("data1", s10);
        arraylist.add(contentvalues2);
_L2:
        if(s7 != null)
        {
            ContentValues contentvalues = new ContentValues(3);
            contentvalues.put("mimetype", "vnd.android.cursor.item/contact_event");
            contentvalues.put("data2", Integer.valueOf(3));
            contentvalues.put("data1", s7);
            arraylist.add(contentvalues);
        }
        if(as1 == null) goto _L7; else goto _L6
_L6:
        int l1;
        int i2;
        l1 = as1.length;
        i2 = 0;
_L9:
        if(i2 < l1)
        {
            String s9 = as1[i2];
            if(s9 == null || s9.isEmpty())
                break MISSING_BLOCK_LABEL_653;
            ContentValues contentvalues1 = new ContentValues(3);
            contentvalues1.put("mimetype", "vnd.android.cursor.item/nickname");
            contentvalues1.put("data2", Integer.valueOf(1));
            contentvalues1.put("data1", s9);
            arraylist.add(contentvalues1);
        }
_L7:
        if(!arraylist.isEmpty())
            intent.putParcelableArrayListExtra("data", arraylist);
        StringBuilder stringbuilder = new StringBuilder();
        if(s1 != null)
            stringbuilder.append('\n').append(s1);
        if(as7 != null)
            stringbuilder.append('\n').append(as7[0]).append(',').append(as7[1]);
        if(stringbuilder.length() > 0)
            putExtra(intent, "notes", stringbuilder.substring(1));
        putExtra(intent, "im_handle", s2);
        putExtra(intent, "postal", s3);
        if(s4 != null)
        {
            int k1 = toAddressContractType(s4);
            if(k1 >= 0)
                intent.putExtra("postal_type", k1);
        }
        putExtra(intent, "company", s5);
        putExtra(intent, "job_title", s6);
        launchIntent(intent);
        return;
_L5:
        k2++;
          goto _L8
        i2++;
          goto _L9
    }

    final void addEmailOnlyContact(String as[], String as1[])
    {
        addContact(null, null, null, null, null, as, as1, null, null, null, null, null, null, null, null, null);
    }

    final void addPhoneOnlyContact(String as[], String as1[])
    {
        addContact(null, null, null, as, as1, null, null, null, null, null, null, null, null, null, null, null);
    }

    public boolean areContentsSecure()
    {
        return false;
    }

    final void dialPhone(String s)
    {
        launchIntent(new Intent("android.intent.action.DIAL", Uri.parse((new StringBuilder()).append("tel:").append(s).toString())));
    }

    final void dialPhoneFromUri(String s)
    {
        launchIntent(new Intent("android.intent.action.DIAL", Uri.parse(s)));
    }

    final String fillInCustomSearchURL(String s)
    {
        if(customProductSearch != null) goto _L2; else goto _L1
_L1:
        String s2 = s;
_L4:
        return s2;
_L2:
        String s3 = URLEncoder.encode(s, "UTF-8");
        s = s3;
_L5:
        String s1 = customProductSearch;
        if(rawResult != null)
        {
            s1 = s1.replaceFirst("%f(?![0-9a-f])", rawResult.getBarcodeFormat().toString());
            if(s1.contains("%t"))
                s1 = s1.replace("%t", ResultParser.parseResult(rawResult).getType().toString());
        }
        s2 = s1.replace("%s", s);
        if(true) goto _L4; else goto _L3
_L3:
        UnsupportedEncodingException unsupportedencodingexception;
        unsupportedencodingexception;
          goto _L5
    }

    final Activity getActivity()
    {
        return activity;
    }

    public abstract int getButtonCount();

    public abstract int getButtonText(int i);

    public Integer getDefaultButtonID()
    {
        return null;
    }

    final void getDirections(double d, double d1)
    {
        launchIntent(new Intent("android.intent.action.VIEW", Uri.parse((new StringBuilder()).append("http://maps.google.").append(LocaleManager.getCountryTLD(activity)).append("/maps?f=d&daddr=").append(d).append(',').append(d1).toString())));
    }

    public CharSequence getDisplayContents()
    {
        return result.getDisplayResult().replace("\r", "");
    }

    public abstract int getDisplayTitle();

    public final ParsedResult getResult()
    {
        return result;
    }

    public final ParsedResultType getType()
    {
        return result.getType();
    }

    public abstract void handleButtonPress(int i);

    final boolean hasCustomProductSearch()
    {
        boolean flag;
        if(customProductSearch != null)
            flag = true;
        else
            flag = false;
        return flag;
    }

    final void launchIntent(Intent intent)
    {
        rawLaunchIntent(intent);
_L1:
        return;
        ActivityNotFoundException activitynotfoundexception;
        activitynotfoundexception;
        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(activity);
        builder.setTitle(com.google.zxing.client.android.R.string.app_name);
        builder.setMessage(com.google.zxing.client.android.R.string.msg_intent_failed);
        builder.setPositiveButton(com.google.zxing.client.android.R.string.button_ok, null);
        builder.show();
          goto _L1
    }

    final void openBookSearch(String s)
    {
        launchIntent(new Intent("android.intent.action.VIEW", Uri.parse((new StringBuilder()).append("http://books.google.").append(LocaleManager.getBookSearchCountryTLD(activity)).append("/books?vid=isbn").append(s).toString())));
    }

    final void openMap(String s)
    {
        launchIntent(new Intent("android.intent.action.VIEW", Uri.parse(s)));
    }

    final void openProductSearch(String s)
    {
        launchIntent(new Intent("android.intent.action.VIEW", Uri.parse((new StringBuilder()).append("http://www.google.").append(LocaleManager.getProductSearchCountryTLD(activity)).append("/m/products?q=").append(s).append("&source=zxing").toString())));
    }

    final void openURL(String s)
    {
        Intent intent;
        if(s.startsWith("HTTP://"))
            s = (new StringBuilder()).append("http").append(s.substring(4)).toString();
        else
        if(s.startsWith("HTTPS://"))
            s = (new StringBuilder()).append("https").append(s.substring(5)).toString();
        intent = new Intent("android.intent.action.VIEW", Uri.parse(s));
        launchIntent(intent);
_L1:
        return;
        ActivityNotFoundException activitynotfoundexception;
        activitynotfoundexception;
        Log.w(TAG, (new StringBuilder()).append("Nothing available to handle ").append(intent).toString());
          goto _L1
    }

    final void rawLaunchIntent(Intent intent)
    {
        if(intent != null)
        {
            intent.addFlags(0x80000);
            Log.d(TAG, (new StringBuilder()).append("Launching intent: ").append(intent).append(" with extras: ").append(intent.getExtras()).toString());
            activity.startActivity(intent);
        }
    }

    final void searchMap(String s)
    {
        launchIntent(new Intent("android.intent.action.VIEW", Uri.parse((new StringBuilder()).append("geo:0,0?q=").append(Uri.encode(s)).toString())));
    }

    final void sendEmail(String as[], String as1[], String as2[], String s, String s1)
    {
        Intent intent = new Intent("android.intent.action.SEND", Uri.parse("mailto:"));
        if(as != null && as.length != 0)
            intent.putExtra("android.intent.extra.EMAIL", as);
        if(as1 != null && as1.length != 0)
            intent.putExtra("android.intent.extra.CC", as1);
        if(as2 != null && as2.length != 0)
            intent.putExtra("android.intent.extra.BCC", as2);
        putExtra(intent, "android.intent.extra.SUBJECT", s);
        putExtra(intent, "android.intent.extra.TEXT", s1);
        intent.setType("text/plain");
        launchIntent(intent);
    }

    final void sendMMS(String s, String s1, String s2)
    {
        sendMMSFromUri((new StringBuilder()).append("mmsto:").append(s).toString(), s1, s2);
    }

    final void sendMMSFromUri(String s, String s1, String s2)
    {
        Intent intent = new Intent("android.intent.action.SENDTO", Uri.parse(s));
        if(s1 == null || s1.isEmpty())
            putExtra(intent, "subject", activity.getString(com.google.zxing.client.android.R.string.msg_default_mms_subject));
        else
            putExtra(intent, "subject", s1);
        putExtra(intent, "sms_body", s2);
        intent.putExtra("compose_mode", true);
        launchIntent(intent);
    }

    final void sendSMS(String s, String s1)
    {
        sendSMSFromUri((new StringBuilder()).append("smsto:").append(s).toString(), s1);
    }

    final void sendSMSFromUri(String s, String s1)
    {
        Intent intent = new Intent("android.intent.action.SENDTO", Uri.parse(s));
        putExtra(intent, "sms_body", s1);
        intent.putExtra("compose_mode", true);
        launchIntent(intent);
    }

    final void shareByEmail(String s)
    {
        sendEmail(null, null, null, null, s);
    }

    final void shareBySMS(String s)
    {
        sendSMSFromUri("smsto:", s);
    }

    final void webSearch(String s)
    {
        Intent intent = new Intent("android.intent.action.WEB_SEARCH");
        intent.putExtra("query", s);
        launchIntent(intent);
    }

    static 
    {
        String as[] = new String[3];
        as[0] = "home";
        as[1] = "work";
        as[2] = "mobile";
        EMAIL_TYPE_STRINGS = as;
        String as1[] = new String[6];
        as1[0] = "home";
        as1[1] = "work";
        as1[2] = "mobile";
        as1[3] = "fax";
        as1[4] = "pager";
        as1[5] = "main";
        PHONE_TYPE_STRINGS = as1;
        String as2[] = new String[2];
        as2[0] = "home";
        as2[1] = "work";
        ADDRESS_TYPE_STRINGS = as2;
        int ai[] = new int[3];
        ai[0] = 1;
        ai[1] = 2;
        ai[2] = 4;
        EMAIL_TYPE_VALUES = ai;
        int ai1[] = new int[6];
        ai1[0] = 1;
        ai1[1] = 3;
        ai1[2] = 2;
        ai1[3] = 4;
        ai1[4] = 6;
        ai1[5] = 12;
        PHONE_TYPE_VALUES = ai1;
        int ai2[] = new int[2];
        ai2[0] = 1;
        ai2[1] = 2;
        ADDRESS_TYPE_VALUES = ai2;
    }
}
