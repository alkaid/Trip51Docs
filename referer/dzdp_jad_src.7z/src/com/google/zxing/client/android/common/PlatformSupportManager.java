// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.client.android.common;

import android.util.Log;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.*;

public abstract class PlatformSupportManager
{

    private static final String TAG = com/google/zxing/client/android/common/PlatformSupportManager.getSimpleName();
    private final Object defaultImplementation;
    private final SortedMap implementations;
    private final Class managedInterface;

    protected PlatformSupportManager(Class class1, Object obj)
    {
        if(!class1.isInterface())
            throw new IllegalArgumentException();
        if(!class1.isInstance(obj))
        {
            throw new IllegalArgumentException();
        } else
        {
            managedInterface = class1;
            defaultImplementation = obj;
            implementations = new TreeMap(Collections.reverseOrder());
            return;
        }
    }

    protected final void addImplementationClass(int i, String s)
    {
        implementations.put(Integer.valueOf(i), s);
    }

    public final Object build()
    {
        Iterator iterator = implementations.keySet().iterator();
_L1:
        Integer integer;
        String s;
        do
        {
            if(!iterator.hasNext())
                break MISSING_BLOCK_LABEL_218;
            integer = (Integer)iterator.next();
        } while(android.os.Build.VERSION.SDK_INT < integer.intValue());
        s = (String)implementations.get(integer);
        Object obj1;
        Class class1 = Class.forName(s).asSubclass(managedInterface);
        Log.i(TAG, (new StringBuilder()).append("Using implementation ").append(class1).append(" of ").append(managedInterface).append(" for SDK ").append(integer).toString());
        obj1 = class1.getConstructor(new Class[0]).newInstance(new Object[0]);
        Object obj = obj1;
_L2:
        return obj;
        ClassNotFoundException classnotfoundexception;
        classnotfoundexception;
        Log.w(TAG, classnotfoundexception);
          goto _L1
        IllegalAccessException illegalaccessexception;
        illegalaccessexception;
        Log.w(TAG, illegalaccessexception);
          goto _L1
        InstantiationException instantiationexception;
        instantiationexception;
        Log.w(TAG, instantiationexception);
          goto _L1
        NoSuchMethodException nosuchmethodexception;
        nosuchmethodexception;
        Log.w(TAG, nosuchmethodexception);
          goto _L1
        InvocationTargetException invocationtargetexception;
        invocationtargetexception;
        Log.w(TAG, invocationtargetexception);
          goto _L1
        Log.i(TAG, (new StringBuilder()).append("Using default implementation ").append(defaultImplementation.getClass()).append(" of ").append(managedInterface).toString());
        obj = defaultImplementation;
          goto _L2
    }

}
