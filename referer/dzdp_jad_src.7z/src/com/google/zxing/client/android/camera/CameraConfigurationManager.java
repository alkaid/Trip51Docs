// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.client.android.camera;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Point;
import android.hardware.Camera;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.Display;
import android.view.WindowManager;

// Referenced classes of package com.google.zxing.client.android.camera:
//            CameraConfigurationUtils, FrontLightMode

final class CameraConfigurationManager
{

    private static final String TAG = "CameraConfiguration";
    private Point cameraResolution;
    private final Context context;
    private Point screenResolution;

    CameraConfigurationManager(Context context1)
    {
        context = context1;
    }

    private void doSetTorch(android.hardware.Camera.Parameters parameters, boolean flag, boolean flag1)
    {
        CameraConfigurationUtils.setTorch(parameters, flag);
        SharedPreferences sharedpreferences = PreferenceManager.getDefaultSharedPreferences(context);
        if(!flag1 && !sharedpreferences.getBoolean("preferences_disable_exposure", true))
            CameraConfigurationUtils.setBestExposure(parameters, flag);
    }

    private void initializeTorch(android.hardware.Camera.Parameters parameters, SharedPreferences sharedpreferences, boolean flag)
    {
        boolean flag1;
        if(FrontLightMode.readPref(sharedpreferences) == FrontLightMode.ON)
            flag1 = true;
        else
            flag1 = false;
        doSetTorch(parameters, flag1, flag);
    }

    Point getCameraResolution()
    {
        return cameraResolution;
    }

    Point getScreenResolution()
    {
        return screenResolution;
    }

    boolean getTorchState(Camera camera)
    {
        boolean flag = false;
        if(camera != null)
        {
            android.hardware.Camera.Parameters parameters = camera.getParameters();
            if(parameters != null)
            {
                String s = parameters.getFlashMode();
                if(s != null && ("on".equals(s) || "torch".equals(s)))
                    flag = true;
            }
        }
        return flag;
    }

    void initFromCameraParameters(Camera camera)
    {
        android.hardware.Camera.Parameters parameters = camera.getParameters();
        Display display = ((WindowManager)context.getSystemService("window")).getDefaultDisplay();
        Point point = new Point();
        if(android.os.Build.VERSION.SDK_INT >= 13)
            display.getSize(point);
        else
            point.set(display.getWidth(), display.getHeight());
        screenResolution = point;
        Log.i("CameraConfiguration", (new StringBuilder()).append("Screen resolution: ").append(screenResolution).toString());
        cameraResolution = CameraConfigurationUtils.findBestPreviewSizeValue(parameters, screenResolution);
        Log.i("CameraConfiguration", (new StringBuilder()).append("Camera resolution: ").append(cameraResolution).toString());
    }

    void setDesiredCameraParameters(Camera camera, boolean flag)
    {
        android.hardware.Camera.Parameters parameters = camera.getParameters();
        if(parameters != null) goto _L2; else goto _L1
_L1:
        Log.w("CameraConfiguration", "Device error: no camera parameters are available. Proceeding without configuration.");
_L4:
        return;
_L2:
        Log.i("CameraConfiguration", (new StringBuilder()).append("Initial camera parameters: ").append(parameters.flatten()).toString());
        if(flag)
            Log.w("CameraConfiguration", "In camera config safe mode -- most settings will not be honored");
        SharedPreferences sharedpreferences = PreferenceManager.getDefaultSharedPreferences(context);
        initializeTorch(parameters, sharedpreferences, flag);
        CameraConfigurationUtils.setFocus(parameters, sharedpreferences.getBoolean("preferences_auto_focus", true), sharedpreferences.getBoolean("preferences_disable_continuous_focus", true), flag);
        if(!flag)
        {
            if(sharedpreferences.getBoolean("preferences_invert_scan", false))
                CameraConfigurationUtils.setInvertColor(parameters);
            if(!sharedpreferences.getBoolean("preferences_disable_barcode_scene_mode", true))
                CameraConfigurationUtils.setBarcodeSceneMode(parameters);
            if(!sharedpreferences.getBoolean("preferences_disable_metering", true))
            {
                CameraConfigurationUtils.setVideoStabilization(parameters);
                CameraConfigurationUtils.setFocusArea(parameters);
                CameraConfigurationUtils.setMetering(parameters);
            }
        }
        parameters.setPreviewSize(cameraResolution.x, cameraResolution.y);
        Log.i("CameraConfiguration", (new StringBuilder()).append("Final camera parameters: ").append(parameters.flatten()).toString());
        camera.setDisplayOrientation(90);
        camera.setParameters(parameters);
        android.hardware.Camera.Size size = camera.getParameters().getPreviewSize();
        if(size != null && (cameraResolution.x != size.width || cameraResolution.y != size.height))
        {
            Log.w("CameraConfiguration", (new StringBuilder()).append("Camera said it supported preview size ").append(cameraResolution.x).append('x').append(cameraResolution.y).append(", but after setting it, preview size is ").append(size.width).append('x').append(size.height).toString());
            cameraResolution.x = size.width;
            cameraResolution.y = size.height;
        }
        if(true) goto _L4; else goto _L3
_L3:
    }

    void setTorch(Camera camera, boolean flag)
    {
        android.hardware.Camera.Parameters parameters = camera.getParameters();
        doSetTorch(parameters, flag, false);
        camera.setParameters(parameters);
    }
}
