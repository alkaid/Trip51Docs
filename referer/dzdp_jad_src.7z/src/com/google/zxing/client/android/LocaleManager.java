// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.client.android;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import java.util.*;

public final class LocaleManager
{

    private static final String DEFAULT_COUNTRY = "US";
    private static final String DEFAULT_LANGUAGE = "en";
    private static final String DEFAULT_TLD = "com";
    private static final Map GOOGLE_BOOK_SEARCH_COUNTRY_TLD;
    private static final Map GOOGLE_COUNTRY_TLD;
    private static final Map GOOGLE_PRODUCT_SEARCH_COUNTRY_TLD;
    private static final Collection TRANSLATED_HELP_ASSET_LANGUAGES;

    private LocaleManager()
    {
    }

    private static String doGetTLD(Map map, Context context)
    {
        String s = (String)map.get(getCountry(context));
        if(s == null)
            s = "com";
        return s;
    }

    public static String getBookSearchCountryTLD(Context context)
    {
        return doGetTLD(GOOGLE_BOOK_SEARCH_COUNTRY_TLD, context);
    }

    public static String getCountry(Context context)
    {
        String s = PreferenceManager.getDefaultSharedPreferences(context).getString("preferences_search_country", "-");
        if(s == null || s.isEmpty() || "-".equals(s))
            s = getSystemCountry();
        return s;
    }

    public static String getCountryTLD(Context context)
    {
        return doGetTLD(GOOGLE_COUNTRY_TLD, context);
    }

    public static String getProductSearchCountryTLD(Context context)
    {
        return doGetTLD(GOOGLE_PRODUCT_SEARCH_COUNTRY_TLD, context);
    }

    private static String getSystemCountry()
    {
        Locale locale = Locale.getDefault();
        String s;
        if(locale == null)
            s = "US";
        else
            s = locale.getCountry();
        return s;
    }

    private static String getSystemLanguage()
    {
        Locale locale = Locale.getDefault();
        if(locale != null) goto _L2; else goto _L1
_L1:
        String s = "en";
_L4:
        return s;
_L2:
        s = locale.getLanguage();
        if(Locale.SIMPLIFIED_CHINESE.getLanguage().equals(s))
            s = (new StringBuilder()).append(s).append("-r").append(getSystemCountry()).toString();
        if(true) goto _L4; else goto _L3
_L3:
    }

    public static String getTranslatedAssetLanguage()
    {
        String s = getSystemLanguage();
        if(!TRANSLATED_HELP_ASSET_LANGUAGES.contains(s))
            s = "en";
        return s;
    }

    public static boolean isBookSearchUrl(String s)
    {
        boolean flag;
        if(s.startsWith("http://google.com/books") || s.startsWith("http://books.google."))
            flag = true;
        else
            flag = false;
        return flag;
    }

    static 
    {
        GOOGLE_COUNTRY_TLD = new HashMap();
        GOOGLE_COUNTRY_TLD.put("AR", "com.ar");
        GOOGLE_COUNTRY_TLD.put("AU", "com.au");
        GOOGLE_COUNTRY_TLD.put("BR", "com.br");
        GOOGLE_COUNTRY_TLD.put("BG", "bg");
        GOOGLE_COUNTRY_TLD.put(Locale.CANADA.getCountry(), "ca");
        GOOGLE_COUNTRY_TLD.put(Locale.CHINA.getCountry(), "cn");
        GOOGLE_COUNTRY_TLD.put("CZ", "cz");
        GOOGLE_COUNTRY_TLD.put("DK", "dk");
        GOOGLE_COUNTRY_TLD.put("FI", "fi");
        GOOGLE_COUNTRY_TLD.put(Locale.FRANCE.getCountry(), "fr");
        GOOGLE_COUNTRY_TLD.put(Locale.GERMANY.getCountry(), "de");
        GOOGLE_COUNTRY_TLD.put("GR", "gr");
        GOOGLE_COUNTRY_TLD.put("HU", "hu");
        GOOGLE_COUNTRY_TLD.put("ID", "co.id");
        GOOGLE_COUNTRY_TLD.put("IL", "co.il");
        GOOGLE_COUNTRY_TLD.put(Locale.ITALY.getCountry(), "it");
        GOOGLE_COUNTRY_TLD.put(Locale.JAPAN.getCountry(), "co.jp");
        GOOGLE_COUNTRY_TLD.put(Locale.KOREA.getCountry(), "co.kr");
        GOOGLE_COUNTRY_TLD.put("NL", "nl");
        GOOGLE_COUNTRY_TLD.put("PL", "pl");
        GOOGLE_COUNTRY_TLD.put("PT", "pt");
        GOOGLE_COUNTRY_TLD.put("RO", "ro");
        GOOGLE_COUNTRY_TLD.put("RU", "ru");
        GOOGLE_COUNTRY_TLD.put("SK", "sk");
        GOOGLE_COUNTRY_TLD.put("SI", "si");
        GOOGLE_COUNTRY_TLD.put("ES", "es");
        GOOGLE_COUNTRY_TLD.put("SE", "se");
        GOOGLE_COUNTRY_TLD.put("CH", "ch");
        GOOGLE_COUNTRY_TLD.put(Locale.TAIWAN.getCountry(), "tw");
        GOOGLE_COUNTRY_TLD.put("TR", "com.tr");
        GOOGLE_COUNTRY_TLD.put("UA", "com.ua");
        GOOGLE_COUNTRY_TLD.put(Locale.UK.getCountry(), "co.uk");
        GOOGLE_COUNTRY_TLD.put(Locale.US.getCountry(), "com");
        GOOGLE_PRODUCT_SEARCH_COUNTRY_TLD = new HashMap();
        GOOGLE_PRODUCT_SEARCH_COUNTRY_TLD.put("AU", "com.au");
        GOOGLE_PRODUCT_SEARCH_COUNTRY_TLD.put(Locale.FRANCE.getCountry(), "fr");
        GOOGLE_PRODUCT_SEARCH_COUNTRY_TLD.put(Locale.GERMANY.getCountry(), "de");
        GOOGLE_PRODUCT_SEARCH_COUNTRY_TLD.put(Locale.ITALY.getCountry(), "it");
        GOOGLE_PRODUCT_SEARCH_COUNTRY_TLD.put(Locale.JAPAN.getCountry(), "co.jp");
        GOOGLE_PRODUCT_SEARCH_COUNTRY_TLD.put("NL", "nl");
        GOOGLE_PRODUCT_SEARCH_COUNTRY_TLD.put("ES", "es");
        GOOGLE_PRODUCT_SEARCH_COUNTRY_TLD.put("CH", "ch");
        GOOGLE_PRODUCT_SEARCH_COUNTRY_TLD.put(Locale.UK.getCountry(), "co.uk");
        GOOGLE_PRODUCT_SEARCH_COUNTRY_TLD.put(Locale.US.getCountry(), "com");
        GOOGLE_BOOK_SEARCH_COUNTRY_TLD = GOOGLE_COUNTRY_TLD;
        String as[] = new String[14];
        as[0] = "de";
        as[1] = "en";
        as[2] = "es";
        as[3] = "fr";
        as[4] = "it";
        as[5] = "ja";
        as[6] = "ko";
        as[7] = "nl";
        as[8] = "pt";
        as[9] = "ru";
        as[10] = "uk";
        as[11] = "zh-rCN";
        as[12] = "zh-rTW";
        as[13] = "zh-rHK";
        TRANSLATED_HELP_ASSET_LANGUAGES = Arrays.asList(as);
    }
}
