// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.client.android;


public final class Contents
{
    public static final class Type
    {

        public static final String CONTACT = "CONTACT_TYPE";
        public static final String EMAIL = "EMAIL_TYPE";
        public static final String LOCATION = "LOCATION_TYPE";
        public static final String PHONE = "PHONE_TYPE";
        public static final String SMS = "SMS_TYPE";
        public static final String TEXT = "TEXT_TYPE";

        private Type()
        {
        }
    }


    public static final String EMAIL_KEYS[];
    public static final String EMAIL_TYPE_KEYS[];
    public static final String NOTE_KEY = "NOTE_KEY";
    public static final String PHONE_KEYS[];
    public static final String PHONE_TYPE_KEYS[];
    public static final String URL_KEY = "URL_KEY";

    private Contents()
    {
    }

    static 
    {
        String as[] = new String[3];
        as[0] = "phone";
        as[1] = "secondary_phone";
        as[2] = "tertiary_phone";
        PHONE_KEYS = as;
        String as1[] = new String[3];
        as1[0] = "phone_type";
        as1[1] = "secondary_phone_type";
        as1[2] = "tertiary_phone_type";
        PHONE_TYPE_KEYS = as1;
        String as2[] = new String[3];
        as2[0] = "email";
        as2[1] = "secondary_email";
        as2[2] = "tertiary_email";
        EMAIL_KEYS = as2;
        String as3[] = new String[3];
        as3[0] = "email_type";
        as3[1] = "secondary_email_type";
        as3[2] = "tertiary_email_type";
        EMAIL_TYPE_KEYS = as3;
    }
}
