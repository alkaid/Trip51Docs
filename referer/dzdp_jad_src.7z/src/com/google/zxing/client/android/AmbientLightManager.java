// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.client.android;

import android.content.Context;
import android.hardware.*;
import android.preference.PreferenceManager;
import com.google.zxing.client.android.camera.CameraManager;
import com.google.zxing.client.android.camera.FrontLightMode;

final class AmbientLightManager
    implements SensorEventListener
{

    private static final float BRIGHT_ENOUGH_LUX = 450F;
    private static final float TOO_DARK_LUX = 45F;
    private CameraManager cameraManager;
    private final Context context;
    private Sensor lightSensor;

    AmbientLightManager(Context context1)
    {
        context = context1;
    }

    public void onAccuracyChanged(Sensor sensor, int i)
    {
    }

    public void onSensorChanged(SensorEvent sensorevent)
    {
        float f = sensorevent.values[0];
        if(cameraManager == null) goto _L2; else goto _L1
_L1:
        if(f > 45F) goto _L4; else goto _L3
_L3:
        cameraManager.setTorch(true);
_L2:
        return;
_L4:
        if(f >= 450F)
            cameraManager.setTorch(false);
        if(true) goto _L2; else goto _L5
_L5:
    }

    void start(CameraManager cameramanager)
    {
        cameraManager = cameramanager;
        if(FrontLightMode.readPref(PreferenceManager.getDefaultSharedPreferences(context)) == FrontLightMode.AUTO)
        {
            SensorManager sensormanager = (SensorManager)context.getSystemService("sensor");
            lightSensor = sensormanager.getDefaultSensor(5);
            if(lightSensor != null)
                sensormanager.registerListener(this, lightSensor, 3);
        }
    }

    void stop()
    {
        if(lightSensor != null)
        {
            ((SensorManager)context.getSystemService("sensor")).unregisterListener(this);
            cameraManager = null;
            lightSensor = null;
        }
    }
}
