// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.client.android;

import android.graphics.Bitmap;
import android.os.*;
import android.util.Log;
import com.google.zxing.*;
import com.google.zxing.client.android.camera.CameraManager;
import com.google.zxing.common.HybridBinarizer;
import java.io.ByteArrayOutputStream;
import java.util.Map;

// Referenced classes of package com.google.zxing.client.android:
//            CaptureActivity

final class DecodeHandler extends Handler
{

    private static final String TAG = com/google/zxing/client/android/DecodeHandler.getSimpleName();
    private final CaptureActivity activity;
    private final MultiFormatReader multiFormatReader = new MultiFormatReader();
    private boolean running;

    DecodeHandler(CaptureActivity captureactivity, Map map)
    {
        running = true;
        multiFormatReader.setHints(map);
        activity = captureactivity;
    }

    private static void bundleThumbnail(PlanarYUVLuminanceSource planaryuvluminancesource, Bundle bundle)
    {
        int ai[] = planaryuvluminancesource.renderThumbnail();
        int i = planaryuvluminancesource.getThumbnailWidth();
        Bitmap bitmap = Bitmap.createBitmap(ai, 0, i, i, planaryuvluminancesource.getThumbnailHeight(), android.graphics.Bitmap.Config.ARGB_8888);
        ByteArrayOutputStream bytearrayoutputstream = new ByteArrayOutputStream();
        bitmap.compress(android.graphics.Bitmap.CompressFormat.JPEG, 50, bytearrayoutputstream);
        bundle.putByteArray("barcode_bitmap", bytearrayoutputstream.toByteArray());
        bundle.putFloat("barcode_scaled_factor", (float)i / (float)planaryuvluminancesource.getWidth());
    }

    private void decode(byte abyte0[], int i, int j)
    {
        long l;
        com.google.zxing.Result result;
        PlanarYUVLuminanceSource planaryuvluminancesource;
        BinaryBitmap binarybitmap;
        l = System.currentTimeMillis();
        result = null;
        byte abyte1[] = new byte[abyte0.length];
        for(int k = 0; k < j; k++)
        {
            for(int i1 = 0; i1 < i; i1++)
                abyte1[-1 + ((j + i1 * j) - k)] = abyte0[i1 + k * i];

        }

        planaryuvluminancesource = activity.getCameraManager().buildLuminanceSource(abyte1, j, i);
        if(planaryuvluminancesource == null)
            break MISSING_BLOCK_LABEL_133;
        HybridBinarizer hybridbinarizer = new HybridBinarizer(planaryuvluminancesource);
        binarybitmap = new BinaryBitmap(hybridbinarizer);
        com.google.zxing.Result result1 = multiFormatReader.decodeWithState(binarybitmap);
        result = result1;
        multiFormatReader.reset();
_L1:
        Handler handler = activity.getHandler();
        Exception exception;
        ReaderException readerexception;
        if(result != null)
        {
            long l1 = System.currentTimeMillis();
            Log.d(TAG, (new StringBuilder()).append("Found barcode in ").append(l1 - l).append(" ms").toString());
            if(handler != null)
            {
                Message message = Message.obtain(handler, R.id.decode_succeeded, result);
                Bundle bundle = new Bundle();
                bundleThumbnail(planaryuvluminancesource, bundle);
                message.setData(bundle);
                message.sendToTarget();
            }
        } else
        if(handler != null)
            Message.obtain(handler, R.id.decode_failed).sendToTarget();
        return;
        readerexception;
        multiFormatReader.reset();
          goto _L1
        exception;
        multiFormatReader.reset();
        throw exception;
    }

    public void handleMessage(Message message)
    {
        if(running) goto _L2; else goto _L1
_L1:
        return;
_L2:
        if(message.what == R.id.decode)
            decode((byte[])(byte[])message.obj, message.arg1, message.arg2);
        else
        if(message.what == R.id.quit)
        {
            running = false;
            Looper.myLooper().quit();
        }
        if(true) goto _L1; else goto _L3
_L3:
    }

}
