// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.client.android.common.executor;

import android.os.AsyncTask;

// Referenced classes of package com.google.zxing.client.android.common.executor:
//            AsyncTaskExecInterface

public final class HoneycombAsyncTaskExecInterface
    implements AsyncTaskExecInterface
{

    public HoneycombAsyncTaskExecInterface()
    {
    }

    public transient void execute(AsyncTask asynctask, Object aobj[])
    {
        asynctask.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, aobj);
    }
}
