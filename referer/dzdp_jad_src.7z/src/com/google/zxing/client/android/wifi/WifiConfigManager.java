// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.client.android.wifi;

import android.net.wifi.WifiConfiguration;
import android.net.wifi.WifiManager;
import android.os.AsyncTask;
import android.util.Log;
import com.google.zxing.client.result.WifiParsedResult;
import java.util.BitSet;
import java.util.Iterator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

// Referenced classes of package com.google.zxing.client.android.wifi:
//            NetworkType

public final class WifiConfigManager extends AsyncTask
{

    private static final Pattern HEX_DIGITS = Pattern.compile("[0-9A-Fa-f]+");
    private static final String TAG = com/google/zxing/client/android/wifi/WifiConfigManager.getSimpleName();
    private final WifiManager wifiManager;

    public WifiConfigManager(WifiManager wifimanager)
    {
        wifiManager = wifimanager;
    }

    private static WifiConfiguration changeNetworkCommon(WifiParsedResult wifiparsedresult)
    {
        WifiConfiguration wificonfiguration = new WifiConfiguration();
        wificonfiguration.allowedAuthAlgorithms.clear();
        wificonfiguration.allowedGroupCiphers.clear();
        wificonfiguration.allowedKeyManagement.clear();
        wificonfiguration.allowedPairwiseCiphers.clear();
        wificonfiguration.allowedProtocols.clear();
        wificonfiguration.SSID = quoteNonHex(wifiparsedresult.getSsid(), new int[0]);
        wificonfiguration.hiddenSSID = wifiparsedresult.isHidden();
        return wificonfiguration;
    }

    private static void changeNetworkUnEncrypted(WifiManager wifimanager, WifiParsedResult wifiparsedresult)
    {
        WifiConfiguration wificonfiguration = changeNetworkCommon(wifiparsedresult);
        wificonfiguration.allowedKeyManagement.set(0);
        updateNetwork(wifimanager, wificonfiguration);
    }

    private static void changeNetworkWEP(WifiManager wifimanager, WifiParsedResult wifiparsedresult)
    {
        WifiConfiguration wificonfiguration = changeNetworkCommon(wifiparsedresult);
        String as[] = wificonfiguration.wepKeys;
        String s = wifiparsedresult.getPassword();
        int ai[] = new int[3];
        ai[0] = 10;
        ai[1] = 26;
        ai[2] = 58;
        as[0] = quoteNonHex(s, ai);
        wificonfiguration.wepTxKeyIndex = 0;
        wificonfiguration.allowedAuthAlgorithms.set(1);
        wificonfiguration.allowedKeyManagement.set(0);
        wificonfiguration.allowedGroupCiphers.set(2);
        wificonfiguration.allowedGroupCiphers.set(3);
        wificonfiguration.allowedGroupCiphers.set(0);
        wificonfiguration.allowedGroupCiphers.set(1);
        updateNetwork(wifimanager, wificonfiguration);
    }

    private static void changeNetworkWPA(WifiManager wifimanager, WifiParsedResult wifiparsedresult)
    {
        WifiConfiguration wificonfiguration = changeNetworkCommon(wifiparsedresult);
        String s = wifiparsedresult.getPassword();
        int ai[] = new int[1];
        ai[0] = 64;
        wificonfiguration.preSharedKey = quoteNonHex(s, ai);
        wificonfiguration.allowedAuthAlgorithms.set(0);
        wificonfiguration.allowedProtocols.set(0);
        wificonfiguration.allowedProtocols.set(1);
        wificonfiguration.allowedKeyManagement.set(1);
        wificonfiguration.allowedKeyManagement.set(2);
        wificonfiguration.allowedPairwiseCiphers.set(1);
        wificonfiguration.allowedPairwiseCiphers.set(2);
        wificonfiguration.allowedGroupCiphers.set(2);
        wificonfiguration.allowedGroupCiphers.set(3);
        updateNetwork(wifimanager, wificonfiguration);
    }

    private static String convertToQuotedString(String s)
    {
        if(s != null && !s.isEmpty()) goto _L2; else goto _L1
_L1:
        s = null;
_L4:
        return s;
_L2:
        if(s.charAt(0) != '"' || s.charAt(-1 + s.length()) != '"')
            s = (new StringBuilder()).append('"').append(s).append('"').toString();
        if(true) goto _L4; else goto _L3
_L3:
    }

    private static Integer findNetworkInExistingConfig(WifiManager wifimanager, String s)
    {
        java.util.List list = wifimanager.getConfiguredNetworks();
        if(list == null) goto _L2; else goto _L1
_L1:
        Iterator iterator = list.iterator();
_L5:
        if(!iterator.hasNext()) goto _L2; else goto _L3
_L3:
        WifiConfiguration wificonfiguration;
        String s1;
        wificonfiguration = (WifiConfiguration)iterator.next();
        s1 = wificonfiguration.SSID;
        if(s1 == null || !s1.equals(s)) goto _L5; else goto _L4
_L4:
        Integer integer = Integer.valueOf(wificonfiguration.networkId);
_L7:
        return integer;
_L2:
        integer = null;
        if(true) goto _L7; else goto _L6
_L6:
    }

    private static transient boolean isHexOfLength(CharSequence charsequence, int ai[])
    {
        boolean flag = true;
        if(charsequence != null && HEX_DIGITS.matcher(charsequence).matches()) goto _L2; else goto _L1
_L1:
        flag = false;
_L4:
        return flag;
_L2:
        if(ai.length == 0)
            continue; /* Loop/switch isn't completed */
        int i = ai.length;
        for(int j = 0; j < i; j++)
        {
            int k = ai[j];
            if(charsequence.length() == k)
                continue; /* Loop/switch isn't completed */
        }

        flag = false;
        if(true) goto _L4; else goto _L3
_L3:
    }

    private static transient String quoteNonHex(String s, int ai[])
    {
        if(!isHexOfLength(s, ai))
            s = convertToQuotedString(s);
        return s;
    }

    private static void updateNetwork(WifiManager wifimanager, WifiConfiguration wificonfiguration)
    {
        Integer integer = findNetworkInExistingConfig(wifimanager, wificonfiguration.SSID);
        if(integer != null)
        {
            Log.i(TAG, (new StringBuilder()).append("Removing old configuration for network ").append(wificonfiguration.SSID).toString());
            wifimanager.removeNetwork(integer.intValue());
            wifimanager.saveConfiguration();
        }
        int i = wifimanager.addNetwork(wificonfiguration);
        if(i >= 0)
        {
            if(wifimanager.enableNetwork(i, true))
            {
                Log.i(TAG, (new StringBuilder()).append("Associating to network ").append(wificonfiguration.SSID).toString());
                wifimanager.saveConfiguration();
            } else
            {
                Log.w(TAG, (new StringBuilder()).append("Failed to enable network ").append(wificonfiguration.SSID).toString());
            }
        } else
        {
            Log.w(TAG, (new StringBuilder()).append("Unable to add network ").append(wificonfiguration.SSID).toString());
        }
    }

    protected transient Object doInBackground(WifiParsedResult awifiparsedresult[])
    {
        WifiParsedResult wifiparsedresult = awifiparsedresult[0];
        if(wifiManager.isWifiEnabled()) goto _L2; else goto _L1
_L1:
        Log.i(TAG, "Enabling wi-fi...");
        if(!wifiManager.setWifiEnabled(true)) goto _L4; else goto _L3
_L3:
        int i;
        Log.i(TAG, "Wi-fi enabled");
        i = 0;
_L9:
        if(wifiManager.isWifiEnabled()) goto _L2; else goto _L5
_L5:
        if(i < 10) goto _L7; else goto _L6
_L6:
        Log.i(TAG, "Took too long to enable wi-fi, quitting");
_L8:
        return null;
_L4:
        Log.w(TAG, "Wi-fi could not be enabled!");
          goto _L8
_L7:
        Log.i(TAG, "Still waiting for wi-fi to enable...");
        String s;
        IllegalArgumentException illegalargumentexception;
        NetworkType networktype;
        String s1;
        try
        {
            Thread.sleep(1000L);
        }
        catch(InterruptedException interruptedexception) { }
        i++;
          goto _L9
_L2:
        s = wifiparsedresult.getNetworkEncryption();
        networktype = NetworkType.forIntentValue(s);
        if(networktype == NetworkType.NO_PASSWORD)
        {
            changeNetworkUnEncrypted(wifiManager, wifiparsedresult);
        } else
        {
            s1 = wifiparsedresult.getPassword();
            if(s1 != null && !s1.isEmpty())
                if(networktype == NetworkType.WEP)
                    changeNetworkWEP(wifiManager, wifiparsedresult);
                else
                if(networktype == NetworkType.WPA)
                    changeNetworkWPA(wifiManager, wifiparsedresult);
        }
          goto _L8
        illegalargumentexception;
        Log.w(TAG, (new StringBuilder()).append("Bad network type; see NetworkType values: ").append(s).toString());
          goto _L8
    }

    protected volatile Object doInBackground(Object aobj[])
    {
        return doInBackground((WifiParsedResult[])aobj);
    }

}
