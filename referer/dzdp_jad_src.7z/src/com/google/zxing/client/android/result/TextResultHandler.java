// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.client.android.result;

import android.app.Activity;
import com.google.zxing.Result;
import com.google.zxing.client.result.ParsedResult;

// Referenced classes of package com.google.zxing.client.android.result:
//            ResultHandler

public final class TextResultHandler extends ResultHandler
{

    private static final int buttons[];

    public TextResultHandler(Activity activity, ParsedResult parsedresult, Result result)
    {
        super(activity, parsedresult, result);
    }

    public int getButtonCount()
    {
        int i;
        if(hasCustomProductSearch())
            i = buttons.length;
        else
            i = -1 + buttons.length;
        return i;
    }

    public int getButtonText(int i)
    {
        return buttons[i];
    }

    public int getDisplayTitle()
    {
        return com.google.zxing.client.android.R.string.result_text;
    }

    public void handleButtonPress(int i)
    {
        String s = getResult().getDisplayResult();
        i;
        JVM INSTR tableswitch 0 3: default 40
    //                   0 41
    //                   1 49
    //                   2 57
    //                   3 65;
           goto _L1 _L2 _L3 _L4 _L5
_L1:
        return;
_L2:
        webSearch(s);
        continue; /* Loop/switch isn't completed */
_L3:
        shareByEmail(s);
        continue; /* Loop/switch isn't completed */
_L4:
        shareBySMS(s);
        continue; /* Loop/switch isn't completed */
_L5:
        openURL(fillInCustomSearchURL(s));
        if(true) goto _L1; else goto _L6
_L6:
    }

    static 
    {
        int ai[] = new int[4];
        ai[0] = com.google.zxing.client.android.R.string.button_web_search;
        ai[1] = com.google.zxing.client.android.R.string.button_share_by_email;
        ai[2] = com.google.zxing.client.android.R.string.button_share_by_sms;
        ai[3] = com.google.zxing.client.android.R.string.button_custom_product_search;
        buttons = ai;
    }
}
