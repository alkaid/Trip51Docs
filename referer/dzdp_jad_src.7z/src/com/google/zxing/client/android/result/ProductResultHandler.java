// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.client.android.result;

import android.app.Activity;
import com.google.zxing.Result;
import com.google.zxing.client.result.*;

// Referenced classes of package com.google.zxing.client.android.result:
//            ResultHandler

public final class ProductResultHandler extends ResultHandler
{

    private static final int buttons[];

    public ProductResultHandler(Activity activity, ParsedResult parsedresult, Result result)
    {
        super(activity, parsedresult, result);
    }

    private static String getProductIDFromResult(ParsedResult parsedresult)
    {
        String s;
        if(parsedresult instanceof ProductParsedResult)
            s = ((ProductParsedResult)parsedresult).getNormalizedProductID();
        else
        if(parsedresult instanceof ExpandedProductParsedResult)
            s = ((ExpandedProductParsedResult)parsedresult).getRawText();
        else
            throw new IllegalArgumentException(parsedresult.getClass().toString());
        return s;
    }

    public int getButtonCount()
    {
        int i;
        if(hasCustomProductSearch())
            i = buttons.length;
        else
            i = -1 + buttons.length;
        return i;
    }

    public int getButtonText(int i)
    {
        return buttons[i];
    }

    public int getDisplayTitle()
    {
        return com.google.zxing.client.android.R.string.result_product;
    }

    public void handleButtonPress(int i)
    {
        String s = getProductIDFromResult(getResult());
        i;
        JVM INSTR tableswitch 0 2: default 36
    //                   0 37
    //                   1 45
    //                   2 53;
           goto _L1 _L2 _L3 _L4
_L1:
        return;
_L2:
        openProductSearch(s);
        continue; /* Loop/switch isn't completed */
_L3:
        webSearch(s);
        continue; /* Loop/switch isn't completed */
_L4:
        openURL(fillInCustomSearchURL(s));
        if(true) goto _L1; else goto _L5
_L5:
    }

    static 
    {
        int ai[] = new int[3];
        ai[0] = com.google.zxing.client.android.R.string.button_product_search;
        ai[1] = com.google.zxing.client.android.R.string.button_web_search;
        ai[2] = com.google.zxing.client.android.R.string.button_custom_product_search;
        buttons = ai;
    }
}
