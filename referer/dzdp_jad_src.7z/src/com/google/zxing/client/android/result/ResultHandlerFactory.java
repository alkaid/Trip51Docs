// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.client.android.result;

import com.google.zxing.Result;
import com.google.zxing.client.android.CaptureActivity;
import com.google.zxing.client.result.*;

// Referenced classes of package com.google.zxing.client.android.result:
//            TextResultHandler, AddressBookResultHandler, EmailAddressResultHandler, ProductResultHandler, 
//            URIResultHandler, WifiResultHandler, GeoResultHandler, TelResultHandler, 
//            SMSResultHandler, CalendarResultHandler, ISBNResultHandler, ResultHandler

public final class ResultHandlerFactory
{

    private ResultHandlerFactory()
    {
    }

    public static ResultHandler makeResultHandler(CaptureActivity captureactivity, Result result)
    {
        ParsedResult parsedresult = parseResult(result);
        class _cls1
        {

            static final int $SwitchMap$com$google$zxing$client$result$ParsedResultType[];

            static 
            {
                $SwitchMap$com$google$zxing$client$result$ParsedResultType = new int[ParsedResultType.values().length];
                NoSuchFieldError nosuchfielderror9;
                try
                {
                    $SwitchMap$com$google$zxing$client$result$ParsedResultType[ParsedResultType.ADDRESSBOOK.ordinal()] = 1;
                }
                catch(NoSuchFieldError nosuchfielderror) { }
                try
                {
                    $SwitchMap$com$google$zxing$client$result$ParsedResultType[ParsedResultType.EMAIL_ADDRESS.ordinal()] = 2;
                }
                catch(NoSuchFieldError nosuchfielderror1) { }
                try
                {
                    $SwitchMap$com$google$zxing$client$result$ParsedResultType[ParsedResultType.PRODUCT.ordinal()] = 3;
                }
                catch(NoSuchFieldError nosuchfielderror2) { }
                try
                {
                    $SwitchMap$com$google$zxing$client$result$ParsedResultType[ParsedResultType.URI.ordinal()] = 4;
                }
                catch(NoSuchFieldError nosuchfielderror3) { }
                try
                {
                    $SwitchMap$com$google$zxing$client$result$ParsedResultType[ParsedResultType.WIFI.ordinal()] = 5;
                }
                catch(NoSuchFieldError nosuchfielderror4) { }
                try
                {
                    $SwitchMap$com$google$zxing$client$result$ParsedResultType[ParsedResultType.GEO.ordinal()] = 6;
                }
                catch(NoSuchFieldError nosuchfielderror5) { }
                try
                {
                    $SwitchMap$com$google$zxing$client$result$ParsedResultType[ParsedResultType.TEL.ordinal()] = 7;
                }
                catch(NoSuchFieldError nosuchfielderror6) { }
                try
                {
                    $SwitchMap$com$google$zxing$client$result$ParsedResultType[ParsedResultType.SMS.ordinal()] = 8;
                }
                catch(NoSuchFieldError nosuchfielderror7) { }
                try
                {
                    $SwitchMap$com$google$zxing$client$result$ParsedResultType[ParsedResultType.CALENDAR.ordinal()] = 9;
                }
                catch(NoSuchFieldError nosuchfielderror8) { }
                $SwitchMap$com$google$zxing$client$result$ParsedResultType[ParsedResultType.ISBN.ordinal()] = 10;
_L2:
                return;
                nosuchfielderror9;
                if(true) goto _L2; else goto _L1
_L1:
            }
        }

        _cls1..SwitchMap.com.google.zxing.client.result.ParsedResultType[parsedresult.getType().ordinal()];
        JVM INSTR tableswitch 1 10: default 72
    //                   1 85
    //                   2 98
    //                   3 111
    //                   4 125
    //                   5 138
    //                   6 151
    //                   7 164
    //                   8 177
    //                   9 190
    //                   10 203;
           goto _L1 _L2 _L3 _L4 _L5 _L6 _L7 _L8 _L9 _L10 _L11
_L1:
        Object obj = new TextResultHandler(captureactivity, parsedresult, result);
_L13:
        return ((ResultHandler) (obj));
_L2:
        obj = new AddressBookResultHandler(captureactivity, parsedresult);
        continue; /* Loop/switch isn't completed */
_L3:
        obj = new EmailAddressResultHandler(captureactivity, parsedresult);
        continue; /* Loop/switch isn't completed */
_L4:
        obj = new ProductResultHandler(captureactivity, parsedresult, result);
        continue; /* Loop/switch isn't completed */
_L5:
        obj = new URIResultHandler(captureactivity, parsedresult);
        continue; /* Loop/switch isn't completed */
_L6:
        obj = new WifiResultHandler(captureactivity, parsedresult);
        continue; /* Loop/switch isn't completed */
_L7:
        obj = new GeoResultHandler(captureactivity, parsedresult);
        continue; /* Loop/switch isn't completed */
_L8:
        obj = new TelResultHandler(captureactivity, parsedresult);
        continue; /* Loop/switch isn't completed */
_L9:
        obj = new SMSResultHandler(captureactivity, parsedresult);
        continue; /* Loop/switch isn't completed */
_L10:
        obj = new CalendarResultHandler(captureactivity, parsedresult);
        continue; /* Loop/switch isn't completed */
_L11:
        obj = new ISBNResultHandler(captureactivity, parsedresult, result);
        if(true) goto _L13; else goto _L12
_L12:
    }

    private static ParsedResult parseResult(Result result)
    {
        return ResultParser.parseResult(result);
    }
}
