// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.client.android.encode;

import android.content.*;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.telephony.PhoneNumberUtils;
import android.util.Log;
import com.google.zxing.*;
import com.google.zxing.client.android.Contents;
import com.google.zxing.client.result.AddressBookParsedResult;
import com.google.zxing.client.result.ResultParser;
import com.google.zxing.common.BitMatrix;
import java.io.*;
import java.util.*;

// Referenced classes of package com.google.zxing.client.android.encode:
//            ContactEncoder, VCardContactEncoder, MECARDContactEncoder

public final class QRCodeEncoder
{

    private static final int BLACK = 0xff000000;
    private static final String TAG = com/google/zxing/client/android/encode/QRCodeEncoder.getSimpleName();
    private static final int WHITE = -1;
    private final Context activity;
    private String contents;
    private String displayContents;
    private BarcodeFormat format;
    private final int height;
    private Map hints;
    private String title;
    private final boolean useVCard;
    private final int width;

    public QRCodeEncoder(Context context, Intent intent, int i, int j, boolean flag)
        throws WriterException
    {
        String s;
        activity = context;
        width = i;
        height = j;
        useVCard = flag;
        s = intent.getAction();
        if(!s.equals("com.google.zxing.client.android.ENCODE")) goto _L2; else goto _L1
_L1:
        encodeContentsFromZXingIntent(intent);
_L4:
        return;
_L2:
        if(s.equals("android.intent.action.SEND"))
            encodeContentsFromShareIntent(intent);
        if(true) goto _L4; else goto _L3
_L3:
    }

    public QRCodeEncoder(Context context, Intent intent, int i, int j, boolean flag, Map map)
        throws WriterException
    {
        String s;
        activity = context;
        width = i;
        height = j;
        useVCard = flag;
        hints = map;
        s = intent.getAction();
        if(!s.equals("com.google.zxing.client.android.ENCODE")) goto _L2; else goto _L1
_L1:
        encodeContentsFromZXingIntent(intent);
_L4:
        return;
_L2:
        if(s.equals("android.intent.action.SEND"))
            encodeContentsFromShareIntent(intent);
        if(true) goto _L4; else goto _L3
_L3:
    }

    private void encodeContentsFromShareIntent(Intent intent)
        throws WriterException
    {
        if(intent.hasExtra("android.intent.extra.STREAM"))
            encodeFromStreamExtra(intent);
        else
            encodeFromTextExtras(intent);
    }

    private boolean encodeContentsFromZXingIntent(Intent intent)
    {
        boolean flag = false;
        String s = intent.getStringExtra("ENCODE_FORMAT");
        format = null;
        String s1;
        String s2;
        if(s != null)
            try
            {
                format = BarcodeFormat.valueOf(s);
            }
            catch(IllegalArgumentException illegalargumentexception) { }
        if(format != null && format != BarcodeFormat.QR_CODE) goto _L2; else goto _L1
_L1:
        s1 = intent.getStringExtra("ENCODE_TYPE");
        if(s1 != null && !s1.isEmpty()) goto _L4; else goto _L3
_L3:
        return flag;
_L4:
        format = BarcodeFormat.QR_CODE;
        encodeQRCodeContents(intent, s1);
_L5:
        if(contents != null && !contents.isEmpty())
            flag = true;
        if(true) goto _L3; else goto _L2
_L2:
        s2 = intent.getStringExtra("ENCODE_DATA");
        if(s2 != null && !s2.isEmpty())
        {
            contents = s2;
            displayContents = s2;
            title = activity.getString(com.google.zxing.client.android.R.string.contents_text);
        }
          goto _L5
    }

    private void encodeFromStreamExtra(Intent intent)
        throws WriterException
    {
        Uri uri;
        InputStream inputstream;
        format = BarcodeFormat.QR_CODE;
        Bundle bundle = intent.getExtras();
        if(bundle == null)
            throw new WriterException("No extras");
        uri = (Uri)bundle.getParcelable("android.intent.extra.STREAM");
        if(uri == null)
            throw new WriterException("No EXTRA_STREAM");
        inputstream = null;
        inputstream = activity.getContentResolver().openInputStream(uri);
        if(inputstream == null)
            throw new WriterException((new StringBuilder()).append("Can't open stream for ").append(uri).toString());
        break MISSING_BLOCK_LABEL_125;
        IOException ioexception1;
        ioexception1;
        throw new WriterException(ioexception1);
        Exception exception;
        exception;
        ByteArrayOutputStream bytearrayoutputstream;
        byte abyte0[];
        int i;
        byte abyte1[];
        String s;
        com.google.zxing.client.result.ParsedResult parsedresult;
        IOException ioexception2;
        if(inputstream != null)
            try
            {
                inputstream.close();
            }
            catch(IOException ioexception) { }
        throw exception;
        bytearrayoutputstream = new ByteArrayOutputStream();
        abyte0 = new byte[2048];
        do
        {
            i = inputstream.read(abyte0);
            if(i <= 0)
                break;
            bytearrayoutputstream.write(abyte0, 0, i);
        } while(true);
        abyte1 = bytearrayoutputstream.toByteArray();
        s = new String(abyte1, 0, abyte1.length, "UTF-8");
        if(inputstream != null)
            try
            {
                inputstream.close();
            }
            // Misplaced declaration of an exception variable
            catch(IOException ioexception2) { }
        Log.d(TAG, "Encoding share intent content:");
        Log.d(TAG, s);
        parsedresult = ResultParser.parseResult(new Result(s, abyte1, null, BarcodeFormat.QR_CODE));
        if(!(parsedresult instanceof AddressBookParsedResult))
            throw new WriterException("Result was not an address");
        encodeQRCodeContents((AddressBookParsedResult)parsedresult);
        if(contents == null || contents.isEmpty())
            throw new WriterException("No content to encode");
        else
            return;
    }

    private void encodeFromTextExtras(Intent intent)
        throws WriterException
    {
        String s = ContactEncoder.trim(intent.getStringExtra("android.intent.extra.TEXT"));
        if(s == null)
        {
            s = ContactEncoder.trim(intent.getStringExtra("android.intent.extra.HTML_TEXT"));
            if(s == null)
            {
                s = ContactEncoder.trim(intent.getStringExtra("android.intent.extra.SUBJECT"));
                if(s == null)
                {
                    String as[] = intent.getStringArrayExtra("android.intent.extra.EMAIL");
                    if(as != null)
                        s = ContactEncoder.trim(as[0]);
                    else
                        s = "?";
                }
            }
        }
        if(s == null || s.isEmpty())
            throw new WriterException("Empty EXTRA_TEXT");
        contents = s;
        format = BarcodeFormat.QR_CODE;
        if(intent.hasExtra("android.intent.extra.SUBJECT"))
            displayContents = intent.getStringExtra("android.intent.extra.SUBJECT");
        else
        if(intent.hasExtra("android.intent.extra.TITLE"))
            displayContents = intent.getStringExtra("android.intent.extra.TITLE");
        else
            displayContents = contents;
        title = activity.getString(com.google.zxing.client.android.R.string.contents_text);
    }

    private void encodeQRCodeContents(Intent intent, String s)
    {
        byte byte0 = -1;
        s.hashCode();
        JVM INSTR lookupswitch 6: default 64
    //                   -1309271157: 135
    //                   -670199783: 165
    //                   709220992: 150
    //                   1349204356: 180
    //                   1778595596: 105
    //                   1833351709: 120;
           goto _L1 _L2 _L3 _L4 _L5 _L6 _L7
_L1:
        byte0;
        JVM INSTR tableswitch 0 5: default 104
    //                   0 195
    //                   1 245
    //                   2 309
    //                   3 376
    //                   4 443
    //                   5 654;
           goto _L8 _L9 _L10 _L11 _L12 _L13 _L14
_L8:
        return;
_L6:
        if(s.equals("TEXT_TYPE"))
            byte0 = 0;
          goto _L1
_L7:
        if(s.equals("EMAIL_TYPE"))
            byte0 = 1;
          goto _L1
_L2:
        if(s.equals("PHONE_TYPE"))
            byte0 = 2;
          goto _L1
_L4:
        if(s.equals("SMS_TYPE"))
            byte0 = 3;
          goto _L1
_L3:
        if(s.equals("CONTACT_TYPE"))
            byte0 = 4;
          goto _L1
_L5:
        if(s.equals("LOCATION_TYPE"))
            byte0 = 5;
          goto _L1
_L9:
        String s9 = intent.getStringExtra("ENCODE_DATA");
        if(s9 != null && !s9.isEmpty())
        {
            contents = s9;
            displayContents = s9;
            title = activity.getString(com.google.zxing.client.android.R.string.contents_text);
        }
          goto _L8
_L10:
        String s8 = ContactEncoder.trim(intent.getStringExtra("ENCODE_DATA"));
        if(s8 != null)
        {
            contents = (new StringBuilder()).append("mailto:").append(s8).toString();
            displayContents = s8;
            title = activity.getString(com.google.zxing.client.android.R.string.contents_email);
        }
          goto _L8
_L11:
        String s7 = ContactEncoder.trim(intent.getStringExtra("ENCODE_DATA"));
        if(s7 != null)
        {
            contents = (new StringBuilder()).append("tel:").append(s7).toString();
            displayContents = PhoneNumberUtils.formatNumber(s7);
            title = activity.getString(com.google.zxing.client.android.R.string.contents_phone);
        }
          goto _L8
_L12:
        String s6 = ContactEncoder.trim(intent.getStringExtra("ENCODE_DATA"));
        if(s6 != null)
        {
            contents = (new StringBuilder()).append("sms:").append(s6).toString();
            displayContents = PhoneNumberUtils.formatNumber(s6);
            title = activity.getString(com.google.zxing.client.android.R.string.contents_sms);
        }
          goto _L8
_L13:
        Bundle bundle1 = intent.getBundleExtra("ENCODE_DATA");
        if(bundle1 != null)
        {
            String s1 = bundle1.getString("name");
            String s2 = bundle1.getString("company");
            String s3 = bundle1.getString("postal");
            List list = getAllBundleValues(bundle1, Contents.PHONE_KEYS);
            List list1 = getAllBundleValues(bundle1, Contents.PHONE_TYPE_KEYS);
            List list2 = getAllBundleValues(bundle1, Contents.EMAIL_KEYS);
            String s4 = bundle1.getString("URL_KEY");
            List list3;
            String s5;
            Object obj;
            String as[];
            if(s4 == null)
                list3 = null;
            else
                list3 = Collections.singletonList(s4);
            s5 = bundle1.getString("NOTE_KEY");
            if(useVCard)
                obj = new VCardContactEncoder();
            else
                obj = new MECARDContactEncoder();
            as = ((ContactEncoder) (obj)).encode(Collections.singletonList(s1), s2, Collections.singletonList(s3), list, list1, list2, list3, s5);
            if(!as[1].isEmpty())
            {
                contents = as[0];
                displayContents = as[1];
                title = activity.getString(com.google.zxing.client.android.R.string.contents_contact);
            }
        }
          goto _L8
_L14:
        Bundle bundle = intent.getBundleExtra("ENCODE_DATA");
        if(bundle != null)
        {
            float f = bundle.getFloat("LAT", 3.402823E+038F);
            float f1 = bundle.getFloat("LONG", 3.402823E+038F);
            if(f != 3.402823E+038F && f1 != 3.402823E+038F)
            {
                contents = (new StringBuilder()).append("geo:").append(f).append(',').append(f1).toString();
                displayContents = (new StringBuilder()).append(f).append(",").append(f1).toString();
                title = activity.getString(com.google.zxing.client.android.R.string.contents_location);
            }
        }
          goto _L8
    }

    private void encodeQRCodeContents(AddressBookParsedResult addressbookparsedresult)
    {
        Object obj;
        String as[];
        if(useVCard)
            obj = new VCardContactEncoder();
        else
            obj = new MECARDContactEncoder();
        as = ((ContactEncoder) (obj)).encode(toList(addressbookparsedresult.getNames()), addressbookparsedresult.getOrg(), toList(addressbookparsedresult.getAddresses()), toList(addressbookparsedresult.getPhoneNumbers()), null, toList(addressbookparsedresult.getEmails()), toList(addressbookparsedresult.getURLs()), null);
        if(!as[1].isEmpty())
        {
            contents = as[0];
            displayContents = as[1];
            title = activity.getString(com.google.zxing.client.android.R.string.contents_contact);
        }
    }

    private static List getAllBundleValues(Bundle bundle, String as[])
    {
        ArrayList arraylist = new ArrayList(as.length);
        int i = as.length;
        int j = 0;
        while(j < i) 
        {
            Object obj = bundle.get(as[j]);
            String s;
            if(obj == null)
                s = null;
            else
                s = obj.toString();
            arraylist.add(s);
            j++;
        }
        return arraylist;
    }

    private static String guessAppropriateEncoding(CharSequence charsequence)
    {
        int i = 0;
_L3:
        if(i >= charsequence.length())
            break MISSING_BLOCK_LABEL_36;
        if(charsequence.charAt(i) <= '\377') goto _L2; else goto _L1
_L1:
        String s = "UTF-8";
_L4:
        return s;
_L2:
        i++;
          goto _L3
        s = null;
          goto _L4
    }

    private static List toList(String as[])
    {
        List list;
        if(as == null)
            list = null;
        else
            list = Arrays.asList(as);
        return list;
    }

    public Bitmap encodeAsBitmap()
        throws WriterException
    {
        String s = contents;
        if(s != null) goto _L2; else goto _L1
_L1:
        Bitmap bitmap = null;
_L4:
        return bitmap;
_L2:
        String s1 = guessAppropriateEncoding(s);
        if(hints == null && s1 != null)
        {
            hints = new EnumMap(com/google/zxing/EncodeHintType);
            hints.put(EncodeHintType.CHARACTER_SET, s1);
        }
        BitMatrix bitmatrix;
        int i;
        int j;
        int ai[];
        int k;
        try
        {
            bitmatrix = (new MultiFormatWriter()).encode(s, format, width, height, hints);
        }
        catch(IllegalArgumentException illegalargumentexception)
        {
            bitmap = null;
            continue; /* Loop/switch isn't completed */
        }
        i = bitmatrix.getWidth();
        j = bitmatrix.getHeight();
        ai = new int[i * j];
        k = 0;
        do
        {
            if(k >= j)
                break;
            int l = k * i;
            int i1 = 0;
            while(i1 < i) 
            {
                int j1 = l + i1;
                int k1;
                if(bitmatrix.get(i1, k))
                    k1 = 0xff000000;
                else
                    k1 = -1;
                ai[j1] = k1;
                i1++;
            }
            k++;
        } while(true);
        bitmap = Bitmap.createBitmap(i, j, android.graphics.Bitmap.Config.ARGB_8888);
        bitmap.setPixels(ai, 0, i, 0, 0, i, j);
        if(true) goto _L4; else goto _L3
_L3:
    }

    String getContents()
    {
        return contents;
    }

    String getDisplayContents()
    {
        return displayContents;
    }

    String getTitle()
    {
        return title;
    }

    boolean isUseVCard()
    {
        return useVCard;
    }

}
