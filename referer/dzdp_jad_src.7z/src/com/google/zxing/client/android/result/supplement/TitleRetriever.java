// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.client.android.result.supplement;

import android.text.Html;
import android.widget.TextView;
import com.google.zxing.client.android.HttpHelper;
import com.google.zxing.client.result.URIParsedResult;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

// Referenced classes of package com.google.zxing.client.android.result.supplement:
//            SupplementalInfoRetriever

final class TitleRetriever extends SupplementalInfoRetriever
{

    private static final int MAX_TITLE_LEN = 100;
    private static final Pattern TITLE_PATTERN = Pattern.compile("<title>([^<]+)");
    private final String httpUrl;

    TitleRetriever(TextView textview, URIParsedResult uriparsedresult)
    {
        super(textview);
        httpUrl = uriparsedresult.getURI();
    }

    void retrieveSupplementalInfo()
    {
        CharSequence charsequence = HttpHelper.downloadViaHttp(httpUrl, com.google.zxing.client.android.HttpHelper.ContentType.HTML, 4096);
        if(charsequence != null && charsequence.length() > 0)
        {
            Matcher matcher = TITLE_PATTERN.matcher(charsequence);
            if(matcher.find())
            {
                String s = matcher.group(1);
                if(s != null && !s.isEmpty())
                {
                    String s1 = Html.fromHtml(s).toString();
                    if(s1.length() > 100)
                        s1 = (new StringBuilder()).append(s1.substring(0, 100)).append("...").toString();
                    String s2 = httpUrl;
                    String as[] = new String[1];
                    as[0] = s1;
                    append(s2, null, as, httpUrl);
                }
            }
        }
_L2:
        return;
        IOException ioexception;
        ioexception;
        if(true) goto _L2; else goto _L1
_L1:
    }

}
