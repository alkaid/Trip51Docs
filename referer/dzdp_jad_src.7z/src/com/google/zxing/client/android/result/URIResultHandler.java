// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.client.android.result;

import android.app.Activity;
import com.google.zxing.client.android.LocaleManager;
import com.google.zxing.client.result.ParsedResult;
import com.google.zxing.client.result.URIParsedResult;
import java.util.Locale;

// Referenced classes of package com.google.zxing.client.android.result:
//            ResultHandler

public final class URIResultHandler extends ResultHandler
{

    private static final String SECURE_PROTOCOLS[];
    private static final int buttons[];

    public URIResultHandler(Activity activity, ParsedResult parsedresult)
    {
        super(activity, parsedresult);
    }

    public boolean areContentsSecure()
    {
        String s;
        String as[];
        int i;
        int j;
        s = ((URIParsedResult)getResult()).getURI().toLowerCase(Locale.ENGLISH);
        as = SECURE_PROTOCOLS;
        i = as.length;
        j = 0;
_L3:
        if(j >= i)
            break MISSING_BLOCK_LABEL_56;
        if(!s.startsWith(as[j])) goto _L2; else goto _L1
_L1:
        boolean flag = true;
_L4:
        return flag;
_L2:
        j++;
          goto _L3
        flag = false;
          goto _L4
    }

    public int getButtonCount()
    {
        int i;
        if(LocaleManager.isBookSearchUrl(((URIParsedResult)getResult()).getURI()))
            i = buttons.length;
        else
            i = -1 + buttons.length;
        return i;
    }

    public int getButtonText(int i)
    {
        return buttons[i];
    }

    public Integer getDefaultButtonID()
    {
        return Integer.valueOf(0);
    }

    public int getDisplayTitle()
    {
        return com.google.zxing.client.android.R.string.result_uri;
    }

    public void handleButtonPress(int i)
    {
        String s = ((URIParsedResult)getResult()).getURI();
        i;
        JVM INSTR tableswitch 0 2: default 40
    //                   0 41
    //                   1 49
    //                   2 57;
           goto _L1 _L2 _L3 _L4
_L1:
        return;
_L2:
        openURL(s);
        continue; /* Loop/switch isn't completed */
_L3:
        shareByEmail(s);
        continue; /* Loop/switch isn't completed */
_L4:
        shareBySMS(s);
        if(true) goto _L1; else goto _L5
_L5:
    }

    static 
    {
        String as[] = new String[1];
        as[0] = "otpauth:";
        SECURE_PROTOCOLS = as;
        int ai[] = new int[3];
        ai[0] = com.google.zxing.client.android.R.string.button_open_browser;
        ai[1] = com.google.zxing.client.android.R.string.button_share_by_email;
        ai[2] = com.google.zxing.client.android.R.string.button_share_by_sms;
        buttons = ai;
    }
}
