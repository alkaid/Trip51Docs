// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.client.android.result;

import android.app.Activity;
import android.telephony.PhoneNumberUtils;
import com.google.zxing.client.result.ParsedResult;
import com.google.zxing.client.result.SMSParsedResult;

// Referenced classes of package com.google.zxing.client.android.result:
//            ResultHandler

public final class SMSResultHandler extends ResultHandler
{

    private static final int buttons[];

    public SMSResultHandler(Activity activity, ParsedResult parsedresult)
    {
        super(activity, parsedresult);
    }

    public int getButtonCount()
    {
        return buttons.length;
    }

    public int getButtonText(int i)
    {
        return buttons[i];
    }

    public CharSequence getDisplayContents()
    {
        SMSParsedResult smsparsedresult = (SMSParsedResult)getResult();
        String as[] = smsparsedresult.getNumbers();
        String as1[] = new String[as.length];
        for(int i = 0; i < as.length; i++)
            as1[i] = PhoneNumberUtils.formatNumber(as[i]);

        StringBuilder stringbuilder = new StringBuilder(50);
        ParsedResult.maybeAppend(as1, stringbuilder);
        ParsedResult.maybeAppend(smsparsedresult.getSubject(), stringbuilder);
        ParsedResult.maybeAppend(smsparsedresult.getBody(), stringbuilder);
        return stringbuilder.toString();
    }

    public int getDisplayTitle()
    {
        return com.google.zxing.client.android.R.string.result_sms;
    }

    public void handleButtonPress(int i)
    {
        SMSParsedResult smsparsedresult;
        String s;
        smsparsedresult = (SMSParsedResult)getResult();
        s = smsparsedresult.getNumbers()[0];
        i;
        JVM INSTR tableswitch 0 1: default 40
    //                   0 41
    //                   1 53;
           goto _L1 _L2 _L3
_L1:
        return;
_L2:
        sendSMS(s, smsparsedresult.getBody());
        continue; /* Loop/switch isn't completed */
_L3:
        sendMMS(s, smsparsedresult.getSubject(), smsparsedresult.getBody());
        if(true) goto _L1; else goto _L4
_L4:
    }

    static 
    {
        int ai[] = new int[2];
        ai[0] = com.google.zxing.client.android.R.string.button_sms;
        ai[1] = com.google.zxing.client.android.R.string.button_mms;
        buttons = ai;
    }
}
