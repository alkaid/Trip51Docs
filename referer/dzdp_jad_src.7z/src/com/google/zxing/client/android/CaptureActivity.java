// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.client.android;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.*;
import android.net.Uri;
import android.os.*;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.*;
import android.widget.TextView;
import android.widget.Toast;
import com.google.zxing.*;
import com.google.zxing.client.android.camera.CameraManager;
import com.google.zxing.client.android.result.ResultHandler;
import com.google.zxing.client.android.result.ResultHandlerFactory;
import com.google.zxing.client.android.result.supplement.SupplementalInfoRetriever;
import com.google.zxing.client.result.*;
import java.io.IOException;
import java.net.URLEncoder;
import java.text.DateFormat;
import java.util.*;

// Referenced classes of package com.google.zxing.client.android:
//            ViewfinderView, CaptureActivityHandler, FinishListener, InactivityTimer, 
//            BeepManager, IntentSource, ScanFromWebPageManager, AmbientLightManager, 
//            DecodeFormatManager, DecodeHintManager

public class CaptureActivity extends Activity
    implements android.view.SurfaceHolder.Callback
{

    private static final long BULK_MODE_SCAN_DELAY_MS = 1000L;
    private static final long DEFAULT_INTENT_RESULT_DURATION_MS = 1500L;
    private static final Collection DISPLAYABLE_METADATA_TYPES;
    private static final String PRODUCT_SEARCH_URL_PREFIX = "http://www.google";
    private static final String PRODUCT_SEARCH_URL_SUFFIX = "/m/products/scan";
    private static final int REQUEST_CHECK_URL = 1;
    private static final String TAG = com/google/zxing/client/android/CaptureActivity.getSimpleName();
    private static final String ZXING_URLS[];
    private AmbientLightManager ambientLightManager;
    private BeepManager beepManager;
    private CameraManager cameraManager;
    private String characterSet;
    private Collection decodeFormats;
    private Map decodeHints;
    private CaptureActivityHandler handler;
    private boolean hasSurface;
    private InactivityTimer inactivityTimer;
    private Result lastResult;
    private View resultView;
    private Result savedResultToShow;
    private ScanFromWebPageManager scanFromWebPageManager;
    private IntentSource source;
    private String sourceUrl;
    private TextView statusView;
    private ViewfinderView viewfinderView;

    public CaptureActivity()
    {
    }

    private void clearScanFrame()
    {
        if(statusView != null)
            statusView.setVisibility(8);
        viewfinderView.setVisibility(8);
    }

    private void decodeOrStoreSavedBitmap(Bitmap bitmap, Result result)
    {
        if(handler == null)
        {
            savedResultToShow = result;
        } else
        {
            if(result != null)
                savedResultToShow = result;
            if(savedResultToShow != null)
            {
                Message message = Message.obtain(handler, R.id.decode_succeeded, savedResultToShow);
                handler.sendMessage(message);
            }
            savedResultToShow = null;
        }
    }

    private void displayFrameworkBugMessageAndExit()
    {
        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        builder.setTitle(getString(R.string.app_name));
        builder.setMessage(getString(R.string.msg_camera_framework_bug));
        builder.setPositiveButton(R.string.button_ok, new FinishListener(this));
        builder.setOnCancelListener(new FinishListener(this));
        builder.show();
    }

    private static void drawLine(Canvas canvas, Paint paint, ResultPoint resultpoint, ResultPoint resultpoint1, float f)
    {
        if(resultpoint != null && resultpoint1 != null)
            canvas.drawLine(f * resultpoint.getX(), f * resultpoint.getY(), f * resultpoint1.getX(), f * resultpoint1.getY(), paint);
    }

    private void drawResultPoints(Bitmap bitmap, float f, Result result)
    {
        ResultPoint aresultpoint[] = result.getResultPoints();
        if(aresultpoint == null || aresultpoint.length <= 0) goto _L2; else goto _L1
_L1:
        Canvas canvas;
        Paint paint;
        canvas = new Canvas(bitmap);
        paint = new Paint();
        paint.setColor(getResources().getColor(R.color.result_points));
        if(aresultpoint.length != 2) goto _L4; else goto _L3
_L3:
        paint.setStrokeWidth(4F);
        drawLine(canvas, paint, aresultpoint[0], aresultpoint[1], f);
_L2:
        return;
_L4:
        if(aresultpoint.length != 4 || result.getBarcodeFormat() != BarcodeFormat.UPC_A && result.getBarcodeFormat() != BarcodeFormat.EAN_13)
            break; /* Loop/switch isn't completed */
        drawLine(canvas, paint, aresultpoint[0], aresultpoint[1], f);
        drawLine(canvas, paint, aresultpoint[2], aresultpoint[3], f);
        if(true) goto _L2; else goto _L5
_L5:
        paint.setStrokeWidth(10F);
        int i = aresultpoint.length;
        int j = 0;
        while(j < i) 
        {
            ResultPoint resultpoint = aresultpoint[j];
            if(resultpoint != null)
                canvas.drawPoint(f * resultpoint.getX(), f * resultpoint.getY(), paint);
            j++;
        }
        if(true) goto _L2; else goto _L6
_L6:
    }

    private void initCamera(SurfaceHolder surfaceholder)
    {
        if(surfaceholder == null)
            throw new IllegalStateException("No SurfaceHolder provided");
        if(cameraManager.isOpen())
            Log.w(TAG, "initCamera() while already open -- late SurfaceView callback?");
        else
            try
            {
                cameraManager.openDriver(surfaceholder);
                if(handler == null)
                    handler = new CaptureActivityHandler(this, decodeFormats, decodeHints, characterSet, cameraManager);
                decodeOrStoreSavedBitmap(null, null);
            }
            catch(IOException ioexception)
            {
                Log.w(TAG, ioexception);
                displayFrameworkBugMessageAndExit();
            }
            catch(RuntimeException runtimeexception)
            {
                Log.w(TAG, "Unexpected error initializing camera", runtimeexception);
                displayFrameworkBugMessageAndExit();
            }
    }

    private static boolean isZXingURL(String s)
    {
        boolean flag = false;
        if(s != null) goto _L2; else goto _L1
_L1:
        return flag;
_L2:
        String as[] = ZXING_URLS;
        int i = as.length;
        int j = 0;
        do
        {
            if(j < i)
            {
label0:
                {
                    if(!s.startsWith(as[j]))
                        break label0;
                    flag = true;
                }
            }
            if(true)
                continue;
            j++;
        } while(true);
        if(true) goto _L1; else goto _L3
_L3:
    }

    private void resetStatusView()
    {
        if(resultView != null)
            resultView.setVisibility(8);
        if(statusView != null)
        {
            statusView.setText(R.string.msg_default_status);
            statusView.setVisibility(0);
        }
        viewfinderView.setVisibility(0);
        lastResult = null;
    }

    private void sendReplyMessage(int i, Object obj, long l)
    {
        if(handler != null)
        {
            Message message = Message.obtain(handler, i, obj);
            if(l > 0L)
                handler.sendMessageDelayed(message, l);
            else
                handler.sendMessage(message);
        }
    }

    public void drawViewfinder()
    {
        viewfinderView.drawViewfinder();
    }

    CameraManager getCameraManager()
    {
        return cameraManager;
    }

    public Handler getHandler()
    {
        return handler;
    }

    ViewfinderView getViewfinderView()
    {
        return viewfinderView;
    }

    public void handleDecode(Result result, Bitmap bitmap, float f)
    {
        ResultHandler resulthandler;
        boolean flag;
        inactivityTimer.onActivity();
        lastResult = result;
        resulthandler = ResultHandlerFactory.makeResultHandler(this, result);
        class _cls1
        {

            static final int $SwitchMap$com$google$zxing$client$android$IntentSource[];

            static 
            {
                $SwitchMap$com$google$zxing$client$android$IntentSource = new int[IntentSource.values().length];
                NoSuchFieldError nosuchfielderror3;
                try
                {
                    $SwitchMap$com$google$zxing$client$android$IntentSource[IntentSource.NATIVE_APP_INTENT.ordinal()] = 1;
                }
                catch(NoSuchFieldError nosuchfielderror) { }
                try
                {
                    $SwitchMap$com$google$zxing$client$android$IntentSource[IntentSource.PRODUCT_SEARCH_LINK.ordinal()] = 2;
                }
                catch(NoSuchFieldError nosuchfielderror1) { }
                try
                {
                    $SwitchMap$com$google$zxing$client$android$IntentSource[IntentSource.ZXING_LINK.ordinal()] = 3;
                }
                catch(NoSuchFieldError nosuchfielderror2) { }
                $SwitchMap$com$google$zxing$client$android$IntentSource[IntentSource.NONE.ordinal()] = 4;
_L2:
                return;
                nosuchfielderror3;
                if(true) goto _L2; else goto _L1
_L1:
            }
        }

        if(bitmap != null)
            flag = true;
        else
            flag = false;
        if(flag)
        {
            beepManager.playBeepSoundAndVibrate();
            drawResultPoints(bitmap, f, result);
        }
        _cls1..SwitchMap.com.google.zxing.client.android.IntentSource[source.ordinal()];
        JVM INSTR tableswitch 1 4: default 88
    //                   1 99
    //                   2 99
    //                   3 110
    //                   4 149;
           goto _L1 _L2 _L2 _L3 _L4
_L1:
        clearScanFrame();
        return;
_L2:
        handleDecodeExternally(result, resulthandler, bitmap);
        continue; /* Loop/switch isn't completed */
_L3:
        if(scanFromWebPageManager == null || !scanFromWebPageManager.isScanFromWebPage())
            handleDecodeInternally(result, resulthandler, bitmap);
        else
            handleDecodeExternally(result, resulthandler, bitmap);
        continue; /* Loop/switch isn't completed */
_L4:
        SharedPreferences sharedpreferences = PreferenceManager.getDefaultSharedPreferences(this);
        if(flag && sharedpreferences.getBoolean("preferences_bulk_mode", false))
        {
            Toast.makeText(getApplicationContext(), (new StringBuilder()).append(getResources().getString(R.string.msg_bulk_mode_scanned)).append(" (").append(result.getText()).append(')').toString(), 0).show();
            restartPreviewAfterDelay(1000L);
        } else
        {
            handleDecodeInternally(result, resulthandler, bitmap);
        }
        if(true) goto _L1; else goto _L5
_L5:
    }

    public void handleDecodeExternally(Result result, ResultHandler resulthandler, Bitmap bitmap)
    {
        long l;
        if(bitmap != null)
            viewfinderView.drawResultBitmap(bitmap);
        byte abyte0[];
        Map map;
        Number number;
        String s;
        Iterable iterable;
        int i;
        Iterator iterator;
        byte abyte1[];
        if(getIntent() == null)
            l = 1500L;
        else
            l = getIntent().getLongExtra("RESULT_DISPLAY_DURATION_MS", 1500L);
        if(l > 0L)
        {
            String s3 = String.valueOf(result);
            if(s3.length() > 32)
                s3 = (new StringBuilder()).append(s3.substring(0, 32)).append(" ...").toString();
            if(statusView != null)
                statusView.setText((new StringBuilder()).append(getString(resulthandler.getDisplayTitle())).append(" : ").append(s3).toString());
        }
        if(source != IntentSource.NATIVE_APP_INTENT) goto _L2; else goto _L1
_L1:
        Intent intent = new Intent(getIntent().getAction());
        intent.addFlags(0x80000);
        intent.putExtra("SCAN_RESULT", result.toString());
        intent.putExtra("SCAN_RESULT_FORMAT", result.getBarcodeFormat().toString());
        abyte0 = result.getRawBytes();
        if(abyte0 != null && abyte0.length > 0)
            intent.putExtra("SCAN_RESULT_BYTES", abyte0);
        map = result.getResultMetadata();
        if(map != null)
        {
            if(map.containsKey(ResultMetadataType.UPC_EAN_EXTENSION))
                intent.putExtra("SCAN_RESULT_UPC_EAN_EXTENSION", map.get(ResultMetadataType.UPC_EAN_EXTENSION).toString());
            number = (Number)map.get(ResultMetadataType.ORIENTATION);
            if(number != null)
                intent.putExtra("SCAN_RESULT_ORIENTATION", number.intValue());
            s = (String)map.get(ResultMetadataType.ERROR_CORRECTION_LEVEL);
            if(s != null)
                intent.putExtra("SCAN_RESULT_ERROR_CORRECTION_LEVEL", s);
            iterable = (Iterable)map.get(ResultMetadataType.BYTE_SEGMENTS);
            if(iterable != null)
            {
                i = 0;
                for(iterator = iterable.iterator(); iterator.hasNext();)
                {
                    abyte1 = (byte[])iterator.next();
                    intent.putExtra((new StringBuilder()).append("SCAN_RESULT_BYTE_SEGMENTS_").append(i).toString(), abyte1);
                    i++;
                }

            }
        }
        sendReplyMessage(R.id.return_scan_result, intent, l);
_L4:
        return;
_L2:
        if(source == IntentSource.PRODUCT_SEARCH_LINK)
        {
            int j = sourceUrl.lastIndexOf("/scan");
            String s2 = (new StringBuilder()).append(sourceUrl.substring(0, j)).append("?q=").append(resulthandler.getDisplayContents()).append("&source=zxing").toString();
            sendReplyMessage(R.id.launch_product_query, s2, l);
        } else
        if(source == IntentSource.ZXING_LINK && scanFromWebPageManager != null && scanFromWebPageManager.isScanFromWebPage())
        {
            String s1 = scanFromWebPageManager.buildReplyURL(result, resulthandler);
            scanFromWebPageManager = null;
            sendReplyMessage(R.id.launch_product_query, s1, l);
        }
        if(true) goto _L4; else goto _L3
_L3:
    }

    public void handleDecodeInternally(Result result, ResultHandler resulthandler, Bitmap bitmap)
    {
        URIParsedResult uriparsedresult;
        ParsedResult parsedresult = ResultParser.parseResult(result);
        if(!parsedresult.getType().equals(ParsedResultType.URI))
            break MISSING_BLOCK_LABEL_161;
        uriparsedresult = (URIParsedResult)parsedresult;
        Uri uri = Uri.parse(uriparsedresult.getURI());
        Log.i(TAG, (new StringBuilder()).append("scan uri: ").append(uri).toString());
        if(uri != null)
        {
            Uri uri1 = Uri.parse((new StringBuilder()).append("dianping://parseqrurl?qrurl=").append(URLEncoder.encode(uri.toString(), "utf-8")).toString());
            Log.i(TAG, (new StringBuilder()).append("startActivity with url ").append(uri1).toString());
            startActivityForResult(new Intent("android.intent.action.VIEW", uri1), 1);
        }
_L1:
        return;
        Exception exception;
        exception;
        exception.printStackTrace();
          goto _L1
        CharSequence charsequence = resulthandler.getDisplayContents();
        SharedPreferences sharedpreferences = PreferenceManager.getDefaultSharedPreferences(this);
        if(resulthandler.getDefaultButtonID() != null && sharedpreferences.getBoolean("preferences_auto_open_web", false))
        {
            resulthandler.handleButtonPress(resulthandler.getDefaultButtonID().intValue());
        } else
        {
            clearScanFrame();
            if(resultView != null)
                resultView.setVisibility(0);
            ((TextView)findViewById(R.id.format_text_view)).setText(result.getBarcodeFormat().toString());
            ((TextView)findViewById(R.id.type_text_view)).setText(resulthandler.getType().toString());
            DateFormat dateformat = DateFormat.getDateTimeInstance(3, 3);
            TextView textview = (TextView)findViewById(R.id.time_text_view);
            Date date = new Date(result.getTimestamp());
            textview.setText(dateformat.format(date));
            TextView textview1 = (TextView)findViewById(R.id.meta_text_view);
            View view = findViewById(R.id.meta_text_view_label);
            textview1.setVisibility(8);
            view.setVisibility(8);
            Map map = result.getResultMetadata();
            if(map != null)
            {
                StringBuilder stringbuilder = new StringBuilder(20);
                Iterator iterator = map.entrySet().iterator();
                do
                {
                    if(!iterator.hasNext())
                        break;
                    java.util.Map.Entry entry = (java.util.Map.Entry)iterator.next();
                    if(DISPLAYABLE_METADATA_TYPES.contains(entry.getKey()))
                        stringbuilder.append(entry.getValue()).append('\n');
                } while(true);
                if(stringbuilder.length() > 0)
                {
                    stringbuilder.setLength(-1 + stringbuilder.length());
                    textview1.setText(stringbuilder);
                    textview1.setVisibility(0);
                    view.setVisibility(0);
                }
            }
            TextView textview2 = (TextView)findViewById(R.id.contents_text_view);
            textview2.setText(charsequence);
            textview2.setTextSize(2, Math.max(22, 32 - charsequence.length() / 4));
            TextView textview3 = (TextView)findViewById(R.id.contents_supplement_text_view);
            textview3.setText("");
            textview3.setOnClickListener(null);
            if(PreferenceManager.getDefaultSharedPreferences(this).getBoolean("preferences_supplemental", true))
                SupplementalInfoRetriever.maybeInvokeRetrieval(textview3, resulthandler.getResult(), this);
        }
          goto _L1
    }

    public void onActivityResult(int i, int j, Intent intent)
    {
        super.onActivityResult(i, j, intent);
        if(i == 1 && j == -1)
            finish();
    }

    public void onCreate(Bundle bundle)
    {
        super.onCreate(bundle);
        getWindow().addFlags(128);
        setContentView(R.layout.capture);
        hasSurface = false;
        inactivityTimer = new InactivityTimer(this);
        beepManager = new BeepManager(this);
        ambientLightManager = new AmbientLightManager(this);
        PreferenceManager.setDefaultValues(this, R.xml.preferences, false);
        if(getResources().getConfiguration().orientation == 1)
            setRequestedOrientation(1);
        else
            setRequestedOrientation(0);
    }

    protected void onDestroy()
    {
        inactivityTimer.shutdown();
        super.onDestroy();
    }

    public boolean onKeyDown(int i, KeyEvent keyevent)
    {
        boolean flag = true;
        i;
        JVM INSTR lookupswitch 5: default 52
    //                   4: 61
    //                   24: 129
    //                   25: 118
    //                   27: 59
    //                   80: 59;
           goto _L1 _L2 _L3 _L4 _L5 _L5
_L3:
        break MISSING_BLOCK_LABEL_129;
_L5:
        break; /* Loop/switch isn't completed */
_L1:
        flag = super.onKeyDown(i, keyevent);
_L6:
        return flag;
_L2:
        if(source != IntentSource.NATIVE_APP_INTENT)
            continue; /* Loop/switch isn't completed */
        setResult(0);
        finish();
          goto _L6
        if(source != IntentSource.NONE && source != IntentSource.ZXING_LINK || lastResult == null) goto _L1; else goto _L7
_L7:
        restartPreviewAfterDelay(0L);
          goto _L6
_L4:
        cameraManager.setTorch(false);
          goto _L6
        cameraManager.setTorch(flag);
          goto _L6
    }

    protected void onPause()
    {
        if(handler != null)
        {
            handler.quitSynchronously();
            handler = null;
        }
        inactivityTimer.onPause();
        ambientLightManager.stop();
        beepManager.close();
        cameraManager.closeDriver();
        if(!hasSurface)
            ((SurfaceView)findViewById(R.id.preview_view)).getHolder().removeCallback(this);
        clearScanFrame();
        super.onPause();
    }

    protected void onResume()
    {
        super.onResume();
        cameraManager = new CameraManager(getApplication());
        viewfinderView = (ViewfinderView)findViewById(R.id.viewfinder_view);
        viewfinderView.setCameraManager(cameraManager);
        resultView = findViewById(R.id.result_view);
        statusView = (TextView)findViewById(R.id.status_view);
        handler = null;
        lastResult = null;
        resetStatusView();
        beepManager.updatePrefs();
        ambientLightManager.start(cameraManager);
        inactivityTimer.onResume();
        Intent intent = getIntent();
        source = IntentSource.NONE;
        sourceUrl = null;
        scanFromWebPageManager = null;
        decodeFormats = null;
        characterSet = null;
        SurfaceHolder surfaceholder;
        if(intent != null)
        {
            String s = intent.getAction();
            String s1 = intent.getDataString();
            if("com.google.zxing.client.android.SCAN".equals(s))
            {
                source = IntentSource.NATIVE_APP_INTENT;
                decodeFormats = DecodeFormatManager.parseDecodeFormats(intent);
                decodeHints = DecodeHintManager.parseDecodeHints(intent);
                if(intent.hasExtra("SCAN_WIDTH") && intent.hasExtra("SCAN_HEIGHT"))
                {
                    int j = intent.getIntExtra("SCAN_WIDTH", 0);
                    int k = intent.getIntExtra("SCAN_HEIGHT", 0);
                    if(j > 0 && k > 0)
                        cameraManager.setManualFramingRect(j, k);
                }
                if(intent.hasExtra("SCAN_CAMERA_ID"))
                {
                    int i = intent.getIntExtra("SCAN_CAMERA_ID", -1);
                    if(i >= 0)
                        cameraManager.setManualCameraId(i);
                }
                String s2 = intent.getStringExtra("PROMPT_MESSAGE");
                if(s2 != null && statusView != null)
                    statusView.setText(s2);
            } else
            if(s1 != null && s1.contains("http://www.google") && s1.contains("/m/products/scan"))
            {
                source = IntentSource.PRODUCT_SEARCH_LINK;
                sourceUrl = s1;
                decodeFormats = DecodeFormatManager.PRODUCT_FORMATS;
            } else
            if(isZXingURL(s1))
            {
                source = IntentSource.ZXING_LINK;
                sourceUrl = s1;
                Uri uri = Uri.parse(s1);
                scanFromWebPageManager = new ScanFromWebPageManager(uri);
                decodeFormats = DecodeFormatManager.parseDecodeFormats(uri);
                decodeHints = DecodeHintManager.parseDecodeHints(uri);
            }
            characterSet = intent.getStringExtra("CHARACTER_SET");
        }
        surfaceholder = ((SurfaceView)findViewById(R.id.preview_view)).getHolder();
        if(hasSurface)
        {
            initCamera(surfaceholder);
        } else
        {
            surfaceholder.addCallback(this);
            if(android.os.Build.VERSION.SDK_INT < 11)
                surfaceholder.setType(3);
        }
    }

    public void restartPreviewAfterDelay(long l)
    {
        if(handler != null)
            handler.sendEmptyMessageDelayed(R.id.restart_preview, l);
        resetStatusView();
    }

    public void surfaceChanged(SurfaceHolder surfaceholder, int i, int j, int k)
    {
    }

    public void surfaceCreated(SurfaceHolder surfaceholder)
    {
        if(surfaceholder == null)
            Log.e(TAG, "*** WARNING *** surfaceCreated() gave us a null surface!");
        if(!hasSurface)
        {
            hasSurface = true;
            initCamera(surfaceholder);
        }
    }

    public void surfaceDestroyed(SurfaceHolder surfaceholder)
    {
        hasSurface = false;
    }

    static 
    {
        String as[] = new String[2];
        as[0] = "http://zxing.appspot.com/scan";
        as[1] = "zxing://scan/";
        ZXING_URLS = as;
        DISPLAYABLE_METADATA_TYPES = EnumSet.of(ResultMetadataType.ISSUE_NUMBER, ResultMetadataType.SUGGESTED_PRICE, ResultMetadataType.ERROR_CORRECTION_LEVEL, ResultMetadataType.POSSIBLE_COUNTRY);
    }
}
