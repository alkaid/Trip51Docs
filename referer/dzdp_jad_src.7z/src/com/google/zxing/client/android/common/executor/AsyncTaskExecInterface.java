// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.client.android.common.executor;

import android.os.AsyncTask;

public interface AsyncTaskExecInterface
{

    public transient abstract void execute(AsyncTask asynctask, Object aobj[]);
}
