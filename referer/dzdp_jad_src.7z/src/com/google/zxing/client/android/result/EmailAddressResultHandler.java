// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.client.android.result;

import android.app.Activity;
import com.google.zxing.client.result.EmailAddressParsedResult;
import com.google.zxing.client.result.ParsedResult;

// Referenced classes of package com.google.zxing.client.android.result:
//            ResultHandler

public final class EmailAddressResultHandler extends ResultHandler
{

    private static final int buttons[];

    public EmailAddressResultHandler(Activity activity, ParsedResult parsedresult)
    {
        super(activity, parsedresult);
    }

    public int getButtonCount()
    {
        return buttons.length;
    }

    public int getButtonText(int i)
    {
        return buttons[i];
    }

    public int getDisplayTitle()
    {
        return com.google.zxing.client.android.R.string.result_email_address;
    }

    public void handleButtonPress(int i)
    {
        EmailAddressParsedResult emailaddressparsedresult = (EmailAddressParsedResult)getResult();
        i;
        JVM INSTR tableswitch 0 1: default 32
    //                   0 33
    //                   1 60;
           goto _L1 _L2 _L3
_L1:
        return;
_L2:
        sendEmail(emailaddressparsedresult.getTos(), emailaddressparsedresult.getCCs(), emailaddressparsedresult.getBCCs(), emailaddressparsedresult.getSubject(), emailaddressparsedresult.getBody());
        continue; /* Loop/switch isn't completed */
_L3:
        addEmailOnlyContact(emailaddressparsedresult.getTos(), null);
        if(true) goto _L1; else goto _L4
_L4:
    }

    static 
    {
        int ai[] = new int[2];
        ai[0] = com.google.zxing.client.android.R.string.button_email;
        ai[1] = com.google.zxing.client.android.R.string.button_add_contact;
        buttons = ai;
    }
}
