// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.client.android;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import com.google.zxing.DecodeHintType;
import java.util.*;
import java.util.regex.Pattern;

final class DecodeHintManager
{

    private static final Pattern COMMA = Pattern.compile(",");
    private static final String TAG = com/google/zxing/client/android/DecodeHintManager.getSimpleName();

    private DecodeHintManager()
    {
    }

    static Map parseDecodeHints(Intent intent)
    {
        Bundle bundle = intent.getExtras();
        if(bundle != null && !bundle.isEmpty()) goto _L2; else goto _L1
_L1:
        Object obj = null;
_L4:
        return ((Map) (obj));
_L2:
        obj = new EnumMap(com/google/zxing/DecodeHintType);
        DecodeHintType adecodehinttype[] = DecodeHintType.values();
        int i = adecodehinttype.length;
        int j = 0;
        while(j < i) 
        {
            DecodeHintType decodehinttype = adecodehinttype[j];
            if(decodehinttype != DecodeHintType.CHARACTER_SET && decodehinttype != DecodeHintType.NEED_RESULT_POINT_CALLBACK && decodehinttype != DecodeHintType.POSSIBLE_FORMATS)
            {
                String s = decodehinttype.name();
                if(bundle.containsKey(s))
                    if(decodehinttype.getValueType().equals(java/lang/Void))
                    {
                        ((Map) (obj)).put(decodehinttype, Boolean.TRUE);
                    } else
                    {
                        Object obj1 = bundle.get(s);
                        if(decodehinttype.getValueType().isInstance(obj1))
                            ((Map) (obj)).put(decodehinttype, obj1);
                        else
                            Log.w(TAG, (new StringBuilder()).append("Ignoring hint ").append(decodehinttype).append(" because it is not assignable from ").append(obj1).toString());
                    }
            }
            j++;
        }
        Log.i(TAG, (new StringBuilder()).append("Hints from the Intent: ").append(obj).toString());
        if(true) goto _L4; else goto _L3
_L3:
    }

    static Map parseDecodeHints(Uri uri)
    {
        String s = uri.getEncodedQuery();
        if(s != null && !s.isEmpty()) goto _L2; else goto _L1
_L1:
        Object obj = null;
_L9:
        return ((Map) (obj));
_L2:
        Map map;
        DecodeHintType adecodehinttype[];
        int i;
        int j;
        map = splitQuery(s);
        obj = new EnumMap(com/google/zxing/DecodeHintType);
        adecodehinttype = DecodeHintType.values();
        i = adecodehinttype.length;
        j = 0;
_L4:
        DecodeHintType decodehinttype;
        if(j >= i)
            break MISSING_BLOCK_LABEL_505;
        decodehinttype = adecodehinttype[j];
        if(decodehinttype != DecodeHintType.CHARACTER_SET && decodehinttype != DecodeHintType.NEED_RESULT_POINT_CALLBACK && decodehinttype != DecodeHintType.POSSIBLE_FORMATS)
            break; /* Loop/switch isn't completed */
_L5:
        j++;
        if(true) goto _L4; else goto _L3
_L3:
        String s1;
        s1 = (String)map.get(decodehinttype.name());
        if(s1 != null)
            if(decodehinttype.getValueType().equals(java/lang/Object))
                ((Map) (obj)).put(decodehinttype, s1);
            else
            if(decodehinttype.getValueType().equals(java/lang/Void))
                ((Map) (obj)).put(decodehinttype, Boolean.TRUE);
            else
            if(decodehinttype.getValueType().equals(java/lang/String))
            {
                ((Map) (obj)).put(decodehinttype, s1);
            } else
            {
label0:
                {
                    if(!decodehinttype.getValueType().equals(java/lang/Boolean))
                        break label0;
                    if(s1.isEmpty())
                        ((Map) (obj)).put(decodehinttype, Boolean.TRUE);
                    else
                    if("0".equals(s1) || "false".equalsIgnoreCase(s1) || "no".equalsIgnoreCase(s1))
                        ((Map) (obj)).put(decodehinttype, Boolean.FALSE);
                    else
                        ((Map) (obj)).put(decodehinttype, Boolean.TRUE);
                }
            }
          goto _L5
        String as[];
        int ai[];
        int k;
        if(!decodehinttype.getValueType().equals([I))
            break MISSING_BLOCK_LABEL_462;
        if(!s1.isEmpty() && s1.charAt(-1 + s1.length()) == ',')
            s1 = s1.substring(0, -1 + s1.length());
        as = COMMA.split(s1);
        ai = new int[as.length];
        k = 0;
_L7:
        if(k >= as.length)
            break MISSING_BLOCK_LABEL_443;
        ai[k] = Integer.parseInt(as[k]);
        k++;
        if(true) goto _L7; else goto _L6
_L6:
        NumberFormatException numberformatexception;
        numberformatexception;
        Log.w(TAG, (new StringBuilder()).append("Skipping array of integers hint ").append(decodehinttype).append(" due to invalid numeric value: '").append(as[k]).append('\'').toString());
        ai = null;
        if(ai != null)
            ((Map) (obj)).put(decodehinttype, ai);
          goto _L5
        Log.w(TAG, (new StringBuilder()).append("Unsupported hint type '").append(decodehinttype).append("' of type ").append(decodehinttype.getValueType()).toString());
          goto _L5
        Log.i(TAG, (new StringBuilder()).append("Hints from the URI: ").append(obj).toString());
        if(true) goto _L9; else goto _L8
_L8:
    }

    private static Map splitQuery(String s)
    {
        HashMap hashmap = new HashMap();
        int i = 0;
        do
        {
            int j;
            int k;
label0:
            {
                if(i < s.length())
                {
                    if(s.charAt(i) == '&')
                    {
                        i++;
                        continue;
                    }
                    j = s.indexOf('&', i);
                    k = s.indexOf('=', i);
                    if(j >= 0)
                        break label0;
                    String s4;
                    String s5;
                    if(k < 0)
                    {
                        s4 = Uri.decode(s.substring(i).replace('+', ' '));
                        s5 = "";
                    } else
                    {
                        s4 = Uri.decode(s.substring(i, k).replace('+', ' '));
                        s5 = Uri.decode(s.substring(k + 1).replace('+', ' '));
                    }
                    if(!hashmap.containsKey(s4))
                        hashmap.put(s4, s5);
                }
                return hashmap;
            }
            if(k < 0 || k > j)
            {
                String s1 = Uri.decode(s.substring(i, j).replace('+', ' '));
                if(!hashmap.containsKey(s1))
                    hashmap.put(s1, "");
                i = j + 1;
            } else
            {
                String s2 = Uri.decode(s.substring(i, k).replace('+', ' '));
                String s3 = Uri.decode(s.substring(k + 1, j).replace('+', ' '));
                if(!hashmap.containsKey(s2))
                    hashmap.put(s2, s3);
                i = j + 1;
            }
        } while(true);
    }

}
