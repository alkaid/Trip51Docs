// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.client.android.result.supplement;

import android.content.Context;
import android.os.AsyncTask;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.method.LinkMovementMethod;
import android.text.style.URLSpan;
import android.util.Log;
import android.widget.TextView;
import com.google.zxing.client.android.common.executor.AsyncTaskExecInterface;
import com.google.zxing.client.android.common.executor.AsyncTaskExecManager;
import com.google.zxing.client.result.*;
import java.io.IOException;
import java.lang.ref.WeakReference;
import java.util.*;
import java.util.concurrent.RejectedExecutionException;

// Referenced classes of package com.google.zxing.client.android.result.supplement:
//            URIResultInfoRetriever, TitleRetriever, ProductResultInfoRetriever, BookResultInfoRetriever

public abstract class SupplementalInfoRetriever extends AsyncTask
{

    private static final String TAG = "SupplementalInfo";
    private final Collection newContents = new ArrayList();
    private final WeakReference textViewRef;

    SupplementalInfoRetriever(TextView textview)
    {
        textViewRef = new WeakReference(textview);
    }

    static void maybeAddText(String s, Collection collection)
    {
        if(s != null && !s.isEmpty())
            collection.add(s);
    }

    static void maybeAddTextSeries(Collection collection, Collection collection1)
    {
        if(collection != null && !collection.isEmpty())
        {
            boolean flag = true;
            StringBuilder stringbuilder = new StringBuilder();
            Iterator iterator = collection.iterator();
            while(iterator.hasNext()) 
            {
                String s = (String)iterator.next();
                if(flag)
                    flag = false;
                else
                    stringbuilder.append(", ");
                stringbuilder.append(s);
            }
            collection1.add(stringbuilder.toString());
        }
    }

    public static void maybeInvokeRetrieval(TextView textview, ParsedResult parsedresult, Context context)
    {
        AsyncTaskExecInterface asynctaskexecinterface = (AsyncTaskExecInterface)(new AsyncTaskExecManager()).build();
        if(parsedresult instanceof URIParsedResult)
        {
            asynctaskexecinterface.execute(new URIResultInfoRetriever(textview, (URIParsedResult)parsedresult, context), new Object[0]);
            asynctaskexecinterface.execute(new TitleRetriever(textview, (URIParsedResult)parsedresult), new Object[0]);
        } else
        if(parsedresult instanceof ProductParsedResult)
            asynctaskexecinterface.execute(new ProductResultInfoRetriever(textview, ((ProductParsedResult)parsedresult).getProductID(), context), new Object[0]);
        else
        if(parsedresult instanceof ISBNParsedResult)
        {
            String s = ((ISBNParsedResult)parsedresult).getISBN();
            asynctaskexecinterface.execute(new ProductResultInfoRetriever(textview, s, context), new Object[0]);
            asynctaskexecinterface.execute(new BookResultInfoRetriever(textview, s, context), new Object[0]);
        }
_L2:
        return;
        RejectedExecutionException rejectedexecutionexception;
        rejectedexecutionexception;
        if(true) goto _L2; else goto _L1
_L1:
    }

    final void append(String s, String s1, String as[], String s2)
    {
        int i;
        int l;
        SpannableString spannablestring;
        StringBuilder stringbuilder = new StringBuilder();
        if(s1 != null)
            stringbuilder.append(s1).append(' ');
        i = stringbuilder.length();
        boolean flag = true;
        int j = as.length;
        int k = 0;
        while(k < j) 
        {
            String s4 = as[k];
            if(flag)
            {
                stringbuilder.append(s4);
                flag = false;
            } else
            {
                stringbuilder.append(" [");
                stringbuilder.append(s4);
                stringbuilder.append(']');
            }
            k++;
        }
        l = stringbuilder.length();
        String s3 = stringbuilder.toString();
        spannablestring = new SpannableString((new StringBuilder()).append(s3).append("\n\n").toString());
        if(s2 == null) goto _L2; else goto _L1
_L1:
        if(!s2.startsWith("HTTP://")) goto _L4; else goto _L3
_L3:
        s2 = (new StringBuilder()).append("http").append(s2.substring(4)).toString();
_L6:
        spannablestring.setSpan(new URLSpan(s2), i, l, 33);
_L2:
        newContents.add(spannablestring);
        return;
_L4:
        if(s2.startsWith("HTTPS://"))
            s2 = (new StringBuilder()).append("https").append(s2.substring(5)).toString();
        if(true) goto _L6; else goto _L5
_L5:
    }

    public final transient Object doInBackground(Object aobj[])
    {
        try
        {
            retrieveSupplementalInfo();
        }
        catch(IOException ioexception)
        {
            Log.w("SupplementalInfo", ioexception);
        }
        return null;
    }

    protected final void onPostExecute(Object obj)
    {
        TextView textview = (TextView)textViewRef.get();
        if(textview != null)
        {
            for(Iterator iterator = newContents.iterator(); iterator.hasNext(); textview.append((CharSequence)iterator.next()));
            textview.setMovementMethod(LinkMovementMethod.getInstance());
        }
    }

    abstract void retrieveSupplementalInfo()
        throws IOException;
}
