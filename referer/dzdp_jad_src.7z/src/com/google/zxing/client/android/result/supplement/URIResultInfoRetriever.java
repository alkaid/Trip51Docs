// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.client.android.result.supplement;

import android.content.Context;
import android.widget.TextView;
import com.google.zxing.client.android.HttpHelper;
import com.google.zxing.client.result.URIParsedResult;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;

// Referenced classes of package com.google.zxing.client.android.result.supplement:
//            SupplementalInfoRetriever

final class URIResultInfoRetriever extends SupplementalInfoRetriever
{

    private static final int MAX_REDIRECTS = 5;
    private final String redirectString;
    private final URIParsedResult result;

    URIResultInfoRetriever(TextView textview, URIParsedResult uriparsedresult, Context context)
    {
        super(textview);
        redirectString = context.getString(com.google.zxing.client.android.R.string.msg_redirect);
        result = uriparsedresult;
    }

    void retrieveSupplementalInfo()
        throws IOException
    {
        URI uri = new URI(result.getURI());
        URI uri1 = HttpHelper.unredirect(uri);
        int i = 0;
        do
        {
            int j = i + 1;
            if(i >= 5 || uri.equals(uri1))
                break;
            String s = result.getDisplayResult();
            String as[] = new String[1];
            as[0] = (new StringBuilder()).append(redirectString).append(" : ").append(uri1).toString();
            append(s, null, as, uri1.toString());
            uri = uri1;
            uri1 = HttpHelper.unredirect(uri1);
            i = j;
        } while(true);
        break MISSING_BLOCK_LABEL_113;
        URISyntaxException urisyntaxexception;
        urisyntaxexception;
    }
}
