// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.client.android.result.supplement;

import android.content.Context;
import android.text.Html;
import android.widget.TextView;
import com.google.zxing.client.android.HttpHelper;
import com.google.zxing.client.android.LocaleManager;
import java.io.IOException;
import java.net.URLEncoder;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

// Referenced classes of package com.google.zxing.client.android.result.supplement:
//            SupplementalInfoRetriever

final class ProductResultInfoRetriever extends SupplementalInfoRetriever
{

    private static final Pattern PRODUCT_NAME_PRICE_PATTERNS[];
    private final Context context;
    private final String productID;
    private final String source;

    ProductResultInfoRetriever(TextView textview, String s, Context context1)
    {
        super(textview);
        productID = s;
        source = context1.getString(com.google.zxing.client.android.R.string.msg_google_product);
        context = context1;
    }

    private static String unescapeHTML(String s)
    {
        return Html.fromHtml(s).toString();
    }

    void retrieveSupplementalInfo()
        throws IOException
    {
        String s = URLEncoder.encode(productID, "UTF-8");
        String s1 = (new StringBuilder()).append("https://www.google.").append(LocaleManager.getProductSearchCountryTLD(context)).append("/m/products?ie=utf8&oe=utf8&scoring=p&source=zxing&q=").append(s).toString();
        CharSequence charsequence = HttpHelper.downloadViaHttp(s1, com.google.zxing.client.android.HttpHelper.ContentType.HTML);
        Pattern apattern[] = PRODUCT_NAME_PRICE_PATTERNS;
        int i = apattern.length;
        int j = 0;
        do
        {
label0:
            {
                if(j < i)
                {
                    Matcher matcher = apattern[j].matcher(charsequence);
                    if(!matcher.find())
                        break label0;
                    String s2 = productID;
                    String s3 = source;
                    String as[] = new String[2];
                    as[0] = unescapeHTML(matcher.group(1));
                    as[1] = unescapeHTML(matcher.group(2));
                    append(s2, s3, as, s1);
                }
                return;
            }
            j++;
        } while(true);
    }

    static 
    {
        Pattern apattern[] = new Pattern[2];
        apattern[0] = Pattern.compile(",event\\)\">([^<]+)</a></h3>.+<span class=psrp>([^<]+)</span>");
        apattern[1] = Pattern.compile("owb63p\">([^<]+).+zdi3pb\">([^<]+)");
        PRODUCT_NAME_PRICE_PATTERNS = apattern;
    }
}
