// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.client.android;

import android.net.Uri;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.Result;
import com.google.zxing.client.android.result.ResultHandler;
import com.google.zxing.client.result.ParsedResultType;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

final class ScanFromWebPageManager
{

    private static final CharSequence CODE_PLACEHOLDER = "{CODE}";
    private static final CharSequence FORMAT_PLACEHOLDER = "{FORMAT}";
    private static final CharSequence META_PLACEHOLDER = "{META}";
    private static final CharSequence RAW_CODE_PLACEHOLDER = "{RAWCODE}";
    private static final String RAW_PARAM = "raw";
    private static final String RETURN_URL_PARAM = "ret";
    private static final CharSequence TYPE_PLACEHOLDER = "{TYPE}";
    private final boolean returnRaw;
    private final String returnUrlTemplate;

    ScanFromWebPageManager(Uri uri)
    {
        returnUrlTemplate = uri.getQueryParameter("ret");
        boolean flag;
        if(uri.getQueryParameter("raw") != null)
            flag = true;
        else
            flag = false;
        returnRaw = flag;
    }

    private static String replace(CharSequence charsequence, CharSequence charsequence1, String s)
    {
        Object obj;
        String s1;
        if(charsequence1 == null)
            obj = "";
        else
            obj = charsequence1;
        s1 = URLEncoder.encode(((CharSequence) (obj)).toString(), "UTF-8");
        obj = s1;
_L2:
        return s.replace(charsequence, ((CharSequence) (obj)));
        UnsupportedEncodingException unsupportedencodingexception;
        unsupportedencodingexception;
        if(true) goto _L2; else goto _L1
_L1:
    }

    String buildReplyURL(Result result, ResultHandler resulthandler)
    {
        String s = returnUrlTemplate;
        CharSequence charsequence = CODE_PLACEHOLDER;
        Object obj;
        String s1;
        String s2;
        String s3;
        String s4;
        if(returnRaw)
            obj = result.getText();
        else
            obj = resulthandler.getDisplayContents();
        s1 = replace(charsequence, ((CharSequence) (obj)), s);
        s2 = replace(RAW_CODE_PLACEHOLDER, result.getText(), s1);
        s3 = replace(FORMAT_PLACEHOLDER, result.getBarcodeFormat().toString(), s2);
        s4 = replace(TYPE_PLACEHOLDER, resulthandler.getType().toString(), s3);
        return replace(META_PLACEHOLDER, String.valueOf(result.getResultMetadata()), s4);
    }

    boolean isScanFromWebPage()
    {
        boolean flag;
        if(returnUrlTemplate != null)
            flag = true;
        else
            flag = false;
        return flag;
    }

}
