// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.client.android.camera;

import android.content.SharedPreferences;

public final class FrontLightMode extends Enum
{

    private static final FrontLightMode $VALUES[];
    public static final FrontLightMode AUTO;
    public static final FrontLightMode OFF;
    public static final FrontLightMode ON;

    private FrontLightMode(String s, int i)
    {
        super(s, i);
    }

    private static FrontLightMode parse(String s)
    {
        FrontLightMode frontlightmode;
        if(s == null)
            frontlightmode = OFF;
        else
            frontlightmode = valueOf(s);
        return frontlightmode;
    }

    public static FrontLightMode readPref(SharedPreferences sharedpreferences)
    {
        return parse(sharedpreferences.getString("preferences_front_light_mode", OFF.toString()));
    }

    public static FrontLightMode valueOf(String s)
    {
        return (FrontLightMode)Enum.valueOf(com/google/zxing/client/android/camera/FrontLightMode, s);
    }

    public static FrontLightMode[] values()
    {
        return (FrontLightMode[])$VALUES.clone();
    }

    static 
    {
        ON = new FrontLightMode("ON", 0);
        AUTO = new FrontLightMode("AUTO", 1);
        OFF = new FrontLightMode("OFF", 2);
        FrontLightMode afrontlightmode[] = new FrontLightMode[3];
        afrontlightmode[0] = ON;
        afrontlightmode[1] = AUTO;
        afrontlightmode[2] = OFF;
        $VALUES = afrontlightmode;
    }
}
