// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.client.android;

import android.util.Log;
import java.io.*;
import java.net.*;
import java.util.*;

public final class HttpHelper
{
    public static final class ContentType extends Enum
    {

        private static final ContentType $VALUES[];
        public static final ContentType HTML;
        public static final ContentType JSON;
        public static final ContentType TEXT;
        public static final ContentType XML;

        public static ContentType valueOf(String s)
        {
            return (ContentType)Enum.valueOf(com/google/zxing/client/android/HttpHelper$ContentType, s);
        }

        public static ContentType[] values()
        {
            return (ContentType[])$VALUES.clone();
        }

        static 
        {
            HTML = new ContentType("HTML", 0);
            JSON = new ContentType("JSON", 1);
            XML = new ContentType("XML", 2);
            TEXT = new ContentType("TEXT", 3);
            ContentType acontenttype[] = new ContentType[4];
            acontenttype[0] = HTML;
            acontenttype[1] = JSON;
            acontenttype[2] = XML;
            acontenttype[3] = TEXT;
            $VALUES = acontenttype;
        }

        private ContentType(String s, int i)
        {
            super(s, i);
        }
    }


    private static final Collection REDIRECTOR_DOMAINS;
    private static final String TAG = com/google/zxing/client/android/HttpHelper.getSimpleName();

    private HttpHelper()
    {
    }

    private static CharSequence consume(URLConnection urlconnection, int i)
        throws IOException
    {
        String s;
        StringBuilder stringbuilder;
        InputStreamReader inputstreamreader;
        s = getEncoding(urlconnection);
        stringbuilder = new StringBuilder();
        inputstreamreader = null;
        InputStreamReader inputstreamreader1;
        inputstreamreader1 = new InputStreamReader(urlconnection.getInputStream(), s);
        break MISSING_BLOCK_LABEL_30;
        Exception exception;
        exception;
        inputstreamreader = inputstreamreader1;
_L2:
        NullPointerException nullpointerexception1;
        IOException ioexception1;
        if(inputstreamreader != null)
            try
            {
                inputstreamreader.close();
            }
            catch(IOException ioexception) { }
            catch(NullPointerException nullpointerexception) { }
        throw exception;
        char ac[] = new char[1024];
        do
        {
            if(stringbuilder.length() >= i)
                break;
            int j = inputstreamreader1.read(ac);
            if(j <= 0)
                break;
            stringbuilder.append(ac, 0, j);
        } while(true);
        if(inputstreamreader1 != null)
            try
            {
                inputstreamreader1.close();
            }
            // Misplaced declaration of an exception variable
            catch(IOException ioexception1) { }
            // Misplaced declaration of an exception variable
            catch(NullPointerException nullpointerexception1) { }
        return stringbuilder;
        exception;
        if(true) goto _L2; else goto _L1
_L1:
    }

    public static CharSequence downloadViaHttp(String s, ContentType contenttype)
        throws IOException
    {
        return downloadViaHttp(s, contenttype, 0x7fffffff);
    }

    public static CharSequence downloadViaHttp(String s, ContentType contenttype, int i)
        throws IOException
    {
        class _cls1
        {

            static final int $SwitchMap$com$google$zxing$client$android$HttpHelper$ContentType[];

            static 
            {
                $SwitchMap$com$google$zxing$client$android$HttpHelper$ContentType = new int[ContentType.values().length];
                NoSuchFieldError nosuchfielderror3;
                try
                {
                    $SwitchMap$com$google$zxing$client$android$HttpHelper$ContentType[ContentType.HTML.ordinal()] = 1;
                }
                catch(NoSuchFieldError nosuchfielderror) { }
                try
                {
                    $SwitchMap$com$google$zxing$client$android$HttpHelper$ContentType[ContentType.JSON.ordinal()] = 2;
                }
                catch(NoSuchFieldError nosuchfielderror1) { }
                try
                {
                    $SwitchMap$com$google$zxing$client$android$HttpHelper$ContentType[ContentType.XML.ordinal()] = 3;
                }
                catch(NoSuchFieldError nosuchfielderror2) { }
                $SwitchMap$com$google$zxing$client$android$HttpHelper$ContentType[ContentType.TEXT.ordinal()] = 4;
_L2:
                return;
                nosuchfielderror3;
                if(true) goto _L2; else goto _L1
_L1:
            }
        }

        _cls1..SwitchMap.com.google.zxing.client.android.HttpHelper.ContentType[contenttype.ordinal()];
        JVM INSTR tableswitch 1 3: default 36
    //                   1 46
    //                   2 52
    //                   3 58;
           goto _L1 _L2 _L3 _L4
_L1:
        String s1 = "text/*,*/*";
_L6:
        return downloadViaHttp(s, s1, i);
_L2:
        s1 = "application/xhtml+xml,text/html,text/*,*/*";
        continue; /* Loop/switch isn't completed */
_L3:
        s1 = "application/json,text/*,*/*";
        continue; /* Loop/switch isn't completed */
_L4:
        s1 = "application/xml,text/*,*/*";
        if(true) goto _L6; else goto _L5
_L5:
    }

    private static CharSequence downloadViaHttp(String s, String s1, int i)
        throws IOException
    {
        int j = 0;
_L8:
        if(j >= 5) goto _L2; else goto _L1
_L1:
        HttpURLConnection httpurlconnection;
        httpurlconnection = safelyOpenConnection(new URL(s));
        httpurlconnection.setInstanceFollowRedirects(true);
        httpurlconnection.setRequestProperty("Accept", s1);
        httpurlconnection.setRequestProperty("Accept-Charset", "utf-8,*");
        httpurlconnection.setRequestProperty("User-Agent", "ZXing (Android)");
        int k = safelyConnect(httpurlconnection);
        k;
        JVM INSTR lookupswitch 2: default 88
    //                   200: 126
    //                   302: 142;
           goto _L3 _L4 _L5
_L3:
        throw new IOException((new StringBuilder()).append("Bad HTTP response: ").append(k).toString());
        Exception exception;
        exception;
        httpurlconnection.disconnect();
        throw exception;
_L4:
        CharSequence charsequence = consume(httpurlconnection, i);
        httpurlconnection.disconnect();
        return charsequence;
_L5:
        String s2 = httpurlconnection.getHeaderField("Location");
        if(s2 == null) goto _L7; else goto _L6
_L6:
        s = s2;
        j++;
        httpurlconnection.disconnect();
          goto _L8
_L7:
        throw new IOException("No Location");
_L2:
        throw new IOException("Too many redirects");
    }

    private static String getEncoding(URLConnection urlconnection)
    {
        String s = urlconnection.getHeaderField("Content-Type");
        if(s == null) goto _L2; else goto _L1
_L1:
        int i = s.indexOf("charset=");
        if(i < 0) goto _L2; else goto _L3
_L3:
        String s1 = s.substring(i + "charset=".length());
_L5:
        return s1;
_L2:
        s1 = "UTF-8";
        if(true) goto _L5; else goto _L4
_L4:
    }

    private static int safelyConnect(HttpURLConnection httpurlconnection)
        throws IOException
    {
        httpurlconnection.connect();
        int i = httpurlconnection.getResponseCode();
        return i;
        Object obj;
        obj;
_L1:
        throw new IOException(((Throwable) (obj)));
        Object obj1;
        obj1;
_L2:
        throw new IOException(((Throwable) (obj1)));
        obj;
          goto _L1
        obj;
          goto _L1
        obj;
          goto _L1
        obj1;
          goto _L2
        obj1;
          goto _L2
    }

    private static HttpURLConnection safelyOpenConnection(URL url)
        throws IOException
    {
        URLConnection urlconnection;
        try
        {
            urlconnection = url.openConnection();
        }
        catch(NullPointerException nullpointerexception)
        {
            Log.w(TAG, (new StringBuilder()).append("Bad URI? ").append(url).toString());
            throw new IOException(nullpointerexception);
        }
        if(!(urlconnection instanceof HttpURLConnection))
            throw new IOException();
        else
            return (HttpURLConnection)urlconnection;
    }

    public static URI unredirect(URI uri)
        throws IOException
    {
        if(REDIRECTOR_DOMAINS.contains(uri.getHost())) goto _L2; else goto _L1
_L1:
        return uri;
_L2:
        HttpURLConnection httpurlconnection;
        httpurlconnection = safelyOpenConnection(uri.toURL());
        httpurlconnection.setInstanceFollowRedirects(false);
        httpurlconnection.setDoInput(false);
        httpurlconnection.setRequestMethod("HEAD");
        httpurlconnection.setRequestProperty("User-Agent", "ZXing (Android)");
        int i = safelyConnect(httpurlconnection);
        i;
        JVM INSTR tableswitch 300 307: default 104
    //                   300 111
    //                   301 111
    //                   302 111
    //                   303 111
    //                   304 104
    //                   305 104
    //                   306 104
    //                   307 111;
           goto _L3 _L4 _L4 _L4 _L4 _L3 _L3 _L3 _L4
_L3:
        httpurlconnection.disconnect();
          goto _L1
_L4:
        String s = httpurlconnection.getHeaderField("Location");
        if(s == null) goto _L3; else goto _L5
_L5:
        URI uri1 = new URI(s);
        httpurlconnection.disconnect();
        uri = uri1;
          goto _L1
        Exception exception;
        exception;
        httpurlconnection.disconnect();
        throw exception;
        URISyntaxException urisyntaxexception;
        urisyntaxexception;
          goto _L3
    }

    static 
    {
        String as[] = new String[16];
        as[0] = "amzn.to";
        as[1] = "bit.ly";
        as[2] = "bitly.com";
        as[3] = "fb.me";
        as[4] = "goo.gl";
        as[5] = "is.gd";
        as[6] = "j.mp";
        as[7] = "lnkd.in";
        as[8] = "ow.ly";
        as[9] = "R.BEETAGG.COM";
        as[10] = "r.beetagg.com";
        as[11] = "SCN.BY";
        as[12] = "su.pr";
        as[13] = "t.co";
        as[14] = "tinyurl.com";
        as[15] = "tr.im";
        REDIRECTOR_DOMAINS = new HashSet(Arrays.asList(as));
    }
}
