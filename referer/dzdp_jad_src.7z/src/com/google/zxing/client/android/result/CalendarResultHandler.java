// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.client.android.result;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.util.Log;
import com.google.zxing.client.result.CalendarParsedResult;
import com.google.zxing.client.result.ParsedResult;
import java.text.DateFormat;
import java.util.Date;

// Referenced classes of package com.google.zxing.client.android.result:
//            ResultHandler

public final class CalendarResultHandler extends ResultHandler
{

    private static final String TAG = com/google/zxing/client/android/result/CalendarResultHandler.getSimpleName();
    private static final int buttons[];

    public CalendarResultHandler(Activity activity, ParsedResult parsedresult)
    {
        super(activity, parsedresult);
    }

    private void addCalendarEvent(String s, Date date, boolean flag, Date date1, String s1, String s2, String as[])
    {
        Intent intent;
        intent = new Intent("android.intent.action.INSERT");
        intent.setType("vnd.android.cursor.item/event");
        long l = date.getTime();
        intent.putExtra("beginTime", l);
        if(flag)
            intent.putExtra("allDay", true);
        long l1;
        if(date1 == null)
        {
            if(flag)
                l1 = l + 0x5265c00L;
            else
                l1 = l;
        } else
        {
            l1 = date1.getTime();
        }
        intent.putExtra("endTime", l1);
        intent.putExtra("title", s);
        intent.putExtra("eventLocation", s1);
        intent.putExtra("description", s2);
        if(as != null)
            intent.putExtra("android.intent.extra.EMAIL", as);
        rawLaunchIntent(intent);
_L1:
        return;
        ActivityNotFoundException activitynotfoundexception;
        activitynotfoundexception;
        Log.w(TAG, "No calendar app available that responds to android.intent.action.INSERT");
        intent.setAction("android.intent.action.EDIT");
        launchIntent(intent);
          goto _L1
    }

    private static String format(boolean flag, Date date)
    {
        String s;
        if(date == null)
        {
            s = null;
        } else
        {
            DateFormat dateformat;
            if(flag)
                dateformat = DateFormat.getDateInstance(2);
            else
                dateformat = DateFormat.getDateTimeInstance(2, 2);
            s = dateformat.format(date);
        }
        return s;
    }

    public int getButtonCount()
    {
        return buttons.length;
    }

    public int getButtonText(int i)
    {
        return buttons[i];
    }

    public CharSequence getDisplayContents()
    {
        CalendarParsedResult calendarparsedresult = (CalendarParsedResult)getResult();
        StringBuilder stringbuilder = new StringBuilder(100);
        ParsedResult.maybeAppend(calendarparsedresult.getSummary(), stringbuilder);
        Date date = calendarparsedresult.getStart();
        ParsedResult.maybeAppend(format(calendarparsedresult.isStartAllDay(), date), stringbuilder);
        Date date1 = calendarparsedresult.getEnd();
        if(date1 != null)
        {
            if(calendarparsedresult.isEndAllDay() && !date.equals(date1))
                date1 = new Date(date1.getTime() - 0x5265c00L);
            ParsedResult.maybeAppend(format(calendarparsedresult.isEndAllDay(), date1), stringbuilder);
        }
        ParsedResult.maybeAppend(calendarparsedresult.getLocation(), stringbuilder);
        ParsedResult.maybeAppend(calendarparsedresult.getOrganizer(), stringbuilder);
        ParsedResult.maybeAppend(calendarparsedresult.getAttendees(), stringbuilder);
        ParsedResult.maybeAppend(calendarparsedresult.getDescription(), stringbuilder);
        return stringbuilder.toString();
    }

    public int getDisplayTitle()
    {
        return com.google.zxing.client.android.R.string.result_calendar;
    }

    public void handleButtonPress(int i)
    {
        if(i == 0)
        {
            CalendarParsedResult calendarparsedresult = (CalendarParsedResult)getResult();
            String s = calendarparsedresult.getDescription();
            String s1 = calendarparsedresult.getOrganizer();
            if(s1 != null)
                if(s == null)
                    s = s1;
                else
                    s = (new StringBuilder()).append(s).append('\n').append(s1).toString();
            addCalendarEvent(calendarparsedresult.getSummary(), calendarparsedresult.getStart(), calendarparsedresult.isStartAllDay(), calendarparsedresult.getEnd(), calendarparsedresult.getLocation(), s, calendarparsedresult.getAttendees());
        }
    }

    static 
    {
        int ai[] = new int[1];
        ai[0] = com.google.zxing.client.android.R.string.button_add_calendar;
        buttons = ai;
    }
}
