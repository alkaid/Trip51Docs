// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing;


// Referenced classes of package com.google.zxing:
//            ReaderException

public final class ChecksumException extends ReaderException
{

    private static final ChecksumException INSTANCE;

    private ChecksumException()
    {
    }

    private ChecksumException(Throwable throwable)
    {
        super(throwable);
    }

    public static ChecksumException getChecksumInstance()
    {
        ChecksumException checksumexception;
        if(isStackTrace)
            checksumexception = new ChecksumException();
        else
            checksumexception = INSTANCE;
        return checksumexception;
    }

    public static ChecksumException getChecksumInstance(Throwable throwable)
    {
        ChecksumException checksumexception;
        if(isStackTrace)
            checksumexception = new ChecksumException(throwable);
        else
            checksumexception = INSTANCE;
        return checksumexception;
    }

    static 
    {
        INSTANCE = new ChecksumException();
        INSTANCE.setStackTrace(NO_TRACE);
    }
}
