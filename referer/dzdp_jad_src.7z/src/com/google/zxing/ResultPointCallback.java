// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing;


// Referenced classes of package com.google.zxing:
//            ResultPoint

public interface ResultPointCallback
{

    public abstract void foundPossibleResultPoint(ResultPoint resultpoint);
}
