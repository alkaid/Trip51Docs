// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.datamatrix.detector;

import com.google.zxing.NotFoundException;
import com.google.zxing.ResultPoint;
import com.google.zxing.common.*;
import com.google.zxing.common.detector.MathUtils;
import com.google.zxing.common.detector.WhiteRectangleDetector;
import java.io.Serializable;
import java.util.*;

public final class Detector
{
    private static final class ResultPointsAndTransitionsComparator
        implements Comparator, Serializable
    {

        public int compare(ResultPointsAndTransitions resultpointsandtransitions, ResultPointsAndTransitions resultpointsandtransitions1)
        {
            return resultpointsandtransitions.getTransitions() - resultpointsandtransitions1.getTransitions();
        }

        public volatile int compare(Object obj, Object obj1)
        {
            return compare((ResultPointsAndTransitions)obj, (ResultPointsAndTransitions)obj1);
        }

        private ResultPointsAndTransitionsComparator()
        {
        }

    }

    private static final class ResultPointsAndTransitions
    {

        private final ResultPoint from;
        private final ResultPoint to;
        private final int transitions;

        ResultPoint getFrom()
        {
            return from;
        }

        ResultPoint getTo()
        {
            return to;
        }

        public int getTransitions()
        {
            return transitions;
        }

        public String toString()
        {
            return (new StringBuilder()).append(from).append("/").append(to).append('/').append(transitions).toString();
        }

        private ResultPointsAndTransitions(ResultPoint resultpoint, ResultPoint resultpoint1, int i)
        {
            from = resultpoint;
            to = resultpoint1;
            transitions = i;
        }

    }


    private final BitMatrix image;
    private final WhiteRectangleDetector rectangleDetector;

    public Detector(BitMatrix bitmatrix)
        throws NotFoundException
    {
        image = bitmatrix;
        rectangleDetector = new WhiteRectangleDetector(bitmatrix);
    }

    private ResultPoint correctTopRight(ResultPoint resultpoint, ResultPoint resultpoint1, ResultPoint resultpoint2, ResultPoint resultpoint3, int i)
    {
        ResultPoint resultpoint4;
        ResultPoint resultpoint5;
        float f = (float)distance(resultpoint, resultpoint1) / (float)i;
        int j = distance(resultpoint2, resultpoint3);
        float f1 = (resultpoint3.getX() - resultpoint2.getX()) / (float)j;
        float f2 = (resultpoint3.getY() - resultpoint2.getY()) / (float)j;
        resultpoint4 = new ResultPoint(resultpoint3.getX() + f * f1, resultpoint3.getY() + f * f2);
        float f3 = (float)distance(resultpoint, resultpoint2) / (float)i;
        int k = distance(resultpoint1, resultpoint3);
        float f4 = (resultpoint3.getX() - resultpoint1.getX()) / (float)k;
        float f5 = (resultpoint3.getY() - resultpoint1.getY()) / (float)k;
        resultpoint5 = new ResultPoint(resultpoint3.getX() + f3 * f4, resultpoint3.getY() + f3 * f5);
        if(isValid(resultpoint4)) goto _L2; else goto _L1
_L1:
        if(isValid(resultpoint5))
            resultpoint4 = resultpoint5;
        else
            resultpoint4 = null;
_L4:
        return resultpoint4;
_L2:
        if(isValid(resultpoint5) && Math.abs(transitionsBetween(resultpoint2, resultpoint4).getTransitions() - transitionsBetween(resultpoint1, resultpoint4).getTransitions()) > Math.abs(transitionsBetween(resultpoint2, resultpoint5).getTransitions() - transitionsBetween(resultpoint1, resultpoint5).getTransitions()))
            resultpoint4 = resultpoint5;
        if(true) goto _L4; else goto _L3
_L3:
    }

    private ResultPoint correctTopRightRectangular(ResultPoint resultpoint, ResultPoint resultpoint1, ResultPoint resultpoint2, ResultPoint resultpoint3, int i, int j)
    {
        ResultPoint resultpoint4;
        ResultPoint resultpoint5;
        float f = (float)distance(resultpoint, resultpoint1) / (float)i;
        int k = distance(resultpoint2, resultpoint3);
        float f1 = (resultpoint3.getX() - resultpoint2.getX()) / (float)k;
        float f2 = (resultpoint3.getY() - resultpoint2.getY()) / (float)k;
        resultpoint4 = new ResultPoint(resultpoint3.getX() + f * f1, resultpoint3.getY() + f * f2);
        float f3 = (float)distance(resultpoint, resultpoint2) / (float)j;
        int l = distance(resultpoint1, resultpoint3);
        float f4 = (resultpoint3.getX() - resultpoint1.getX()) / (float)l;
        float f5 = (resultpoint3.getY() - resultpoint1.getY()) / (float)l;
        resultpoint5 = new ResultPoint(resultpoint3.getX() + f3 * f4, resultpoint3.getY() + f3 * f5);
        if(isValid(resultpoint4)) goto _L2; else goto _L1
_L1:
        if(!isValid(resultpoint5))
            resultpoint5 = null;
_L4:
        return resultpoint5;
_L2:
        if(!isValid(resultpoint5))
            resultpoint5 = resultpoint4;
        else
        if(Math.abs(i - transitionsBetween(resultpoint2, resultpoint4).getTransitions()) + Math.abs(j - transitionsBetween(resultpoint1, resultpoint4).getTransitions()) <= Math.abs(i - transitionsBetween(resultpoint2, resultpoint5).getTransitions()) + Math.abs(j - transitionsBetween(resultpoint1, resultpoint5).getTransitions()))
            resultpoint5 = resultpoint4;
        if(true) goto _L4; else goto _L3
_L3:
    }

    private static int distance(ResultPoint resultpoint, ResultPoint resultpoint1)
    {
        return MathUtils.round(ResultPoint.distance(resultpoint, resultpoint1));
    }

    private static void increment(Map map, ResultPoint resultpoint)
    {
        Integer integer = (Integer)map.get(resultpoint);
        int i;
        if(integer == null)
            i = 1;
        else
            i = 1 + integer.intValue();
        map.put(resultpoint, Integer.valueOf(i));
    }

    private boolean isValid(ResultPoint resultpoint)
    {
        boolean flag;
        if(resultpoint.getX() >= 0.0F && resultpoint.getX() < (float)image.getWidth() && resultpoint.getY() > 0.0F && resultpoint.getY() < (float)image.getHeight())
            flag = true;
        else
            flag = false;
        return flag;
    }

    private static BitMatrix sampleGrid(BitMatrix bitmatrix, ResultPoint resultpoint, ResultPoint resultpoint1, ResultPoint resultpoint2, ResultPoint resultpoint3, int i, int j)
        throws NotFoundException
    {
        return GridSampler.getInstance().sampleGrid(bitmatrix, i, j, 0.5F, 0.5F, (float)i - 0.5F, 0.5F, (float)i - 0.5F, (float)j - 0.5F, 0.5F, (float)j - 0.5F, resultpoint.getX(), resultpoint.getY(), resultpoint3.getX(), resultpoint3.getY(), resultpoint2.getX(), resultpoint2.getY(), resultpoint1.getX(), resultpoint1.getY());
    }

    private ResultPointsAndTransitions transitionsBetween(ResultPoint resultpoint, ResultPoint resultpoint1)
    {
        int i = (int)resultpoint.getX();
        int j = (int)resultpoint.getY();
        int k = (int)resultpoint1.getX();
        int l = (int)resultpoint1.getY();
        boolean flag;
        int i1;
        int j1;
        int k1;
        byte byte0;
        byte byte1;
        int l1;
        BitMatrix bitmatrix;
        int i2;
        int j2;
        boolean flag1;
        int k2;
        int l2;
        if(Math.abs(l - j) > Math.abs(k - i))
            flag = true;
        else
            flag = false;
        if(flag)
        {
            int k3 = i;
            i = j;
            j = k3;
            int l3 = k;
            k = l;
            l = l3;
        }
        i1 = Math.abs(k - i);
        j1 = Math.abs(l - j);
        k1 = -i1 / 2;
        if(j < l)
            byte0 = 1;
        else
            byte0 = -1;
        if(i < k)
            byte1 = 1;
        else
            byte1 = -1;
        l1 = 0;
        bitmatrix = image;
        if(flag)
            i2 = j;
        else
            i2 = i;
        if(flag)
            j2 = i;
        else
            j2 = j;
        flag1 = bitmatrix.get(i2, j2);
        k2 = i;
        l2 = j;
        do
        {
label0:
            {
label1:
                {
                    if(k2 != k)
                    {
                        BitMatrix bitmatrix1 = image;
                        ResultPointsAndTransitions resultpointsandtransitions;
                        int i3;
                        int j3;
                        boolean flag2;
                        if(flag)
                            i3 = l2;
                        else
                            i3 = k2;
                        if(flag)
                            j3 = k2;
                        else
                            j3 = l2;
                        flag2 = bitmatrix1.get(i3, j3);
                        if(flag2 != flag1)
                        {
                            l1++;
                            flag1 = flag2;
                        }
                        k1 += j1;
                        if(k1 <= 0)
                            break label0;
                        if(l2 != l)
                            break label1;
                    }
                    resultpointsandtransitions = new ResultPointsAndTransitions(resultpoint, resultpoint1, l1);
                    return resultpointsandtransitions;
                }
                l2 += byte0;
                k1 -= i1;
            }
            k2 += byte1;
        } while(true);
    }

    public DetectorResult detect()
        throws NotFoundException
    {
        ResultPoint aresultpoint[] = rectangleDetector.detect();
        ResultPoint resultpoint = aresultpoint[0];
        ResultPoint resultpoint1 = aresultpoint[1];
        ResultPoint resultpoint2 = aresultpoint[2];
        ResultPoint resultpoint3 = aresultpoint[3];
        ArrayList arraylist = new ArrayList(4);
        arraylist.add(transitionsBetween(resultpoint, resultpoint1));
        arraylist.add(transitionsBetween(resultpoint, resultpoint2));
        arraylist.add(transitionsBetween(resultpoint1, resultpoint3));
        arraylist.add(transitionsBetween(resultpoint2, resultpoint3));
        Collections.sort(arraylist, new ResultPointsAndTransitionsComparator());
        ResultPointsAndTransitions resultpointsandtransitions = (ResultPointsAndTransitions)arraylist.get(0);
        ResultPointsAndTransitions resultpointsandtransitions1 = (ResultPointsAndTransitions)arraylist.get(1);
        HashMap hashmap = new HashMap();
        increment(hashmap, resultpointsandtransitions.getFrom());
        increment(hashmap, resultpointsandtransitions.getTo());
        increment(hashmap, resultpointsandtransitions1.getFrom());
        increment(hashmap, resultpointsandtransitions1.getTo());
        ResultPoint resultpoint4 = null;
        ResultPoint resultpoint5 = null;
        ResultPoint resultpoint6 = null;
        for(Iterator iterator = hashmap.entrySet().iterator(); iterator.hasNext();)
        {
            java.util.Map.Entry entry = (java.util.Map.Entry)iterator.next();
            ResultPoint resultpoint12 = (ResultPoint)entry.getKey();
            if(((Integer)entry.getValue()).intValue() == 2)
                resultpoint5 = resultpoint12;
            else
            if(resultpoint4 == null)
                resultpoint4 = resultpoint12;
            else
                resultpoint6 = resultpoint12;
        }

        if(resultpoint4 == null || resultpoint5 == null || resultpoint6 == null)
            throw NotFoundException.getNotFoundInstance();
        ResultPoint aresultpoint1[] = new ResultPoint[3];
        aresultpoint1[0] = resultpoint4;
        aresultpoint1[1] = resultpoint5;
        aresultpoint1[2] = resultpoint6;
        ResultPoint.orderBestPatterns(aresultpoint1);
        ResultPoint resultpoint7 = aresultpoint1[0];
        ResultPoint resultpoint8 = aresultpoint1[1];
        ResultPoint resultpoint9 = aresultpoint1[2];
        ResultPoint resultpoint10;
        int i;
        int j;
        int k;
        int l;
        ResultPoint resultpoint11;
        BitMatrix bitmatrix;
        ResultPoint aresultpoint2[];
        if(!hashmap.containsKey(resultpoint))
            resultpoint10 = resultpoint;
        else
        if(!hashmap.containsKey(resultpoint1))
            resultpoint10 = resultpoint1;
        else
        if(!hashmap.containsKey(resultpoint2))
            resultpoint10 = resultpoint2;
        else
            resultpoint10 = resultpoint3;
        i = transitionsBetween(resultpoint9, resultpoint10).getTransitions();
        j = transitionsBetween(resultpoint7, resultpoint10).getTransitions();
        if((i & 1) == 1)
            i++;
        k = i + 2;
        if((j & 1) == 1)
            j++;
        l = j + 2;
        if(k * 4 >= l * 7 || l * 4 >= k * 7)
        {
            resultpoint11 = correctTopRightRectangular(resultpoint8, resultpoint7, resultpoint9, resultpoint10, k, l);
            if(resultpoint11 == null)
                resultpoint11 = resultpoint10;
            int i1 = transitionsBetween(resultpoint9, resultpoint11).getTransitions();
            int j1 = transitionsBetween(resultpoint7, resultpoint11).getTransitions();
            if((i1 & 1) == 1)
                i1++;
            if((j1 & 1) == 1)
                j1++;
            bitmatrix = sampleGrid(image, resultpoint9, resultpoint8, resultpoint7, resultpoint11, i1, j1);
        } else
        {
            int k1 = Math.min(l, k);
            resultpoint11 = correctTopRight(resultpoint8, resultpoint7, resultpoint9, resultpoint10, k1);
            if(resultpoint11 == null)
                resultpoint11 = resultpoint10;
            int l1 = 1 + Math.max(transitionsBetween(resultpoint9, resultpoint11).getTransitions(), transitionsBetween(resultpoint7, resultpoint11).getTransitions());
            if((l1 & 1) == 1)
                l1++;
            bitmatrix = sampleGrid(image, resultpoint9, resultpoint8, resultpoint7, resultpoint11, l1, l1);
        }
        aresultpoint2 = new ResultPoint[4];
        aresultpoint2[0] = resultpoint9;
        aresultpoint2[1] = resultpoint8;
        aresultpoint2[2] = resultpoint7;
        aresultpoint2[3] = resultpoint11;
        return new DetectorResult(bitmatrix, aresultpoint2);
    }
}
