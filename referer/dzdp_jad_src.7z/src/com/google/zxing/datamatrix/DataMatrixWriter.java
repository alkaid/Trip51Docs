// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.datamatrix;

import com.google.zxing.*;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.datamatrix.encoder.DefaultPlacement;
import com.google.zxing.datamatrix.encoder.ErrorCorrection;
import com.google.zxing.datamatrix.encoder.HighLevelEncoder;
import com.google.zxing.datamatrix.encoder.SymbolInfo;
import com.google.zxing.datamatrix.encoder.SymbolShapeHint;
import com.google.zxing.qrcode.encoder.ByteMatrix;
import java.util.Map;

public final class DataMatrixWriter
    implements Writer
{

    public DataMatrixWriter()
    {
    }

    private static BitMatrix convertByteMatrixToBitMatrix(ByteMatrix bytematrix)
    {
        int i = bytematrix.getWidth();
        int j = bytematrix.getHeight();
        BitMatrix bitmatrix = new BitMatrix(i, j);
        bitmatrix.clear();
        for(int k = 0; k < i; k++)
        {
            for(int l = 0; l < j; l++)
                if(bytematrix.get(k, l) == 1)
                    bitmatrix.set(k, l);

        }

        return bitmatrix;
    }

    private static BitMatrix encodeLowLevel(DefaultPlacement defaultplacement, SymbolInfo symbolinfo)
    {
        int i = symbolinfo.getSymbolDataWidth();
        int j = symbolinfo.getSymbolDataHeight();
        ByteMatrix bytematrix = new ByteMatrix(symbolinfo.getSymbolWidth(), symbolinfo.getSymbolHeight());
        int k = 0;
        for(int l = 0; l < j; l++)
        {
            if(l % symbolinfo.matrixHeight == 0)
            {
                int i2 = 0;
                int j2 = 0;
                while(j2 < symbolinfo.getSymbolWidth()) 
                {
                    boolean flag1;
                    if(j2 % 2 == 0)
                        flag1 = true;
                    else
                        flag1 = false;
                    bytematrix.set(i2, k, flag1);
                    i2++;
                    j2++;
                }
                k++;
            }
            int i1 = 0;
            int j1 = 0;
            while(j1 < i) 
            {
                if(j1 % symbolinfo.matrixWidth == 0)
                {
                    bytematrix.set(i1, k, true);
                    i1++;
                }
                bytematrix.set(i1, k, defaultplacement.getBit(j1, l));
                i1++;
                if(j1 % symbolinfo.matrixWidth == -1 + symbolinfo.matrixWidth)
                {
                    boolean flag;
                    if(l % 2 == 0)
                        flag = true;
                    else
                        flag = false;
                    bytematrix.set(i1, k, flag);
                    i1++;
                }
                j1++;
            }
            k++;
            if(l % symbolinfo.matrixHeight != -1 + symbolinfo.matrixHeight)
                continue;
            int k1 = 0;
            for(int l1 = 0; l1 < symbolinfo.getSymbolWidth(); l1++)
            {
                bytematrix.set(k1, k, true);
                k1++;
            }

            k++;
        }

        return convertByteMatrixToBitMatrix(bytematrix);
    }

    public BitMatrix encode(String s, BarcodeFormat barcodeformat, int i, int j)
    {
        return encode(s, barcodeformat, i, j, null);
    }

    public BitMatrix encode(String s, BarcodeFormat barcodeformat, int i, int j, Map map)
    {
        if(s.isEmpty())
            throw new IllegalArgumentException("Found empty contents");
        if(barcodeformat != BarcodeFormat.DATA_MATRIX)
            throw new IllegalArgumentException((new StringBuilder()).append("Can only encode DATA_MATRIX, but got ").append(barcodeformat).toString());
        if(i < 0 || j < 0)
            throw new IllegalArgumentException((new StringBuilder()).append("Requested dimensions are too small: ").append(i).append('x').append(j).toString());
        SymbolShapeHint symbolshapehint = SymbolShapeHint.FORCE_NONE;
        Dimension dimension = null;
        Dimension dimension1 = null;
        if(map != null)
        {
            SymbolShapeHint symbolshapehint1 = (SymbolShapeHint)map.get(EncodeHintType.DATA_MATRIX_SHAPE);
            if(symbolshapehint1 != null)
                symbolshapehint = symbolshapehint1;
            Dimension dimension2 = (Dimension)map.get(EncodeHintType.MIN_SIZE);
            if(dimension2 != null)
                dimension = dimension2;
            Dimension dimension3 = (Dimension)map.get(EncodeHintType.MAX_SIZE);
            if(dimension3 != null)
                dimension1 = dimension3;
        }
        String s1 = HighLevelEncoder.encodeHighLevel(s, symbolshapehint, dimension, dimension1);
        SymbolInfo symbolinfo = SymbolInfo.lookup(s1.length(), symbolshapehint, dimension, dimension1, true);
        DefaultPlacement defaultplacement = new DefaultPlacement(ErrorCorrection.encodeECC200(s1, symbolinfo), symbolinfo.getSymbolDataWidth(), symbolinfo.getSymbolDataHeight());
        defaultplacement.place();
        return encodeLowLevel(defaultplacement, symbolinfo);
    }
}
