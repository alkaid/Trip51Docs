// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.datamatrix.encoder;


// Referenced classes of package com.google.zxing.datamatrix.encoder:
//            Encoder, EncoderContext, SymbolInfo, HighLevelEncoder

class C40Encoder
    implements Encoder
{

    C40Encoder()
    {
    }

    private int backtrackOneCharacter(EncoderContext encodercontext, StringBuilder stringbuilder, StringBuilder stringbuilder1, int i)
    {
        int j = stringbuilder.length();
        stringbuilder.delete(j - i, j);
        encodercontext.pos = -1 + encodercontext.pos;
        int k = encodeChar(encodercontext.getCurrentChar(), stringbuilder1);
        encodercontext.resetSymbolInfo();
        return k;
    }

    private static String encodeToCodewords(CharSequence charsequence, int i)
    {
        char c = charsequence.charAt(i);
        char c1 = charsequence.charAt(i + 1);
        int j = 1 + (charsequence.charAt(i + 2) + (c * 1600 + c1 * 40));
        int k = j / 256;
        int l = j % 256;
        char ac[] = new char[2];
        ac[0] = k;
        ac[1] = l;
        return new String(ac);
    }

    static void writeNextTriplet(EncoderContext encodercontext, StringBuilder stringbuilder)
    {
        encodercontext.writeCodewords(encodeToCodewords(stringbuilder, 0));
        stringbuilder.delete(0, 3);
    }

    public void encode(EncoderContext encodercontext)
    {
        StringBuilder stringbuilder = new StringBuilder();
        do
        {
            if(!encodercontext.hasMoreCharacters())
                break;
            char c = encodercontext.getCurrentChar();
            encodercontext.pos = 1 + encodercontext.pos;
            int i = encodeChar(c, stringbuilder);
            int j = 2 * (stringbuilder.length() / 3) + encodercontext.getCodewordCount();
            encodercontext.updateSymbolInfo(j);
            int k = encodercontext.getSymbolInfo().getDataCapacity() - j;
            if(!encodercontext.hasMoreCharacters())
            {
                StringBuilder stringbuilder1 = new StringBuilder();
                if(stringbuilder.length() % 3 == 2 && (k < 2 || k > 2))
                    i = backtrackOneCharacter(encodercontext, stringbuilder, stringbuilder1, i);
                for(; stringbuilder.length() % 3 == 1 && (i <= 3 && k != 1 || i > 3); i = backtrackOneCharacter(encodercontext, stringbuilder, stringbuilder1, i));
                break;
            }
            if(stringbuilder.length() % 3 != 0)
                continue;
            int l = HighLevelEncoder.lookAheadTest(encodercontext.getMessage(), encodercontext.pos, getEncodingMode());
            if(l == getEncodingMode())
                continue;
            encodercontext.signalEncoderChange(l);
            break;
        } while(true);
        handleEOD(encodercontext, stringbuilder);
    }

    int encodeChar(char c, StringBuilder stringbuilder)
    {
        int i = 1;
        if(c == ' ')
            stringbuilder.append('\003');
        else
        if(c >= '0' && c <= '9')
            stringbuilder.append(4 + (c + -48));
        else
        if(c >= 'A' && c <= 'Z')
            stringbuilder.append(14 + (c + -65));
        else
        if(c >= 0 && c <= '\037')
        {
            stringbuilder.append('\0');
            stringbuilder.append(c);
            i = 2;
        } else
        if(c >= '!' && c <= '/')
        {
            stringbuilder.append(i);
            stringbuilder.append(c + -33);
            i = 2;
        } else
        if(c >= ':' && c <= '@')
        {
            stringbuilder.append(i);
            stringbuilder.append(15 + (c + -58));
            i = 2;
        } else
        if(c >= '[' && c <= '_')
        {
            stringbuilder.append(i);
            stringbuilder.append(22 + (c + -91));
            i = 2;
        } else
        if(c >= '`' && c <= '\177')
        {
            stringbuilder.append('\002');
            stringbuilder.append(c + -96);
            i = 2;
        } else
        if(c >= '\200')
        {
            stringbuilder.append("\001\036");
            i = 2 + encodeChar(c + -128, stringbuilder);
        } else
        {
            throw new IllegalArgumentException((new StringBuilder()).append("Illegal character: ").append(c).toString());
        }
        return i;
    }

    public int getEncodingMode()
    {
        return 1;
    }

    void handleEOD(EncoderContext encodercontext, StringBuilder stringbuilder)
    {
        int j;
        int l;
        int i = 2 * (stringbuilder.length() / 3);
        j = stringbuilder.length() % 3;
        int k = i + encodercontext.getCodewordCount();
        encodercontext.updateSymbolInfo(k);
        l = encodercontext.getSymbolInfo().getDataCapacity() - k;
        if(j != 2) goto _L2; else goto _L1
_L1:
        stringbuilder.append('\0');
        for(; stringbuilder.length() >= 3; writeNextTriplet(encodercontext, stringbuilder));
        if(encodercontext.hasMoreCharacters())
            encodercontext.writeCodeword('\376');
_L4:
        encodercontext.signalEncoderChange(0);
        return;
_L2:
        if(l == 1 && j == 1)
        {
            for(; stringbuilder.length() >= 3; writeNextTriplet(encodercontext, stringbuilder));
            if(encodercontext.hasMoreCharacters())
                encodercontext.writeCodeword('\376');
            encodercontext.pos = -1 + encodercontext.pos;
            continue; /* Loop/switch isn't completed */
        }
        if(j != 0)
            break; /* Loop/switch isn't completed */
        for(; stringbuilder.length() >= 3; writeNextTriplet(encodercontext, stringbuilder));
        if(l > 0 || encodercontext.hasMoreCharacters())
            encodercontext.writeCodeword('\376');
        if(true) goto _L4; else goto _L3
_L3:
        throw new IllegalStateException("Unexpected case. Please report!");
    }
}
