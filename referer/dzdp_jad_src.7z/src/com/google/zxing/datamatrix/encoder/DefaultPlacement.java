// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.datamatrix.encoder;

import java.util.Arrays;

public class DefaultPlacement
{

    private final byte bits[];
    private final CharSequence codewords;
    private final int numcols;
    private final int numrows;

    public DefaultPlacement(CharSequence charsequence, int i, int j)
    {
        codewords = charsequence;
        numcols = i;
        numrows = j;
        bits = new byte[i * j];
        Arrays.fill(bits, (byte)-1);
    }

    private void corner1(int i)
    {
        module(-1 + numrows, 0, i, 1);
        module(-1 + numrows, 1, i, 2);
        module(-1 + numrows, 2, i, 3);
        module(0, -2 + numcols, i, 4);
        module(0, -1 + numcols, i, 5);
        module(1, -1 + numcols, i, 6);
        module(2, -1 + numcols, i, 7);
        module(3, -1 + numcols, i, 8);
    }

    private void corner2(int i)
    {
        module(-3 + numrows, 0, i, 1);
        module(-2 + numrows, 0, i, 2);
        module(-1 + numrows, 0, i, 3);
        module(0, -4 + numcols, i, 4);
        module(0, -3 + numcols, i, 5);
        module(0, -2 + numcols, i, 6);
        module(0, -1 + numcols, i, 7);
        module(1, -1 + numcols, i, 8);
    }

    private void corner3(int i)
    {
        module(-3 + numrows, 0, i, 1);
        module(-2 + numrows, 0, i, 2);
        module(-1 + numrows, 0, i, 3);
        module(0, -2 + numcols, i, 4);
        module(0, -1 + numcols, i, 5);
        module(1, -1 + numcols, i, 6);
        module(2, -1 + numcols, i, 7);
        module(3, -1 + numcols, i, 8);
    }

    private void corner4(int i)
    {
        module(-1 + numrows, 0, i, 1);
        module(-1 + numrows, -1 + numcols, i, 2);
        module(0, -3 + numcols, i, 3);
        module(0, -2 + numcols, i, 4);
        module(0, -1 + numcols, i, 5);
        module(1, -3 + numcols, i, 6);
        module(1, -2 + numcols, i, 7);
        module(1, -1 + numcols, i, 8);
    }

    private void module(int i, int j, int k, int l)
    {
        boolean flag = true;
        if(i < 0)
        {
            i += numrows;
            j += 4 - (4 + numrows) % 8;
        }
        if(j < 0)
        {
            j += numcols;
            i += 4 - (4 + numcols) % 8;
        }
        if((codewords.charAt(k) & flag << 8 - l) == 0)
            flag = false;
        setBit(j, i, flag);
    }

    private void utah(int i, int j, int k)
    {
        module(i - 2, j - 2, k, 1);
        module(i - 2, j - 1, k, 2);
        module(i - 1, j - 2, k, 3);
        module(i - 1, j - 1, k, 4);
        module(i - 1, j, k, 5);
        module(i, j - 2, k, 6);
        module(i, j - 1, k, 7);
        module(i, j, k, 8);
    }

    public final boolean getBit(int i, int j)
    {
        boolean flag = true;
        if(bits[i + j * numcols] != flag)
            flag = false;
        return flag;
    }

    final byte[] getBits()
    {
        return bits;
    }

    final int getNumcols()
    {
        return numcols;
    }

    final int getNumrows()
    {
        return numrows;
    }

    final boolean hasBit(int i, int j)
    {
        boolean flag;
        if(bits[i + j * numcols] >= 0)
            flag = true;
        else
            flag = false;
        return flag;
    }

    public final void place()
    {
        int i;
        int j;
        int k;
        i = 0;
        j = 4;
        k = 0;
_L2:
        int l;
        int i1;
        int j1;
        if(j == numrows && k == 0)
        {
            int k2 = i + 1;
            corner1(i);
            i = k2;
        }
        if(j == -2 + numrows && k == 0 && numcols % 4 != 0)
        {
            int j2 = i + 1;
            corner2(i);
            i = j2;
        }
        if(j == -2 + numrows && k == 0 && numcols % 8 == 4)
        {
            int i2 = i + 1;
            corner3(i);
            i = i2;
        }
        if(j == 4 + numrows && k == 2 && numcols % 8 == 0)
        {
            int l1 = i + 1;
            corner4(i);
            i = l1;
        }
        do
        {
            if(j < numrows && k >= 0 && !hasBit(k, j))
            {
                int k1 = i + 1;
                utah(j, k, i);
                i = k1;
            }
            j -= 2;
            k += 2;
        } while(j >= 0 && k < numcols);
        l = j + 1;
        i1 = k + 3;
        j1 = i;
_L3:
label0:
        {
            if(l >= 0 && i1 < numcols && !hasBit(i1, l))
            {
                i = j1 + 1;
                utah(l, i1, j1);
            } else
            {
                i = j1;
            }
            l += 2;
            i1 -= 2;
            if(l < numrows && i1 >= 0)
                break label0;
            j = l + 3;
            k = i1 + 1;
            if(j >= numrows && k >= numcols)
            {
                if(!hasBit(-1 + numcols, -1 + numrows))
                {
                    setBit(-1 + numcols, -1 + numrows, true);
                    setBit(-2 + numcols, -2 + numrows, true);
                }
                return;
            }
        }
        if(true) goto _L2; else goto _L1
_L1:
        j1 = i;
          goto _L3
    }

    final void setBit(int i, int j, boolean flag)
    {
        byte abyte0[] = bits;
        int k = i + j * numcols;
        byte byte0;
        if(flag)
            byte0 = 1;
        else
            byte0 = 0;
        abyte0[k] = byte0;
    }
}
