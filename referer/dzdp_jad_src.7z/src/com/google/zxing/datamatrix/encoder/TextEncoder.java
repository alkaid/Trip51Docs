// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.datamatrix.encoder;


// Referenced classes of package com.google.zxing.datamatrix.encoder:
//            C40Encoder, HighLevelEncoder

final class TextEncoder extends C40Encoder
{

    TextEncoder()
    {
    }

    int encodeChar(char c, StringBuilder stringbuilder)
    {
        int i = 1;
        if(c == ' ')
            stringbuilder.append('\003');
        else
        if(c >= '0' && c <= '9')
            stringbuilder.append(4 + (c + -48));
        else
        if(c >= 'a' && c <= 'z')
            stringbuilder.append(14 + (c + -97));
        else
        if(c >= 0 && c <= '\037')
        {
            stringbuilder.append('\0');
            stringbuilder.append(c);
            i = 2;
        } else
        if(c >= '!' && c <= '/')
        {
            stringbuilder.append(i);
            stringbuilder.append(c + -33);
            i = 2;
        } else
        if(c >= ':' && c <= '@')
        {
            stringbuilder.append(i);
            stringbuilder.append(15 + (c + -58));
            i = 2;
        } else
        if(c >= '[' && c <= '_')
        {
            stringbuilder.append(i);
            stringbuilder.append(22 + (c + -91));
            i = 2;
        } else
        if(c == '`')
        {
            stringbuilder.append('\002');
            stringbuilder.append(c + -96);
            i = 2;
        } else
        if(c >= 'A' && c <= 'Z')
        {
            stringbuilder.append('\002');
            stringbuilder.append(1 + (c + -65));
            i = 2;
        } else
        if(c >= '{' && c <= '\177')
        {
            stringbuilder.append('\002');
            stringbuilder.append(27 + (c + -123));
            i = 2;
        } else
        if(c >= '\200')
        {
            stringbuilder.append("\001\036");
            i = 2 + encodeChar(c + -128, stringbuilder);
        } else
        {
            HighLevelEncoder.illegalCharacter(c);
            i = -1;
        }
        return i;
    }

    public int getEncodingMode()
    {
        return 2;
    }
}
