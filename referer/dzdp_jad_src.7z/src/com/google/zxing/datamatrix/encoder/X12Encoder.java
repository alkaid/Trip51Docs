// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.datamatrix.encoder;


// Referenced classes of package com.google.zxing.datamatrix.encoder:
//            C40Encoder, EncoderContext, HighLevelEncoder, SymbolInfo

final class X12Encoder extends C40Encoder
{

    X12Encoder()
    {
    }

    public void encode(EncoderContext encodercontext)
    {
        StringBuilder stringbuilder = new StringBuilder();
        do
        {
            if(!encodercontext.hasMoreCharacters())
                break;
            char c = encodercontext.getCurrentChar();
            encodercontext.pos = 1 + encodercontext.pos;
            encodeChar(c, stringbuilder);
            if(stringbuilder.length() % 3 != 0)
                continue;
            writeNextTriplet(encodercontext, stringbuilder);
            int i = HighLevelEncoder.lookAheadTest(encodercontext.getMessage(), encodercontext.pos, getEncodingMode());
            if(i == getEncodingMode())
                continue;
            encodercontext.signalEncoderChange(i);
            break;
        } while(true);
        handleEOD(encodercontext, stringbuilder);
    }

    int encodeChar(char c, StringBuilder stringbuilder)
    {
        if(c == '\r')
            stringbuilder.append('\0');
        else
        if(c == '*')
            stringbuilder.append('\001');
        else
        if(c == '>')
            stringbuilder.append('\002');
        else
        if(c == ' ')
            stringbuilder.append('\003');
        else
        if(c >= '0' && c <= '9')
            stringbuilder.append(4 + (c + -48));
        else
        if(c >= 'A' && c <= 'Z')
            stringbuilder.append(14 + (c + -65));
        else
            HighLevelEncoder.illegalCharacter(c);
        return 1;
    }

    public int getEncodingMode()
    {
        return 3;
    }

    void handleEOD(EncoderContext encodercontext, StringBuilder stringbuilder)
    {
        encodercontext.updateSymbolInfo();
        int i = encodercontext.getSymbolInfo().getDataCapacity() - encodercontext.getCodewordCount();
        int j = stringbuilder.length();
        encodercontext.pos = encodercontext.pos - j;
        if(encodercontext.getRemainingCharacters() > 1 || i > 1 || encodercontext.getRemainingCharacters() != i)
            encodercontext.writeCodeword('\376');
        if(encodercontext.getNewEncoding() < 0)
            encodercontext.signalEncoderChange(0);
    }
}
