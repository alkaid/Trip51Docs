// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.datamatrix.encoder;


// Referenced classes of package com.google.zxing.datamatrix.encoder:
//            Encoder, EncoderContext, HighLevelEncoder, SymbolInfo

final class Base256Encoder
    implements Encoder
{

    Base256Encoder()
    {
    }

    private static char randomize255State(char c, int i)
    {
        int j = c + (1 + (i * 149) % 255);
        char c1;
        if(j <= 255)
            c1 = j;
        else
            c1 = j + -256;
        return c1;
    }

    public void encode(EncoderContext encodercontext)
    {
        StringBuilder stringbuilder = new StringBuilder();
        stringbuilder.append('\0');
        do
        {
            if(!encodercontext.hasMoreCharacters())
                break;
            stringbuilder.append(encodercontext.getCurrentChar());
            encodercontext.pos = 1 + encodercontext.pos;
            int i1 = HighLevelEncoder.lookAheadTest(encodercontext.getMessage(), encodercontext.pos, getEncodingMode());
            if(i1 == getEncodingMode())
                continue;
            encodercontext.signalEncoderChange(i1);
            break;
        } while(true);
        int i = -1 + stringbuilder.length();
        int j = 1 + (i + encodercontext.getCodewordCount());
        encodercontext.updateSymbolInfo(j);
        boolean flag;
        int k;
        if(encodercontext.getSymbolInfo().getDataCapacity() - j > 0)
            flag = true;
        else
            flag = false;
        if(encodercontext.hasMoreCharacters() || flag)
            if(i <= 249)
                stringbuilder.setCharAt(0, (char)i);
            else
            if(i > 249 && i <= 1555)
            {
                stringbuilder.setCharAt(0, (char)(249 + i / 250));
                stringbuilder.insert(1, (char)(i % 250));
            } else
            {
                throw new IllegalStateException((new StringBuilder()).append("Message length not in valid ranges: ").append(i).toString());
            }
        k = 0;
        for(int l = stringbuilder.length(); k < l; k++)
            encodercontext.writeCodeword(randomize255State(stringbuilder.charAt(k), 1 + encodercontext.getCodewordCount()));

    }

    public int getEncodingMode()
    {
        return 5;
    }
}
