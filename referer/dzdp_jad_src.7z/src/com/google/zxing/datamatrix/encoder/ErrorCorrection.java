// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.datamatrix.encoder;


// Referenced classes of package com.google.zxing.datamatrix.encoder:
//            SymbolInfo

public final class ErrorCorrection
{

    private static final int ALOG[];
    private static final int FACTORS[][];
    private static final int FACTOR_SETS[];
    private static final int LOG[];
    private static final int MODULO_VALUE = 301;

    private ErrorCorrection()
    {
    }

    private static String createECCBlock(CharSequence charsequence, int i)
    {
        return createECCBlock(charsequence, 0, charsequence.length(), i);
    }

    private static String createECCBlock(CharSequence charsequence, int i, int j, int k)
    {
        int l = -1;
        int i1 = 0;
label0:
        do
        {
label1:
            {
                if(i1 < FACTOR_SETS.length)
                {
                    if(FACTOR_SETS[i1] != k)
                        break label1;
                    l = i1;
                }
                if(l < 0)
                    throw new IllegalArgumentException((new StringBuilder()).append("Illegal number of error correction codewords specified: ").append(k).toString());
                break label0;
            }
            i1++;
        } while(true);
        int ai[] = FACTORS[l];
        char ac[] = new char[k];
        for(int j1 = 0; j1 < k; j1++)
            ac[j1] = '\0';

        int k1 = i;
        while(k1 < i + j) 
        {
            int i2 = ac[k - 1] ^ charsequence.charAt(k1);
            int j2 = k - 1;
            while(j2 > 0) 
            {
                if(i2 != 0 && ai[j2] != 0)
                    ac[j2] = (char)(ac[j2 - 1] ^ ALOG[(LOG[i2] + LOG[ai[j2]]) % 255]);
                else
                    ac[j2] = ac[j2 - 1];
                j2--;
            }
            if(i2 != 0 && ai[0] != 0)
                ac[0] = (char)ALOG[(LOG[i2] + LOG[ai[0]]) % 255];
            else
                ac[0] = '\0';
            k1++;
        }
        char ac1[] = new char[k];
        for(int l1 = 0; l1 < k; l1++)
            ac1[l1] = ac[-1 + (k - l1)];

        return String.valueOf(ac1);
    }

    public static String encodeECC200(String s, SymbolInfo symbolinfo)
    {
        if(s.length() != symbolinfo.getDataCapacity())
            throw new IllegalArgumentException("The number of codewords does not match the selected symbol");
        StringBuilder stringbuilder = new StringBuilder(symbolinfo.getDataCapacity() + symbolinfo.getErrorCodewords());
        stringbuilder.append(s);
        int i = symbolinfo.getInterleavedBlockCount();
        if(i == 1)
        {
            stringbuilder.append(createECCBlock(s, symbolinfo.getErrorCodewords()));
        } else
        {
            stringbuilder.setLength(stringbuilder.capacity());
            int ai[] = new int[i];
            int ai1[] = new int[i];
            int ai2[] = new int[i];
            for(int j = 0; j < i; j++)
            {
                ai[j] = symbolinfo.getDataLengthForInterleavedBlock(j + 1);
                ai1[j] = symbolinfo.getErrorLengthForInterleavedBlock(j + 1);
                ai2[j] = 0;
                if(j > 0)
                    ai2[j] = ai2[j - 1] + ai[j];
            }

            int k = 0;
            while(k < i) 
            {
                StringBuilder stringbuilder1 = new StringBuilder(ai[k]);
                for(int l = k; l < symbolinfo.getDataCapacity(); l += i)
                    stringbuilder1.append(s.charAt(l));

                String s1 = createECCBlock(stringbuilder1.toString(), ai1[k]);
                int i1 = 0;
                for(int j1 = k; j1 < i * ai1[k];)
                {
                    int k1 = j1 + symbolinfo.getDataCapacity();
                    int l1 = i1 + 1;
                    stringbuilder.setCharAt(k1, s1.charAt(i1));
                    j1 += i;
                    i1 = l1;
                }

                k++;
            }
        }
        return stringbuilder.toString();
    }

    static 
    {
        int ai[] = new int[16];
        ai[0] = 5;
        ai[1] = 7;
        ai[2] = 10;
        ai[3] = 11;
        ai[4] = 12;
        ai[5] = 14;
        ai[6] = 18;
        ai[7] = 20;
        ai[8] = 24;
        ai[9] = 28;
        ai[10] = 36;
        ai[11] = 42;
        ai[12] = 48;
        ai[13] = 56;
        ai[14] = 62;
        ai[15] = 68;
        FACTOR_SETS = ai;
        int ai1[][] = new int[16][];
        int ai2[] = new int[5];
        ai2[0] = 228;
        ai2[1] = 48;
        ai2[2] = 15;
        ai2[3] = 111;
        ai2[4] = 62;
        ai1[0] = ai2;
        int ai3[] = new int[7];
        ai3[0] = 23;
        ai3[1] = 68;
        ai3[2] = 144;
        ai3[3] = 134;
        ai3[4] = 240;
        ai3[5] = 92;
        ai3[6] = 254;
        ai1[1] = ai3;
        int ai4[] = new int[10];
        ai4[0] = 28;
        ai4[1] = 24;
        ai4[2] = 185;
        ai4[3] = 166;
        ai4[4] = 223;
        ai4[5] = 248;
        ai4[6] = 116;
        ai4[7] = 255;
        ai4[8] = 110;
        ai4[9] = 61;
        ai1[2] = ai4;
        int ai5[] = new int[11];
        ai5[0] = 175;
        ai5[1] = 138;
        ai5[2] = 205;
        ai5[3] = 12;
        ai5[4] = 194;
        ai5[5] = 168;
        ai5[6] = 39;
        ai5[7] = 245;
        ai5[8] = 60;
        ai5[9] = 97;
        ai5[10] = 120;
        ai1[3] = ai5;
        int ai6[] = new int[12];
        ai6[0] = 41;
        ai6[1] = 153;
        ai6[2] = 158;
        ai6[3] = 91;
        ai6[4] = 61;
        ai6[5] = 42;
        ai6[6] = 142;
        ai6[7] = 213;
        ai6[8] = 97;
        ai6[9] = 178;
        ai6[10] = 100;
        ai6[11] = 242;
        ai1[4] = ai6;
        int ai7[] = new int[14];
        ai7[0] = 156;
        ai7[1] = 97;
        ai7[2] = 192;
        ai7[3] = 252;
        ai7[4] = 95;
        ai7[5] = 9;
        ai7[6] = 157;
        ai7[7] = 119;
        ai7[8] = 138;
        ai7[9] = 45;
        ai7[10] = 18;
        ai7[11] = 186;
        ai7[12] = 83;
        ai7[13] = 185;
        ai1[5] = ai7;
        int ai8[] = new int[18];
        ai8[0] = 83;
        ai8[1] = 195;
        ai8[2] = 100;
        ai8[3] = 39;
        ai8[4] = 188;
        ai8[5] = 75;
        ai8[6] = 66;
        ai8[7] = 61;
        ai8[8] = 241;
        ai8[9] = 213;
        ai8[10] = 109;
        ai8[11] = 129;
        ai8[12] = 94;
        ai8[13] = 254;
        ai8[14] = 225;
        ai8[15] = 48;
        ai8[16] = 90;
        ai8[17] = 188;
        ai1[6] = ai8;
        int ai9[] = new int[20];
        ai9[0] = 15;
        ai9[1] = 195;
        ai9[2] = 244;
        ai9[3] = 9;
        ai9[4] = 233;
        ai9[5] = 71;
        ai9[6] = 168;
        ai9[7] = 2;
        ai9[8] = 188;
        ai9[9] = 160;
        ai9[10] = 153;
        ai9[11] = 145;
        ai9[12] = 253;
        ai9[13] = 79;
        ai9[14] = 108;
        ai9[15] = 82;
        ai9[16] = 27;
        ai9[17] = 174;
        ai9[18] = 186;
        ai9[19] = 172;
        ai1[7] = ai9;
        int ai10[] = new int[24];
        ai10[0] = 52;
        ai10[1] = 190;
        ai10[2] = 88;
        ai10[3] = 205;
        ai10[4] = 109;
        ai10[5] = 39;
        ai10[6] = 176;
        ai10[7] = 21;
        ai10[8] = 155;
        ai10[9] = 197;
        ai10[10] = 251;
        ai10[11] = 223;
        ai10[12] = 155;
        ai10[13] = 21;
        ai10[14] = 5;
        ai10[15] = 172;
        ai10[16] = 254;
        ai10[17] = 124;
        ai10[18] = 12;
        ai10[19] = 181;
        ai10[20] = 184;
        ai10[21] = 96;
        ai10[22] = 50;
        ai10[23] = 193;
        ai1[8] = ai10;
        int ai11[] = new int[28];
        ai11[0] = 211;
        ai11[1] = 231;
        ai11[2] = 43;
        ai11[3] = 97;
        ai11[4] = 71;
        ai11[5] = 96;
        ai11[6] = 103;
        ai11[7] = 174;
        ai11[8] = 37;
        ai11[9] = 151;
        ai11[10] = 170;
        ai11[11] = 53;
        ai11[12] = 75;
        ai11[13] = 34;
        ai11[14] = 249;
        ai11[15] = 121;
        ai11[16] = 17;
        ai11[17] = 138;
        ai11[18] = 110;
        ai11[19] = 213;
        ai11[20] = 141;
        ai11[21] = 136;
        ai11[22] = 120;
        ai11[23] = 151;
        ai11[24] = 233;
        ai11[25] = 168;
        ai11[26] = 93;
        ai11[27] = 255;
        ai1[9] = ai11;
        int ai12[] = new int[36];
        ai12[0] = 245;
        ai12[1] = 127;
        ai12[2] = 242;
        ai12[3] = 218;
        ai12[4] = 130;
        ai12[5] = 250;
        ai12[6] = 162;
        ai12[7] = 181;
        ai12[8] = 102;
        ai12[9] = 120;
        ai12[10] = 84;
        ai12[11] = 179;
        ai12[12] = 220;
        ai12[13] = 251;
        ai12[14] = 80;
        ai12[15] = 182;
        ai12[16] = 229;
        ai12[17] = 18;
        ai12[18] = 2;
        ai12[19] = 4;
        ai12[20] = 68;
        ai12[21] = 33;
        ai12[22] = 101;
        ai12[23] = 137;
        ai12[24] = 95;
        ai12[25] = 119;
        ai12[26] = 115;
        ai12[27] = 44;
        ai12[28] = 175;
        ai12[29] = 184;
        ai12[30] = 59;
        ai12[31] = 25;
        ai12[32] = 225;
        ai12[33] = 98;
        ai12[34] = 81;
        ai12[35] = 112;
        ai1[10] = ai12;
        int ai13[] = new int[42];
        ai13[0] = 77;
        ai13[1] = 193;
        ai13[2] = 137;
        ai13[3] = 31;
        ai13[4] = 19;
        ai13[5] = 38;
        ai13[6] = 22;
        ai13[7] = 153;
        ai13[8] = 247;
        ai13[9] = 105;
        ai13[10] = 122;
        ai13[11] = 2;
        ai13[12] = 245;
        ai13[13] = 133;
        ai13[14] = 242;
        ai13[15] = 8;
        ai13[16] = 175;
        ai13[17] = 95;
        ai13[18] = 100;
        ai13[19] = 9;
        ai13[20] = 167;
        ai13[21] = 105;
        ai13[22] = 214;
        ai13[23] = 111;
        ai13[24] = 57;
        ai13[25] = 121;
        ai13[26] = 21;
        ai13[27] = 1;
        ai13[28] = 253;
        ai13[29] = 57;
        ai13[30] = 54;
        ai13[31] = 101;
        ai13[32] = 248;
        ai13[33] = 202;
        ai13[34] = 69;
        ai13[35] = 50;
        ai13[36] = 150;
        ai13[37] = 177;
        ai13[38] = 226;
        ai13[39] = 5;
        ai13[40] = 9;
        ai13[41] = 5;
        ai1[11] = ai13;
        int ai14[] = new int[48];
        ai14[0] = 245;
        ai14[1] = 132;
        ai14[2] = 172;
        ai14[3] = 223;
        ai14[4] = 96;
        ai14[5] = 32;
        ai14[6] = 117;
        ai14[7] = 22;
        ai14[8] = 238;
        ai14[9] = 133;
        ai14[10] = 238;
        ai14[11] = 231;
        ai14[12] = 205;
        ai14[13] = 188;
        ai14[14] = 237;
        ai14[15] = 87;
        ai14[16] = 191;
        ai14[17] = 106;
        ai14[18] = 16;
        ai14[19] = 147;
        ai14[20] = 118;
        ai14[21] = 23;
        ai14[22] = 37;
        ai14[23] = 90;
        ai14[24] = 170;
        ai14[25] = 205;
        ai14[26] = 131;
        ai14[27] = 88;
        ai14[28] = 120;
        ai14[29] = 100;
        ai14[30] = 66;
        ai14[31] = 138;
        ai14[32] = 186;
        ai14[33] = 240;
        ai14[34] = 82;
        ai14[35] = 44;
        ai14[36] = 176;
        ai14[37] = 87;
        ai14[38] = 187;
        ai14[39] = 147;
        ai14[40] = 160;
        ai14[41] = 175;
        ai14[42] = 69;
        ai14[43] = 213;
        ai14[44] = 92;
        ai14[45] = 253;
        ai14[46] = 225;
        ai14[47] = 19;
        ai1[12] = ai14;
        int ai15[] = new int[56];
        ai15[0] = 175;
        ai15[1] = 9;
        ai15[2] = 223;
        ai15[3] = 238;
        ai15[4] = 12;
        ai15[5] = 17;
        ai15[6] = 220;
        ai15[7] = 208;
        ai15[8] = 100;
        ai15[9] = 29;
        ai15[10] = 175;
        ai15[11] = 170;
        ai15[12] = 230;
        ai15[13] = 192;
        ai15[14] = 215;
        ai15[15] = 235;
        ai15[16] = 150;
        ai15[17] = 159;
        ai15[18] = 36;
        ai15[19] = 223;
        ai15[20] = 38;
        ai15[21] = 200;
        ai15[22] = 132;
        ai15[23] = 54;
        ai15[24] = 228;
        ai15[25] = 146;
        ai15[26] = 218;
        ai15[27] = 234;
        ai15[28] = 117;
        ai15[29] = 203;
        ai15[30] = 29;
        ai15[31] = 232;
        ai15[32] = 144;
        ai15[33] = 238;
        ai15[34] = 22;
        ai15[35] = 150;
        ai15[36] = 201;
        ai15[37] = 117;
        ai15[38] = 62;
        ai15[39] = 207;
        ai15[40] = 164;
        ai15[41] = 13;
        ai15[42] = 137;
        ai15[43] = 245;
        ai15[44] = 127;
        ai15[45] = 67;
        ai15[46] = 247;
        ai15[47] = 28;
        ai15[48] = 155;
        ai15[49] = 43;
        ai15[50] = 203;
        ai15[51] = 107;
        ai15[52] = 233;
        ai15[53] = 53;
        ai15[54] = 143;
        ai15[55] = 46;
        ai1[13] = ai15;
        int ai16[] = new int[62];
        ai16[0] = 242;
        ai16[1] = 93;
        ai16[2] = 169;
        ai16[3] = 50;
        ai16[4] = 144;
        ai16[5] = 210;
        ai16[6] = 39;
        ai16[7] = 118;
        ai16[8] = 202;
        ai16[9] = 188;
        ai16[10] = 201;
        ai16[11] = 189;
        ai16[12] = 143;
        ai16[13] = 108;
        ai16[14] = 196;
        ai16[15] = 37;
        ai16[16] = 185;
        ai16[17] = 112;
        ai16[18] = 134;
        ai16[19] = 230;
        ai16[20] = 245;
        ai16[21] = 63;
        ai16[22] = 197;
        ai16[23] = 190;
        ai16[24] = 250;
        ai16[25] = 106;
        ai16[26] = 185;
        ai16[27] = 221;
        ai16[28] = 175;
        ai16[29] = 64;
        ai16[30] = 114;
        ai16[31] = 71;
        ai16[32] = 161;
        ai16[33] = 44;
        ai16[34] = 147;
        ai16[35] = 6;
        ai16[36] = 27;
        ai16[37] = 218;
        ai16[38] = 51;
        ai16[39] = 63;
        ai16[40] = 87;
        ai16[41] = 10;
        ai16[42] = 40;
        ai16[43] = 130;
        ai16[44] = 188;
        ai16[45] = 17;
        ai16[46] = 163;
        ai16[47] = 31;
        ai16[48] = 176;
        ai16[49] = 170;
        ai16[50] = 4;
        ai16[51] = 107;
        ai16[52] = 232;
        ai16[53] = 7;
        ai16[54] = 94;
        ai16[55] = 166;
        ai16[56] = 224;
        ai16[57] = 124;
        ai16[58] = 86;
        ai16[59] = 47;
        ai16[60] = 11;
        ai16[61] = 204;
        ai1[14] = ai16;
        int ai17[] = new int[68];
        ai17[0] = 220;
        ai17[1] = 228;
        ai17[2] = 173;
        ai17[3] = 89;
        ai17[4] = 251;
        ai17[5] = 149;
        ai17[6] = 159;
        ai17[7] = 56;
        ai17[8] = 89;
        ai17[9] = 33;
        ai17[10] = 147;
        ai17[11] = 244;
        ai17[12] = 154;
        ai17[13] = 36;
        ai17[14] = 73;
        ai17[15] = 127;
        ai17[16] = 213;
        ai17[17] = 136;
        ai17[18] = 248;
        ai17[19] = 180;
        ai17[20] = 234;
        ai17[21] = 197;
        ai17[22] = 158;
        ai17[23] = 177;
        ai17[24] = 68;
        ai17[25] = 122;
        ai17[26] = 93;
        ai17[27] = 213;
        ai17[28] = 15;
        ai17[29] = 160;
        ai17[30] = 227;
        ai17[31] = 236;
        ai17[32] = 66;
        ai17[33] = 139;
        ai17[34] = 153;
        ai17[35] = 185;
        ai17[36] = 202;
        ai17[37] = 167;
        ai17[38] = 179;
        ai17[39] = 25;
        ai17[40] = 220;
        ai17[41] = 232;
        ai17[42] = 96;
        ai17[43] = 210;
        ai17[44] = 231;
        ai17[45] = 136;
        ai17[46] = 223;
        ai17[47] = 239;
        ai17[48] = 181;
        ai17[49] = 241;
        ai17[50] = 59;
        ai17[51] = 52;
        ai17[52] = 172;
        ai17[53] = 25;
        ai17[54] = 49;
        ai17[55] = 232;
        ai17[56] = 211;
        ai17[57] = 189;
        ai17[58] = 64;
        ai17[59] = 54;
        ai17[60] = 108;
        ai17[61] = 153;
        ai17[62] = 132;
        ai17[63] = 63;
        ai17[64] = 96;
        ai17[65] = 103;
        ai17[66] = 82;
        ai17[67] = 186;
        ai1[15] = ai17;
        FACTORS = ai1;
        LOG = new int[256];
        ALOG = new int[255];
        int i = 1;
        for(int j = 0; j < 255; j++)
        {
            ALOG[j] = i;
            LOG[i] = j;
            i *= 2;
            if(i >= 256)
                i ^= 0x12d;
        }

    }
}
