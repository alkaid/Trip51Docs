// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.datamatrix.encoder;


// Referenced classes of package com.google.zxing.datamatrix.encoder:
//            Encoder, HighLevelEncoder, EncoderContext, SymbolInfo

final class EdifactEncoder
    implements Encoder
{

    EdifactEncoder()
    {
    }

    private static void encodeChar(char c, StringBuilder stringbuilder)
    {
        if(c >= ' ' && c <= '?')
            stringbuilder.append(c);
        else
        if(c >= '@' && c <= '^')
            stringbuilder.append(c + -64);
        else
            HighLevelEncoder.illegalCharacter(c);
    }

    private static String encodeToCodewords(CharSequence charsequence, int i)
    {
        char c = '\0';
        int j = charsequence.length() - i;
        if(j == 0)
            throw new IllegalStateException("StringBuilder must not be empty");
        char c1 = charsequence.charAt(i);
        char c2;
        char c3;
        int k;
        int l;
        int i1;
        int j1;
        StringBuilder stringbuilder;
        if(j >= 2)
            c2 = charsequence.charAt(i + 1);
        else
            c2 = '\0';
        if(j >= 3)
            c3 = charsequence.charAt(i + 2);
        else
            c3 = '\0';
        if(j >= 4)
            c = charsequence.charAt(i + 3);
        k = c + ((c1 << 18) + (c2 << 12) + (c3 << 6));
        l = 0xff & k >> 16;
        i1 = 0xff & k >> 8;
        j1 = k & 0xff;
        stringbuilder = new StringBuilder(3);
        stringbuilder.append(l);
        if(j >= 2)
            stringbuilder.append(i1);
        if(j >= 3)
            stringbuilder.append(j1);
        return stringbuilder.toString();
    }

    private static void handleEOD(EncoderContext encodercontext, CharSequence charsequence)
    {
        int i = 1;
        int j = charsequence.length();
        if(j != 0) goto _L2; else goto _L1
_L1:
        encodercontext.signalEncoderChange(0);
_L3:
        return;
_L2:
        if(j != i)
            break MISSING_BLOCK_LABEL_70;
        int i1;
        int j1;
        encodercontext.updateSymbolInfo();
        i1 = encodercontext.getSymbolInfo().getDataCapacity() - encodercontext.getCodewordCount();
        j1 = encodercontext.getRemainingCharacters();
        if(j1 != 0 || i1 > 2)
            break MISSING_BLOCK_LABEL_70;
        encodercontext.signalEncoderChange(0);
          goto _L3
        if(j <= 4)
            break MISSING_BLOCK_LABEL_94;
        throw new IllegalStateException("Count must not exceed 4");
        Exception exception;
        exception;
        encodercontext.signalEncoderChange(0);
        throw exception;
        int k = j - 1;
        String s = encodeToCodewords(charsequence, 0);
        if(encodercontext.hasMoreCharacters()) goto _L5; else goto _L4
_L4:
        int l = i;
          goto _L6
_L10:
        if(k <= 2)
        {
            encodercontext.updateSymbolInfo(k + encodercontext.getCodewordCount());
            if(encodercontext.getSymbolInfo().getDataCapacity() - encodercontext.getCodewordCount() >= 3)
            {
                i = 0;
                encodercontext.updateSymbolInfo(encodercontext.getCodewordCount() + s.length());
            }
        }
        if(i == 0) goto _L8; else goto _L7
_L7:
        encodercontext.resetSymbolInfo();
        encodercontext.pos = encodercontext.pos - k;
_L9:
        encodercontext.signalEncoderChange(0);
          goto _L3
_L5:
        l = 0;
          goto _L6
_L11:
        i = 0;
        break; /* Loop/switch isn't completed */
_L8:
        encodercontext.writeCodewords(s);
          goto _L9
_L6:
        if(l == 0 || k > 2) goto _L11; else goto _L10
    }

    public void encode(EncoderContext encodercontext)
    {
        StringBuilder stringbuilder = new StringBuilder();
        do
        {
            if(!encodercontext.hasMoreCharacters())
                break;
            encodeChar(encodercontext.getCurrentChar(), stringbuilder);
            encodercontext.pos = 1 + encodercontext.pos;
            if(stringbuilder.length() < 4)
                continue;
            encodercontext.writeCodewords(encodeToCodewords(stringbuilder, 0));
            stringbuilder.delete(0, 4);
            if(HighLevelEncoder.lookAheadTest(encodercontext.getMessage(), encodercontext.pos, getEncodingMode()) == getEncodingMode())
                continue;
            encodercontext.signalEncoderChange(0);
            break;
        } while(true);
        stringbuilder.append('\037');
        handleEOD(encodercontext, stringbuilder);
    }

    public int getEncodingMode()
    {
        return 4;
    }
}
