// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.datamatrix.encoder;


// Referenced classes of package com.google.zxing.datamatrix.encoder:
//            SymbolInfo

final class DataMatrixSymbolInfo144 extends SymbolInfo
{

    DataMatrixSymbolInfo144()
    {
        super(false, 1558, 620, 22, 22, 36, -1, 62);
    }

    public int getDataLengthForInterleavedBlock(int i)
    {
        char c;
        if(i <= 8)
            c = '\234';
        else
            c = '\233';
        return c;
    }

    public int getInterleavedBlockCount()
    {
        return 10;
    }
}
