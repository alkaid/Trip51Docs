// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.datamatrix.encoder;

import com.google.zxing.Dimension;
import java.util.Arrays;

// Referenced classes of package com.google.zxing.datamatrix.encoder:
//            SymbolShapeHint, Encoder, ASCIIEncoder, C40Encoder, 
//            TextEncoder, X12Encoder, EdifactEncoder, Base256Encoder, 
//            EncoderContext, SymbolInfo

public final class HighLevelEncoder
{

    static final int ASCII_ENCODATION = 0;
    static final int BASE256_ENCODATION = 5;
    static final int C40_ENCODATION = 1;
    static final char C40_UNLATCH = 254;
    static final int EDIFACT_ENCODATION = 4;
    static final char LATCH_TO_ANSIX12 = 238;
    static final char LATCH_TO_BASE256 = 231;
    static final char LATCH_TO_C40 = 230;
    static final char LATCH_TO_EDIFACT = 240;
    static final char LATCH_TO_TEXT = 239;
    private static final char MACRO_05 = 236;
    private static final String MACRO_05_HEADER = "[)>\03605\035";
    private static final char MACRO_06 = 237;
    private static final String MACRO_06_HEADER = "[)>\03606\035";
    private static final String MACRO_TRAILER = "\036\004";
    private static final char PAD = 129;
    static final int TEXT_ENCODATION = 2;
    static final char UPPER_SHIFT = 235;
    static final int X12_ENCODATION = 3;
    static final char X12_UNLATCH = 254;

    private HighLevelEncoder()
    {
    }

    public static int determineConsecutiveDigitCount(CharSequence charsequence, int i)
    {
        int j = 0;
        int k = charsequence.length();
        int l = i;
        if(l < k)
        {
            char c = charsequence.charAt(l);
            do
            {
                if(!isDigit(c) || l >= k)
                    break;
                j++;
                if(++l < k)
                    c = charsequence.charAt(l);
            } while(true);
        }
        return j;
    }

    public static String encodeHighLevel(String s)
    {
        return encodeHighLevel(s, SymbolShapeHint.FORCE_NONE, null, null);
    }

    public static String encodeHighLevel(String s, SymbolShapeHint symbolshapehint, Dimension dimension, Dimension dimension1)
    {
        Encoder aencoder[];
        EncoderContext encodercontext;
        aencoder = new Encoder[6];
        aencoder[0] = new ASCIIEncoder();
        aencoder[1] = new C40Encoder();
        aencoder[2] = new TextEncoder();
        aencoder[3] = new X12Encoder();
        aencoder[4] = new EdifactEncoder();
        aencoder[5] = new Base256Encoder();
        encodercontext = new EncoderContext(s);
        encodercontext.setSymbolShape(symbolshapehint);
        encodercontext.setSizeConstraints(dimension, dimension1);
        if(!s.startsWith("[)>\03605\035") || !s.endsWith("\036\004")) goto _L2; else goto _L1
_L1:
        encodercontext.writeCodeword('\354');
        encodercontext.setSkipAtEnd(2);
        encodercontext.pos = encodercontext.pos + "[)>\03605\035".length();
_L4:
        int i;
        i = 0;
        do
        {
            if(!encodercontext.hasMoreCharacters())
                break;
            aencoder[i].encode(encodercontext);
            if(encodercontext.getNewEncoding() >= 0)
            {
                i = encodercontext.getNewEncoding();
                encodercontext.resetEncoderSignal();
            }
        } while(true);
        break; /* Loop/switch isn't completed */
_L2:
        if(s.startsWith("[)>\03606\035") && s.endsWith("\036\004"))
        {
            encodercontext.writeCodeword('\355');
            encodercontext.setSkipAtEnd(2);
            encodercontext.pos = encodercontext.pos + "[)>\03606\035".length();
        }
        if(true) goto _L4; else goto _L3
_L3:
        int j = encodercontext.getCodewordCount();
        encodercontext.updateSymbolInfo();
        int k = encodercontext.getSymbolInfo().getDataCapacity();
        if(j < k && i != 0 && i != 5)
            encodercontext.writeCodeword('\376');
        StringBuilder stringbuilder = encodercontext.getCodewords();
        if(stringbuilder.length() < k)
            stringbuilder.append('\201');
        for(; stringbuilder.length() < k; stringbuilder.append(randomize253State('\201', 1 + stringbuilder.length())));
        return encodercontext.getCodewords().toString();
    }

    private static int findMinimums(float af[], int ai[], int i, byte abyte0[])
    {
        Arrays.fill(abyte0, (byte)0);
        for(int j = 0; j < 6; j++)
        {
            ai[j] = (int)Math.ceil(af[j]);
            int k = ai[j];
            if(i > k)
            {
                i = k;
                Arrays.fill(abyte0, (byte)0);
            }
            if(i == k)
                abyte0[j] = (byte)(1 + abyte0[j]);
        }

        return i;
    }

    private static int getMinimumCount(byte abyte0[])
    {
        int i = 0;
        for(int j = 0; j < 6; j++)
            i += abyte0[j];

        return i;
    }

    static void illegalCharacter(char c)
    {
        String s = Integer.toHexString(c);
        String s1 = (new StringBuilder()).append("0000".substring(0, 4 - s.length())).append(s).toString();
        throw new IllegalArgumentException((new StringBuilder()).append("Illegal character: ").append(c).append(" (0x").append(s1).append(')').toString());
    }

    static boolean isDigit(char c)
    {
        boolean flag;
        if(c >= '0' && c <= '9')
            flag = true;
        else
            flag = false;
        return flag;
    }

    static boolean isExtendedASCII(char c)
    {
        boolean flag;
        if(c >= '\200' && c <= '\377')
            flag = true;
        else
            flag = false;
        return flag;
    }

    private static boolean isNativeC40(char c)
    {
        boolean flag;
        if(c == ' ' || c >= '0' && c <= '9' || c >= 'A' && c <= 'Z')
            flag = true;
        else
            flag = false;
        return flag;
    }

    private static boolean isNativeEDIFACT(char c)
    {
        boolean flag;
        if(c >= ' ' && c <= '^')
            flag = true;
        else
            flag = false;
        return flag;
    }

    private static boolean isNativeText(char c)
    {
        boolean flag;
        if(c == ' ' || c >= '0' && c <= '9' || c >= 'a' && c <= 'z')
            flag = true;
        else
            flag = false;
        return flag;
    }

    private static boolean isNativeX12(char c)
    {
        boolean flag;
        if(isX12TermSep(c) || c == ' ' || c >= '0' && c <= '9' || c >= 'A' && c <= 'Z')
            flag = true;
        else
            flag = false;
        return flag;
    }

    private static boolean isSpecialB256(char c)
    {
        return false;
    }

    private static boolean isX12TermSep(char c)
    {
        boolean flag;
        if(c == '\r' || c == '*' || c == '>')
            flag = true;
        else
            flag = false;
        return flag;
    }

    static int lookAheadTest(CharSequence charsequence, int i, int j)
    {
        if(i < charsequence.length()) goto _L2; else goto _L1
_L1:
        return j;
_L2:
label0:
        {
label1:
            {
                float af[];
                int k;
                if(j == 0)
                {
                    af = new float[6];
                    af[0] = 0.0F;
                    af[1] = 1.0F;
                    af[2] = 1.0F;
                    af[3] = 1.0F;
                    af[4] = 1.0F;
                    af[5] = 1.25F;
                } else
                {
                    af = new float[6];
                    af[0] = 1.0F;
                    af[1] = 2.0F;
                    af[2] = 2.0F;
                    af[3] = 2.0F;
                    af[4] = 2.0F;
                    af[5] = 2.25F;
                    af[j] = 0.0F;
                }
                k = 0;
                int ai[];
                do
                {
                    do
                    {
                        byte abyte0[];
                        int l;
                        do
                        {
                            if(i + k == charsequence.length())
                            {
                                byte abyte1[] = new byte[6];
                                int ai1[] = new int[6];
                                int j1 = findMinimums(af, ai1, 0x7fffffff, abyte1);
                                int k1 = getMinimumCount(abyte1);
                                if(ai1[0] == j1)
                                    j = 0;
                                else
                                if(k1 == 1 && abyte1[5] > 0)
                                    j = 5;
                                else
                                if(k1 == 1 && abyte1[4] > 0)
                                    j = 4;
                                else
                                if(k1 == 1 && abyte1[2] > 0)
                                    j = 2;
                                else
                                if(k1 == 1 && abyte1[3] > 0)
                                    j = 3;
                                else
                                    j = 1;
                                continue; /* Loop/switch isn't completed */
                            }
                            char c = charsequence.charAt(i + k);
                            k++;
                            if(isDigit(c))
                                af[0] = (float)(0.5D + (double)af[0]);
                            else
                            if(isExtendedASCII(c))
                            {
                                af[0] = (int)Math.ceil(af[0]);
                                af[0] = 2.0F + af[0];
                            } else
                            {
                                af[0] = (int)Math.ceil(af[0]);
                                af[0] = 1.0F + af[0];
                            }
                            if(isNativeC40(c))
                                af[1] = 0.6666667F + af[1];
                            else
                            if(isExtendedASCII(c))
                                af[1] = 2.666667F + af[1];
                            else
                                af[1] = 1.333333F + af[1];
                            if(isNativeText(c))
                                af[2] = 0.6666667F + af[2];
                            else
                            if(isExtendedASCII(c))
                                af[2] = 2.666667F + af[2];
                            else
                                af[2] = 1.333333F + af[2];
                            if(isNativeX12(c))
                                af[3] = 0.6666667F + af[3];
                            else
                            if(isExtendedASCII(c))
                                af[3] = 4.333333F + af[3];
                            else
                                af[3] = 3.333333F + af[3];
                            if(isNativeEDIFACT(c))
                                af[4] = 0.75F + af[4];
                            else
                            if(isExtendedASCII(c))
                                af[4] = 4.25F + af[4];
                            else
                                af[4] = 3.25F + af[4];
                            if(isSpecialB256(c))
                                af[5] = 4F + af[5];
                            else
                                af[5] = 1.0F + af[5];
                        } while(k < 4);
                        ai = new int[6];
                        abyte0 = new byte[6];
                        findMinimums(af, ai, 0x7fffffff, abyte0);
                        l = getMinimumCount(abyte0);
                        if(ai[0] < ai[5] && ai[0] < ai[1] && ai[0] < ai[2] && ai[0] < ai[3] && ai[0] < ai[4])
                            j = 0;
                        else
                        if(ai[5] < ai[0] || abyte0[1] + abyte0[2] + abyte0[3] + abyte0[4] == 0)
                            j = 5;
                        else
                        if(l == 1 && abyte0[4] > 0)
                            j = 4;
                        else
                        if(l == 1 && abyte0[2] > 0)
                        {
                            j = 2;
                        } else
                        {
                            if(l != 1 || abyte0[3] <= 0)
                                continue;
                            j = 3;
                        }
                        continue; /* Loop/switch isn't completed */
                    } while(1 + ai[1] >= ai[0] || 1 + ai[1] >= ai[5] || 1 + ai[1] >= ai[4] || 1 + ai[1] >= ai[2]);
                    if(ai[1] >= ai[3])
                        continue;
                    j = 1;
                    continue; /* Loop/switch isn't completed */
                } while(ai[1] != ai[3]);
                char c1;
                for(int i1 = 1 + (i + k); i1 >= charsequence.length(); i1++)
                    break label1;

                c1 = charsequence.charAt(i1);
                if(isX12TermSep(c1))
                {
                    j = 3;
                    continue; /* Loop/switch isn't completed */
                }
                if(isNativeX12(c1))
                    break label0;
            }
            j = 1;
        }
        if(true) goto _L1; else goto _L3
_L3:
    }

    private static char randomize253State(char c, int i)
    {
        int j = c + (1 + (i * 149) % 253);
        char c1;
        if(j <= 254)
            c1 = j;
        else
            c1 = j + -254;
        return c1;
    }
}
