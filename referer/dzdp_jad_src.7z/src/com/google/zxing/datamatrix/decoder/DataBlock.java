// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.datamatrix.decoder;


// Referenced classes of package com.google.zxing.datamatrix.decoder:
//            Version

final class DataBlock
{

    private final byte codewords[];
    private final int numDataCodewords;

    private DataBlock(int i, byte abyte0[])
    {
        numDataCodewords = i;
        codewords = abyte0;
    }

    static DataBlock[] getDataBlocks(byte abyte0[], Version version)
    {
        Version.ECBlocks ecblocks = version.getECBlocks();
        int i = 0;
        Version.ECB aecb[] = ecblocks.getECBlocks();
        int j = aecb.length;
        for(int k = 0; k < j; k++)
            i += aecb[k].getCount();

        DataBlock adatablock[] = new DataBlock[i];
        int l = 0;
        int i1 = aecb.length;
        for(int j1 = 0; j1 < i1; j1++)
        {
            Version.ECB ecb = aecb[j1];
            for(int l6 = 0; l6 < ecb.getCount();)
            {
                int i7 = ecb.getDataCodewords();
                int j7 = i7 + ecblocks.getECCodewords();
                int k7 = l + 1;
                DataBlock datablock = new DataBlock(i7, new byte[j7]);
                adatablock[l] = datablock;
                l6++;
                l = k7;
            }

        }

        int k1 = adatablock[0].codewords.length - ecblocks.getECCodewords();
        int l1 = k1 - 1;
        int i2 = 0;
        for(int j2 = 0; j2 < l1;)
        {
            int i6 = 0;
            int j6;
            int k6;
            for(j6 = i2; i6 < l; j6 = k6)
            {
                byte abyte3[] = adatablock[i6].codewords;
                k6 = j6 + 1;
                abyte3[j2] = abyte0[j6];
                i6++;
            }

            j2++;
            i2 = j6;
        }

        boolean flag;
        int k2;
        int l2;
        int i3;
        if(version.getVersionNumber() == 24)
            flag = true;
        else
            flag = false;
        if(flag)
            k2 = 8;
        else
            k2 = l;
        l2 = 0;
        int l5;
        for(i3 = i2; l2 < k2; i3 = l5)
        {
            byte abyte2[] = adatablock[l2].codewords;
            int k5 = k1 - 1;
            l5 = i3 + 1;
            abyte2[k5] = abyte0[i3];
            l2++;
        }

        int j3 = adatablock[0].codewords.length;
        int k3 = k1;
        int l3;
        int k4;
        for(l3 = i3; k3 < j3; l3 = k4)
        {
            int j4 = 0;
            k4 = l3;
            while(j4 < l) 
            {
                int l4;
                int i5;
                byte abyte1[];
                int j5;
                if(flag)
                    l4 = (j4 + 8) % l;
                else
                    l4 = j4;
                if(flag && l4 > 7)
                    i5 = k3 - 1;
                else
                    i5 = k3;
                abyte1 = adatablock[l4].codewords;
                j5 = k4 + 1;
                abyte1[i5] = abyte0[k4];
                j4++;
                k4 = j5;
            }
            k3++;
        }

        int i4 = abyte0.length;
        if(l3 != i4)
            throw new IllegalArgumentException();
        else
            return adatablock;
    }

    byte[] getCodewords()
    {
        return codewords;
    }

    int getNumDataCodewords()
    {
        return numDataCodewords;
    }
}
