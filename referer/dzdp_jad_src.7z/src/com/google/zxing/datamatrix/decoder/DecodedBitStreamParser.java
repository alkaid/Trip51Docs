// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.datamatrix.decoder;

import com.google.zxing.FormatException;
import com.google.zxing.common.BitSource;
import com.google.zxing.common.DecoderResult;
import java.io.UnsupportedEncodingException;
import java.util.*;

final class DecodedBitStreamParser
{
    private static final class Mode extends Enum
    {

        private static final Mode $VALUES[];
        public static final Mode ANSIX12_ENCODE;
        public static final Mode ASCII_ENCODE;
        public static final Mode BASE256_ENCODE;
        public static final Mode C40_ENCODE;
        public static final Mode EDIFACT_ENCODE;
        public static final Mode PAD_ENCODE;
        public static final Mode TEXT_ENCODE;

        public static Mode valueOf(String s)
        {
            return (Mode)Enum.valueOf(com/google/zxing/datamatrix/decoder/DecodedBitStreamParser$Mode, s);
        }

        public static Mode[] values()
        {
            return (Mode[])$VALUES.clone();
        }

        static 
        {
            PAD_ENCODE = new Mode("PAD_ENCODE", 0);
            ASCII_ENCODE = new Mode("ASCII_ENCODE", 1);
            C40_ENCODE = new Mode("C40_ENCODE", 2);
            TEXT_ENCODE = new Mode("TEXT_ENCODE", 3);
            ANSIX12_ENCODE = new Mode("ANSIX12_ENCODE", 4);
            EDIFACT_ENCODE = new Mode("EDIFACT_ENCODE", 5);
            BASE256_ENCODE = new Mode("BASE256_ENCODE", 6);
            Mode amode[] = new Mode[7];
            amode[0] = PAD_ENCODE;
            amode[1] = ASCII_ENCODE;
            amode[2] = C40_ENCODE;
            amode[3] = TEXT_ENCODE;
            amode[4] = ANSIX12_ENCODE;
            amode[5] = EDIFACT_ENCODE;
            amode[6] = BASE256_ENCODE;
            $VALUES = amode;
        }

        private Mode(String s, int i)
        {
            super(s, i);
        }
    }


    private static final char C40_BASIC_SET_CHARS[];
    private static final char C40_SHIFT2_SET_CHARS[];
    private static final char TEXT_BASIC_SET_CHARS[];
    private static final char TEXT_SHIFT2_SET_CHARS[];
    private static final char TEXT_SHIFT3_SET_CHARS[];

    private DecodedBitStreamParser()
    {
    }

    static DecoderResult decode(byte abyte0[])
        throws FormatException
    {
        BitSource bitsource;
        StringBuilder stringbuilder;
        StringBuilder stringbuilder1;
        ArrayList arraylist;
        Mode mode;
        bitsource = new BitSource(abyte0);
        stringbuilder = new StringBuilder(100);
        stringbuilder1 = new StringBuilder(0);
        arraylist = new ArrayList(1);
        mode = Mode.ASCII_ENCODE;
_L2:
        if(mode != Mode.ASCII_ENCODE)
            break; /* Loop/switch isn't completed */
        mode = decodeAsciiSegment(bitsource, stringbuilder, stringbuilder1);
_L9:
        if(mode == Mode.PAD_ENCODE || bitsource.available() <= 0)
        {
            if(stringbuilder1.length() > 0)
                stringbuilder.append(stringbuilder1);
            String s = stringbuilder.toString();
            if(arraylist.isEmpty())
                arraylist = null;
            return new DecoderResult(abyte0, s, arraylist, null);
        }
        if(true) goto _L2; else goto _L1
_L1:
        class _cls1
        {

            static final int $SwitchMap$com$google$zxing$datamatrix$decoder$DecodedBitStreamParser$Mode[];

            static 
            {
                $SwitchMap$com$google$zxing$datamatrix$decoder$DecodedBitStreamParser$Mode = new int[Mode.values().length];
                NoSuchFieldError nosuchfielderror4;
                try
                {
                    $SwitchMap$com$google$zxing$datamatrix$decoder$DecodedBitStreamParser$Mode[Mode.C40_ENCODE.ordinal()] = 1;
                }
                catch(NoSuchFieldError nosuchfielderror) { }
                try
                {
                    $SwitchMap$com$google$zxing$datamatrix$decoder$DecodedBitStreamParser$Mode[Mode.TEXT_ENCODE.ordinal()] = 2;
                }
                catch(NoSuchFieldError nosuchfielderror1) { }
                try
                {
                    $SwitchMap$com$google$zxing$datamatrix$decoder$DecodedBitStreamParser$Mode[Mode.ANSIX12_ENCODE.ordinal()] = 3;
                }
                catch(NoSuchFieldError nosuchfielderror2) { }
                try
                {
                    $SwitchMap$com$google$zxing$datamatrix$decoder$DecodedBitStreamParser$Mode[Mode.EDIFACT_ENCODE.ordinal()] = 4;
                }
                catch(NoSuchFieldError nosuchfielderror3) { }
                $SwitchMap$com$google$zxing$datamatrix$decoder$DecodedBitStreamParser$Mode[Mode.BASE256_ENCODE.ordinal()] = 5;
_L2:
                return;
                nosuchfielderror4;
                if(true) goto _L2; else goto _L1
_L1:
            }
        }

        _cls1..SwitchMap.com.google.zxing.datamatrix.decoder.DecodedBitStreamParser.Mode[mode.ordinal()];
        JVM INSTR tableswitch 1 5: default 164
    //                   1 168
    //                   2 181
    //                   3 189
    //                   4 197
    //                   5 205;
           goto _L3 _L4 _L5 _L6 _L7 _L8
_L8:
        break MISSING_BLOCK_LABEL_205;
_L3:
        throw FormatException.getFormatInstance();
_L4:
        decodeC40Segment(bitsource, stringbuilder);
_L10:
        mode = Mode.ASCII_ENCODE;
          goto _L9
_L5:
        decodeTextSegment(bitsource, stringbuilder);
          goto _L10
_L6:
        decodeAnsiX12Segment(bitsource, stringbuilder);
          goto _L10
_L7:
        decodeEdifactSegment(bitsource, stringbuilder);
          goto _L10
        decodeBase256Segment(bitsource, stringbuilder, arraylist);
          goto _L10
    }

    private static void decodeAnsiX12Segment(BitSource bitsource, StringBuilder stringbuilder)
        throws FormatException
    {
        int ai[] = new int[3];
_L4:
        if(bitsource.available() != 8) goto _L2; else goto _L1
_L1:
        int i;
        return;
_L2:
        if((i = bitsource.readBits(8)) == 254) goto _L1; else goto _L3
_L3:
        parseTwoBytes(i, bitsource.readBits(8), ai);
        int j = 0;
        while(j < 3) 
        {
            int k = ai[j];
            if(k == 0)
                stringbuilder.append('\r');
            else
            if(k == 1)
                stringbuilder.append('*');
            else
            if(k == 2)
                stringbuilder.append('>');
            else
            if(k == 3)
                stringbuilder.append(' ');
            else
            if(k < 14)
                stringbuilder.append((char)(k + 44));
            else
            if(k < 40)
                stringbuilder.append((char)(k + 51));
            else
                throw FormatException.getFormatInstance();
            j++;
        }
        if(bitsource.available() > 0) goto _L4; else goto _L1
    }

    private static Mode decodeAsciiSegment(BitSource bitsource, StringBuilder stringbuilder, StringBuilder stringbuilder1)
        throws FormatException
    {
        boolean flag = false;
_L4:
        int i;
        Mode mode;
        i = bitsource.readBits(8);
        if(i == 0)
            throw FormatException.getFormatInstance();
        if(i <= 128)
        {
            if(flag)
                i += 128;
            stringbuilder.append((char)(i - 1));
            mode = Mode.ASCII_ENCODE;
        } else
        {
label0:
            {
                if(i != 129)
                    break label0;
                mode = Mode.PAD_ENCODE;
            }
        }
_L5:
        return mode;
        if(i > 229) goto _L2; else goto _L1
_L1:
        int j = i - 130;
        if(j < 10)
            stringbuilder.append('0');
        stringbuilder.append(j);
_L6:
        if(bitsource.available() > 0) goto _L4; else goto _L3
_L3:
        mode = Mode.ASCII_ENCODE;
          goto _L5
_L2:
        if(i == 230)
        {
            mode = Mode.C40_ENCODE;
        } else
        {
label1:
            {
                if(i != 231)
                    break label1;
                mode = Mode.BASE256_ENCODE;
            }
        }
          goto _L5
        if(i == 232)
            stringbuilder.append('\035');
        else
        if(i != 233 && i != 234)
            if(i == 235)
                flag = true;
            else
            if(i == 236)
            {
                stringbuilder.append("[)>\03605\035");
                stringbuilder1.insert(0, "\036\004");
            } else
            {
label2:
                {
                    if(i != 237)
                        break label2;
                    stringbuilder.append("[)>\03606\035");
                    stringbuilder1.insert(0, "\036\004");
                }
            }
          goto _L6
        if(i == 238)
            mode = Mode.ANSIX12_ENCODE;
        else
        if(i == 239)
        {
            mode = Mode.TEXT_ENCODE;
        } else
        {
            if(i != 240)
                continue; /* Loop/switch isn't completed */
            mode = Mode.EDIFACT_ENCODE;
        }
          goto _L5
        if(i == 241 || i < 242 || i == 254 && bitsource.available() == 0) goto _L6; else goto _L7
_L7:
        throw FormatException.getFormatInstance();
          goto _L5
    }

    private static void decodeBase256Segment(BitSource bitsource, StringBuilder stringbuilder, Collection collection)
        throws FormatException
    {
        int i = 1 + bitsource.getByteOffset();
        int j = bitsource.readBits(8);
        int k = i + 1;
        int l = unrandomize255State(j, i);
        int k1;
        int l1;
        if(l == 0)
        {
            l1 = bitsource.available() / 8;
            k1 = k;
        } else
        if(l < 250)
        {
            l1 = l;
            k1 = k;
        } else
        {
            int i1 = 250 * (l - 249);
            int j1 = bitsource.readBits(8);
            k1 = k + 1;
            l1 = i1 + unrandomize255State(j1, k);
        }
        if(l1 < 0)
            throw FormatException.getFormatInstance();
        byte abyte0[] = new byte[l1];
        int i2 = 0;
        int l2;
        for(int j2 = k1; i2 < l1; j2 = l2)
        {
            if(bitsource.available() < 8)
                throw FormatException.getFormatInstance();
            int k2 = bitsource.readBits(8);
            l2 = j2 + 1;
            abyte0[i2] = (byte)unrandomize255State(k2, j2);
            i2++;
        }

        collection.add(abyte0);
        try
        {
            stringbuilder.append(new String(abyte0, "ISO8859_1"));
            return;
        }
        catch(UnsupportedEncodingException unsupportedencodingexception)
        {
            throw new IllegalStateException((new StringBuilder()).append("Platform does not support required encoding: ").append(unsupportedencodingexception).toString());
        }
    }

    private static void decodeC40Segment(BitSource bitsource, StringBuilder stringbuilder)
        throws FormatException
    {
        boolean flag;
        int ai[];
        int i;
        flag = false;
        ai = new int[3];
        i = 0;
_L12:
        if(bitsource.available() != 8) goto _L2; else goto _L1
_L1:
        int j;
        return;
_L2:
        if((j = bitsource.readBits(8)) == 254) goto _L1; else goto _L3
_L3:
        int k;
        parseTwoBytes(j, bitsource.readBits(8), ai);
        k = 0;
_L10:
        int l;
        if(k >= 3)
            continue; /* Loop/switch isn't completed */
        l = ai[k];
        i;
        JVM INSTR tableswitch 0 3: default 96
    //                   0 100
    //                   1 170
    //                   2 205
    //                   3 289;
           goto _L4 _L5 _L6 _L7 _L8
_L8:
        break MISSING_BLOCK_LABEL_289;
_L6:
        break; /* Loop/switch isn't completed */
_L4:
        throw FormatException.getFormatInstance();
_L5:
        if(l < 3)
            i = l + 1;
        else
        if(l < C40_BASIC_SET_CHARS.length)
        {
            char c1 = C40_BASIC_SET_CHARS[l];
            if(flag)
            {
                stringbuilder.append((char)(c1 + 128));
                flag = false;
            } else
            {
                stringbuilder.append(c1);
            }
        } else
        {
            throw FormatException.getFormatInstance();
        }
_L11:
        k++;
        if(true) goto _L10; else goto _L9
_L9:
        if(flag)
        {
            stringbuilder.append((char)(l + 128));
            flag = false;
        } else
        {
            stringbuilder.append((char)l);
        }
        i = 0;
          goto _L11
_L7:
        if(l < C40_SHIFT2_SET_CHARS.length)
        {
            char c = C40_SHIFT2_SET_CHARS[l];
            if(flag)
            {
                stringbuilder.append((char)(c + 128));
                flag = false;
            } else
            {
                stringbuilder.append(c);
            }
        } else
        if(l == 27)
            stringbuilder.append('\035');
        else
        if(l == 30)
            flag = true;
        else
            throw FormatException.getFormatInstance();
        i = 0;
          goto _L11
        if(flag)
        {
            stringbuilder.append((char)(l + 224));
            flag = false;
        } else
        {
            stringbuilder.append((char)(l + 96));
        }
        i = 0;
          goto _L11
        if(bitsource.available() > 0) goto _L12; else goto _L1
    }

    private static void decodeEdifactSegment(BitSource bitsource, StringBuilder stringbuilder)
    {
_L6:
        if(bitsource.available() > 16) goto _L2; else goto _L1
_L1:
        return;
_L2:
        int i = 0;
_L5:
        if(i >= 4) goto _L4; else goto _L3
_L3:
        int j;
label0:
        {
            j = bitsource.readBits(6);
            if(j != 31)
                break label0;
            int k = 8 - bitsource.getBitOffset();
            if(k != 8)
                bitsource.readBits(k);
        }
          goto _L1
        if((j & 0x20) == 0)
            j |= 0x40;
        stringbuilder.append((char)j);
        i++;
          goto _L5
_L4:
        if(bitsource.available() > 0) goto _L6; else goto _L1
    }

    private static void decodeTextSegment(BitSource bitsource, StringBuilder stringbuilder)
        throws FormatException
    {
        boolean flag;
        int ai[];
        int i;
        flag = false;
        ai = new int[3];
        i = 0;
_L12:
        if(bitsource.available() != 8) goto _L2; else goto _L1
_L1:
        int j;
        return;
_L2:
        if((j = bitsource.readBits(8)) == 254) goto _L1; else goto _L3
_L3:
        int k;
        parseTwoBytes(j, bitsource.readBits(8), ai);
        k = 0;
_L10:
        int l;
        if(k >= 3)
            continue; /* Loop/switch isn't completed */
        l = ai[k];
        i;
        JVM INSTR tableswitch 0 3: default 96
    //                   0 100
    //                   1 170
    //                   2 205
    //                   3 289;
           goto _L4 _L5 _L6 _L7 _L8
_L8:
        break MISSING_BLOCK_LABEL_289;
_L6:
        break; /* Loop/switch isn't completed */
_L4:
        throw FormatException.getFormatInstance();
_L5:
        if(l < 3)
            i = l + 1;
        else
        if(l < TEXT_BASIC_SET_CHARS.length)
        {
            char c2 = TEXT_BASIC_SET_CHARS[l];
            if(flag)
            {
                stringbuilder.append((char)(c2 + 128));
                flag = false;
            } else
            {
                stringbuilder.append(c2);
            }
        } else
        {
            throw FormatException.getFormatInstance();
        }
_L11:
        k++;
        if(true) goto _L10; else goto _L9
_L9:
        if(flag)
        {
            stringbuilder.append((char)(l + 128));
            flag = false;
        } else
        {
            stringbuilder.append((char)l);
        }
        i = 0;
          goto _L11
_L7:
        if(l < TEXT_SHIFT2_SET_CHARS.length)
        {
            char c1 = TEXT_SHIFT2_SET_CHARS[l];
            if(flag)
            {
                stringbuilder.append((char)(c1 + 128));
                flag = false;
            } else
            {
                stringbuilder.append(c1);
            }
        } else
        if(l == 27)
            stringbuilder.append('\035');
        else
        if(l == 30)
            flag = true;
        else
            throw FormatException.getFormatInstance();
        i = 0;
          goto _L11
        if(l < TEXT_SHIFT3_SET_CHARS.length)
        {
            char c = TEXT_SHIFT3_SET_CHARS[l];
            if(flag)
            {
                stringbuilder.append((char)(c + 128));
                flag = false;
            } else
            {
                stringbuilder.append(c);
            }
            i = 0;
        } else
        {
            throw FormatException.getFormatInstance();
        }
          goto _L11
        if(bitsource.available() > 0) goto _L12; else goto _L1
    }

    private static void parseTwoBytes(int i, int j, int ai[])
    {
        int k = -1 + (j + (i << 8));
        int l = k / 1600;
        ai[0] = l;
        int i1 = k - l * 1600;
        int j1 = i1 / 40;
        ai[1] = j1;
        ai[2] = i1 - j1 * 40;
    }

    private static int unrandomize255State(int i, int j)
    {
        int k = i - (1 + (j * 149) % 255);
        if(k < 0)
            k += 256;
        return k;
    }

    static 
    {
        char ac[] = new char[40];
        ac[0] = '*';
        ac[1] = '*';
        ac[2] = '*';
        ac[3] = ' ';
        ac[4] = '0';
        ac[5] = '1';
        ac[6] = '2';
        ac[7] = '3';
        ac[8] = '4';
        ac[9] = '5';
        ac[10] = '6';
        ac[11] = '7';
        ac[12] = '8';
        ac[13] = '9';
        ac[14] = 'A';
        ac[15] = 'B';
        ac[16] = 'C';
        ac[17] = 'D';
        ac[18] = 'E';
        ac[19] = 'F';
        ac[20] = 'G';
        ac[21] = 'H';
        ac[22] = 'I';
        ac[23] = 'J';
        ac[24] = 'K';
        ac[25] = 'L';
        ac[26] = 'M';
        ac[27] = 'N';
        ac[28] = 'O';
        ac[29] = 'P';
        ac[30] = 'Q';
        ac[31] = 'R';
        ac[32] = 'S';
        ac[33] = 'T';
        ac[34] = 'U';
        ac[35] = 'V';
        ac[36] = 'W';
        ac[37] = 'X';
        ac[38] = 'Y';
        ac[39] = 'Z';
        C40_BASIC_SET_CHARS = ac;
        char ac1[] = new char[27];
        ac1[0] = '!';
        ac1[1] = '"';
        ac1[2] = '#';
        ac1[3] = '$';
        ac1[4] = '%';
        ac1[5] = '&';
        ac1[6] = '\'';
        ac1[7] = '(';
        ac1[8] = ')';
        ac1[9] = '*';
        ac1[10] = '+';
        ac1[11] = ',';
        ac1[12] = '-';
        ac1[13] = '.';
        ac1[14] = '/';
        ac1[15] = ':';
        ac1[16] = ';';
        ac1[17] = '<';
        ac1[18] = '=';
        ac1[19] = '>';
        ac1[20] = '?';
        ac1[21] = '@';
        ac1[22] = '[';
        ac1[23] = '\\';
        ac1[24] = ']';
        ac1[25] = '^';
        ac1[26] = '_';
        C40_SHIFT2_SET_CHARS = ac1;
        char ac2[] = new char[40];
        ac2[0] = '*';
        ac2[1] = '*';
        ac2[2] = '*';
        ac2[3] = ' ';
        ac2[4] = '0';
        ac2[5] = '1';
        ac2[6] = '2';
        ac2[7] = '3';
        ac2[8] = '4';
        ac2[9] = '5';
        ac2[10] = '6';
        ac2[11] = '7';
        ac2[12] = '8';
        ac2[13] = '9';
        ac2[14] = 'a';
        ac2[15] = 'b';
        ac2[16] = 'c';
        ac2[17] = 'd';
        ac2[18] = 'e';
        ac2[19] = 'f';
        ac2[20] = 'g';
        ac2[21] = 'h';
        ac2[22] = 'i';
        ac2[23] = 'j';
        ac2[24] = 'k';
        ac2[25] = 'l';
        ac2[26] = 'm';
        ac2[27] = 'n';
        ac2[28] = 'o';
        ac2[29] = 'p';
        ac2[30] = 'q';
        ac2[31] = 'r';
        ac2[32] = 's';
        ac2[33] = 't';
        ac2[34] = 'u';
        ac2[35] = 'v';
        ac2[36] = 'w';
        ac2[37] = 'x';
        ac2[38] = 'y';
        ac2[39] = 'z';
        TEXT_BASIC_SET_CHARS = ac2;
        TEXT_SHIFT2_SET_CHARS = C40_SHIFT2_SET_CHARS;
        char ac3[] = new char[32];
        ac3[0] = '`';
        ac3[1] = 'A';
        ac3[2] = 'B';
        ac3[3] = 'C';
        ac3[4] = 'D';
        ac3[5] = 'E';
        ac3[6] = 'F';
        ac3[7] = 'G';
        ac3[8] = 'H';
        ac3[9] = 'I';
        ac3[10] = 'J';
        ac3[11] = 'K';
        ac3[12] = 'L';
        ac3[13] = 'M';
        ac3[14] = 'N';
        ac3[15] = 'O';
        ac3[16] = 'P';
        ac3[17] = 'Q';
        ac3[18] = 'R';
        ac3[19] = 'S';
        ac3[20] = 'T';
        ac3[21] = 'U';
        ac3[22] = 'V';
        ac3[23] = 'W';
        ac3[24] = 'X';
        ac3[25] = 'Y';
        ac3[26] = 'Z';
        ac3[27] = '{';
        ac3[28] = '|';
        ac3[29] = '}';
        ac3[30] = '~';
        ac3[31] = '\177';
        TEXT_SHIFT3_SET_CHARS = ac3;
    }
}
