// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.datamatrix;

import com.google.zxing.*;
import com.google.zxing.common.*;
import com.google.zxing.datamatrix.decoder.Decoder;
import com.google.zxing.datamatrix.detector.Detector;
import java.util.Map;

public final class DataMatrixReader
    implements Reader
{

    private static final ResultPoint NO_POINTS[] = new ResultPoint[0];
    private final Decoder decoder = new Decoder();

    public DataMatrixReader()
    {
    }

    private static BitMatrix extractPureBits(BitMatrix bitmatrix)
        throws NotFoundException
    {
        int ai[] = bitmatrix.getTopLeftOnBit();
        int ai1[] = bitmatrix.getBottomRightOnBit();
        if(ai == null || ai1 == null)
            throw NotFoundException.getNotFoundInstance();
        int i = moduleSize(ai, bitmatrix);
        int j = ai[1];
        int k = ai1[1];
        int l = ai[0];
        int i1 = (1 + (ai1[0] - l)) / i;
        int j1 = (1 + (k - j)) / i;
        if(i1 <= 0 || j1 <= 0)
            throw NotFoundException.getNotFoundInstance();
        int k1 = i / 2;
        int l1 = j + k1;
        int i2 = l + k1;
        BitMatrix bitmatrix1 = new BitMatrix(i1, j1);
        for(int j2 = 0; j2 < j1; j2++)
        {
            int k2 = l1 + j2 * i;
            for(int l2 = 0; l2 < i1; l2++)
                if(bitmatrix.get(i2 + l2 * i, k2))
                    bitmatrix1.set(l2, j2);

        }

        return bitmatrix1;
    }

    private static int moduleSize(int ai[], BitMatrix bitmatrix)
        throws NotFoundException
    {
        int i = bitmatrix.getWidth();
        int j = ai[0];
        for(int k = ai[1]; j < i && bitmatrix.get(j, k); j++);
        if(j == i)
            throw NotFoundException.getNotFoundInstance();
        int l = j - ai[0];
        if(l == 0)
            throw NotFoundException.getNotFoundInstance();
        else
            return l;
    }

    public Result decode(BinaryBitmap binarybitmap)
        throws NotFoundException, ChecksumException, FormatException
    {
        return decode(binarybitmap, null);
    }

    public Result decode(BinaryBitmap binarybitmap, Map map)
        throws NotFoundException, ChecksumException, FormatException
    {
        DecoderResult decoderresult;
        ResultPoint aresultpoint[];
        Result result;
        java.util.List list;
        String s;
        if(map != null && map.containsKey(DecodeHintType.PURE_BARCODE))
        {
            BitMatrix bitmatrix = extractPureBits(binarybitmap.getBlackMatrix());
            decoderresult = decoder.decode(bitmatrix);
            aresultpoint = NO_POINTS;
        } else
        {
            DetectorResult detectorresult = (new Detector(binarybitmap.getBlackMatrix())).detect();
            decoderresult = decoder.decode(detectorresult.getBits());
            aresultpoint = detectorresult.getPoints();
        }
        result = new Result(decoderresult.getText(), decoderresult.getRawBytes(), aresultpoint, BarcodeFormat.DATA_MATRIX);
        list = decoderresult.getByteSegments();
        if(list != null)
            result.putMetadata(ResultMetadataType.BYTE_SEGMENTS, list);
        s = decoderresult.getECLevel();
        if(s != null)
            result.putMetadata(ResultMetadataType.ERROR_CORRECTION_LEVEL, s);
        return result;
    }

    public void reset()
    {
    }

}
