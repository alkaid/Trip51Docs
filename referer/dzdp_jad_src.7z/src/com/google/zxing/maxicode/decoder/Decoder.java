// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.maxicode.decoder;

import com.google.zxing.ChecksumException;
import com.google.zxing.FormatException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.common.DecoderResult;
import com.google.zxing.common.reedsolomon.*;
import java.util.Map;

// Referenced classes of package com.google.zxing.maxicode.decoder:
//            BitMatrixParser, DecodedBitStreamParser

public final class Decoder
{

    private static final int ALL = 0;
    private static final int EVEN = 1;
    private static final int ODD = 2;
    private final ReedSolomonDecoder rsDecoder;

    public Decoder()
    {
        rsDecoder = new ReedSolomonDecoder(GenericGF.MAXICODE_FIELD_64);
    }

    private void correctErrors(byte abyte0[], int i, int j, int k, int l)
        throws ChecksumException
    {
        int i1 = j + k;
        int j1;
        int ai[];
        if(l == 0)
            j1 = 1;
        else
            j1 = 2;
        ai = new int[i1 / j1];
        for(int k1 = 0; k1 < i1; k1++)
            if(l == 0 || k1 % 2 == l - 1)
                ai[k1 / j1] = 0xff & abyte0[k1 + i];

        int l1;
        try
        {
            rsDecoder.decode(ai, k / j1);
        }
        catch(ReedSolomonException reedsolomonexception)
        {
            throw ChecksumException.getChecksumInstance();
        }
        for(l1 = 0; l1 < j; l1++)
            if(l == 0 || l1 % 2 == l - 1)
                abyte0[l1 + i] = (byte)ai[l1 / j1];

    }

    public DecoderResult decode(BitMatrix bitmatrix)
        throws ChecksumException, FormatException
    {
        return decode(bitmatrix, null);
    }

    public DecoderResult decode(BitMatrix bitmatrix, Map map)
        throws FormatException, ChecksumException
    {
        byte abyte0[];
        int i;
        abyte0 = (new BitMatrixParser(bitmatrix)).readCodewords();
        correctErrors(abyte0, 0, 10, 10, 0);
        i = 0xf & abyte0[0];
        i;
        JVM INSTR tableswitch 2 5: default 64
    //                   2 68
    //                   3 68
    //                   4 68
    //                   5 132;
           goto _L1 _L2 _L2 _L2 _L3
_L1:
        throw FormatException.getFormatInstance();
_L2:
        byte abyte1[];
        correctErrors(abyte0, 20, 84, 40, 1);
        correctErrors(abyte0, 20, 84, 40, 2);
        abyte1 = new byte[94];
_L5:
        System.arraycopy(abyte0, 0, abyte1, 0, 10);
        System.arraycopy(abyte0, 20, abyte1, 10, -10 + abyte1.length);
        return DecodedBitStreamParser.decode(abyte1, i);
_L3:
        correctErrors(abyte0, 20, 68, 56, 1);
        correctErrors(abyte0, 20, 68, 56, 2);
        abyte1 = new byte[78];
        if(true) goto _L5; else goto _L4
_L4:
    }
}
