// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.maxicode.decoder;

import com.google.zxing.common.DecoderResult;
import java.text.DecimalFormat;
import java.text.NumberFormat;

final class DecodedBitStreamParser
{

    private static final char ECI = 65530;
    private static final char FS = 28;
    private static final char GS = 29;
    private static final char LATCHA = 65527;
    private static final char LATCHB = 65528;
    private static final char LOCK = 65529;
    private static final NumberFormat NINE_DIGITS = new DecimalFormat("000000000");
    private static final char NS = 65531;
    private static final char PAD = 65532;
    private static final char RS = 30;
    private static final String SETS[];
    private static final char SHIFTA = 65520;
    private static final char SHIFTB = 65521;
    private static final char SHIFTC = 65522;
    private static final char SHIFTD = 65523;
    private static final char SHIFTE = 65524;
    private static final char THREESHIFTA = 65526;
    private static final NumberFormat THREE_DIGITS = new DecimalFormat("000");
    private static final char TWOSHIFTA = 65525;

    private DecodedBitStreamParser()
    {
    }

    static DecoderResult decode(byte abyte0[], int i)
    {
        StringBuilder stringbuilder = new StringBuilder(144);
        i;
        JVM INSTR tableswitch 2 5: default 44
    //                   2 62
    //                   3 62
    //                   4 257
    //                   5 272;
           goto _L1 _L2 _L2 _L3 _L4
_L1:
        return new DecoderResult(abyte0, stringbuilder.toString(), null, String.valueOf(i));
_L2:
        String s;
        String s1;
        String s2;
        if(i == 2)
        {
            int j = getPostCode2(abyte0);
            s = (new DecimalFormat("0000000000".substring(0, getPostCode2Length(abyte0)))).format(j);
        } else
        {
            s = getPostCode3(abyte0);
        }
        s1 = THREE_DIGITS.format(getCountry(abyte0));
        s2 = THREE_DIGITS.format(getServiceClass(abyte0));
        stringbuilder.append(getMessage(abyte0, 10, 84));
        if(stringbuilder.toString().startsWith("[)>\03601\035"))
            stringbuilder.insert(9, (new StringBuilder()).append(s).append('\035').append(s1).append('\035').append(s2).append('\035').toString());
        else
            stringbuilder.insert(0, (new StringBuilder()).append(s).append('\035').append(s1).append('\035').append(s2).append('\035').toString());
        continue; /* Loop/switch isn't completed */
_L3:
        stringbuilder.append(getMessage(abyte0, 1, 93));
        continue; /* Loop/switch isn't completed */
_L4:
        stringbuilder.append(getMessage(abyte0, 1, 77));
        if(true) goto _L1; else goto _L5
_L5:
    }

    private static int getBit(int i, byte abyte0[])
    {
        int j = 1;
        int k = i - 1;
        if((abyte0[k / 6] & j << 5 - k % 6) == 0)
            j = 0;
        return j;
    }

    private static int getCountry(byte abyte0[])
    {
        byte abyte1[] = new byte[10];
        abyte1[0] = 53;
        abyte1[1] = 54;
        abyte1[2] = 43;
        abyte1[3] = 44;
        abyte1[4] = 45;
        abyte1[5] = 46;
        abyte1[6] = 47;
        abyte1[7] = 48;
        abyte1[8] = 37;
        abyte1[9] = 38;
        return getInt(abyte0, abyte1);
    }

    private static int getInt(byte abyte0[], byte abyte1[])
    {
        if(abyte1.length == 0)
            throw new IllegalArgumentException();
        int i = 0;
        for(int j = 0; j < abyte1.length; j++)
            i += getBit(abyte1[j], abyte0) << -1 + (abyte1.length - j);

        return i;
    }

    private static String getMessage(byte abyte0[], int i, int j)
    {
        StringBuilder stringbuilder;
        int k;
        int l;
        int i1;
        int j1;
        stringbuilder = new StringBuilder();
        k = -1;
        l = 0;
        i1 = 0;
        j1 = i;
_L10:
        char c;
        if(j1 >= i + j)
            break MISSING_BLOCK_LABEL_315;
        c = SETS[l].charAt(abyte0[j1]);
        c;
        JVM INSTR tableswitch 65520 65531: default 108
    //                   65520 160
    //                   65521 160
    //                   65522 160
    //                   65523 160
    //                   65524 160
    //                   65525 177
    //                   65526 190
    //                   65527 140
    //                   65528 150
    //                   65529 308
    //                   65530 108
    //                   65531 203;
           goto _L1 _L2 _L2 _L2 _L2 _L2 _L3 _L4 _L5 _L6 _L7 _L1 _L8
_L7:
        break MISSING_BLOCK_LABEL_308;
_L5:
        break; /* Loop/switch isn't completed */
_L1:
        int k1;
        stringbuilder.append(c);
        k1 = k;
_L11:
        k = k1 - 1;
        if(k1 == 0)
            l = i1;
        j1++;
        if(true) goto _L10; else goto _L9
_L9:
        l = 0;
        k1 = -1;
          goto _L11
_L6:
        l = 1;
        k1 = -1;
          goto _L11
_L2:
        i1 = l;
        l = c - 65520;
        k1 = 1;
          goto _L11
_L3:
        i1 = l;
        l = 0;
        k1 = 2;
          goto _L11
_L4:
        i1 = l;
        l = 0;
        k1 = 3;
          goto _L11
_L8:
        int l1 = j1 + 1;
        int i2 = abyte0[l1] << 24;
        int j2 = l1 + 1;
        int k2 = i2 + (abyte0[j2] << 18);
        int l2 = j2 + 1;
        int i3 = k2 + (abyte0[l2] << 12);
        int j3 = l2 + 1;
        int k3 = i3 + (abyte0[j3] << 6);
        j1 = j3 + 1;
        int l3 = k3 + abyte0[j1];
        stringbuilder.append(NINE_DIGITS.format(l3));
        k1 = k;
          goto _L11
        k1 = -1;
          goto _L11
        for(; stringbuilder.length() > 0 && stringbuilder.charAt(-1 + stringbuilder.length()) == '\uFFFC'; stringbuilder.setLength(-1 + stringbuilder.length()));
        return stringbuilder.toString();
    }

    private static int getPostCode2(byte abyte0[])
    {
        byte abyte1[] = new byte[30];
        abyte1[0] = 33;
        abyte1[1] = 34;
        abyte1[2] = 35;
        abyte1[3] = 36;
        abyte1[4] = 25;
        abyte1[5] = 26;
        abyte1[6] = 27;
        abyte1[7] = 28;
        abyte1[8] = 29;
        abyte1[9] = 30;
        abyte1[10] = 19;
        abyte1[11] = 20;
        abyte1[12] = 21;
        abyte1[13] = 22;
        abyte1[14] = 23;
        abyte1[15] = 24;
        abyte1[16] = 13;
        abyte1[17] = 14;
        abyte1[18] = 15;
        abyte1[19] = 16;
        abyte1[20] = 17;
        abyte1[21] = 18;
        abyte1[22] = 7;
        abyte1[23] = 8;
        abyte1[24] = 9;
        abyte1[25] = 10;
        abyte1[26] = 11;
        abyte1[27] = 12;
        abyte1[28] = 1;
        abyte1[29] = 2;
        return getInt(abyte0, abyte1);
    }

    private static int getPostCode2Length(byte abyte0[])
    {
        byte abyte1[] = new byte[6];
        abyte1[0] = 39;
        abyte1[1] = 40;
        abyte1[2] = 41;
        abyte1[3] = 42;
        abyte1[4] = 31;
        abyte1[5] = 32;
        return getInt(abyte0, abyte1);
    }

    private static String getPostCode3(byte abyte0[])
    {
        char ac[] = new char[6];
        String s = SETS[0];
        byte abyte1[] = new byte[6];
        abyte1[0] = 39;
        abyte1[1] = 40;
        abyte1[2] = 41;
        abyte1[3] = 42;
        abyte1[4] = 31;
        abyte1[5] = 32;
        ac[0] = s.charAt(getInt(abyte0, abyte1));
        String s1 = SETS[0];
        byte abyte2[] = new byte[6];
        abyte2[0] = 33;
        abyte2[1] = 34;
        abyte2[2] = 35;
        abyte2[3] = 36;
        abyte2[4] = 25;
        abyte2[5] = 26;
        ac[1] = s1.charAt(getInt(abyte0, abyte2));
        String s2 = SETS[0];
        byte abyte3[] = new byte[6];
        abyte3[0] = 27;
        abyte3[1] = 28;
        abyte3[2] = 29;
        abyte3[3] = 30;
        abyte3[4] = 19;
        abyte3[5] = 20;
        ac[2] = s2.charAt(getInt(abyte0, abyte3));
        String s3 = SETS[0];
        byte abyte4[] = new byte[6];
        abyte4[0] = 21;
        abyte4[1] = 22;
        abyte4[2] = 23;
        abyte4[3] = 24;
        abyte4[4] = 13;
        abyte4[5] = 14;
        ac[3] = s3.charAt(getInt(abyte0, abyte4));
        String s4 = SETS[0];
        byte abyte5[] = new byte[6];
        abyte5[0] = 15;
        abyte5[1] = 16;
        abyte5[2] = 17;
        abyte5[3] = 18;
        abyte5[4] = 7;
        abyte5[5] = 8;
        ac[4] = s4.charAt(getInt(abyte0, abyte5));
        String s5 = SETS[0];
        byte abyte6[] = new byte[6];
        abyte6[0] = 9;
        abyte6[1] = 10;
        abyte6[2] = 11;
        abyte6[3] = 12;
        abyte6[4] = 1;
        abyte6[5] = 2;
        ac[5] = s5.charAt(getInt(abyte0, abyte6));
        return String.valueOf(ac);
    }

    private static int getServiceClass(byte abyte0[])
    {
        byte abyte1[] = new byte[10];
        abyte1[0] = 55;
        abyte1[1] = 56;
        abyte1[2] = 57;
        abyte1[3] = 58;
        abyte1[4] = 59;
        abyte1[5] = 60;
        abyte1[6] = 49;
        abyte1[7] = 50;
        abyte1[8] = 51;
        abyte1[9] = 52;
        return getInt(abyte0, abyte1);
    }

    static 
    {
        String as[] = new String[6];
        as[0] = "\nABCDEFGHIJKLMNOPQRSTUVWXYZ\uFFFA\034\035\036\uFFFB \uFFFC\"#$%&'()*+,-./0123456789:\uFFF1\uFFF2\uFFF3\uFFF4\uFFF8";
        as[1] = "`abcdefghijklmnopqrstuvwxyz\uFFFA\034\035\036\uFFFB{\uFFFC}~\177;<=>?[\\]^_ ,./:@!|\uFFFC\uFFF5\uFFF6\uFFFC\uFFF0\uFFF2\uFFF3\uFFF4\uFFF7";
        as[2] = "\300\301\302\303\304\305\306\307\310\311\312\313\314\315\316\317\320\321\322\323\324\325\326\327\330\331\332\uFFFA\034\035\036\333\334\335\336\337\252\254\261\262\263\265\271\272\274\275\276\200\201\202\203\204\205\206\207\210\211\uFFF7 \uFFF9\uFFF3\uFFF4\uFFF8";
        as[3] = "\340\341\342\343\344\345\346\347\350\351\352\353\354\355\356\357\360\361\362\363\364\365\366\367\370\371\372\uFFFA\034\035\036\uFFFB\373\374\375\376\377\241\250\253\257\260\264\267\270\273\277\212\213\214\215\216\217\220\221\222\223\224\uFFF7 \uFFF2\uFFF9\uFFF4\uFFF8";
        as[4] = "\uFFFD\uFFFD\001\002\003\004\005\006\007\b\t\n\013\f\r\016\017\020\021\022\023\024\025\026\027\030\031\032\uFFFA\uFFFC\uFFFC\033\uFFFB\034\035\036\037\237\240\242\243\244\245\246\247\251\255\256\266\225\226\227\230\231\232\233\234\235\236\uFFF7 \uFFF2\uFFF3\uFFF9\uFFF8";
        as[5] = "\uFFFD\uFFFD\001\002\003\004\005\006\007\b\t\n\013\f\r\016\017\020\021\022\023\024\025\026\027\030\031\032\033\034\035\036\037 !\"#$%&'()*+,-./0123456789:;<=>?";
        SETS = as;
    }
}
