// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.maxicode;

import com.google.zxing.*;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.common.DecoderResult;
import com.google.zxing.maxicode.decoder.Decoder;
import java.util.Map;

public final class MaxiCodeReader
    implements Reader
{

    private static final int MATRIX_HEIGHT = 33;
    private static final int MATRIX_WIDTH = 30;
    private static final ResultPoint NO_POINTS[] = new ResultPoint[0];
    private final Decoder decoder = new Decoder();

    public MaxiCodeReader()
    {
    }

    private static BitMatrix extractPureBits(BitMatrix bitmatrix)
        throws NotFoundException
    {
        int ai[] = bitmatrix.getEnclosingRectangle();
        if(ai == null)
            throw NotFoundException.getNotFoundInstance();
        int i = ai[0];
        int j = ai[1];
        int k = ai[2];
        int l = ai[3];
        BitMatrix bitmatrix1 = new BitMatrix(30, 33);
        for(int i1 = 0; i1 < 33; i1++)
        {
            int j1 = j + (i1 * l + l / 2) / 33;
            for(int k1 = 0; k1 < 30; k1++)
                if(bitmatrix.get(i + (k1 * k + k / 2 + (k * (i1 & 1)) / 2) / 30, j1))
                    bitmatrix1.set(k1, i1);

        }

        return bitmatrix1;
    }

    public Result decode(BinaryBitmap binarybitmap)
        throws NotFoundException, ChecksumException, FormatException
    {
        return decode(binarybitmap, null);
    }

    public Result decode(BinaryBitmap binarybitmap, Map map)
        throws NotFoundException, ChecksumException, FormatException
    {
        if(map != null && map.containsKey(DecodeHintType.PURE_BARCODE))
        {
            BitMatrix bitmatrix = extractPureBits(binarybitmap.getBlackMatrix());
            DecoderResult decoderresult = decoder.decode(bitmatrix, map);
            ResultPoint aresultpoint[] = NO_POINTS;
            Result result = new Result(decoderresult.getText(), decoderresult.getRawBytes(), aresultpoint, BarcodeFormat.MAXICODE);
            String s = decoderresult.getECLevel();
            if(s != null)
                result.putMetadata(ResultMetadataType.ERROR_CORRECTION_LEVEL, s);
            return result;
        } else
        {
            throw NotFoundException.getNotFoundInstance();
        }
    }

    public void reset()
    {
    }

}
