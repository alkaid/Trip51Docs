// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing;


// Referenced classes of package com.google.zxing:
//            LuminanceSource

public final class RGBLuminanceSource extends LuminanceSource
{

    private final int dataHeight;
    private final int dataWidth;
    private final int left;
    private final byte luminances[];
    private final int top;

    public RGBLuminanceSource(int i, int j, int ai[])
    {
        super(i, j);
        dataWidth = i;
        dataHeight = j;
        left = 0;
        top = 0;
        luminances = new byte[i * j];
        for(int k = 0; k < j; k++)
        {
            int l = k * i;
            int i1 = 0;
            while(i1 < i) 
            {
                int j1 = ai[l + i1];
                int k1 = 0xff & j1 >> 16;
                int l1 = 0xff & j1 >> 8;
                int i2 = j1 & 0xff;
                if(k1 == l1 && l1 == i2)
                    luminances[l + i1] = (byte)k1;
                else
                    luminances[l + i1] = (byte)((i2 + (k1 + l1 * 2)) / 4);
                i1++;
            }
        }

    }

    private RGBLuminanceSource(byte abyte0[], int i, int j, int k, int l, int i1, int j1)
    {
        super(i1, j1);
        if(k + i1 > i || l + j1 > j)
        {
            throw new IllegalArgumentException("Crop rectangle does not fit within image data.");
        } else
        {
            luminances = abyte0;
            dataWidth = i;
            dataHeight = j;
            left = k;
            top = l;
            return;
        }
    }

    public LuminanceSource crop(int i, int j, int k, int l)
    {
        return new RGBLuminanceSource(luminances, dataWidth, dataHeight, i + left, j + top, k, l);
    }

    public byte[] getMatrix()
    {
        int i;
        int j;
        i = getWidth();
        j = getHeight();
        if(i != dataWidth || j != dataHeight) goto _L2; else goto _L1
_L1:
        byte abyte0[] = luminances;
_L4:
        return abyte0;
_L2:
        int l;
        int k = i * j;
        abyte0 = new byte[k];
        l = top * dataWidth + left;
        if(i != dataWidth)
            break; /* Loop/switch isn't completed */
        System.arraycopy(luminances, l, abyte0, 0, k);
        if(true) goto _L4; else goto _L3
_L3:
        byte abyte1[] = luminances;
        int i1 = 0;
        while(i1 < j) 
        {
            System.arraycopy(abyte1, l, abyte0, i1 * i, i);
            l += dataWidth;
            i1++;
        }
        if(true) goto _L4; else goto _L5
_L5:
    }

    public byte[] getRow(int i, byte abyte0[])
    {
        if(i < 0 || i >= getHeight())
            throw new IllegalArgumentException((new StringBuilder()).append("Requested row is outside the image: ").append(i).toString());
        int j = getWidth();
        if(abyte0 == null || abyte0.length < j)
            abyte0 = new byte[j];
        int k = (i + top) * dataWidth + left;
        System.arraycopy(luminances, k, abyte0, 0, j);
        return abyte0;
    }

    public boolean isCropSupported()
    {
        return true;
    }
}
