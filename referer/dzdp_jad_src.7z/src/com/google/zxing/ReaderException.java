// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing;


public abstract class ReaderException extends Exception
{

    protected static final StackTraceElement NO_TRACE[] = new StackTraceElement[0];
    protected static final boolean isStackTrace;

    ReaderException()
    {
    }

    ReaderException(Throwable throwable)
    {
        super(throwable);
    }

    public final Throwable fillInStackTrace()
    {
        return null;
    }

    static 
    {
        boolean flag;
        if(System.getProperty("surefire.test.class.path") != null)
            flag = true;
        else
            flag = false;
        isStackTrace = flag;
    }
}
