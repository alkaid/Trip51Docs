// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing;


// Referenced classes of package com.google.zxing:
//            ReaderException

public final class NotFoundException extends ReaderException
{

    private static final NotFoundException INSTANCE;

    private NotFoundException()
    {
    }

    public static NotFoundException getNotFoundInstance()
    {
        return INSTANCE;
    }

    static 
    {
        INSTANCE = new NotFoundException();
        INSTANCE.setStackTrace(NO_TRACE);
    }
}
