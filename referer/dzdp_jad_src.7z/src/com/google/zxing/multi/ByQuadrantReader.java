// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.multi;

import com.google.zxing.*;
import java.util.Map;

public final class ByQuadrantReader
    implements Reader
{

    private final Reader _flddelegate;

    public ByQuadrantReader(Reader reader)
    {
        _flddelegate = reader;
    }

    private static void makeAbsolute(ResultPoint aresultpoint[], int i, int j)
    {
        if(aresultpoint != null)
        {
            for(int k = 0; k < aresultpoint.length; k++)
            {
                ResultPoint resultpoint = aresultpoint[k];
                aresultpoint[k] = new ResultPoint(resultpoint.getX() + (float)i, resultpoint.getY() + (float)j);
            }

        }
    }

    public Result decode(BinaryBitmap binarybitmap)
        throws NotFoundException, ChecksumException, FormatException
    {
        return decode(binarybitmap, null);
    }

    public Result decode(BinaryBitmap binarybitmap, Map map)
        throws NotFoundException, ChecksumException, FormatException
    {
        int k;
        int l;
        int i = binarybitmap.getWidth();
        int j = binarybitmap.getHeight();
        k = i / 2;
        l = j / 2;
        Result result1 = _flddelegate.decode(binarybitmap.crop(0, 0, k, l), map);
        Result result = result1;
_L2:
        return result;
        NotFoundException notfoundexception;
        notfoundexception;
        try
        {
            result = _flddelegate.decode(binarybitmap.crop(k, 0, k, l), map);
            makeAbsolute(result.getResultPoints(), k, 0);
        }
        catch(NotFoundException notfoundexception1)
        {
            try
            {
                result = _flddelegate.decode(binarybitmap.crop(0, l, k, l), map);
                makeAbsolute(result.getResultPoints(), 0, l);
            }
            catch(NotFoundException notfoundexception2)
            {
                try
                {
                    result = _flddelegate.decode(binarybitmap.crop(k, l, k, l), map);
                    makeAbsolute(result.getResultPoints(), k, l);
                }
                catch(NotFoundException notfoundexception3)
                {
                    int i1 = k / 2;
                    int j1 = l / 2;
                    BinaryBitmap binarybitmap1 = binarybitmap.crop(i1, j1, k, l);
                    result = _flddelegate.decode(binarybitmap1, map);
                    makeAbsolute(result.getResultPoints(), i1, j1);
                }
            }
        }
        if(true) goto _L2; else goto _L1
_L1:
    }

    public void reset()
    {
        _flddelegate.reset();
    }
}
