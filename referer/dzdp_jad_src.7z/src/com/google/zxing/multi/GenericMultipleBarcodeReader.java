// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.multi;

import com.google.zxing.*;
import java.util.*;

// Referenced classes of package com.google.zxing.multi:
//            MultipleBarcodeReader

public final class GenericMultipleBarcodeReader
    implements MultipleBarcodeReader
{

    private static final int MAX_DEPTH = 4;
    private static final int MIN_DIMENSION_TO_RECUR = 100;
    private final Reader _flddelegate;

    public GenericMultipleBarcodeReader(Reader reader)
    {
        _flddelegate = reader;
    }

    private void doDecodeMultiple(BinaryBitmap binarybitmap, Map map, List list, int i, int j, int k)
    {
        if(k <= 4) goto _L2; else goto _L1
_L1:
        return;
_L2:
        Result result;
        boolean flag;
        Iterator iterator;
        ResultPoint aresultpoint[];
        int l;
        int i1;
        float f;
        float f1;
        float f2;
        float f3;
        int j1;
        int k1;
        try
        {
            result = _flddelegate.decode(binarybitmap, map);
        }
        catch(ReaderException readerexception)
        {
            continue; /* Loop/switch isn't completed */
        }
        flag = false;
        iterator = list.iterator();
        do
        {
            if(!iterator.hasNext())
                break;
            if(!((Result)iterator.next()).getText().equals(result.getText()))
                continue;
            flag = true;
            break;
        } while(true);
        if(!flag)
            list.add(translateResultPoints(result, i, j));
        aresultpoint = result.getResultPoints();
        if(aresultpoint == null || aresultpoint.length == 0)
            continue; /* Loop/switch isn't completed */
        l = binarybitmap.getWidth();
        i1 = binarybitmap.getHeight();
        f = l;
        f1 = i1;
        f2 = 0.0F;
        f3 = 0.0F;
        j1 = aresultpoint.length;
        k1 = 0;
        while(k1 < j1) 
        {
            ResultPoint resultpoint = aresultpoint[k1];
            if(resultpoint != null)
            {
                float f4 = resultpoint.getX();
                float f5 = resultpoint.getY();
                if(f4 < f)
                    f = f4;
                if(f5 < f1)
                    f1 = f5;
                if(f4 > f2)
                    f2 = f4;
                if(f5 > f3)
                    f3 = f5;
            }
            k1++;
        }
        if(f > 100F)
            doDecodeMultiple(binarybitmap.crop(0, 0, (int)f, i1), map, list, i, j, k + 1);
        if(f1 > 100F)
            doDecodeMultiple(binarybitmap.crop(0, 0, l, (int)f1), map, list, i, j, k + 1);
        if(f2 < (float)(l - 100))
            doDecodeMultiple(binarybitmap.crop((int)f2, 0, l - (int)f2, i1), map, list, i + (int)f2, j, k + 1);
        if(f3 < (float)(i1 - 100))
            doDecodeMultiple(binarybitmap.crop(0, (int)f3, l, i1 - (int)f3), map, list, i, j + (int)f3, k + 1);
        if(true) goto _L1; else goto _L3
_L3:
    }

    private static Result translateResultPoints(Result result, int i, int j)
    {
        ResultPoint aresultpoint[] = result.getResultPoints();
        if(aresultpoint != null)
        {
            ResultPoint aresultpoint1[] = new ResultPoint[aresultpoint.length];
            for(int k = 0; k < aresultpoint.length; k++)
            {
                ResultPoint resultpoint = aresultpoint[k];
                if(resultpoint != null)
                    aresultpoint1[k] = new ResultPoint(resultpoint.getX() + (float)i, resultpoint.getY() + (float)j);
            }

            Result result1 = new Result(result.getText(), result.getRawBytes(), aresultpoint1, result.getBarcodeFormat());
            result1.putAllMetadata(result.getResultMetadata());
            result = result1;
        }
        return result;
    }

    public Result[] decodeMultiple(BinaryBitmap binarybitmap)
        throws NotFoundException
    {
        return decodeMultiple(binarybitmap, null);
    }

    public Result[] decodeMultiple(BinaryBitmap binarybitmap, Map map)
        throws NotFoundException
    {
        ArrayList arraylist = new ArrayList();
        doDecodeMultiple(binarybitmap, map, arraylist, 0, 0, 0);
        if(arraylist.isEmpty())
            throw NotFoundException.getNotFoundInstance();
        else
            return (Result[])arraylist.toArray(new Result[arraylist.size()]);
    }
}
