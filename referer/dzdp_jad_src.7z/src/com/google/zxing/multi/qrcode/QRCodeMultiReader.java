// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.multi.qrcode;

import com.google.zxing.*;
import com.google.zxing.common.DecoderResult;
import com.google.zxing.common.DetectorResult;
import com.google.zxing.multi.MultipleBarcodeReader;
import com.google.zxing.multi.qrcode.detector.MultiDetector;
import com.google.zxing.qrcode.QRCodeReader;
import com.google.zxing.qrcode.decoder.Decoder;
import com.google.zxing.qrcode.decoder.QRCodeDecoderMetaData;
import java.io.Serializable;
import java.util.*;

public final class QRCodeMultiReader extends QRCodeReader
    implements MultipleBarcodeReader
{
    private static final class SAComparator
        implements Comparator, Serializable
    {

        public int compare(Result result, Result result1)
        {
            int i = ((Integer)result.getResultMetadata().get(ResultMetadataType.STRUCTURED_APPEND_SEQUENCE)).intValue();
            int j = ((Integer)result1.getResultMetadata().get(ResultMetadataType.STRUCTURED_APPEND_SEQUENCE)).intValue();
            byte byte0;
            if(i < j)
                byte0 = -1;
            else
            if(i > j)
                byte0 = 1;
            else
                byte0 = 0;
            return byte0;
        }

        public volatile int compare(Object obj, Object obj1)
        {
            return compare((Result)obj, (Result)obj1);
        }

        private SAComparator()
        {
        }

    }


    private static final Result EMPTY_RESULT_ARRAY[] = new Result[0];
    private static final ResultPoint NO_POINTS[] = new ResultPoint[0];

    public QRCodeMultiReader()
    {
    }

    private static List processStructuredAppend(List list)
    {
        boolean flag = false;
        Iterator iterator = list.iterator();
        do
        {
            if(!iterator.hasNext())
                break;
            if(!((Result)iterator.next()).getResultMetadata().containsKey(ResultMetadataType.STRUCTURED_APPEND_SEQUENCE))
                continue;
            flag = true;
            break;
        } while(true);
        if(flag)
        {
            ArrayList arraylist = new ArrayList();
            ArrayList arraylist1 = new ArrayList();
            Iterator iterator1 = list.iterator();
            do
            {
                if(!iterator1.hasNext())
                    break;
                Result result3 = (Result)iterator1.next();
                arraylist.add(result3);
                if(result3.getResultMetadata().containsKey(ResultMetadataType.STRUCTURED_APPEND_SEQUENCE))
                    arraylist1.add(result3);
            } while(true);
            Collections.sort(arraylist1, new SAComparator());
            StringBuilder stringbuilder = new StringBuilder();
            int i = 0;
            int j = 0;
            Iterator iterator2 = arraylist1.iterator();
            do
            {
                if(!iterator2.hasNext())
                    break;
                Result result2 = (Result)iterator2.next();
                stringbuilder.append(result2.getText());
                i += result2.getRawBytes().length;
                if(result2.getResultMetadata().containsKey(ResultMetadataType.BYTE_SEGMENTS))
                {
                    Iterator iterator5 = ((Iterable)result2.getResultMetadata().get(ResultMetadataType.BYTE_SEGMENTS)).iterator();
                    while(iterator5.hasNext()) 
                        j += ((byte[])iterator5.next()).length;
                }
            } while(true);
            byte abyte0[] = new byte[i];
            byte abyte1[] = new byte[j];
            int k = 0;
            int l = 0;
            Iterator iterator3 = arraylist1.iterator();
            do
            {
                if(!iterator3.hasNext())
                    break;
                Result result1 = (Result)iterator3.next();
                System.arraycopy(result1.getRawBytes(), 0, abyte0, k, result1.getRawBytes().length);
                k += result1.getRawBytes().length;
                if(result1.getResultMetadata().containsKey(ResultMetadataType.BYTE_SEGMENTS))
                {
                    Iterator iterator4 = ((Iterable)result1.getResultMetadata().get(ResultMetadataType.BYTE_SEGMENTS)).iterator();
                    while(iterator4.hasNext()) 
                    {
                        byte abyte2[] = (byte[])iterator4.next();
                        System.arraycopy(abyte2, 0, abyte1, l, abyte2.length);
                        l += abyte2.length;
                    }
                }
            } while(true);
            Result result = new Result(stringbuilder.toString(), abyte0, NO_POINTS, BarcodeFormat.QR_CODE);
            if(j > 0)
            {
                ArrayList arraylist2 = new ArrayList();
                arraylist2.add(abyte1);
                result.putMetadata(ResultMetadataType.BYTE_SEGMENTS, arraylist2);
            }
            arraylist.add(result);
            list = arraylist;
        }
        return list;
    }

    public Result[] decodeMultiple(BinaryBitmap binarybitmap)
        throws NotFoundException
    {
        return decodeMultiple(binarybitmap, null);
    }

    public Result[] decodeMultiple(BinaryBitmap binarybitmap, Map map)
        throws NotFoundException
    {
        ArrayList arraylist = new ArrayList();
        DetectorResult adetectorresult[] = (new MultiDetector(binarybitmap.getBlackMatrix())).detectMulti(map);
        int i = adetectorresult.length;
        int j = 0;
        while(j < i) 
        {
            DetectorResult detectorresult = adetectorresult[j];
            List list;
            Result aresult[];
            try
            {
                DecoderResult decoderresult = getDecoder().decode(detectorresult.getBits(), map);
                ResultPoint aresultpoint[] = detectorresult.getPoints();
                if(decoderresult.getOther() instanceof QRCodeDecoderMetaData)
                    ((QRCodeDecoderMetaData)decoderresult.getOther()).applyMirroredCorrection(aresultpoint);
                Result result = new Result(decoderresult.getText(), decoderresult.getRawBytes(), aresultpoint, BarcodeFormat.QR_CODE);
                List list1 = decoderresult.getByteSegments();
                if(list1 != null)
                    result.putMetadata(ResultMetadataType.BYTE_SEGMENTS, list1);
                String s = decoderresult.getECLevel();
                if(s != null)
                    result.putMetadata(ResultMetadataType.ERROR_CORRECTION_LEVEL, s);
                if(decoderresult.hasStructuredAppend())
                {
                    result.putMetadata(ResultMetadataType.STRUCTURED_APPEND_SEQUENCE, Integer.valueOf(decoderresult.getStructuredAppendSequenceNumber()));
                    result.putMetadata(ResultMetadataType.STRUCTURED_APPEND_PARITY, Integer.valueOf(decoderresult.getStructuredAppendParity()));
                }
                arraylist.add(result);
            }
            catch(ReaderException readerexception) { }
            j++;
        }
        if(arraylist.isEmpty())
        {
            aresult = EMPTY_RESULT_ARRAY;
        } else
        {
            list = processStructuredAppend(arraylist);
            aresult = (Result[])list.toArray(new Result[list.size()]);
        }
        return aresult;
    }

}
