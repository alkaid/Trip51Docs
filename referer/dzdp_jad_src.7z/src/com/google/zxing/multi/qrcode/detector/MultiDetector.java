// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.multi.qrcode.detector;

import com.google.zxing.*;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.common.DetectorResult;
import com.google.zxing.qrcode.detector.Detector;
import java.util.*;

// Referenced classes of package com.google.zxing.multi.qrcode.detector:
//            MultiFinderPatternFinder

public final class MultiDetector extends Detector
{

    private static final DetectorResult EMPTY_DETECTOR_RESULTS[] = new DetectorResult[0];

    public MultiDetector(BitMatrix bitmatrix)
    {
        super(bitmatrix);
    }

    public DetectorResult[] detectMulti(Map map)
        throws NotFoundException
    {
        BitMatrix bitmatrix = getImage();
        ResultPointCallback resultpointcallback;
        com.google.zxing.qrcode.detector.FinderPatternInfo afinderpatterninfo[];
        if(map == null)
            resultpointcallback = null;
        else
            resultpointcallback = (ResultPointCallback)map.get(DecodeHintType.NEED_RESULT_POINT_CALLBACK);
        afinderpatterninfo = (new MultiFinderPatternFinder(bitmatrix, resultpointcallback)).findMulti(map);
        if(afinderpatterninfo.length == 0)
            throw NotFoundException.getNotFoundInstance();
        ArrayList arraylist = new ArrayList();
        int i = afinderpatterninfo.length;
        int j = 0;
        while(j < i) 
        {
            com.google.zxing.qrcode.detector.FinderPatternInfo finderpatterninfo = afinderpatterninfo[j];
            DetectorResult adetectorresult[];
            try
            {
                arraylist.add(processFinderPatternInfo(finderpatterninfo));
            }
            catch(ReaderException readerexception) { }
            j++;
        }
        if(arraylist.isEmpty())
            adetectorresult = EMPTY_DETECTOR_RESULTS;
        else
            adetectorresult = (DetectorResult[])arraylist.toArray(new DetectorResult[arraylist.size()]);
        return adetectorresult;
    }

}
