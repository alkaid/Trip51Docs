// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing;


public final class ResultMetadataType extends Enum
{

    private static final ResultMetadataType $VALUES[];
    public static final ResultMetadataType BYTE_SEGMENTS;
    public static final ResultMetadataType ERROR_CORRECTION_LEVEL;
    public static final ResultMetadataType ISSUE_NUMBER;
    public static final ResultMetadataType ORIENTATION;
    public static final ResultMetadataType OTHER;
    public static final ResultMetadataType PDF417_EXTRA_METADATA;
    public static final ResultMetadataType POSSIBLE_COUNTRY;
    public static final ResultMetadataType STRUCTURED_APPEND_PARITY;
    public static final ResultMetadataType STRUCTURED_APPEND_SEQUENCE;
    public static final ResultMetadataType SUGGESTED_PRICE;
    public static final ResultMetadataType UPC_EAN_EXTENSION;

    private ResultMetadataType(String s, int i)
    {
        super(s, i);
    }

    public static ResultMetadataType valueOf(String s)
    {
        return (ResultMetadataType)Enum.valueOf(com/google/zxing/ResultMetadataType, s);
    }

    public static ResultMetadataType[] values()
    {
        return (ResultMetadataType[])$VALUES.clone();
    }

    static 
    {
        OTHER = new ResultMetadataType("OTHER", 0);
        ORIENTATION = new ResultMetadataType("ORIENTATION", 1);
        BYTE_SEGMENTS = new ResultMetadataType("BYTE_SEGMENTS", 2);
        ERROR_CORRECTION_LEVEL = new ResultMetadataType("ERROR_CORRECTION_LEVEL", 3);
        ISSUE_NUMBER = new ResultMetadataType("ISSUE_NUMBER", 4);
        SUGGESTED_PRICE = new ResultMetadataType("SUGGESTED_PRICE", 5);
        POSSIBLE_COUNTRY = new ResultMetadataType("POSSIBLE_COUNTRY", 6);
        UPC_EAN_EXTENSION = new ResultMetadataType("UPC_EAN_EXTENSION", 7);
        PDF417_EXTRA_METADATA = new ResultMetadataType("PDF417_EXTRA_METADATA", 8);
        STRUCTURED_APPEND_SEQUENCE = new ResultMetadataType("STRUCTURED_APPEND_SEQUENCE", 9);
        STRUCTURED_APPEND_PARITY = new ResultMetadataType("STRUCTURED_APPEND_PARITY", 10);
        ResultMetadataType aresultmetadatatype[] = new ResultMetadataType[11];
        aresultmetadatatype[0] = OTHER;
        aresultmetadatatype[1] = ORIENTATION;
        aresultmetadatatype[2] = BYTE_SEGMENTS;
        aresultmetadatatype[3] = ERROR_CORRECTION_LEVEL;
        aresultmetadatatype[4] = ISSUE_NUMBER;
        aresultmetadatatype[5] = SUGGESTED_PRICE;
        aresultmetadatatype[6] = POSSIBLE_COUNTRY;
        aresultmetadatatype[7] = UPC_EAN_EXTENSION;
        aresultmetadatatype[8] = PDF417_EXTRA_METADATA;
        aresultmetadatatype[9] = STRUCTURED_APPEND_SEQUENCE;
        aresultmetadatatype[10] = STRUCTURED_APPEND_PARITY;
        $VALUES = aresultmetadatatype;
    }
}
