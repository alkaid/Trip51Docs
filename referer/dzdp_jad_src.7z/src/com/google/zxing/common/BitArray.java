// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.common;

import java.util.Arrays;

public final class BitArray
    implements Cloneable
{

    private int bits[];
    private int size;

    public BitArray()
    {
        size = 0;
        bits = new int[1];
    }

    public BitArray(int i)
    {
        size = i;
        bits = makeArray(i);
    }

    BitArray(int ai[], int i)
    {
        bits = ai;
        size = i;
    }

    private void ensureCapacity(int i)
    {
        if(i > 32 * bits.length)
        {
            int ai[] = makeArray(i);
            System.arraycopy(bits, 0, ai, 0, bits.length);
            bits = ai;
        }
    }

    private static int[] makeArray(int i)
    {
        return new int[(i + 31) / 32];
    }

    public void appendBit(boolean flag)
    {
        ensureCapacity(1 + size);
        if(flag)
        {
            int ai[] = bits;
            int i = size / 32;
            ai[i] = ai[i] | 1 << (0x1f & size);
        }
        size = 1 + size;
    }

    public void appendBitArray(BitArray bitarray)
    {
        int i = bitarray.size;
        ensureCapacity(i + size);
        for(int j = 0; j < i; j++)
            appendBit(bitarray.get(j));

    }

    public void appendBits(int i, int j)
    {
        if(j < 0 || j > 32)
            throw new IllegalArgumentException("Num bits must be between 0 and 32");
        ensureCapacity(j + size);
        int k = j;
        while(k > 0) 
        {
            boolean flag;
            if((1 & i >> k - 1) == 1)
                flag = true;
            else
                flag = false;
            appendBit(flag);
            k--;
        }
    }

    public void clear()
    {
        int i = bits.length;
        for(int j = 0; j < i; j++)
            bits[j] = 0;

    }

    public BitArray clone()
    {
        return new BitArray((int[])bits.clone(), size);
    }

    public volatile Object clone()
        throws CloneNotSupportedException
    {
        return clone();
    }

    public boolean equals(Object obj)
    {
        boolean flag = false;
        if(obj instanceof BitArray) goto _L2; else goto _L1
_L1:
        return flag;
_L2:
        BitArray bitarray = (BitArray)obj;
        if(size == bitarray.size && Arrays.equals(bits, bitarray.bits))
            flag = true;
        if(true) goto _L1; else goto _L3
_L3:
    }

    public void flip(int i)
    {
        int ai[] = bits;
        int j = i / 32;
        ai[j] = ai[j] ^ 1 << (i & 0x1f);
    }

    public boolean get(int i)
    {
        boolean flag = true;
        if((bits[i / 32] & flag << (i & 0x1f)) == 0)
            flag = false;
        return flag;
    }

    public int[] getBitArray()
    {
        return bits;
    }

    public int getNextSet(int i)
    {
        if(i < size) goto _L2; else goto _L1
_L1:
        int l = size;
_L4:
        return l;
_L2:
        int j = i / 32;
        int k = bits[j] & (-1 ^ -1 + (1 << (i & 0x1f)));
        do
        {
            if(k != 0)
                break;
            if(++j == bits.length)
            {
                l = size;
                continue; /* Loop/switch isn't completed */
            }
            k = bits[j];
        } while(true);
        l = j * 32 + Integer.numberOfTrailingZeros(k);
        if(l > size)
            l = size;
        if(true) goto _L4; else goto _L3
_L3:
    }

    public int getNextUnset(int i)
    {
        if(i < size) goto _L2; else goto _L1
_L1:
        int l = size;
_L4:
        return l;
_L2:
        int j = i / 32;
        int k = (-1 ^ bits[j]) & (-1 ^ -1 + (1 << (i & 0x1f)));
        do
        {
            if(k != 0)
                break;
            if(++j == bits.length)
            {
                l = size;
                continue; /* Loop/switch isn't completed */
            }
            k = -1 ^ bits[j];
        } while(true);
        l = j * 32 + Integer.numberOfTrailingZeros(k);
        if(l > size)
            l = size;
        if(true) goto _L4; else goto _L3
_L3:
    }

    public int getSize()
    {
        return size;
    }

    public int getSizeInBytes()
    {
        return (7 + size) / 8;
    }

    public int hashCode()
    {
        return 31 * size + Arrays.hashCode(bits);
    }

    public boolean isRange(int i, int j, boolean flag)
    {
        boolean flag1;
        flag1 = true;
        if(j < i)
            throw new IllegalArgumentException();
        if(j != i) goto _L2; else goto _L1
_L1:
        return flag1;
_L2:
        int k = j - 1;
        int l = i / 32;
        int i1 = k / 32;
        int j1 = l;
        do
        {
            if(j1 <= i1)
            {
label0:
                {
                    int k1;
                    int l1;
                    int i2;
                    int k2;
                    if(j1 > l)
                        k1 = 0;
                    else
                        k1 = i & 0x1f;
                    if(j1 < i1)
                        l1 = 31;
                    else
                        l1 = k & 0x1f;
                    if(k1 == 0 && l1 == 31)
                    {
                        i2 = -1;
                    } else
                    {
                        i2 = 0;
                        int j2 = k1;
                        while(j2 <= l1) 
                        {
                            i2 |= flag1 << j2;
                            j2++;
                        }
                    }
                    k2 = i2 & bits[j1];
                    if(!flag)
                        i2 = 0;
                    if(k2 == i2)
                        break label0;
                    flag1 = false;
                }
            }
            if(true)
                continue;
            j1++;
        } while(true);
        if(true) goto _L1; else goto _L3
_L3:
    }

    public void reverse()
    {
        int ai[] = new int[bits.length];
        int i = (-1 + size) / 32;
        int j = i + 1;
        for(int k = 0; k < j; k++)
        {
            long l2 = bits[k];
            long l3 = 0x55555555L & l2 >> 1 | (0x55555555L & l2) << 1;
            long l4 = 0x33333333L & l3 >> 2 | (0x33333333L & l3) << 2;
            long l5 = 0xf0f0f0fL & l4 >> 4 | (0xf0f0f0fL & l4) << 4;
            long l6 = 0xff00ffL & l5 >> 8 | (0xff00ffL & l5) << 8;
            long l7 = 65535L & l6 >> 16 | (65535L & l6) << 16;
            ai[i - k] = (int)l7;
        }

        if(size != j * 32)
        {
            int l = j * 32 - size;
            int i1 = 1;
            for(int j1 = 0; j1 < 31 - l; j1++)
                i1 = 1 | i1 << 1;

            int k1 = i1 & ai[0] >> l;
            for(int l1 = 1; l1 < j; l1++)
            {
                int i2 = ai[l1];
                int j2 = k1 | i2 << 32 - l;
                ai[l1 - 1] = j2;
                k1 = i1 & i2 >> l;
            }

            ai[j - 1] = k1;
        }
        bits = ai;
    }

    public void set(int i)
    {
        int ai[] = bits;
        int j = i / 32;
        ai[j] = ai[j] | 1 << (i & 0x1f);
    }

    public void setBulk(int i, int j)
    {
        bits[i / 32] = j;
    }

    public void setRange(int i, int j)
    {
        if(j < i)
            throw new IllegalArgumentException();
        if(j != i)
        {
            int k = j - 1;
            int l = i / 32;
            int i1 = k / 32;
            int j1 = l;
            while(j1 <= i1) 
            {
                int k1;
                int l1;
                int i2;
                int ai[];
                if(j1 > l)
                    k1 = 0;
                else
                    k1 = i & 0x1f;
                if(j1 < i1)
                    l1 = 31;
                else
                    l1 = k & 0x1f;
                if(k1 == 0 && l1 == 31)
                {
                    i2 = -1;
                } else
                {
                    i2 = 0;
                    int j2 = k1;
                    while(j2 <= l1) 
                    {
                        i2 |= 1 << j2;
                        j2++;
                    }
                }
                ai = bits;
                ai[j1] = i2 | ai[j1];
                j1++;
            }
        }
    }

    public void toBytes(int i, byte abyte0[], int j, int k)
    {
        for(int l = 0; l < k; l++)
        {
            int i1 = 0;
            for(int j1 = 0; j1 < 8; j1++)
            {
                if(get(i))
                    i1 |= 1 << 7 - j1;
                i++;
            }

            abyte0[j + l] = (byte)i1;
        }

    }

    public String toString()
    {
        StringBuilder stringbuilder = new StringBuilder(size);
        int i = 0;
        while(i < size) 
        {
            if((i & 7) == 0)
                stringbuilder.append(' ');
            char c;
            if(get(i))
                c = 'X';
            else
                c = '.';
            stringbuilder.append(c);
            i++;
        }
        return stringbuilder.toString();
    }

    public void xor(BitArray bitarray)
    {
        if(bits.length != bitarray.bits.length)
            throw new IllegalArgumentException("Sizes don't match");
        for(int i = 0; i < bits.length; i++)
        {
            int ai[] = bits;
            ai[i] = ai[i] ^ bitarray.bits[i];
        }

    }
}
