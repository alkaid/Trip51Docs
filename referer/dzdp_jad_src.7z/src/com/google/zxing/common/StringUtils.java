// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.common;

import com.google.zxing.DecodeHintType;
import java.nio.charset.Charset;
import java.util.Map;

public final class StringUtils
{

    private static final boolean ASSUME_SHIFT_JIS = false;
    private static final String EUC_JP = "EUC_JP";
    public static final String GB2312 = "GB2312";
    private static final String ISO88591 = "ISO8859_1";
    private static final String PLATFORM_DEFAULT_ENCODING = Charset.defaultCharset().name();
    public static final String SHIFT_JIS = "SJIS";
    private static final String UTF8 = "UTF8";

    private StringUtils()
    {
    }

    public static String guessEncoding(byte abyte0[], Map map)
    {
        if(map == null) goto _L2; else goto _L1
_L1:
        String s = (String)map.get(DecodeHintType.CHARACTER_SET);
        if(s == null) goto _L2; else goto _L3
_L3:
        return s;
_L2:
        int i = abyte0.length;
        boolean flag = true;
        boolean flag1 = true;
        boolean flag2 = true;
        int j = 0;
        int k = 0;
        int l = 0;
        int i1 = 0;
        int j1 = 0;
        int k1 = 0;
        int l1 = 0;
        int i2 = 0;
        int j2 = 0;
        int k2 = 0;
        int l2 = 0;
        boolean flag3;
        int i3;
        if(abyte0.length > 3 && abyte0[0] == -17 && abyte0[1] == -69 && abyte0[2] == -65)
            flag3 = true;
        else
            flag3 = false;
        i3 = 0;
        while(i3 < i && (flag || flag1 || flag2)) 
        {
            int j3 = 0xff & abyte0[i3];
            if(flag2)
                if(j > 0)
                {
                    if((j3 & 0x80) == 0)
                        flag2 = false;
                    else
                        j--;
                } else
                if((j3 & 0x80) != 0)
                    if((j3 & 0x40) == 0)
                    {
                        flag2 = false;
                    } else
                    {
                        j++;
                        if((j3 & 0x20) == 0)
                        {
                            k++;
                        } else
                        {
                            j++;
                            if((j3 & 0x10) == 0)
                            {
                                l++;
                            } else
                            {
                                j++;
                                if((j3 & 8) == 0)
                                    i1++;
                                else
                                    flag2 = false;
                            }
                        }
                    }
            if(flag)
                if(j3 > 127 && j3 < 160)
                    flag = false;
                else
                if(j3 > 159 && (j3 < 192 || j3 == 215 || j3 == 247))
                    l2++;
            if(flag1)
                if(j1 > 0)
                {
                    if(j3 < 64 || j3 == 127 || j3 > 252)
                        flag1 = false;
                    else
                        j1--;
                } else
                if(j3 == 128 || j3 == 160 || j3 > 239)
                    flag1 = false;
                else
                if(j3 > 160 && j3 < 224)
                {
                    k1++;
                    i2 = 0;
                    if(++l1 > j2)
                        j2 = l1;
                } else
                if(j3 > 127)
                {
                    j1++;
                    l1 = 0;
                    if(++i2 > k2)
                        k2 = i2;
                } else
                {
                    l1 = 0;
                    i2 = 0;
                }
            i3++;
        }
        if(flag2 && j > 0)
            flag2 = false;
        if(flag1 && j1 > 0)
            flag1 = false;
        if(flag2 && (flag3 || i1 + (k + l) > 0))
            s = "UTF8";
        else
        if(flag1 && (ASSUME_SHIFT_JIS || j2 >= 3 || k2 >= 3))
            s = "SJIS";
        else
        if(flag && flag1)
        {
            String s1;
            if(j2 == 2 && k1 == 2 || l2 * 10 >= i)
                s1 = "SJIS";
            else
                s1 = "ISO8859_1";
            s = s1;
        } else
        if(flag)
            s = "ISO8859_1";
        else
        if(flag1)
            s = "SJIS";
        else
        if(flag2)
            s = "UTF8";
        else
            s = PLATFORM_DEFAULT_ENCODING;
        if(true) goto _L3; else goto _L4
_L4:
    }

    static 
    {
        boolean flag;
        if("SJIS".equalsIgnoreCase(PLATFORM_DEFAULT_ENCODING) || "EUC_JP".equalsIgnoreCase(PLATFORM_DEFAULT_ENCODING))
            flag = true;
        else
            flag = false;
        ASSUME_SHIFT_JIS = flag;
    }
}
