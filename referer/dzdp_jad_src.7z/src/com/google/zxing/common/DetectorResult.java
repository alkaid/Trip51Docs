// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.common;

import com.google.zxing.ResultPoint;

// Referenced classes of package com.google.zxing.common:
//            BitMatrix

public class DetectorResult
{

    private final BitMatrix bits;
    private final ResultPoint points[];

    public DetectorResult(BitMatrix bitmatrix, ResultPoint aresultpoint[])
    {
        bits = bitmatrix;
        points = aresultpoint;
    }

    public final BitMatrix getBits()
    {
        return bits;
    }

    public final ResultPoint[] getPoints()
    {
        return points;
    }
}
