// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.common;

import com.google.zxing.FormatException;
import java.util.HashMap;
import java.util.Map;

public final class CharacterSetECI extends Enum
{

    private static final CharacterSetECI $VALUES[];
    public static final CharacterSetECI ASCII;
    public static final CharacterSetECI Big5;
    public static final CharacterSetECI Cp1250;
    public static final CharacterSetECI Cp1251;
    public static final CharacterSetECI Cp1252;
    public static final CharacterSetECI Cp1256;
    public static final CharacterSetECI Cp437;
    public static final CharacterSetECI EUC_KR;
    public static final CharacterSetECI GB18030;
    public static final CharacterSetECI ISO8859_1;
    public static final CharacterSetECI ISO8859_10;
    public static final CharacterSetECI ISO8859_11;
    public static final CharacterSetECI ISO8859_13;
    public static final CharacterSetECI ISO8859_14;
    public static final CharacterSetECI ISO8859_15;
    public static final CharacterSetECI ISO8859_16;
    public static final CharacterSetECI ISO8859_2;
    public static final CharacterSetECI ISO8859_3;
    public static final CharacterSetECI ISO8859_4;
    public static final CharacterSetECI ISO8859_5;
    public static final CharacterSetECI ISO8859_6;
    public static final CharacterSetECI ISO8859_7;
    public static final CharacterSetECI ISO8859_8;
    public static final CharacterSetECI ISO8859_9;
    private static final Map NAME_TO_ECI;
    public static final CharacterSetECI SJIS;
    public static final CharacterSetECI UTF8;
    public static final CharacterSetECI UnicodeBigUnmarked;
    private static final Map VALUE_TO_ECI;
    private final String otherEncodingNames[];
    private final int values[];

    private CharacterSetECI(String s, int i, int j)
    {
        int ai[] = new int[1];
        ai[0] = j;
        this(s, i, ai, new String[0]);
    }

    private transient CharacterSetECI(String s, int i, int j, String as[])
    {
        super(s, i);
        int ai[] = new int[1];
        ai[0] = j;
        values = ai;
        otherEncodingNames = as;
    }

    private transient CharacterSetECI(String s, int i, int ai[], String as[])
    {
        super(s, i);
        values = ai;
        otherEncodingNames = as;
    }

    public static CharacterSetECI getCharacterSetECIByName(String s)
    {
        return (CharacterSetECI)NAME_TO_ECI.get(s);
    }

    public static CharacterSetECI getCharacterSetECIByValue(int i)
        throws FormatException
    {
        if(i < 0 || i >= 900)
            throw FormatException.getFormatInstance();
        else
            return (CharacterSetECI)VALUE_TO_ECI.get(Integer.valueOf(i));
    }

    public static CharacterSetECI valueOf(String s)
    {
        return (CharacterSetECI)Enum.valueOf(com/google/zxing/common/CharacterSetECI, s);
    }

    public static CharacterSetECI[] values()
    {
        return (CharacterSetECI[])$VALUES.clone();
    }

    public int getValue()
    {
        return values[0];
    }

    static 
    {
        int ai[] = new int[2];
        ai[0] = 0;
        ai[1] = 2;
        Cp437 = new CharacterSetECI("Cp437", 0, ai, new String[0]);
        int ai1[] = new int[2];
        ai1[0] = 1;
        ai1[1] = 3;
        String as[] = new String[1];
        as[0] = "ISO-8859-1";
        ISO8859_1 = new CharacterSetECI("ISO8859_1", 1, ai1, as);
        String as1[] = new String[1];
        as1[0] = "ISO-8859-2";
        ISO8859_2 = new CharacterSetECI("ISO8859_2", 2, 4, as1);
        String as2[] = new String[1];
        as2[0] = "ISO-8859-3";
        ISO8859_3 = new CharacterSetECI("ISO8859_3", 3, 5, as2);
        String as3[] = new String[1];
        as3[0] = "ISO-8859-4";
        ISO8859_4 = new CharacterSetECI("ISO8859_4", 4, 6, as3);
        String as4[] = new String[1];
        as4[0] = "ISO-8859-5";
        ISO8859_5 = new CharacterSetECI("ISO8859_5", 5, 7, as4);
        String as5[] = new String[1];
        as5[0] = "ISO-8859-6";
        ISO8859_6 = new CharacterSetECI("ISO8859_6", 6, 8, as5);
        String as6[] = new String[1];
        as6[0] = "ISO-8859-7";
        ISO8859_7 = new CharacterSetECI("ISO8859_7", 7, 9, as6);
        String as7[] = new String[1];
        as7[0] = "ISO-8859-8";
        ISO8859_8 = new CharacterSetECI("ISO8859_8", 8, 10, as7);
        String as8[] = new String[1];
        as8[0] = "ISO-8859-9";
        ISO8859_9 = new CharacterSetECI("ISO8859_9", 9, 11, as8);
        String as9[] = new String[1];
        as9[0] = "ISO-8859-10";
        ISO8859_10 = new CharacterSetECI("ISO8859_10", 10, 12, as9);
        String as10[] = new String[1];
        as10[0] = "ISO-8859-11";
        ISO8859_11 = new CharacterSetECI("ISO8859_11", 11, 13, as10);
        String as11[] = new String[1];
        as11[0] = "ISO-8859-13";
        ISO8859_13 = new CharacterSetECI("ISO8859_13", 12, 15, as11);
        String as12[] = new String[1];
        as12[0] = "ISO-8859-14";
        ISO8859_14 = new CharacterSetECI("ISO8859_14", 13, 16, as12);
        String as13[] = new String[1];
        as13[0] = "ISO-8859-15";
        ISO8859_15 = new CharacterSetECI("ISO8859_15", 14, 17, as13);
        String as14[] = new String[1];
        as14[0] = "ISO-8859-16";
        ISO8859_16 = new CharacterSetECI("ISO8859_16", 15, 18, as14);
        String as15[] = new String[1];
        as15[0] = "Shift_JIS";
        SJIS = new CharacterSetECI("SJIS", 16, 20, as15);
        String as16[] = new String[1];
        as16[0] = "windows-1250";
        Cp1250 = new CharacterSetECI("Cp1250", 17, 21, as16);
        String as17[] = new String[1];
        as17[0] = "windows-1251";
        Cp1251 = new CharacterSetECI("Cp1251", 18, 22, as17);
        String as18[] = new String[1];
        as18[0] = "windows-1252";
        Cp1252 = new CharacterSetECI("Cp1252", 19, 23, as18);
        String as19[] = new String[1];
        as19[0] = "windows-1256";
        Cp1256 = new CharacterSetECI("Cp1256", 20, 24, as19);
        String as20[] = new String[2];
        as20[0] = "UTF-16BE";
        as20[1] = "UnicodeBig";
        UnicodeBigUnmarked = new CharacterSetECI("UnicodeBigUnmarked", 21, 25, as20);
        String as21[] = new String[1];
        as21[0] = "UTF-8";
        UTF8 = new CharacterSetECI("UTF8", 22, 26, as21);
        int ai2[] = new int[2];
        ai2[0] = 27;
        ai2[1] = 170;
        String as22[] = new String[1];
        as22[0] = "US-ASCII";
        ASCII = new CharacterSetECI("ASCII", 23, ai2, as22);
        Big5 = new CharacterSetECI("Big5", 24, 28);
        String as23[] = new String[3];
        as23[0] = "GB2312";
        as23[1] = "EUC_CN";
        as23[2] = "GBK";
        GB18030 = new CharacterSetECI("GB18030", 25, 29, as23);
        String as24[] = new String[1];
        as24[0] = "EUC-KR";
        EUC_KR = new CharacterSetECI("EUC_KR", 26, 30, as24);
        CharacterSetECI acharacterseteci[] = new CharacterSetECI[27];
        acharacterseteci[0] = Cp437;
        acharacterseteci[1] = ISO8859_1;
        acharacterseteci[2] = ISO8859_2;
        acharacterseteci[3] = ISO8859_3;
        acharacterseteci[4] = ISO8859_4;
        acharacterseteci[5] = ISO8859_5;
        acharacterseteci[6] = ISO8859_6;
        acharacterseteci[7] = ISO8859_7;
        acharacterseteci[8] = ISO8859_8;
        acharacterseteci[9] = ISO8859_9;
        acharacterseteci[10] = ISO8859_10;
        acharacterseteci[11] = ISO8859_11;
        acharacterseteci[12] = ISO8859_13;
        acharacterseteci[13] = ISO8859_14;
        acharacterseteci[14] = ISO8859_15;
        acharacterseteci[15] = ISO8859_16;
        acharacterseteci[16] = SJIS;
        acharacterseteci[17] = Cp1250;
        acharacterseteci[18] = Cp1251;
        acharacterseteci[19] = Cp1252;
        acharacterseteci[20] = Cp1256;
        acharacterseteci[21] = UnicodeBigUnmarked;
        acharacterseteci[22] = UTF8;
        acharacterseteci[23] = ASCII;
        acharacterseteci[24] = Big5;
        acharacterseteci[25] = GB18030;
        acharacterseteci[26] = EUC_KR;
        $VALUES = acharacterseteci;
        VALUE_TO_ECI = new HashMap();
        NAME_TO_ECI = new HashMap();
        CharacterSetECI acharacterseteci1[] = values();
        int i = acharacterseteci1.length;
        for(int j = 0; j < i; j++)
        {
            CharacterSetECI characterseteci = acharacterseteci1[j];
            int ai3[] = characterseteci.values;
            int k = ai3.length;
            for(int l = 0; l < k; l++)
            {
                int k1 = ai3[l];
                VALUE_TO_ECI.put(Integer.valueOf(k1), characterseteci);
            }

            NAME_TO_ECI.put(characterseteci.name(), characterseteci);
            String as25[] = characterseteci.otherEncodingNames;
            int i1 = as25.length;
            for(int j1 = 0; j1 < i1; j1++)
            {
                String s = as25[j1];
                NAME_TO_ECI.put(s, characterseteci);
            }

        }

    }
}
