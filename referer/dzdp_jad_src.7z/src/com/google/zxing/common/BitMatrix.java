// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.common;

import java.util.Arrays;

// Referenced classes of package com.google.zxing.common:
//            BitArray

public final class BitMatrix
    implements Cloneable
{

    private final int bits[];
    private final int height;
    private final int rowSize;
    private final int width;

    public BitMatrix(int i)
    {
        this(i, i);
    }

    public BitMatrix(int i, int j)
    {
        if(i < 1 || j < 1)
        {
            throw new IllegalArgumentException("Both dimensions must be greater than 0");
        } else
        {
            width = i;
            height = j;
            rowSize = (i + 31) / 32;
            bits = new int[j * rowSize];
            return;
        }
    }

    private BitMatrix(int i, int j, int k, int ai[])
    {
        width = i;
        height = j;
        rowSize = k;
        bits = ai;
    }

    public static BitMatrix parse(String s, String s1, String s2)
    {
        boolean aflag[];
        int i;
        int j;
        int k;
        int l;
        int i1;
        if(s == null)
            throw new IllegalArgumentException();
        aflag = new boolean[s.length()];
        i = 0;
        j = 0;
        k = -1;
        l = 0;
        i1 = 0;
_L8:
        if(i1 >= s.length())
            break; /* Loop/switch isn't completed */
        if(s.charAt(i1) != '\n' && s.charAt(i1) != '\r')
            break MISSING_BLOCK_LABEL_120;
        if(i <= j) goto _L2; else goto _L1
_L1:
        if(k != -1) goto _L4; else goto _L3
_L3:
        k = i - j;
_L6:
        j = i;
        l++;
_L2:
        i1++;
        continue; /* Loop/switch isn't completed */
_L4:
        if(i - j == k) goto _L6; else goto _L5
_L5:
        throw new IllegalArgumentException("row lengths do not match");
        if(s.substring(i1, i1 + s1.length()).equals(s1))
        {
            i1 += s1.length();
            aflag[i] = true;
            i++;
        } else
        if(s.substring(i1, i1 + s2.length()).equals(s2))
        {
            i1 += s2.length();
            aflag[i] = false;
            i++;
        } else
        {
            throw new IllegalArgumentException((new StringBuilder()).append("illegal character encountered: ").append(s.substring(i1)).toString());
        }
        if(true) goto _L8; else goto _L7
_L7:
        BitMatrix bitmatrix;
        if(i > j)
        {
            int j1;
            if(k == -1)
                k = i - j;
            else
            if(i - j != k)
                throw new IllegalArgumentException("row lengths do not match");
            l++;
        }
        bitmatrix = new BitMatrix(k, l);
        for(j1 = 0; j1 < i; j1++)
            if(aflag[j1])
                bitmatrix.set(j1 % k, j1 / k);

        return bitmatrix;
    }

    public void clear()
    {
        int i = bits.length;
        for(int j = 0; j < i; j++)
            bits[j] = 0;

    }

    public BitMatrix clone()
    {
        return new BitMatrix(width, height, rowSize, (int[])bits.clone());
    }

    public volatile Object clone()
        throws CloneNotSupportedException
    {
        return clone();
    }

    public boolean equals(Object obj)
    {
        boolean flag = false;
        if(obj instanceof BitMatrix) goto _L2; else goto _L1
_L1:
        return flag;
_L2:
        BitMatrix bitmatrix = (BitMatrix)obj;
        if(width == bitmatrix.width && height == bitmatrix.height && rowSize == bitmatrix.rowSize && Arrays.equals(bits, bitmatrix.bits))
            flag = true;
        if(true) goto _L1; else goto _L3
_L3:
    }

    public void flip(int i, int j)
    {
        int k = j * rowSize + i / 32;
        int ai[] = bits;
        ai[k] = ai[k] ^ 1 << (i & 0x1f);
    }

    public boolean get(int i, int j)
    {
        int k = j * rowSize + i / 32;
        boolean flag;
        if((1 & bits[k] >>> (i & 0x1f)) != 0)
            flag = true;
        else
            flag = false;
        return flag;
    }

    public int[] getBottomRightOnBit()
    {
        int i;
        for(i = -1 + bits.length; i >= 0 && bits[i] == 0; i--);
        int ai[];
        if(i < 0)
        {
            ai = null;
        } else
        {
            int j = i / rowSize;
            int k = 32 * (i % rowSize);
            int l = bits[i];
            int i1;
            for(i1 = 31; l >>> i1 == 0; i1--);
            int j1 = k + i1;
            ai = new int[2];
            ai[0] = j1;
            ai[1] = j;
        }
        return ai;
    }

    public int[] getEnclosingRectangle()
    {
        int i = width;
        int j = height;
        int k = -1;
        int l = -1;
        for(int i1 = 0; i1 < height; i1++)
        {
            for(int l1 = 0; l1 < rowSize; l1++)
            {
                int i2 = bits[l1 + i1 * rowSize];
                if(i2 == 0)
                    continue;
                if(i1 < j)
                    j = i1;
                if(i1 > l)
                    l = i1;
                if(l1 * 32 < i)
                {
                    int k2;
                    for(k2 = 0; i2 << 31 - k2 == 0; k2++);
                    if(k2 + l1 * 32 < i)
                        i = k2 + l1 * 32;
                }
                if(31 + l1 * 32 <= k)
                    continue;
                int j2;
                for(j2 = 31; i2 >>> j2 == 0; j2--);
                if(j2 + l1 * 32 > k)
                    k = j2 + l1 * 32;
            }

        }

        int j1 = k - i;
        int k1 = l - j;
        int ai[];
        if(j1 < 0 || k1 < 0)
        {
            ai = null;
        } else
        {
            ai = new int[4];
            ai[0] = i;
            ai[1] = j;
            ai[2] = j1;
            ai[3] = k1;
        }
        return ai;
    }

    public int getHeight()
    {
        return height;
    }

    public BitArray getRow(int i, BitArray bitarray)
    {
        int j;
        if(bitarray == null || bitarray.getSize() < width)
            bitarray = new BitArray(width);
        else
            bitarray.clear();
        j = i * rowSize;
        for(int k = 0; k < rowSize; k++)
            bitarray.setBulk(k * 32, bits[j + k]);

        return bitarray;
    }

    public int getRowSize()
    {
        return rowSize;
    }

    public int[] getTopLeftOnBit()
    {
        int i;
        for(i = 0; i < bits.length && bits[i] == 0; i++);
        int ai[];
        if(i == bits.length)
        {
            ai = null;
        } else
        {
            int j = i / rowSize;
            int k = 32 * (i % rowSize);
            int l = bits[i];
            int i1;
            for(i1 = 0; l << 31 - i1 == 0; i1++);
            int j1 = k + i1;
            ai = new int[2];
            ai[0] = j1;
            ai[1] = j;
        }
        return ai;
    }

    public int getWidth()
    {
        return width;
    }

    public int hashCode()
    {
        return 31 * (31 * (31 * (31 * width + width) + height) + rowSize) + Arrays.hashCode(bits);
    }

    public void rotate180()
    {
        int i = getWidth();
        int j = getHeight();
        BitArray bitarray = new BitArray(i);
        BitArray bitarray1 = new BitArray(i);
        for(int k = 0; k < (j + 1) / 2; k++)
        {
            bitarray = getRow(k, bitarray);
            bitarray1 = getRow(j - 1 - k, bitarray1);
            bitarray.reverse();
            bitarray1.reverse();
            setRow(k, bitarray1);
            setRow(j - 1 - k, bitarray);
        }

    }

    public void set(int i, int j)
    {
        int k = j * rowSize + i / 32;
        int ai[] = bits;
        ai[k] = ai[k] | 1 << (i & 0x1f);
    }

    public void setRegion(int i, int j, int k, int l)
    {
        if(j < 0 || i < 0)
            throw new IllegalArgumentException("Left and top must be nonnegative");
        if(l < 1 || k < 1)
            throw new IllegalArgumentException("Height and width must be at least 1");
        int i1 = i + k;
        int j1 = j + l;
        if(j1 > height || i1 > width)
            throw new IllegalArgumentException("The region must fit inside the matrix");
        for(int k1 = j; k1 < j1; k1++)
        {
            int l1 = k1 * rowSize;
            for(int i2 = i; i2 < i1; i2++)
            {
                int ai[] = bits;
                int j2 = l1 + i2 / 32;
                ai[j2] = ai[j2] | 1 << (i2 & 0x1f);
            }

        }

    }

    public void setRow(int i, BitArray bitarray)
    {
        System.arraycopy(bitarray.getBitArray(), 0, bits, i * rowSize, rowSize);
    }

    public String toString()
    {
        return toString("X ", "  ");
    }

    public String toString(String s, String s1)
    {
        return toString(s, s1, "\n");
    }

    public String toString(String s, String s1, String s2)
    {
        StringBuilder stringbuilder = new StringBuilder(height * (1 + width));
        for(int i = 0; i < height; i++)
        {
            int j = 0;
            while(j < width) 
            {
                String s3;
                if(get(j, i))
                    s3 = s;
                else
                    s3 = s1;
                stringbuilder.append(s3);
                j++;
            }
            stringbuilder.append(s2);
        }

        return stringbuilder.toString();
    }

    public void unset(int i, int j)
    {
        int k = j * rowSize + i / 32;
        int ai[] = bits;
        ai[k] = ai[k] & (-1 ^ 1 << (i & 0x1f));
    }

    public void xor(BitMatrix bitmatrix)
    {
        if(width != bitmatrix.getWidth() || height != bitmatrix.getHeight() || rowSize != bitmatrix.getRowSize())
            throw new IllegalArgumentException("input matrix dimensions do not match");
        BitArray bitarray = new BitArray(1 + width / 32);
        for(int i = 0; i < height; i++)
        {
            int j = i * rowSize;
            int ai[] = bitmatrix.getRow(i, bitarray).getBitArray();
            for(int k = 0; k < rowSize; k++)
            {
                int ai1[] = bits;
                int l = j + k;
                ai1[l] = ai1[l] ^ ai[k];
            }

        }

    }
}
