// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.common;

import com.google.zxing.*;
import java.lang.reflect.Array;

// Referenced classes of package com.google.zxing.common:
//            GlobalHistogramBinarizer, BitMatrix

public final class HybridBinarizer extends GlobalHistogramBinarizer
{

    private static final int BLOCK_SIZE = 8;
    private static final int BLOCK_SIZE_MASK = 7;
    private static final int BLOCK_SIZE_POWER = 3;
    private static final int MINIMUM_DIMENSION = 40;
    private static final int MIN_DYNAMIC_RANGE = 24;
    private BitMatrix matrix;

    public HybridBinarizer(LuminanceSource luminancesource)
    {
        super(luminancesource);
    }

    private static int[][] calculateBlackPoints(byte abyte0[], int i, int j, int k, int l)
    {
        int ai[] = new int[2];
        ai[0] = j;
        ai[1] = i;
        int ai1[][] = (int[][])Array.newInstance(Integer.TYPE, ai);
        for(int i1 = 0; i1 < j; i1++)
        {
            int j1 = i1 << 3;
            int k1 = l - 8;
            if(j1 > k1)
                j1 = k1;
            for(int l1 = 0; l1 < i; l1++)
            {
                int i2 = l1 << 3;
                int j2 = k - 8;
                if(i2 > j2)
                    i2 = j2;
                int k2 = 0;
                int l2 = 255;
                int i3 = 0;
                int j3 = 0;
                for(int k3 = i2 + j1 * k; j3 < 8; k3 += k)
                {
                    for(int j4 = 0; j4 < 8; j4++)
                    {
                        int l4 = 0xff & abyte0[k3 + j4];
                        k2 += l4;
                        if(l4 < l2)
                            l2 = l4;
                        if(l4 > i3)
                            i3 = l4;
                    }

                    if(i3 - l2 > 24)
                    {
                        j3++;
                        for(k3 += k; j3 < 8; k3 += k)
                        {
                            for(int k4 = 0; k4 < 8; k4++)
                                k2 += 0xff & abyte0[k3 + k4];

                            j3++;
                        }

                    }
                    j3++;
                }

                int l3 = k2 >> 6;
                if(i3 - l2 <= 24)
                {
                    l3 = l2 / 2;
                    if(i1 > 0 && l1 > 0)
                    {
                        int i4 = (ai1[i1 - 1][l1] + 2 * ai1[i1][l1 - 1] + ai1[i1 - 1][l1 - 1]) / 4;
                        if(l2 < i4)
                            l3 = i4;
                    }
                }
                ai1[i1][l1] = l3;
            }

        }

        return ai1;
    }

    private static void calculateThresholdForBlock(byte abyte0[], int i, int j, int k, int l, int ai[][], BitMatrix bitmatrix)
    {
        for(int i1 = 0; i1 < j; i1++)
        {
            int j1 = i1 << 3;
            int k1 = l - 8;
            if(j1 > k1)
                j1 = k1;
            for(int l1 = 0; l1 < i; l1++)
            {
                int i2 = l1 << 3;
                int j2 = k - 8;
                if(i2 > j2)
                    i2 = j2;
                int k2 = cap(l1, 2, i - 3);
                int l2 = cap(i1, 2, j - 3);
                int i3 = 0;
                for(int j3 = -2; j3 <= 2; j3++)
                {
                    int ai1[] = ai[l2 + j3];
                    i3 += ai1[k2 - 2] + ai1[k2 - 1] + ai1[k2] + ai1[k2 + 1] + ai1[k2 + 2];
                }

                thresholdBlock(abyte0, i2, j1, i3 / 25, k, bitmatrix);
            }

        }

    }

    private static int cap(int i, int j, int k)
    {
        if(i >= j)
            if(i > k)
                j = k;
            else
                j = i;
        return j;
    }

    private static void thresholdBlock(byte abyte0[], int i, int j, int k, int l, BitMatrix bitmatrix)
    {
        int i1 = 0;
        for(int j1 = i + j * l; i1 < 8; j1 += l)
        {
            for(int k1 = 0; k1 < 8; k1++)
                if((0xff & abyte0[j1 + k1]) <= k)
                    bitmatrix.set(i + k1, j + i1);

            i1++;
        }

    }

    public Binarizer createBinarizer(LuminanceSource luminancesource)
    {
        return new HybridBinarizer(luminancesource);
    }

    public BitMatrix getBlackMatrix()
        throws NotFoundException
    {
        BitMatrix bitmatrix;
        if(matrix != null)
        {
            bitmatrix = matrix;
        } else
        {
            LuminanceSource luminancesource = getLuminanceSource();
            int i = luminancesource.getWidth();
            int j = luminancesource.getHeight();
            if(i >= 40 && j >= 40)
            {
                byte abyte0[] = luminancesource.getMatrix();
                int k = i >> 3;
                if((i & 7) != 0)
                    k++;
                int l = j >> 3;
                if((j & 7) != 0)
                    l++;
                int ai[][] = calculateBlackPoints(abyte0, k, l, i, j);
                BitMatrix bitmatrix1 = new BitMatrix(i, j);
                calculateThresholdForBlock(abyte0, k, l, i, j, ai, bitmatrix1);
                matrix = bitmatrix1;
            } else
            {
                matrix = super.getBlackMatrix();
            }
            bitmatrix = matrix;
        }
        return bitmatrix;
    }
}
