// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.common.reedsolomon;


// Referenced classes of package com.google.zxing.common.reedsolomon:
//            GenericGFPoly

public final class GenericGF
{

    public static final GenericGF AZTEC_DATA_10 = new GenericGF(1033, 1024, 1);
    public static final GenericGF AZTEC_DATA_12 = new GenericGF(4201, 4096, 1);
    public static final GenericGF AZTEC_DATA_6;
    public static final GenericGF AZTEC_DATA_8;
    public static final GenericGF AZTEC_PARAM = new GenericGF(19, 16, 1);
    public static final GenericGF DATA_MATRIX_FIELD_256;
    public static final GenericGF MAXICODE_FIELD_64;
    public static final GenericGF QR_CODE_FIELD_256 = new GenericGF(285, 256, 0);
    private final int expTable[];
    private final int generatorBase;
    private final int logTable[];
    private final GenericGFPoly one;
    private final int primitive;
    private final int size;
    private final GenericGFPoly zero;

    public GenericGF(int i, int j, int k)
    {
        primitive = i;
        size = j;
        generatorBase = k;
        expTable = new int[j];
        logTable = new int[j];
        int l = 1;
        for(int i1 = 0; i1 < j; i1++)
        {
            expTable[i1] = l;
            l *= 2;
            if(l >= j)
                l = (l ^ i) & j - 1;
        }

        for(int j1 = 0; j1 < j - 1; j1++)
            logTable[expTable[j1]] = j1;

        int ai[] = new int[1];
        ai[0] = 0;
        zero = new GenericGFPoly(this, ai);
        int ai1[] = new int[1];
        ai1[0] = 1;
        one = new GenericGFPoly(this, ai1);
    }

    static int addOrSubtract(int i, int j)
    {
        return i ^ j;
    }

    GenericGFPoly buildMonomial(int i, int j)
    {
        if(i < 0)
            throw new IllegalArgumentException();
        GenericGFPoly genericgfpoly;
        if(j == 0)
        {
            genericgfpoly = zero;
        } else
        {
            int ai[] = new int[i + 1];
            ai[0] = j;
            genericgfpoly = new GenericGFPoly(this, ai);
        }
        return genericgfpoly;
    }

    int exp(int i)
    {
        return expTable[i];
    }

    public int getGeneratorBase()
    {
        return generatorBase;
    }

    GenericGFPoly getOne()
    {
        return one;
    }

    public int getSize()
    {
        return size;
    }

    GenericGFPoly getZero()
    {
        return zero;
    }

    int inverse(int i)
    {
        if(i == 0)
            throw new ArithmeticException();
        else
            return expTable[-1 + (size - logTable[i])];
    }

    int log(int i)
    {
        if(i == 0)
            throw new IllegalArgumentException();
        else
            return logTable[i];
    }

    int multiply(int i, int j)
    {
        int k;
        if(i == 0 || j == 0)
            k = 0;
        else
            k = expTable[(logTable[i] + logTable[j]) % (-1 + size)];
        return k;
    }

    public String toString()
    {
        return (new StringBuilder()).append("GF(0x").append(Integer.toHexString(primitive)).append(',').append(size).append(')').toString();
    }

    static 
    {
        AZTEC_DATA_6 = new GenericGF(67, 64, 1);
        DATA_MATRIX_FIELD_256 = new GenericGF(301, 256, 1);
        AZTEC_DATA_8 = DATA_MATRIX_FIELD_256;
        MAXICODE_FIELD_64 = AZTEC_DATA_6;
    }
}
