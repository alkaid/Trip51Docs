// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.common.reedsolomon;

import java.util.ArrayList;
import java.util.List;

// Referenced classes of package com.google.zxing.common.reedsolomon:
//            GenericGFPoly, GenericGF

public final class ReedSolomonEncoder
{

    private final List cachedGenerators = new ArrayList();
    private final GenericGF field;

    public ReedSolomonEncoder(GenericGF genericgf)
    {
        field = genericgf;
        List list = cachedGenerators;
        int ai[] = new int[1];
        ai[0] = 1;
        list.add(new GenericGFPoly(genericgf, ai));
    }

    private GenericGFPoly buildGenerator(int i)
    {
        if(i >= cachedGenerators.size())
        {
            GenericGFPoly genericgfpoly = (GenericGFPoly)cachedGenerators.get(-1 + cachedGenerators.size());
            for(int j = cachedGenerators.size(); j <= i; j++)
            {
                GenericGF genericgf = field;
                int ai[] = new int[2];
                ai[0] = 1;
                ai[1] = field.exp((j - 1) + field.getGeneratorBase());
                GenericGFPoly genericgfpoly1 = genericgfpoly.multiply(new GenericGFPoly(genericgf, ai));
                cachedGenerators.add(genericgfpoly1);
                genericgfpoly = genericgfpoly1;
            }

        }
        return (GenericGFPoly)cachedGenerators.get(i);
    }

    public void encode(int ai[], int i)
    {
        if(i == 0)
            throw new IllegalArgumentException("No error correction bytes");
        int j = ai.length - i;
        if(j <= 0)
            throw new IllegalArgumentException("No data bytes provided");
        GenericGFPoly genericgfpoly = buildGenerator(i);
        int ai1[] = new int[j];
        System.arraycopy(ai, 0, ai1, 0, j);
        int ai2[] = (new GenericGFPoly(field, ai1)).multiplyByMonomial(i, 1).divide(genericgfpoly)[1].getCoefficients();
        int k = i - ai2.length;
        for(int l = 0; l < k; l++)
            ai[j + l] = 0;

        System.arraycopy(ai2, 0, ai, j + k, ai2.length);
    }
}
