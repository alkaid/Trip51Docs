// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.common.reedsolomon;


// Referenced classes of package com.google.zxing.common.reedsolomon:
//            ReedSolomonException, GenericGFPoly, GenericGF

public final class ReedSolomonDecoder
{

    private final GenericGF field;

    public ReedSolomonDecoder(GenericGF genericgf)
    {
        field = genericgf;
    }

    private int[] findErrorLocations(GenericGFPoly genericgfpoly)
        throws ReedSolomonException
    {
        int i = genericgfpoly.getDegree();
        int ai[];
        if(i == 1)
        {
            ai = new int[1];
            ai[0] = genericgfpoly.getCoefficient(1);
        } else
        {
            ai = new int[i];
            int j = 0;
            for(int k = 1; k < field.getSize() && j < i; k++)
                if(genericgfpoly.evaluateAt(k) == 0)
                {
                    ai[j] = field.inverse(k);
                    j++;
                }

            if(j != i)
                throw new ReedSolomonException("Error locator degree does not match number of roots");
        }
        return ai;
    }

    private int[] findErrorMagnitudes(GenericGFPoly genericgfpoly, int ai[])
    {
        int i = ai.length;
        int ai1[] = new int[i];
        for(int j = 0; j < i; j++)
        {
            int k = field.inverse(ai[j]);
            int l = 1;
            int i1 = 0;
            while(i1 < i) 
            {
                if(j != i1)
                {
                    int j1 = field.multiply(ai[i1], k);
                    int k1;
                    if((j1 & 1) == 0)
                        k1 = j1 | 1;
                    else
                        k1 = j1 & -2;
                    l = field.multiply(l, k1);
                }
                i1++;
            }
            ai1[j] = field.multiply(genericgfpoly.evaluateAt(k), field.inverse(l));
            if(field.getGeneratorBase() != 0)
                ai1[j] = field.multiply(ai1[j], k);
        }

        return ai1;
    }

    private GenericGFPoly[] runEuclideanAlgorithm(GenericGFPoly genericgfpoly, GenericGFPoly genericgfpoly1, int i)
        throws ReedSolomonException
    {
        if(genericgfpoly.getDegree() < genericgfpoly1.getDegree())
        {
            GenericGFPoly genericgfpoly11 = genericgfpoly;
            genericgfpoly = genericgfpoly1;
            genericgfpoly1 = genericgfpoly11;
        }
        GenericGFPoly genericgfpoly2 = genericgfpoly;
        GenericGFPoly genericgfpoly3 = genericgfpoly1;
        GenericGFPoly genericgfpoly4 = field.getZero();
        GenericGFPoly genericgfpoly5 = field.getOne();
        while(genericgfpoly3.getDegree() >= i / 2) 
        {
            GenericGFPoly genericgfpoly8 = genericgfpoly2;
            GenericGFPoly genericgfpoly9 = genericgfpoly4;
            genericgfpoly2 = genericgfpoly3;
            genericgfpoly4 = genericgfpoly5;
            if(genericgfpoly2.isZero())
                throw new ReedSolomonException("r_{i-1} was zero");
            genericgfpoly3 = genericgfpoly8;
            GenericGFPoly genericgfpoly10 = field.getZero();
            int l = genericgfpoly2.getCoefficient(genericgfpoly2.getDegree());
            int i1 = field.inverse(l);
            int j1;
            int k1;
            for(; genericgfpoly3.getDegree() >= genericgfpoly2.getDegree() && !genericgfpoly3.isZero(); genericgfpoly3 = genericgfpoly3.addOrSubtract(genericgfpoly2.multiplyByMonomial(j1, k1)))
            {
                j1 = genericgfpoly3.getDegree() - genericgfpoly2.getDegree();
                k1 = field.multiply(genericgfpoly3.getCoefficient(genericgfpoly3.getDegree()), i1);
                genericgfpoly10 = genericgfpoly10.addOrSubtract(field.buildMonomial(j1, k1));
            }

            genericgfpoly5 = genericgfpoly10.multiply(genericgfpoly4).addOrSubtract(genericgfpoly9);
            if(genericgfpoly3.getDegree() >= genericgfpoly2.getDegree())
                throw new IllegalStateException("Division algorithm failed to reduce polynomial?");
        }
        int j = genericgfpoly5.getCoefficient(0);
        if(j == 0)
        {
            throw new ReedSolomonException("sigmaTilde(0) was zero");
        } else
        {
            int k = field.inverse(j);
            GenericGFPoly genericgfpoly6 = genericgfpoly5.multiply(k);
            GenericGFPoly genericgfpoly7 = genericgfpoly3.multiply(k);
            GenericGFPoly agenericgfpoly[] = new GenericGFPoly[2];
            agenericgfpoly[0] = genericgfpoly6;
            agenericgfpoly[1] = genericgfpoly7;
            return agenericgfpoly;
        }
    }

    public void decode(int ai[], int i)
        throws ReedSolomonException
    {
        GenericGFPoly genericgfpoly = new GenericGFPoly(field, ai);
        int ai1[] = new int[i];
        boolean flag = true;
        for(int j = 0; j < i; j++)
        {
            int i1 = genericgfpoly.evaluateAt(field.exp(j + field.getGeneratorBase()));
            ai1[(-1 + ai1.length) - j] = i1;
            if(i1 != 0)
                flag = false;
        }

        if(!flag)
        {
            GenericGFPoly genericgfpoly1 = new GenericGFPoly(field, ai1);
            GenericGFPoly agenericgfpoly[] = runEuclideanAlgorithm(field.buildMonomial(i, 1), genericgfpoly1, i);
            GenericGFPoly genericgfpoly2 = agenericgfpoly[0];
            GenericGFPoly genericgfpoly3 = agenericgfpoly[1];
            int ai2[] = findErrorLocations(genericgfpoly2);
            int ai3[] = findErrorMagnitudes(genericgfpoly3, ai2);
            int k = 0;
            while(k < ai2.length) 
            {
                int l = (-1 + ai.length) - field.log(ai2[k]);
                if(l < 0)
                    throw new ReedSolomonException("Bad error location");
                ai[l] = GenericGF.addOrSubtract(ai[l], ai3[k]);
                k++;
            }
        }
    }
}
