// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.common.reedsolomon;


public final class ReedSolomonException extends Exception
{

    public ReedSolomonException(String s)
    {
        super(s);
    }
}
