// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing.common.reedsolomon;


// Referenced classes of package com.google.zxing.common.reedsolomon:
//            GenericGF

final class GenericGFPoly
{

    private final int coefficients[];
    private final GenericGF field;

    GenericGFPoly(GenericGF genericgf, int ai[])
    {
        if(ai.length == 0)
            throw new IllegalArgumentException();
        field = genericgf;
        int i = ai.length;
        if(i > 1 && ai[0] == 0)
        {
            int j;
            for(j = 1; j < i && ai[j] == 0; j++);
            if(j == i)
            {
                int ai1[] = new int[1];
                ai1[0] = 0;
                coefficients = ai1;
            } else
            {
                coefficients = new int[i - j];
                System.arraycopy(ai, j, coefficients, 0, coefficients.length);
            }
        } else
        {
            coefficients = ai;
        }
    }

    GenericGFPoly addOrSubtract(GenericGFPoly genericgfpoly)
    {
        if(!field.equals(genericgfpoly.field))
            throw new IllegalArgumentException("GenericGFPolys do not have same GenericGF field");
        if(!isZero())
            if(genericgfpoly.isZero())
            {
                genericgfpoly = this;
            } else
            {
                int ai[] = coefficients;
                int ai1[] = genericgfpoly.coefficients;
                if(ai.length > ai1.length)
                {
                    int ai3[] = ai;
                    ai = ai1;
                    ai1 = ai3;
                }
                int ai2[] = new int[ai1.length];
                int i = ai1.length - ai.length;
                System.arraycopy(ai1, 0, ai2, 0, i);
                for(int j = i; j < ai1.length; j++)
                    ai2[j] = GenericGF.addOrSubtract(ai[j - i], ai1[j]);

                genericgfpoly = new GenericGFPoly(field, ai2);
            }
        return genericgfpoly;
    }

    GenericGFPoly[] divide(GenericGFPoly genericgfpoly)
    {
        if(!field.equals(genericgfpoly.field))
            throw new IllegalArgumentException("GenericGFPolys do not have same GenericGF field");
        if(genericgfpoly.isZero())
            throw new IllegalArgumentException("Divide by 0");
        GenericGFPoly genericgfpoly1 = field.getZero();
        GenericGFPoly genericgfpoly2 = this;
        int i = genericgfpoly.getCoefficient(genericgfpoly.getDegree());
        int j = field.inverse(i);
        GenericGFPoly genericgfpoly3;
        for(; genericgfpoly2.getDegree() >= genericgfpoly.getDegree() && !genericgfpoly2.isZero(); genericgfpoly2 = genericgfpoly2.addOrSubtract(genericgfpoly3))
        {
            int k = genericgfpoly2.getDegree() - genericgfpoly.getDegree();
            int l = field.multiply(genericgfpoly2.getCoefficient(genericgfpoly2.getDegree()), j);
            genericgfpoly3 = genericgfpoly.multiplyByMonomial(k, l);
            genericgfpoly1 = genericgfpoly1.addOrSubtract(field.buildMonomial(k, l));
        }

        GenericGFPoly agenericgfpoly[] = new GenericGFPoly[2];
        agenericgfpoly[0] = genericgfpoly1;
        agenericgfpoly[1] = genericgfpoly2;
        return agenericgfpoly;
    }

    int evaluateAt(int i)
    {
        int j = 0;
        if(i != 0) goto _L2; else goto _L1
_L1:
        int l = getCoefficient(0);
_L4:
        return l;
_L2:
        int k;
        k = coefficients.length;
        if(i != 1)
            break; /* Loop/switch isn't completed */
        l = 0;
        int ai[] = coefficients;
        int j1 = ai.length;
        while(j < j1) 
        {
            l = GenericGF.addOrSubtract(l, ai[j]);
            j++;
        }
        if(true) goto _L4; else goto _L3
_L3:
        l = coefficients[0];
        int i1 = 1;
        while(i1 < k) 
        {
            l = GenericGF.addOrSubtract(field.multiply(i, l), coefficients[i1]);
            i1++;
        }
        if(true) goto _L4; else goto _L5
_L5:
    }

    int getCoefficient(int i)
    {
        return coefficients[(-1 + coefficients.length) - i];
    }

    int[] getCoefficients()
    {
        return coefficients;
    }

    int getDegree()
    {
        return -1 + coefficients.length;
    }

    boolean isZero()
    {
        boolean flag = false;
        if(coefficients[0] == 0)
            flag = true;
        return flag;
    }

    GenericGFPoly multiply(int i)
    {
        if(i != 0) goto _L2; else goto _L1
_L1:
        this = field.getZero();
_L4:
        return this;
_L2:
        if(i != 1)
        {
            int j = coefficients.length;
            int ai[] = new int[j];
            for(int k = 0; k < j; k++)
                ai[k] = field.multiply(coefficients[k], i);

            this = new GenericGFPoly(field, ai);
        }
        if(true) goto _L4; else goto _L3
_L3:
    }

    GenericGFPoly multiply(GenericGFPoly genericgfpoly)
    {
        if(!field.equals(genericgfpoly.field))
            throw new IllegalArgumentException("GenericGFPolys do not have same GenericGF field");
        GenericGFPoly genericgfpoly1;
        if(isZero() || genericgfpoly.isZero())
        {
            genericgfpoly1 = field.getZero();
        } else
        {
            int ai[] = coefficients;
            int i = ai.length;
            int ai1[] = genericgfpoly.coefficients;
            int j = ai1.length;
            int ai2[] = new int[-1 + (i + j)];
            for(int k = 0; k < i; k++)
            {
                int l = ai[k];
                for(int i1 = 0; i1 < j; i1++)
                    ai2[k + i1] = GenericGF.addOrSubtract(ai2[k + i1], field.multiply(l, ai1[i1]));

            }

            genericgfpoly1 = new GenericGFPoly(field, ai2);
        }
        return genericgfpoly1;
    }

    GenericGFPoly multiplyByMonomial(int i, int j)
    {
        if(i < 0)
            throw new IllegalArgumentException();
        GenericGFPoly genericgfpoly;
        if(j == 0)
        {
            genericgfpoly = field.getZero();
        } else
        {
            int k = coefficients.length;
            int ai[] = new int[k + i];
            for(int l = 0; l < k; l++)
                ai[l] = field.multiply(coefficients[l], j);

            genericgfpoly = new GenericGFPoly(field, ai);
        }
        return genericgfpoly;
    }

    public String toString()
    {
        StringBuilder stringbuilder = new StringBuilder(8 * getDegree());
        int i = getDegree();
        do
        {
            if(i >= 0)
            {
                int j = getCoefficient(i);
                if(j != 0)
                {
                    if(j < 0)
                    {
                        stringbuilder.append(" - ");
                        j = -j;
                    } else
                    if(stringbuilder.length() > 0)
                        stringbuilder.append(" + ");
                    if(i == 0 || j != 1)
                    {
                        int k = field.log(j);
                        if(k == 0)
                            stringbuilder.append('1');
                        else
                        if(k == 1)
                        {
                            stringbuilder.append('a');
                        } else
                        {
                            stringbuilder.append("a^");
                            stringbuilder.append(k);
                        }
                    }
                    if(i != 0)
                        if(i == 1)
                        {
                            stringbuilder.append('x');
                        } else
                        {
                            stringbuilder.append("x^");
                            stringbuilder.append(i);
                        }
                }
                i--;
                continue;
            }
            return stringbuilder.toString();
        } while(true);
    }
}
