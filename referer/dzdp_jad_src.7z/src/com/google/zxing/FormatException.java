// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.google.zxing;


// Referenced classes of package com.google.zxing:
//            ReaderException

public final class FormatException extends ReaderException
{

    private static final FormatException INSTANCE;

    private FormatException()
    {
    }

    private FormatException(Throwable throwable)
    {
        super(throwable);
    }

    public static FormatException getFormatInstance()
    {
        FormatException formatexception;
        if(isStackTrace)
            formatexception = new FormatException();
        else
            formatexception = INSTANCE;
        return formatexception;
    }

    public static FormatException getFormatInstance(Throwable throwable)
    {
        FormatException formatexception;
        if(isStackTrace)
            formatexception = new FormatException(throwable);
        else
            formatexception = INSTANCE;
        return formatexception;
    }

    static 
    {
        INSTANCE = new FormatException();
        INSTANCE.setStackTrace(NO_TRACE);
    }
}
