// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.alipay.mobilesecuritysdk.deviceID;

import HttpUtils.HttpFetcher;
import android.content.Context;
import android.os.Environment;
import com.alipay.mobilesecuritysdk.util.CommonUtils;
import java.io.File;
import java.io.IOException;
import java.util.*;
import org.apache.http.HttpResponse;
import org.apache.http.StatusLine;
import org.apache.http.util.EntityUtils;
import org.json.*;

// Referenced classes of package com.alipay.mobilesecuritysdk.deviceID:
//            DeviceMetaData, Profile, LOG, SecurityUtils, 
//            CollectDeviceInfo, IdResponseInfo

public class DeviceIdModel
{

    public static final String PREFS_NAME = "profiles";
    public static final String PRIVATE_NAME = "deviceid";
    public static final String SERVICEID = "deviceFingerprint";
    public static final String VER = "1";
    public static final String mApdtk = "apdtk";
    public static final String mAppId = "appId";
    public static final String mCheckCode = "checkcode";
    public static final String mDeviceId = "deviceId";
    public static final String mDeviceInfo = "deviceInfo";
    public static final String mPriDeviceId = "priDeviceId";
    public static final String mRule = "rule";
    public static final String mah1 = "AH1";
    public static final String mah10 = "AH10";
    public static final String mah2 = "AH2";
    public static final String mah3 = "AH3";
    public static final String mah4 = "AH4";
    public static final String mah5 = "AH5";
    public static final String mah6 = "AH6";
    public static final String mah7 = "AH7";
    public static final String mah8 = "AH8";
    public static final String mah9 = "AH9";
    public static final String mas1 = "AS1";
    public static final String mas2 = "AS2";
    public static final String mas3 = "AS3";
    public static final String mas4 = "AS4";
    public static final String mtid = "AC1";
    public static final String mtime = "time";
    public static final String mutdid = "AC2";
    private DeviceMetaData dv;
    private Profile profile;

    public DeviceIdModel()
    {
        dv = new DeviceMetaData();
        profile = new Profile();
    }

    private void Log(String s)
    {
        ArrayList arraylist = new ArrayList();
        if(CommonUtils.isBlank(dv.getMtid()))
            arraylist.add(dv.getMtid().substring(0, 20));
        if(CommonUtils.isBlank(dv.getMutdid()))
            arraylist.add(dv.getMutdid().substring(0, 20));
        if(CommonUtils.isBlank(dv.getMappId()))
            arraylist.add(dv.getMappId().substring(0, 20));
        arraylist.add(s);
        LOG.logMessage(arraylist);
    }

    private String getCheckCodeString()
    {
        if(!CommonUtils.isBlank(dv.getMrule())) goto _L2; else goto _L1
_L1:
        String s = null;
_L3:
        return s;
_L2:
        JSONArray jsonarray;
label0:
        {
            jsonarray = (new JSONObject(dv.getMrule())).getJSONArray("params");
            if(jsonarray != null)
                break label0;
            s = null;
        }
          goto _L3
        int i;
        s = new String();
        i = 0;
_L5:
        if(i == jsonarray.length()) goto _L3; else goto _L4
_L4:
        String s1;
        if(jsonarray.getString(i).equals("AC1"))
            if(!CommonUtils.isBlank(dv.getMtid()))
                s = (new StringBuilder(String.valueOf(s))).append(dv.getMtid()).toString();
            else
                s = (new StringBuilder(String.valueOf(s))).toString();
        if(jsonarray.getString(i).equals("AC2"))
            if(!CommonUtils.isBlank(dv.getMutdid()))
                s = (new StringBuilder(String.valueOf(s))).append(dv.getMutdid()).toString();
            else
                s = (new StringBuilder(String.valueOf(s))).toString();
        if(jsonarray.getString(i).equals("AH1"))
            if(!CommonUtils.isBlank(dv.getMah1()))
                s = (new StringBuilder(String.valueOf(s))).append(dv.getMah1()).toString();
            else
                s = (new StringBuilder(String.valueOf(s))).toString();
        if(jsonarray.getString(i).equals("AH2"))
            if(!CommonUtils.isBlank(dv.getMah2()))
                s = (new StringBuilder(String.valueOf(s))).append(dv.getMah2()).toString();
            else
                s = (new StringBuilder(String.valueOf(s))).toString();
        if(jsonarray.getString(i).equals("AH3"))
            if(!CommonUtils.isBlank(dv.getMah3()))
                s = (new StringBuilder(String.valueOf(s))).append(dv.getMah3()).toString();
            else
                s = (new StringBuilder(String.valueOf(s))).toString();
        if(jsonarray.getString(i).equals("AH4"))
            if(!CommonUtils.isBlank(dv.getMah4()))
                s = (new StringBuilder(String.valueOf(s))).append(dv.getMah4()).toString();
            else
                s = (new StringBuilder(String.valueOf(s))).toString();
        if(jsonarray.getString(i).equals("AH5"))
            if(!CommonUtils.isBlank(dv.getMah5()))
                s = (new StringBuilder(String.valueOf(s))).append(dv.getMah5()).toString();
            else
                s = (new StringBuilder(String.valueOf(s))).toString();
        if(jsonarray.getString(i).equals("AH6"))
            if(!CommonUtils.isBlank(dv.getMah6()))
                s = (new StringBuilder(String.valueOf(s))).append(dv.getMah6()).toString();
            else
                s = (new StringBuilder(String.valueOf(s))).toString();
        if(jsonarray.getString(i).equals("AH7"))
            if(!CommonUtils.isBlank(dv.getMah7()))
                s = (new StringBuilder(String.valueOf(s))).append(dv.getMah7()).toString();
            else
                s = (new StringBuilder(String.valueOf(s))).toString();
        if(jsonarray.getString(i).equals("AH8"))
            if(!CommonUtils.isBlank(dv.getMah8()))
                s = (new StringBuilder(String.valueOf(s))).append(dv.getMah8()).toString();
            else
                s = (new StringBuilder(String.valueOf(s))).toString();
        if(jsonarray.getString(i).equals("AH9"))
            if(!CommonUtils.isBlank(dv.getMah9()))
                s = (new StringBuilder(String.valueOf(s))).append(dv.getMah9()).toString();
            else
                s = (new StringBuilder(String.valueOf(s))).toString();
        if(jsonarray.getString(i).equals("AH10"))
            if(!CommonUtils.isBlank(dv.getMah10()))
                s = (new StringBuilder(String.valueOf(s))).append(dv.getMah10()).toString();
            else
                s = (new StringBuilder(String.valueOf(s))).toString();
        if(jsonarray.getString(i).equals("AS1"))
            if(!CommonUtils.isBlank(dv.getMas1()))
                s = (new StringBuilder(String.valueOf(s))).append(dv.getMas1()).toString();
            else
                s = (new StringBuilder(String.valueOf(s))).toString();
        if(jsonarray.getString(i).equals("AS2"))
            if(!CommonUtils.isBlank(dv.getMas2()))
                s = (new StringBuilder(String.valueOf(s))).append(dv.getMas2()).toString();
            else
                s = (new StringBuilder(String.valueOf(s))).toString();
        if(jsonarray.getString(i).equals("AS3"))
            if(!CommonUtils.isBlank(dv.getMas3()))
                s = (new StringBuilder(String.valueOf(s))).append(dv.getMas3()).toString();
            else
                s = (new StringBuilder(String.valueOf(s))).toString();
        if(!jsonarray.getString(i).equals("AS4"))
            break MISSING_BLOCK_LABEL_1207;
        if(!CommonUtils.isBlank(dv.getMas4()))
        {
            s = (new StringBuilder(String.valueOf(s))).append(dv.getMas4()).toString();
            break MISSING_BLOCK_LABEL_1207;
        }
        s1 = (new StringBuilder(String.valueOf(s))).toString();
        s = s1;
        break MISSING_BLOCK_LABEL_1207;
        JSONException jsonexception;
        jsonexception;
        Log(LOG.getStackString(jsonexception));
        s = null;
          goto _L3
        i++;
          goto _L5
    }

    private boolean hasDataInSdcard()
    {
        boolean flag;
        flag = false;
        break MISSING_BLOCK_LABEL_2;
        if(!CommonUtils.isBlank(readDataFromSdCard()) && readDataFromSdCard().length() > 0)
            flag = true;
        return flag;
    }

    private boolean hasDataInSettings()
    {
        boolean flag;
        flag = false;
        break MISSING_BLOCK_LABEL_2;
        if(!CommonUtils.isBlank(readDataFromSettings()) && readDataFromSettings().length() > 0)
            flag = true;
        return flag;
    }

    public boolean CheckPrivateData(Map map)
    {
        boolean flag;
        flag = false;
        break MISSING_BLOCK_LABEL_2;
        if(map != null && map.size() >= 0 && map.containsKey("deviceId") && map.containsKey("checkcode") && map.containsKey("apdtk") && map.containsKey("time") && map.containsKey("rule"))
            flag = true;
        return flag;
    }

    public Map GetLocalInfo()
    {
        HashMap hashmap = new HashMap();
        hashmap.put("deviceId", dv.getMdeviceId());
        hashmap.put("priDeviceId", dv.getMpriDeviceId());
        hashmap.put("appId", dv.getMappId());
        hashmap.put("time", dv.getMtime());
        hashmap.put("apdtk", dv.getMapdtk());
        return hashmap;
    }

    public Map GetPrivateData(Context context)
    {
        Map map;
        String s;
        map = null;
        s = profile.GetDataFromSharedPre(context.getSharedPreferences("profiles", 0), "deviceid");
        if(!CommonUtils.isBlank(s)) goto _L2; else goto _L1
_L1:
        return map;
_L2:
        String s1 = SecurityUtils.decrypt(SecurityUtils.getSeed(), s);
        if(!CommonUtils.isBlank(s1))
            map = (new Profile()).getMap(s1);
        if(true) goto _L1; else goto _L3
_L3:
    }

    public Map GetShareData(Context context)
    {
        return null;
    }

    public Map GetUploadInfo()
    {
        HashMap hashmap = new HashMap();
        HashMap hashmap1 = new HashMap();
        if(!CommonUtils.isBlank(dv.getMah1()))
            hashmap1.put("AH1", dv.getMah1());
        else
            hashmap1.put("AH1", "");
        if(!CommonUtils.isBlank(dv.getMah2()))
            hashmap1.put("AH2", dv.getMah2());
        else
            hashmap1.put("AH2", "");
        if(!CommonUtils.isBlank(dv.getMah3()))
            hashmap1.put("AH3", dv.getMah3());
        else
            hashmap1.put("AH3", "");
        if(!CommonUtils.isBlank(dv.getMah4()))
            hashmap1.put("AH4", dv.getMah4());
        else
            hashmap1.put("AH4", "");
        if(!CommonUtils.isBlank(dv.getMah5()))
            hashmap1.put("AH5", dv.getMah5());
        else
            hashmap1.put("AH4", "");
        if(!CommonUtils.isBlank(dv.getMah6()))
            hashmap1.put("AH6", dv.getMah6());
        else
            hashmap1.put("AH6", "");
        if(!CommonUtils.isBlank(dv.getMah7()))
            hashmap1.put("AH7", dv.getMah7());
        else
            hashmap1.put("AH7", "");
        if(!CommonUtils.isBlank(dv.getMah8()))
            hashmap1.put("AH8", dv.getMah8());
        else
            hashmap1.put("AH8", "");
        if(!CommonUtils.isBlank(dv.getMah9()))
            hashmap1.put("AH9", dv.getMah9());
        else
            hashmap1.put("AH9", "");
        if(!CommonUtils.isBlank(dv.getMah10()))
            hashmap1.put("AH10", dv.getMah10());
        else
            hashmap1.put("AH10", "");
        if(!CommonUtils.isBlank(dv.getMas1()))
            hashmap1.put("AS1", dv.getMas1());
        else
            hashmap1.put("AS1", "");
        if(!CommonUtils.isBlank(dv.getMas2()))
            hashmap1.put("AS2", dv.getMas2());
        else
            hashmap1.put("AS2", "");
        if(!CommonUtils.isBlank(dv.getMas3()))
            hashmap1.put("AS3", dv.getMas3());
        else
            hashmap1.put("AS3", "");
        if(!CommonUtils.isBlank(dv.getMas4()))
            hashmap1.put("AS4", dv.getMas4());
        else
            hashmap1.put("AS4", "");
        if(!CommonUtils.isBlank(dv.getMtid()))
            hashmap1.put("AC1", dv.getMtid());
        else
            hashmap1.put("AC1", "");
        if(!CommonUtils.isBlank(dv.getMutdid()))
            hashmap1.put("AC2", dv.getMutdid());
        else
            hashmap1.put("AC2", "");
        hashmap.put("deviceInfo", hashmap1);
        if(!CommonUtils.isBlank(dv.getMdeviceId()))
            hashmap.put("deviceId", dv.getMdeviceId());
        if(!CommonUtils.isBlank(dv.getMpriDeviceId()))
            hashmap.put("priDeviceId", dv.getMpriDeviceId());
        if(!CommonUtils.isBlank(dv.getMappId()))
            hashmap.put("appId", dv.getMappId());
        if(!CommonUtils.isBlank(dv.getMtime()))
            hashmap.put("time", dv.getMtime());
        if(!CommonUtils.isBlank(dv.getMapdtk()))
            hashmap.put("apdtk", dv.getMapdtk());
        return hashmap;
    }

    public void Init(Context context, Map map)
    {
        CollectDeviceInfo collectdeviceinfo;
        collectdeviceinfo = CollectDeviceInfo.getInstance();
        LOG.init(context);
        if(map == null)
            break MISSING_BLOCK_LABEL_95;
        if(map.size() > 0)
        {
            if(!CommonUtils.isBlank((String)map.get("tid")))
                dv.setMtid((String)map.get("tid"));
            if(!CommonUtils.isBlank((String)map.get("utdid")))
                dv.setMutdid((String)map.get("utdid"));
        }
        if(!CommonUtils.isBlank(collectdeviceinfo.getImei(context)))
            dv.setMah1(collectdeviceinfo.getImei(context));
        if(!CommonUtils.isBlank(collectdeviceinfo.getImsi(context)))
            dv.setMah2(collectdeviceinfo.getImsi(context));
        if(!CommonUtils.isBlank(collectdeviceinfo.getMacAddress(context)))
            dv.setMah3(collectdeviceinfo.getMacAddress(context));
        if(!CommonUtils.isBlank(collectdeviceinfo.getCpuFre()))
            dv.setMah4(collectdeviceinfo.getCpuFre());
        if(!CommonUtils.isBlank(collectdeviceinfo.getCpuNum()))
            dv.setMah5(collectdeviceinfo.getCpuNum());
        if(!CommonUtils.isBlank(collectdeviceinfo.getBluMac()))
            dv.setMah6(collectdeviceinfo.getBluMac());
        if(!CommonUtils.isBlank(Long.toString(collectdeviceinfo.getTotalMemory())))
            dv.setMah7(Long.toString(collectdeviceinfo.getTotalMemory()));
        if(!CommonUtils.isBlank(Long.toString(collectdeviceinfo.getSDCardMemory())))
            dv.setMah8(Long.toString(collectdeviceinfo.getSDCardMemory()));
        if(!CommonUtils.isBlank(collectdeviceinfo.getDeviceMx(context)))
            dv.setMah9(collectdeviceinfo.getDeviceMx(context));
        if(!CommonUtils.isBlank(collectdeviceinfo.getPhoneModel()))
            dv.setMah10(collectdeviceinfo.getPhoneModel());
        if(!CommonUtils.isBlank(collectdeviceinfo.getRomName()))
            dv.setMas1(collectdeviceinfo.getRomName());
        if(!CommonUtils.isBlank(collectdeviceinfo.getSDKVer()))
            dv.setMas2(collectdeviceinfo.getSDKVer());
        if(!CommonUtils.isBlank(collectdeviceinfo.getBandVer()))
            dv.setMas3(collectdeviceinfo.getBandVer());
        if(!CommonUtils.isBlank(collectdeviceinfo.getOsVer()))
            dv.setMas4(collectdeviceinfo.getOsVer());
        if(!CommonUtils.isBlank(collectdeviceinfo.getPackageName(context)))
            dv.setMappId(collectdeviceinfo.getPackageName(context));
        Map map1 = GetPrivateData(context);
        if(map1 != null && map1.size() > 0)
        {
            if(!CommonUtils.isBlank((String)map1.get("apdtk")))
                dv.setMapdtk((String)map1.get("apdtk"));
            if(!CommonUtils.isBlank((String)map1.get("deviceId")))
                dv.setMpriDeviceId((String)map1.get("deviceId"));
            if(!CommonUtils.isBlank((String)map1.get("time")))
                dv.setMtime((String)map1.get("time"));
            if(!CommonUtils.isBlank((String)map1.get("rule")))
                dv.setMrule((String)map1.get("rule"));
        }
        if(!CommonUtils.isBlank(readDataFromSettings()) && readDataFromSettings().length() > 32)
            dv.setMdeviceId(readDataFromSettings().substring(0, 32));
        else
        if(!CommonUtils.isBlank(readDataFromSdCard()) && readDataFromSdCard().length() > 32)
            dv.setMdeviceId(readDataFromSdCard().substring(0, 32));
        break MISSING_BLOCK_LABEL_697;
        Exception exception;
        exception;
        Log(LOG.getStackString(exception));
    }

    public String UpdateId(Context context)
    {
        IdResponseInfo idresponseinfo = UploadData(context);
        if(idresponseinfo == null) goto _L2; else goto _L1
_L1:
        if(!idresponseinfo.isMsuccess()) goto _L2; else goto _L3
_L3:
        String s1;
        HashMap hashmap;
        Profile profile1;
        s1 = (new StringBuilder(String.valueOf(idresponseinfo.getMapdid()))).append(idresponseinfo.getMtime()).toString();
        hashmap = new HashMap();
        hashmap.put("deviceId", idresponseinfo.getMapdid());
        hashmap.put("priDeviceId", idresponseinfo.getMapdid());
        hashmap.put("time", idresponseinfo.getMtime());
        hashmap.put("checkcode", idresponseinfo.getMcheckcode());
        hashmap.put("rule", idresponseinfo.getMrule());
        hashmap.put("apdtk", idresponseinfo.getMapdtk());
        profile1 = new Profile();
        String s;
        Exception exception;
        String s2;
        try
        {
            WritePrivateData(context, profile1.generatePrivateData(hashmap));
        }
        catch(JSONException jsonexception) { }
        WriteDataToSettings(s1);
        WriteDataToSdCard(s1);
        s2 = idresponseinfo.getMapdid();
        s = s2;
_L5:
        return s;
        exception;
        Log(LOG.getStackString(exception));
_L2:
        s = null;
        if(true) goto _L5; else goto _L4
_L4:
    }

    public String UpdateId(Context context, Map map)
    {
        if(map != null) goto _L2; else goto _L1
_L1:
        String s = UpdateId(context);
_L4:
        return s;
_L2:
        boolean flag = hasInPublic();
        if(CheckPrivateData(map))
        {
            if(!flag && !CommonUtils.isBlank((String)map.get("priDeviceId")) && !CommonUtils.isBlank((String)map.get("time")))
            {
                String s3 = (new StringBuilder(String.valueOf((String)map.get("priDeviceId")))).append((String)map.get("time")).toString();
                WriteDataToSettings(s3);
                WriteDataToSdCard(s3);
            }
            String s1 = (String)map.get("checkcode");
            String s2 = generaterCheckCode();
            if(checkApdid() && checkCheckCode(s1, s2))
            {
                s = (String)map.get("apdid");
                continue; /* Loop/switch isn't completed */
            }
        }
        s = UpdateId(context);
        if(true) goto _L4; else goto _L3
_L3:
    }

    public IdResponseInfo UploadData(Context context)
    {
        IdResponseInfo idresponseinfo = new IdResponseInfo();
        idresponseinfo.setMsuccess(false);
        String s = profile.generateUploadData(GetUploadInfo());
        if(s != null && s.length() >= 0)
            try
            {
                HttpResponse httpresponse = (new HttpFetcher()).uploadCollectedData(context, "https://seccliprod.alipay.com/api/do.htm", "deviceFingerprint", s, "1", false);
                if(httpresponse != null && httpresponse.getStatusLine().getStatusCode() == 200)
                    idresponseinfo = (new Profile()).ParseResponse(EntityUtils.toString(httpresponse.getEntity()));
                else
                    idresponseinfo.setMsuccess(false);
            }
            catch(IOException ioexception)
            {
                Log(LOG.getStackString(ioexception));
            }
        return idresponseinfo;
    }

    public void WriteDataToSdCard(String s)
    {
        if(!CommonUtils.GetSdCardFile()) goto _L2; else goto _L1
_L1:
        String s1;
        File file;
        s1 = SecurityUtils.encrypt(SecurityUtils.getSeed(), s);
        file = new File(Environment.getExternalStorageDirectory(), ".SystemConfig");
        if(file == null) goto _L2; else goto _L3
_L3:
        JSONObject jsonobject;
        if(!file.exists())
            file.mkdir();
        jsonobject = new JSONObject();
        jsonobject.put("device", s1);
_L4:
        CommonUtils.WriteFile((new StringBuilder(String.valueOf(file.getAbsolutePath()))).append(File.separator).append("data").toString(), jsonobject.toString());
_L2:
        return;
        JSONException jsonexception;
        jsonexception;
        Exception exception;
        Log(LOG.getStackString(jsonexception));
          goto _L4
        IOException ioexception;
        ioexception;
        try
        {
            Log(LOG.getStackString(ioexception));
        }
        // Misplaced declaration of an exception variable
        catch(Exception exception)
        {
            Log(LOG.getStackString(exception));
        }
          goto _L2
    }

    public void WriteDataToSettings(String s)
    {
        if(!CommonUtils.isBlank(s)) goto _L2; else goto _L1
_L1:
        return;
_L2:
        String s1 = SecurityUtils.encrypt(SecurityUtils.getSeed(), s);
        if(!CommonUtils.isBlank(s1))
            try
            {
                JSONObject jsonobject = new JSONObject();
                jsonobject.put("device", s1);
                System.setProperty("deviceid", jsonobject.toString());
            }
            catch(JSONException jsonexception)
            {
                Log(LOG.getStackString(jsonexception));
            }
        if(true) goto _L1; else goto _L3
_L3:
    }

    public void WritePrivateData(Context context, String s)
    {
        String s1 = SecurityUtils.encrypt(SecurityUtils.getSeed(), s);
        if(!CommonUtils.isBlank(s1))
        {
            HashMap hashmap = new HashMap();
            hashmap.put("deviceid", s1);
            profile.SetDataToSharePre(context.getSharedPreferences("profiles", 0), hashmap);
        }
    }

    public boolean checkApdid()
    {
        boolean flag;
        String s;
        String s1;
        flag = false;
        s = readDataFromSettings();
        s1 = readDataFromSdCard();
        if(CommonUtils.isBlank(s)) goto _L2; else goto _L1
_L1:
        flag = dv.getMpriDeviceId().equals(s.substring(0, 32));
_L4:
        return flag;
_L2:
        if(!CommonUtils.isBlank(s1))
            flag = dv.getMpriDeviceId().equals(s1.subSequence(0, 32));
        if(true) goto _L4; else goto _L3
_L3:
    }

    public boolean checkCheckCode(String s, String s1)
    {
        boolean flag;
        if(s == null || s1 == null)
            flag = false;
        else
            flag = s.equals(s1);
        return flag;
    }

    public String generaterCheckCode()
    {
        String s = getCheckCodeString();
        if(s == null)
            s = "";
        String s1 = CommonUtils.MD5(s);
        if(s1 == null)
            s1 = "";
        return s1;
    }

    public boolean hasInPublic()
    {
        boolean flag;
        if(hasDataInSettings() && hasDataInSdcard())
            flag = true;
        else
            flag = false;
        return flag;
    }

    public String readDataFromSdCard()
    {
        String s = null;
        if(!CommonUtils.GetSdCardFile()) goto _L2; else goto _L1
_L1:
        String s1;
        boolean flag;
        File file = new File(Environment.getExternalStorageDirectory(), ".SystemConfig");
        if(file != null && !file.exists())
            file.mkdir();
        s1 = CommonUtils.ReadFile((new StringBuilder(String.valueOf(file.getAbsolutePath()))).append(File.separator).append("data").toString());
        flag = CommonUtils.isBlank(s1);
        if(!flag) goto _L3; else goto _L2
_L2:
        return s;
_L3:
        String s2 = null;
        String s3 = (new JSONObject(s1)).getString("device");
        s2 = s3;
_L5:
        if(!CommonUtils.isBlank(s2))
            s = SecurityUtils.decrypt(SecurityUtils.getSeed(), s2);
        continue; /* Loop/switch isn't completed */
        JSONException jsonexception;
        jsonexception;
        Log(LOG.getStackString(jsonexception));
        if(true) goto _L5; else goto _L4
_L4:
        Exception exception;
        exception;
        Log(LOG.getStackString(exception));
        if(true) goto _L2; else goto _L6
_L6:
    }

    public String readDataFromSettings()
    {
        String s;
        String s2;
        s = System.getProperty("deviceid");
        if(CommonUtils.isBlank(s))
            break MISSING_BLOCK_LABEL_65;
        s2 = null;
        String s3 = (new JSONObject(s)).getString("device");
        s2 = s3;
_L1:
        String s1;
        if(CommonUtils.isBlank(s2))
            break MISSING_BLOCK_LABEL_65;
        s1 = SecurityUtils.decrypt(SecurityUtils.getSeed(), s2);
_L2:
        return s1;
        JSONException jsonexception;
        jsonexception;
        Log(LOG.getStackString(jsonexception));
          goto _L1
        s1 = null;
          goto _L2
    }
}
