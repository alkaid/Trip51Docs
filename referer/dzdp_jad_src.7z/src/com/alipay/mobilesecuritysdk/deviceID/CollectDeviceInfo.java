// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.alipay.mobilesecuritysdk.deviceID;

import android.bluetooth.BluetoothAdapter;
import android.content.Context;
import android.content.res.Resources;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.*;
import android.telephony.TelephonyManager;
import android.util.DisplayMetrics;
import android.util.Log;
import java.io.*;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class CollectDeviceInfo
{

    private static CollectDeviceInfo collectSingleton = new CollectDeviceInfo();

    private CollectDeviceInfo()
    {
    }

    public static CollectDeviceInfo getInstance()
    {
        return collectSingleton;
    }

    public String getBandVer()
    {
        String s = null;
        try
        {
            Class class1 = Class.forName("android.os.SystemProperties");
            Object obj = class1.newInstance();
            Class aclass[] = new Class[2];
            aclass[0] = java/lang/String;
            aclass[1] = java/lang/String;
            Method method = class1.getMethod("get", aclass);
            Object aobj[] = new Object[2];
            aobj[0] = "gsm.version.baseband";
            aobj[1] = "no message";
            s = (String)method.invoke(obj, aobj);
        }
        catch(Exception exception) { }
        return s;
    }

    public String getBluMac()
    {
        BluetoothAdapter bluetoothadapter = BluetoothAdapter.getDefaultAdapter();
        if(bluetoothadapter == null) goto _L2; else goto _L1
_L1:
        boolean flag = bluetoothadapter.isEnabled();
        if(flag) goto _L2; else goto _L3
_L3:
        String s = "";
_L5:
        return s;
_L2:
        String s1 = bluetoothadapter.getAddress();
        s = s1;
        continue; /* Loop/switch isn't completed */
        Exception exception;
        exception;
        s = null;
        if(true) goto _L5; else goto _L4
_L4:
    }

    public String getCpuFre()
    {
        String as[];
        as = new String[2];
        as[0] = "";
        as[1] = "";
        BufferedReader bufferedreader;
        String as1[];
        int i;
        bufferedreader = new BufferedReader(new FileReader("/proc/cpuinfo"), 8192);
        as1 = bufferedreader.readLine().split("\\s+");
        i = 2;
_L1:
        String s;
        if(i >= as1.length)
        {
            String as2[] = bufferedreader.readLine().split("\\s+");
            as[1] = (new StringBuilder(String.valueOf(as[1]))).append(as2[2]).toString();
            bufferedreader.close();
            s = as[1];
            break MISSING_BLOCK_LABEL_148;
        }
        as[0] = (new StringBuilder(String.valueOf(as[0]))).append(as1[i]).append(" ").toString();
        i++;
          goto _L1
        IOException ioexception;
        ioexception;
        s = null;
        return s;
    }

    public String getCpuNum()
    {
        String s = "";
        FileReader filereader = new FileReader("/proc/cpuinfo");
        if(filereader == null)
            break MISSING_BLOCK_LABEL_45;
        BufferedReader bufferedreader = new BufferedReader(filereader, 1024);
        s = bufferedreader.readLine();
        bufferedreader.close();
        filereader.close();
_L1:
        IOException ioexception;
        String s1;
        if(s != null)
            s1 = s.substring(1 + s.indexOf(':')).trim();
        else
            s1 = "";
        return s1;
        ioexception;
_L2:
        FileNotFoundException filenotfoundexception2;
        try
        {
            Log.i("deviceid", (new StringBuilder("getCpuNum")).append(ioexception.getLocalizedMessage()).toString());
        }
        catch(FileNotFoundException filenotfoundexception) { }
          goto _L1
        filenotfoundexception2;
          goto _L1
        FileNotFoundException filenotfoundexception1;
        filenotfoundexception1;
          goto _L1
        ioexception;
          goto _L2
    }

    public String getDeviceMx(Context context)
    {
        String s1;
        DisplayMetrics displaymetrics = context.getResources().getDisplayMetrics();
        s1 = (new StringBuilder(String.valueOf(Integer.toString(displaymetrics.widthPixels)))).append("*").append(Integer.toString(displaymetrics.heightPixels)).toString();
        String s = s1;
_L2:
        return s;
        Exception exception;
        exception;
        s = null;
        if(true) goto _L2; else goto _L1
_L1:
    }

    public String getImei(Context context)
    {
        String s;
        s = null;
        if(context == null)
            break MISSING_BLOCK_LABEL_32;
        String s1;
        TelephonyManager telephonymanager = (TelephonyManager)context.getSystemService("phone");
        if(telephonymanager == null)
            break MISSING_BLOCK_LABEL_32;
        s1 = telephonymanager.getDeviceId();
        s = s1;
_L2:
        return s;
        Exception exception;
        exception;
        if(true) goto _L2; else goto _L1
_L1:
    }

    public String getImsi(Context context)
    {
        String s;
        s = null;
        if(context == null)
            break MISSING_BLOCK_LABEL_32;
        String s1;
        TelephonyManager telephonymanager = (TelephonyManager)context.getSystemService("phone");
        if(telephonymanager == null)
            break MISSING_BLOCK_LABEL_32;
        s1 = telephonymanager.getSubscriberId();
        s = s1;
_L2:
        return s;
        Exception exception;
        exception;
        if(true) goto _L2; else goto _L1
_L1:
    }

    public String getMacAddress(Context context)
    {
        return ((WifiManager)context.getSystemService("wifi")).getConnectionInfo().getMacAddress();
    }

    public String getNetworkType(Context context)
    {
        return Integer.toString(((TelephonyManager)context.getSystemService("phone")).getNetworkType());
    }

    public String getOsVer()
    {
        return android.os.Build.VERSION.RELEASE;
    }

    public String getPackageName(Context context)
    {
        return context.getPackageName();
    }

    public String getPhoneModel()
    {
        return Build.MODEL;
    }

    public String getResolution(Context context)
    {
        return context.getResources().getDisplayMetrics().toString();
    }

    public String getRomName()
    {
        return Build.DISPLAY;
    }

    public long getSDCardMemory()
    {
        long al[] = new long[2];
        try
        {
            if("mounted".equals(Environment.getExternalStorageState()))
            {
                StatFs statfs = new StatFs(Environment.getExternalStorageDirectory().getPath());
                long l = statfs.getBlockSize();
                long l1 = statfs.getBlockCount();
                long l2 = statfs.getAvailableBlocks();
                al[0] = l * l1;
                al[1] = l * l2;
            }
        }
        catch(Exception exception) { }
        return al[0];
    }

    public String getSDKVer()
    {
        int k = android/os/Build$VERSION.getField("SDK_INT").getInt(null);
        int i = k;
_L2:
        return Integer.toString(i);
        Exception exception;
        exception;
        int j = Integer.parseInt((String)android/os/Build$VERSION.getField("SDK").get(null));
        i = j;
        continue; /* Loop/switch isn't completed */
        Exception exception1;
        exception1;
        i = 2;
        if(true) goto _L2; else goto _L1
_L1:
    }

    public long getTotalMemory()
    {
        long l = 0L;
        try
        {
            BufferedReader bufferedreader = new BufferedReader(new FileReader("/proc/meminfo"), 8192);
            l = Integer.valueOf(bufferedreader.readLine().split("\\s+")[1]).intValue();
            bufferedreader.close();
        }
        catch(IOException ioexception)
        {
            Log.i("deviceid", (new StringBuilder("getTotalMemory")).append(ioexception.getLocalizedMessage()).toString());
        }
        return l;
    }

}
