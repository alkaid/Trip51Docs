// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.alipay.mobilesecuritysdk.deviceID;

import android.content.Context;
import java.util.*;

// Referenced classes of package com.alipay.mobilesecuritysdk.deviceID:
//            LOG, DeviceIdModel

public class DeviceIdManager
{

    public static Map strMap = null;
    private final Context mcontext;

    public DeviceIdManager(Context context)
    {
        mcontext = context;
        LOG.init(context);
    }

    /**
     * @deprecated Method Update is deprecated
     */

    private void Update(final Context context, final Map args)
    {
        this;
        JVM INSTR monitorenter ;
        (new Thread(new Runnable() {

            final DeviceIdManager this$0;
            private final Map val$args;
            private final Context val$context;

            public void run()
            {
                DeviceIdModel deviceidmodel = new DeviceIdModel();
                deviceidmodel.Init(context, args);
                deviceidmodel.UpdateId(context, DeviceIdManager.strMap);
_L1:
                return;
                Throwable throwable;
                throwable;
                ArrayList arraylist = new ArrayList();
                if(args.get("tid") != null && ((String)args.get("tid")).length() > 20)
                    arraylist.add(((String)args.get("tid")).substring(0, 20));
                if(args.get("utdid") != null && ((String)args.get("utdid")).length() > 20)
                    arraylist.add(((String)args.get("utdid")).substring(0, 20));
                arraylist.add(LOG.getStackString(throwable));
                LOG.logMessage(arraylist);
                  goto _L1
            }

            
            {
                this$0 = DeviceIdManager.this;
                context = context1;
                args = map;
                super();
            }
        }
)).start();
        this;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    private void UpdateLog()
    {
        (new Thread(new Runnable() {

            final DeviceIdManager this$0;

            public void run()
            {
                LOG.uploadLogFile();
_L1:
                return;
                Throwable throwable;
                throwable;
                ArrayList arraylist = new ArrayList();
                arraylist.add("");
                arraylist.add("");
                arraylist.add("");
                arraylist.add(LOG.getStackString(throwable));
                LOG.logMessage(arraylist);
                  goto _L1
            }

            
            {
                this$0 = DeviceIdManager.this;
                super();
            }
        }
)).start();
    }

    public String GetApDid(Map map)
    {
        String s;
        s = null;
        UpdateLog();
        DeviceIdModel deviceidmodel;
        deviceidmodel = new DeviceIdModel();
        strMap = deviceidmodel.GetPrivateData(mcontext);
        if(strMap != null) goto _L2; else goto _L1
_L1:
        String s1;
        ArrayList arraylist1 = new ArrayList();
        if(map.get("tid") != null && ((String)map.get("tid")).length() > 20)
            arraylist1.add(((String)map.get("tid")).substring(0, 20));
        if(map.get("utdid") != null && ((String)map.get("utdid")).length() > 20)
            arraylist1.add(((String)map.get("utdid")).substring(0, 20));
        arraylist1.add("model.GetPrivateData(mcontext)  strMap is null");
        LOG.logMessage(arraylist1);
        Update(mcontext, map);
        s1 = null;
          goto _L3
_L2:
        if(deviceidmodel.CheckPrivateData(strMap))
        {
            s = (String)strMap.get("deviceId");
            ArrayList arraylist2 = new ArrayList();
            if(map.get("tid") != null && ((String)map.get("tid")).length() > 20)
                arraylist2.add(((String)map.get("tid")).substring(0, 20));
            if(map.get("utdid") != null && ((String)map.get("utdid")).length() > 20)
                arraylist2.add(((String)map.get("utdid")).substring(0, 20));
            arraylist2.add((new StringBuilder("GetApDid  deviceID is ")).append(s).toString());
            LOG.logMessage(arraylist2);
        }
        Update(mcontext, map);
_L4:
        s1 = s;
        break; /* Loop/switch isn't completed */
        Exception exception;
        exception;
        ArrayList arraylist = new ArrayList();
        if(map.get("tid") != null && ((String)map.get("tid")).length() > 20)
            arraylist.add(((String)map.get("tid")).substring(0, 20));
        if(map.get("utdid") != null && ((String)map.get("utdid")).length() > 20)
            arraylist.add(((String)map.get("utdid")).substring(0, 20));
        arraylist.add(LOG.getStackString(exception));
        LOG.logMessage(arraylist);
        if(true) goto _L4; else goto _L3
_L3:
        return s1;
    }

}
