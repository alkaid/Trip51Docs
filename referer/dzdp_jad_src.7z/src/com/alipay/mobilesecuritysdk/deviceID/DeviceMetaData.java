// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.alipay.mobilesecuritysdk.deviceID;

import android.provider.BaseColumns;

public class DeviceMetaData
    implements BaseColumns
{

    public static final String AUTH = "content://com.alipay.mobilesecuritysdk.deviceID.DeviceContentProvider";
    public static final String DATABASE_NAME = "device.db";
    public static final int DATABASE_VER = 1;
    public static final String DEVICE_TABLE_NAME = "devices";
    private String mah1;
    private String mah10;
    private String mah2;
    private String mah3;
    private String mah4;
    private String mah5;
    private String mah6;
    private String mah7;
    private String mah8;
    private String mah9;
    private String mapdtk;
    private String mappId;
    private String mas1;
    private String mas2;
    private String mas3;
    private String mas4;
    private String mcheckCode;
    private String mdeviceId;
    private String mpriDeviceId;
    private String mrule;
    private String mtid;
    private String mtime;
    private String mutdid;

    public DeviceMetaData()
    {
        mah1 = null;
        mah2 = null;
        mah3 = null;
        mah4 = null;
        mah5 = null;
        mah6 = null;
        mah7 = null;
        mah8 = null;
        mah9 = null;
        mah10 = null;
        mas1 = null;
        mas2 = null;
        mas3 = null;
        mas4 = null;
        mtime = null;
        mtid = null;
        mutdid = null;
        mappId = null;
    }

    public String getMah1()
    {
        return mah1;
    }

    public String getMah10()
    {
        return mah10;
    }

    public String getMah2()
    {
        return mah2;
    }

    public String getMah3()
    {
        return mah3;
    }

    public String getMah4()
    {
        return mah4;
    }

    public String getMah5()
    {
        return mah5;
    }

    public String getMah6()
    {
        return mah6;
    }

    public String getMah7()
    {
        return mah7;
    }

    public String getMah8()
    {
        return mah8;
    }

    public String getMah9()
    {
        return mah9;
    }

    public String getMapdtk()
    {
        return mapdtk;
    }

    public String getMappId()
    {
        return mappId;
    }

    public String getMas1()
    {
        return mas1;
    }

    public String getMas2()
    {
        return mas2;
    }

    public String getMas3()
    {
        return mas3;
    }

    public String getMas4()
    {
        return mas4;
    }

    public String getMcheckCode()
    {
        return mcheckCode;
    }

    public String getMdeviceId()
    {
        return mdeviceId;
    }

    public String getMpriDeviceId()
    {
        return mpriDeviceId;
    }

    public String getMrule()
    {
        return mrule;
    }

    public String getMtid()
    {
        return mtid;
    }

    public String getMtime()
    {
        return mtime;
    }

    public String getMutdid()
    {
        return mutdid;
    }

    public void setMah1(String s)
    {
        mah1 = s;
    }

    public void setMah10(String s)
    {
        mah10 = s;
    }

    public void setMah2(String s)
    {
        mah2 = s;
    }

    public void setMah3(String s)
    {
        mah3 = s;
    }

    public void setMah4(String s)
    {
        mah4 = s;
    }

    public void setMah5(String s)
    {
        mah5 = s;
    }

    public void setMah6(String s)
    {
        mah6 = s;
    }

    public void setMah7(String s)
    {
        mah7 = s;
    }

    public void setMah8(String s)
    {
        mah8 = s;
    }

    public void setMah9(String s)
    {
        mah9 = s;
    }

    public void setMapdtk(String s)
    {
        mapdtk = s;
    }

    public void setMappId(String s)
    {
        mappId = s;
    }

    public void setMas1(String s)
    {
        mas1 = s;
    }

    public void setMas2(String s)
    {
        mas2 = s;
    }

    public void setMas3(String s)
    {
        mas3 = s;
    }

    public void setMas4(String s)
    {
        mas4 = s;
    }

    public void setMcheckCode(String s)
    {
        mcheckCode = s;
    }

    public void setMdeviceId(String s)
    {
        mdeviceId = s;
    }

    public void setMpriDeviceId(String s)
    {
        mpriDeviceId = s;
    }

    public void setMrule(String s)
    {
        mrule = s;
    }

    public void setMtid(String s)
    {
        mtid = s;
    }

    public void setMtime(String s)
    {
        mtime = s;
    }

    public void setMutdid(String s)
    {
        mutdid = s;
    }
}
