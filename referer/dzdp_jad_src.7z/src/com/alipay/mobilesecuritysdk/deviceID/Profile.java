// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.alipay.mobilesecuritysdk.deviceID;

import android.content.SharedPreferences;
import android.util.Log;
import java.util.*;
import org.json.JSONException;
import org.json.JSONObject;

// Referenced classes of package com.alipay.mobilesecuritysdk.deviceID:
//            IdResponseInfo, LOG

public class Profile
{

    public static final String devicever = "0";

    public Profile()
    {
    }

    private String MaptoString(Map map)
        throws JSONException
    {
        Iterator iterator;
        JSONObject jsonobject;
        if(map == null || map.size() <= 0)
            break MISSING_BLOCK_LABEL_104;
        iterator = map.entrySet().iterator();
        jsonobject = new JSONObject();
_L3:
        if(iterator.hasNext()) goto _L2; else goto _L1
_L1:
        String s = jsonobject.toString();
_L4:
        return s;
_L2:
        java.util.Map.Entry entry = (java.util.Map.Entry)iterator.next();
        String s1 = (String)entry.getKey();
        String s2 = (String)entry.getValue();
        try
        {
            jsonobject.put(s1, s2);
        }
        catch(JSONException jsonexception) { }
          goto _L3
        s = null;
          goto _L4
    }

    String GetDataFromSharedPre(SharedPreferences sharedpreferences, String s)
    {
        return sharedpreferences.getString(s, "");
    }

    public IdResponseInfo ParseResponse(String s)
    {
        if(s != null) goto _L2; else goto _L1
_L1:
        IdResponseInfo idresponseinfo = null;
_L4:
        return idresponseinfo;
_L2:
        Log.i("deviceid", (new StringBuilder("server response is")).append(s).toString());
        idresponseinfo = new IdResponseInfo();
        try
        {
            JSONObject jsonobject = new JSONObject(s);
            idresponseinfo.setMsuccess(jsonobject.getBoolean("success"));
            if(idresponseinfo.isMsuccess())
            {
                JSONObject jsonobject1 = jsonobject.getJSONObject("data");
                if(jsonobject1 != null)
                {
                    idresponseinfo.setMversion(jsonobject1.getString("version"));
                    idresponseinfo.setMapdid(jsonobject1.getString("apdid"));
                    idresponseinfo.setMapdtk(jsonobject1.getString("apdtk"));
                    JSONObject jsonobject2 = jsonobject1.getJSONObject("rule");
                    if(jsonobject2 != null)
                        idresponseinfo.setFuction(jsonobject2.getString("function"));
                    idresponseinfo.setMrule(jsonobject2.toString());
                    idresponseinfo.setMtime(jsonobject1.getString("time"));
                    idresponseinfo.setMcheckcode(jsonobject1.getString("checkcode"));
                }
            }
        }
        catch(JSONException jsonexception)
        {
            ArrayList arraylist = new ArrayList();
            arraylist.add("");
            arraylist.add("");
            arraylist.add("");
            arraylist.add(LOG.getStackString(jsonexception));
            LOG.logMessage(arraylist);
        }
        if(true) goto _L4; else goto _L3
_L3:
    }

    void SetDataToSharePre(SharedPreferences sharedpreferences, Map map)
    {
        if(sharedpreferences == null || map == null) goto _L2; else goto _L1
_L1:
        android.content.SharedPreferences.Editor editor = sharedpreferences.edit();
        if(editor == null) goto _L2; else goto _L3
_L3:
        Iterator iterator;
        editor.clear();
        iterator = map.entrySet().iterator();
_L7:
        if(iterator.hasNext()) goto _L5; else goto _L4
_L4:
        editor.commit();
_L2:
        return;
_L5:
        java.util.Map.Entry entry = (java.util.Map.Entry)iterator.next();
        String s = (String)entry.getKey();
        Object obj = entry.getValue();
        if(obj instanceof String)
            editor.putString(s, (String)obj);
        else
        if(obj instanceof Integer)
            editor.putInt(s, ((Integer)obj).intValue());
        else
        if(obj instanceof Long)
            editor.putLong(s, ((Long)obj).longValue());
        else
        if(obj instanceof Float)
            editor.putFloat(s, ((Float)obj).floatValue());
        else
        if(obj instanceof Boolean)
            editor.putBoolean(s, ((Boolean)obj).booleanValue());
        if(true) goto _L7; else goto _L6
_L6:
    }

    public String generatePrivateData(Map map)
        throws JSONException
    {
        return MaptoString(map);
    }

    public String generateUploadData(Map map)
    {
        JSONObject jsonobject;
        JSONObject jsonobject1;
        JSONObject jsonobject2;
        jsonobject = new JSONObject();
        jsonobject1 = new JSONObject();
        jsonobject2 = new JSONObject();
        if(map == null) goto _L2; else goto _L1
_L1:
        if(map.size() <= 0) goto _L2; else goto _L3
_L3:
        Iterator iterator = map.entrySet().iterator();
_L5:
        if(iterator.hasNext()) goto _L4; else goto _L2
_L2:
        jsonobject1.put("os", "android");
        jsonobject1.put("data", jsonobject2);
        jsonobject.put("type", "deviceinfo");
        jsonobject.put("model", jsonobject1);
_L6:
        return jsonobject.toString();
_L4:
        java.util.Map.Entry entry = (java.util.Map.Entry)iterator.next();
        String s = (String)entry.getKey();
        if(s.equals("deviceInfo"))
            jsonobject2.put(s, new JSONObject(MaptoString((Map)entry.getValue())));
        else
            jsonobject2.put(s, (String)entry.getValue());
          goto _L5
        JSONException jsonexception;
        jsonexception;
          goto _L6
    }

    public Map getMap(String s)
    {
        HashMap hashmap;
        try
        {
            JSONObject jsonobject = new JSONObject(s);
            Iterator iterator = jsonobject.keys();
            hashmap = new HashMap();
            String s1;
            for(; iterator.hasNext(); hashmap.put(s1, (String)jsonobject.get(s1)))
                s1 = (String)iterator.next();

        }
        catch(JSONException jsonexception)
        {
            jsonexception.printStackTrace();
            hashmap = null;
        }
        return hashmap;
    }
}
