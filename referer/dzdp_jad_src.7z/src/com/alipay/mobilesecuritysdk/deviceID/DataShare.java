// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.alipay.mobilesecuritysdk.deviceID;

import android.content.SharedPreferences;
import java.util.*;

public class DataShare
{

    public DataShare()
    {
    }

    String GetDataFromSharedPre(SharedPreferences sharedpreferences, String s)
    {
        return sharedpreferences.getString(s, "");
    }

    void SetDataToSharePre(SharedPreferences sharedpreferences, Map map)
    {
        if(sharedpreferences == null || map == null) goto _L2; else goto _L1
_L1:
        android.content.SharedPreferences.Editor editor = sharedpreferences.edit();
        if(editor == null) goto _L2; else goto _L3
_L3:
        Iterator iterator;
        editor.clear();
        iterator = map.entrySet().iterator();
_L7:
        if(iterator.hasNext()) goto _L5; else goto _L4
_L4:
        editor.commit();
_L2:
        return;
_L5:
        java.util.Map.Entry entry = (java.util.Map.Entry)iterator.next();
        String s = (String)entry.getKey();
        Object obj = entry.getValue();
        if(obj instanceof String)
            editor.putString(s, (String)obj);
        else
        if(obj instanceof Integer)
            editor.putInt(s, ((Integer)obj).intValue());
        else
        if(obj instanceof Long)
            editor.putLong(s, ((Long)obj).longValue());
        else
        if(obj instanceof Float)
            editor.putFloat(s, ((Float)obj).floatValue());
        else
        if(obj instanceof Boolean)
            editor.putBoolean(s, ((Boolean)obj).booleanValue());
        if(true) goto _L7; else goto _L6
_L6:
    }
}
