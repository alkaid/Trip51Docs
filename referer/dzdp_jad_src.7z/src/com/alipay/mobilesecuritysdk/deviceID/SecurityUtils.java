// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.alipay.mobilesecuritysdk.deviceID;

import java.security.SecureRandom;
import javax.crypto.*;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class SecurityUtils
{

    public static final String TAG = "SecurityUtils";
    private static String str = new String("idnjfhncnsfuobcnt847y929o449u474w7j3h22aoddc98euk#%&&)*&^%#");

    public SecurityUtils()
    {
    }

    private static void appendHex(StringBuffer stringbuffer, byte byte0)
    {
        stringbuffer.append("0123456789ABCDEF".charAt(0xf & byte0 >> 4)).append("0123456789ABCDEF".charAt(byte0 & 0xf));
    }

    public static String decrypt(String s, String s1)
    {
        String s2;
        try
        {
            s2 = new String(decrypt(getRawKey(s.getBytes()), toByte(s1)));
        }
        catch(Exception exception)
        {
            exception.printStackTrace();
            s2 = null;
        }
        return s2;
    }

    private static byte[] decrypt(byte abyte0[], byte abyte1[])
        throws Exception
    {
        SecretKeySpec secretkeyspec = new SecretKeySpec(abyte0, "AES");
        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
        cipher.init(2, secretkeyspec, new IvParameterSpec(new byte[cipher.getBlockSize()]));
        return cipher.doFinal(abyte1);
    }

    public static String encrypt(String s, String s1)
    {
        byte abyte0[] = null;
        byte abyte1[] = encrypt(getRawKey(s.getBytes()), s1.getBytes());
        abyte0 = abyte1;
_L2:
        return toHex(abyte0);
        Exception exception;
        exception;
        exception.printStackTrace();
        if(true) goto _L2; else goto _L1
_L1:
    }

    private static byte[] encrypt(byte abyte0[], byte abyte1[])
        throws Exception
    {
        SecretKeySpec secretkeyspec = new SecretKeySpec(abyte0, "AES");
        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
        cipher.init(1, secretkeyspec, new IvParameterSpec(new byte[cipher.getBlockSize()]));
        return cipher.doFinal(abyte1);
    }

    public static String fromHex(String s)
    {
        return new String(toByte(s));
    }

    private static byte[] getRawKey(byte abyte0[])
        throws Exception
    {
        KeyGenerator keygenerator = KeyGenerator.getInstance("AES");
        SecureRandom securerandom = SecureRandom.getInstance("SHA1PRNG", "Crypto");
        securerandom.setSeed(abyte0);
        keygenerator.init(128, securerandom);
        return keygenerator.generateKey().getEncoded();
    }

    public static String getSeed()
    {
        String s = new String();
        int i = 0;
        do
        {
            if(i >= -1 + str.length())
                return s;
            s = (new StringBuilder(String.valueOf(s))).append(str.charAt(i)).toString();
            i += 4;
        } while(true);
    }

    public static byte[] toByte(String s)
    {
        int i = s.length() / 2;
        byte abyte0[] = new byte[i];
        int j = 0;
        do
        {
            if(j >= i)
                return abyte0;
            abyte0[j] = Integer.valueOf(s.substring(j * 2, 2 + j * 2), 16).byteValue();
            j++;
        } while(true);
    }

    public static String toHex(String s)
    {
        return toHex(s.getBytes());
    }

    public static String toHex(byte abyte0[])
    {
        if(abyte0 != null) goto _L2; else goto _L1
_L1:
        String s = "";
_L4:
        return s;
_L2:
        StringBuffer stringbuffer = new StringBuffer(2 * abyte0.length);
        int i = 0;
        do
        {
label0:
            {
                if(i < abyte0.length)
                    break label0;
                s = stringbuffer.toString();
            }
            if(true)
                continue;
            appendHex(stringbuffer, abyte0[i]);
            i++;
        } while(true);
        if(true) goto _L4; else goto _L3
_L3:
    }

}
