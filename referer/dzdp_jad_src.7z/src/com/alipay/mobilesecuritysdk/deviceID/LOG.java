// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.alipay.mobilesecuritysdk.deviceID;

import HttpUtils.HttpFetcher;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.os.Build;
import android.util.Log;
import com.alipay.mobilesecuritysdk.util.CommonUtils;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;
import org.apache.http.HttpResponse;
import org.apache.http.StatusLine;
import org.json.JSONException;
import org.json.JSONObject;

public class LOG
{

    public static boolean DBG = true;
    private static String TAG = "logger";
    private static File logFileDir = null;
    private static File logFileName = null;
    private static Context mcontext = null;
    private static String model = null;
    private static String pkgName = null;

    public LOG()
    {
    }

    /**
     * @deprecated Method checkLogFile is deprecated
     */

    private static long checkLogFile()
    {
        com/alipay/mobilesecuritysdk/deviceID/LOG;
        JVM INSTR monitorenter ;
        boolean flag;
        logFileName = new File(logFileDir, getCurLogFileName());
        if(DBG)
            Log.d(TAG, (new StringBuilder("current logfile is:")).append(logFileName.getAbsolutePath()).toString());
        flag = logFileName.exists();
        if(flag) goto _L2; else goto _L1
_L1:
        logFileName.createNewFile();
_L3:
        long l1 = 0L;
_L4:
        com/alipay/mobilesecuritysdk/deviceID/LOG;
        JVM INSTR monitorexit ;
        return l1;
        IOException ioexception;
        ioexception;
        ioexception.printStackTrace();
          goto _L3
        Exception exception;
        exception;
        throw exception;
_L2:
        long l = logFileName.length();
        l1 = l;
          goto _L4
    }

    private static boolean doUpload(String s)
    {
        boolean flag = true;
        if(s != null) goto _L2; else goto _L1
_L1:
        Log.e(TAG, "logFile to JosonString is null");
        flag = false;
_L4:
        return flag;
_L2:
        if(DBG)
            Log.d(TAG, s);
        if(mcontext == null)
            flag = false;
        else
        if(!CommonUtils.isNetWorkActive(mcontext))
        {
            flag = false;
        } else
        {
            HttpResponse httpresponse = (new HttpFetcher()).uploadCollectedData(mcontext, "https://seccliprod.alipay.com/api/do.htm", "bugTrack", s, "1", flag);
            if(httpresponse == null)
                flag = false;
            else
            if(httpresponse.getStatusLine().getStatusCode() != 200)
                flag = false;
        }
        if(true) goto _L4; else goto _L3
_L3:
    }

    private static String getCurLogFileName()
    {
        java.util.Date date = Calendar.getInstance().getTime();
        return (new StringBuilder(String.valueOf((new SimpleDateFormat("yyyyMMdd")).format(date)))).append(".log").toString();
    }

    private static void getInfo(Context context)
    {
        model = Build.MODEL;
        pkgName = context.getApplicationContext().getApplicationInfo().packageName;
        if(DBG)
            Log.d(TAG, (new StringBuilder(String.valueOf(pkgName))).append(",").append(model).toString());
    }

    public static String getStackString(Throwable throwable)
    {
        StringWriter stringwriter = new StringWriter();
        throwable.printStackTrace(new PrintWriter(stringwriter));
        return stringwriter.toString();
    }

    /**
     * @deprecated Method init is deprecated
     */

    public static void init(Context context)
    {
        com/alipay/mobilesecuritysdk/deviceID/LOG;
        JVM INSTR monitorenter ;
        mcontext = context;
        if(logFileDir == null)
        {
            logFileDir = new File((new StringBuilder(String.valueOf(context.getFilesDir().getAbsolutePath()))).append("/log/ap").toString());
            getInfo(context);
        }
        if(logFileDir.exists())
        {
            if(!logFileDir.isDirectory())
            {
                Object aobj[] = new Object[1];
                aobj[0] = logFileDir.getAbsoluteFile();
                throw new IllegalStateException(String.format("<%s> exists but not a Directory!", aobj));
            }
            break MISSING_BLOCK_LABEL_111;
        }
        break MISSING_BLOCK_LABEL_104;
        Exception exception;
        exception;
        com/alipay/mobilesecuritysdk/deviceID/LOG;
        JVM INSTR monitorexit ;
        throw exception;
        logFileDir.mkdirs();
        com/alipay/mobilesecuritysdk/deviceID/LOG;
        JVM INSTR monitorexit ;
    }

    /**
     * @deprecated Method logMessage is deprecated
     */

    public static void logMessage(List list)
    {
        com/alipay/mobilesecuritysdk/deviceID/LOG;
        JVM INSTR monitorenter ;
        if(logFileDir == null)
            throw new IllegalStateException("logFileDir can not be null! call 'LOG.init' first!");
        break MISSING_BLOCK_LABEL_25;
        Exception exception;
        exception;
        com/alipay/mobilesecuritysdk/deviceID/LOG;
        JVM INSTR monitorexit ;
        throw exception;
        StringBuffer stringbuffer;
        Iterator iterator;
        stringbuffer = new StringBuffer((new SimpleDateFormat("yyyyMMddHHmmssSSS")).format(Calendar.getInstance().getTime()));
        stringbuffer.append((new StringBuilder(",")).append(model).toString());
        stringbuffer.append((new StringBuilder(",")).append(pkgName).toString());
        iterator = list.iterator();
_L5:
        boolean flag = iterator.hasNext();
        if(flag) goto _L2; else goto _L1
_L1:
        FileWriter filewriter = null;
        long l;
        l = checkLogFile();
        if(DBG)
            Log.d(TAG, (new StringBuilder("logFileSize=")).append(l).toString());
        if(l + (long)stringbuffer.length() > 51200L) goto _L4; else goto _L3
_L3:
        filewriter = new FileWriter(logFileName, true);
_L6:
        stringbuffer.append("\n");
        if(DBG)
            Log.d(TAG, (new StringBuilder("sb=")).append(stringbuffer.toString()).toString());
        filewriter.write(stringbuffer.toString());
        if(filewriter == null)
            break MISSING_BLOCK_LABEL_245;
        Exception exception1;
        Exception exception2;
        IOException ioexception1;
        FileWriter filewriter1;
        try
        {
            filewriter.close();
        }
        catch(IOException ioexception2)
        {
            Log.e(TAG, "close logfile failed");
            ioexception2.printStackTrace();
        }
        com/alipay/mobilesecuritysdk/deviceID/LOG;
        JVM INSTR monitorexit ;
        return;
_L2:
        String s = (String)iterator.next();
        stringbuffer.append((new StringBuilder(",")).append(s).toString());
          goto _L5
_L4:
        filewriter1 = new FileWriter(logFileName);
        filewriter = filewriter1;
          goto _L6
        exception2;
        exception2.printStackTrace();
        if(filewriter == null)
            break MISSING_BLOCK_LABEL_245;
        filewriter.close();
        break MISSING_BLOCK_LABEL_245;
        ioexception1;
        Log.e(TAG, "close logfile failed");
        ioexception1.printStackTrace();
        break MISSING_BLOCK_LABEL_245;
        exception1;
        if(filewriter == null)
            break MISSING_BLOCK_LABEL_357;
        try
        {
            filewriter.close();
        }
        catch(IOException ioexception)
        {
            Log.e(TAG, "close logfile failed");
            ioexception.printStackTrace();
        }
        throw exception1;
          goto _L5
    }

    private static String toJsonString(String s)
    {
        String s1;
        JSONObject jsonobject;
        File file;
        s1 = null;
        jsonobject = new JSONObject();
        file = new File(logFileDir, s);
        if(file != null && file.exists() && file.length() != 0L) goto _L2; else goto _L1
_L1:
        return s1;
_L2:
        char ac[];
        FileReader filereader;
        ac = new char[(int)file.length()];
        filereader = null;
        FileReader filereader1 = new FileReader(file);
        filereader1.read(ac);
        FileNotFoundException filenotfoundexception;
        Exception exception;
        IOException ioexception2;
        if(filereader1 != null)
            try
            {
                filereader1.close();
            }
            catch(IOException ioexception4)
            {
                ioexception4.printStackTrace();
            }
        jsonobject.put("type", "id");
        jsonobject.put("error", String.valueOf(ac));
        s1 = jsonobject.toString();
          goto _L1
        filenotfoundexception;
_L5:
        filenotfoundexception.printStackTrace();
        if(filereader != null)
            try
            {
                filereader.close();
            }
            catch(IOException ioexception1)
            {
                ioexception1.printStackTrace();
            }
          goto _L1
        ioexception2;
_L4:
        ioexception2.printStackTrace();
        if(filereader != null)
            try
            {
                filereader.close();
            }
            catch(IOException ioexception3)
            {
                ioexception3.printStackTrace();
            }
          goto _L1
        exception;
_L3:
        if(filereader != null)
            try
            {
                filereader.close();
            }
            catch(IOException ioexception)
            {
                ioexception.printStackTrace();
            }
        throw exception;
        JSONException jsonexception;
        jsonexception;
        Log.e(TAG, jsonexception.getMessage());
          goto _L1
        exception;
        filereader = filereader1;
          goto _L3
        ioexception2;
        filereader = filereader1;
          goto _L4
        filenotfoundexception;
        filereader = filereader1;
          goto _L5
    }

    /**
     * @deprecated Method uploadLogFile is deprecated
     */

    public static void uploadLogFile()
    {
        com/alipay/mobilesecuritysdk/deviceID/LOG;
        JVM INSTR monitorenter ;
        if(logFileDir == null)
            throw new IllegalStateException("logFileDir can not be null! call 'LOG.init' first!");
        break MISSING_BLOCK_LABEL_25;
        Exception exception;
        exception;
        com/alipay/mobilesecuritysdk/deviceID/LOG;
        JVM INSTR monitorexit ;
        throw exception;
        if(logFileDir.exists() && logFileDir.isDirectory() && logFileDir.list().length != 0) goto _L2; else goto _L1
_L1:
        if(DBG)
            Log.d(TAG, "log Dir not exist or no log");
_L4:
        com/alipay/mobilesecuritysdk/deviceID/LOG;
        JVM INSTR monitorexit ;
        return;
_L2:
        int l;
        ArrayList arraylist;
        String s1;
        int k;
label0:
        {
            arraylist = new ArrayList();
            String as[] = logFileDir.list();
            int i = as.length;
            int j = 0;
            do
            {
                if(j >= i)
                {
                    Collections.sort(arraylist);
                    String s = (String)arraylist.get(-1 + arraylist.size());
                    s1 = s;
                    k = arraylist.size();
                    if(!s.equals(getCurLogFileName()))
                        break label0;
                    if(arraylist.size() < 2)
                    {
                        if(DBG)
                            Log.d(TAG, "only log of today");
                        continue; /* Loop/switch isn't completed */
                    }
                    break;
                }
                arraylist.add(as[j]);
                j++;
            } while(true);
            s1 = (String)arraylist.get(-2 + arraylist.size());
            k--;
        }
        String s2;
        if(!doUpload(toJsonString(s1)))
            k--;
        else
        if(DBG)
            Log.d(TAG, "upload success");
        break; /* Loop/switch isn't completed */
_L6:
        while(l < k) 
        {
            s2 = (String)arraylist.get(l);
            (new File(logFileDir, s2)).delete();
            l++;
        }
        if(true) goto _L4; else goto _L3
_L3:
        l = 0;
        if(true) goto _L6; else goto _L5
_L5:
        if(true) goto _L4; else goto _L7
_L7:
    }

}
