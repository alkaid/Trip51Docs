// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.alipay.mobilesecuritysdk.deviceID;

import java.util.List;

public class IdResponseInfo
{

    private List arrList;
    private String fuction;
    private String mapdid;
    private String mapdtk;
    private String mcheckcode;
    private String merrorcode;
    private String mrule;
    private boolean msuccess;
    private String mtime;
    private String mversion;

    public IdResponseInfo()
    {
    }

    public List getArrList()
    {
        return arrList;
    }

    public String getFuction()
    {
        return fuction;
    }

    public String getMapdid()
    {
        return mapdid;
    }

    public String getMapdtk()
    {
        return mapdtk;
    }

    public String getMcheckcode()
    {
        return mcheckcode;
    }

    public String getMrule()
    {
        return mrule;
    }

    public String getMtime()
    {
        return mtime;
    }

    public String getMversion()
    {
        return mversion;
    }

    public String isMerrorcode()
    {
        return merrorcode;
    }

    public boolean isMsuccess()
    {
        return msuccess;
    }

    public void setArrList(List list)
    {
        arrList = list;
    }

    public void setFuction(String s)
    {
        fuction = s;
    }

    public void setMapdid(String s)
    {
        mapdid = s;
    }

    public void setMapdtk(String s)
    {
        mapdtk = s;
    }

    public void setMcheckcode(String s)
    {
        mcheckcode = s;
    }

    public void setMerrorcode(String s)
    {
        merrorcode = s;
    }

    public void setMrule(String s)
    {
        mrule = s;
    }

    public void setMsuccess(boolean flag)
    {
        msuccess = flag;
    }

    public void setMtime(String s)
    {
        mtime = s;
    }

    public void setMversion(String s)
    {
        mversion = s;
    }
}
