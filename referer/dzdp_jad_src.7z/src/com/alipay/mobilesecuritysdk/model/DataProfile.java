// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.alipay.mobilesecuritysdk.model;

import android.util.Log;
import com.alipay.mobilesecuritysdk.constant.ConfigNameEnum;
import com.alipay.mobilesecuritysdk.constant.LocationNameEnum;
import com.alipay.mobilesecuritysdk.datainfo.*;
import com.alipay.mobilesecuritysdk.face.SecurityClientMobile;
import com.alipay.mobilesecuritysdk.util.CommonUtils;
import java.io.File;
import java.io.StringReader;
import java.util.*;
import org.json.*;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

public class DataProfile
{

    private List tid;

    public DataProfile()
    {
    }

    private SdkConfig GetDefaultConfig()
    {
        SdkConfig sdkconfig = SdkConfig.getInstance();
        sdkconfig.setMainSwitchLUT(0L);
        sdkconfig.setMainSwitchState("on");
        sdkconfig.setMainSwitchInterval(1);
        sdkconfig.setLocateLUT(0L);
        sdkconfig.setLocateInterval(30);
        sdkconfig.setLocationMaxLines(24);
        sdkconfig.setAppLUT(0L);
        sdkconfig.setAppInterval(7);
        return sdkconfig;
    }

    private JSONArray GetWifiToJson(List list)
    {
        JSONArray jsonarray;
        Iterator iterator;
        jsonarray = new JSONArray();
        iterator = list.iterator();
_L3:
        WifiCollectInfo wificollectinfo;
        if(!iterator.hasNext())
            return jsonarray;
        wificollectinfo = (WifiCollectInfo)iterator.next();
        JSONObject jsonobject = new JSONObject();
        if(wificollectinfo.getMbssid() != null) goto _L2; else goto _L1
_L1:
        jsonobject.put(LocationNameEnum.BSSID.getValue(), "");
_L4:
        if(wificollectinfo.getMssid() != null)
            break MISSING_BLOCK_LABEL_170;
        jsonobject.put(LocationNameEnum.SSID.getValue(), "");
_L5:
        jsonobject.put(LocationNameEnum.CURRENT.getValue(), wificollectinfo.isMiscurrent());
        jsonobject.put(LocationNameEnum.LEVEL.getValue(), wificollectinfo.getMlevel());
        jsonarray.put(jsonobject);
          goto _L3
        JSONException jsonexception;
        jsonexception;
        Log.d("location", jsonexception.getLocalizedMessage());
          goto _L3
_L2:
        jsonobject.put(LocationNameEnum.BSSID.getValue(), wificollectinfo.getMbssid());
          goto _L4
        jsonobject.put(LocationNameEnum.SSID.getValue(), wificollectinfo.getMssid());
          goto _L5
    }

    public String AppToString(String s, List list)
    {
        JSONArray jsonarray;
        JSONObject jsonobject;
        JSONObject jsonobject1;
        JSONArray jsonarray1;
        Iterator iterator;
        File file = new File(s);
        if(file.length() > 51200L)
        {
            file.delete();
            Log.i("delete file", (new StringBuilder("app file size > 50k, file path is")).append(s).toString());
        }
        jsonarray = new JSONArray();
        jsonobject = new JSONObject();
        jsonobject1 = new JSONObject();
        jsonarray1 = new JSONArray();
        iterator = list.iterator();
_L5:
        if(iterator.hasNext()) goto _L2; else goto _L1
_L1:
        if(GetTIDJson() != null) goto _L4; else goto _L3
_L3:
        jsonobject1.put("tid", "");
_L6:
        jsonobject1.put("appList", jsonarray1);
        jsonobject1.put("timestamp", CommonUtils.convertDate2String(new Date()));
        jsonobject.put("type", ConfigNameEnum.START_TAG.getValue());
        jsonobject.put("model", jsonobject1);
_L7:
        jsonarray.put(jsonobject);
        return jsonarray.toString();
_L2:
        AppInfo appinfo = (AppInfo)iterator.next();
        try
        {
            JSONObject jsonobject2 = new JSONObject();
            jsonobject2.put(ConfigNameEnum.PKG_NAME.getValue(), appinfo.getPkgName());
            jsonobject2.put(ConfigNameEnum.PUB_KEY_HASH.getValue(), appinfo.getPkeyhash());
            jsonarray1.put(jsonobject2);
        }
        catch(JSONException jsonexception)
        {
            Log.d("appinfo", jsonexception.getLocalizedMessage());
        }
          goto _L5
_L4:
        jsonobject1.put("tid", GetTIDJson());
          goto _L6
        JSONException jsonexception1;
        jsonexception1;
        Log.i("apptojason", jsonexception1.getLocalizedMessage());
          goto _L7
    }

    public JSONArray GetJsonFromFile(String s)
    {
        if(s.length() <= 0) goto _L2; else goto _L1
_L1:
        JSONArray jsonarray;
        String s1;
        s1 = CommonUtils.ReadFile(s);
        jsonarray = null;
        if(s1.length() > 0) goto _L4; else goto _L3
_L3:
        jsonarray = null;
_L6:
        return jsonarray;
_L4:
        JSONArray jsonarray1;
        try
        {
            jsonarray1 = new JSONArray(s1);
        }
        catch(JSONException jsonexception)
        {
            Log.d("getjsonfromfile", jsonexception.getLocalizedMessage());
            continue; /* Loop/switch isn't completed */
        }
        jsonarray = jsonarray1;
        continue; /* Loop/switch isn't completed */
_L2:
        jsonarray = null;
        if(true) goto _L6; else goto _L5
_L5:
    }

    public JSONArray GetTIDJson()
    {
        JSONArray jsonarray;
        if(tid == null || tid.isEmpty())
        {
            jsonarray = null;
        } else
        {
            jsonarray = new JSONArray();
            Iterator iterator = tid.iterator();
            while(iterator.hasNext()) 
                jsonarray.put((String)iterator.next());
        }
        return jsonarray;
    }

    public String LocationToString(String s, List list)
    {
        Log.i("LocationToString path is ", s);
        JSONArray jsonarray = null;
        File file = new File(s);
        JSONObject jsonobject;
        Iterator iterator;
        if(file.length() > 51200L)
        {
            file.delete();
            Log.i("delete file", "lc file size > 50k");
        } else
        if(s.length() > 0 && !file.isDirectory() && file.exists())
            jsonarray = GetJsonFromFile(s);
        if(jsonarray == null)
            jsonarray = new JSONArray();
        jsonobject = new JSONObject();
        iterator = list.iterator();
        do
        {
            if(!iterator.hasNext())
            {
                jsonarray.put(jsonobject);
                return jsonarray.toString();
            }
            LocationInfo locationinfo = (LocationInfo)iterator.next();
            try
            {
                JSONObject jsonobject1 = new JSONObject();
                jsonobject1.put(LocationNameEnum.LOCATE_LATITUDE.getValue(), locationinfo.getLatitude());
                jsonobject1.put(LocationNameEnum.LOCATE_LONGITUDE.getValue(), locationinfo.getLongitude());
                jsonobject1.put(LocationNameEnum.LOCATE_CELL_ID.getValue(), locationinfo.getCid());
                jsonobject1.put(LocationNameEnum.LOCATE_LAC.getValue(), locationinfo.getLac());
                jsonobject1.put(LocationNameEnum.TIME_STAMP.getValue(), locationinfo.getTime());
                jsonobject1.put("tid", GetTIDJson());
                jsonobject1.put(LocationNameEnum.MCC.getValue(), locationinfo.getMcc());
                jsonobject1.put(LocationNameEnum.MNC.getValue(), locationinfo.getMnc());
                jsonobject1.put(LocationNameEnum.PHONETYPE.getValue(), locationinfo.getPhonetype());
                JSONArray jsonarray1 = null;
                if(locationinfo.getWifi() != null)
                    jsonarray1 = GetWifiToJson(locationinfo.getWifi());
                if(jsonarray1 != null)
                    jsonobject1.put(LocationNameEnum.LOCATE_WIFI.getValue(), jsonarray1);
                jsonobject.put("type", LocationNameEnum.START_TAG.getValue());
                jsonobject.put("model", jsonobject1);
            }
            catch(JSONException jsonexception)
            {
                Log.d("location", jsonexception.getLocalizedMessage());
            }
        } while(true);
    }

    public GeoResponseInfo analysisServerRespond(String s)
    {
        GeoResponseInfo georesponseinfo = new GeoResponseInfo();
        XmlPullParser xmlpullparser;
        int i;
        xmlpullparser = XmlPullParserFactory.newInstance().newPullParser();
        xmlpullparser.setInput(new StringReader(s));
        i = xmlpullparser.getEventType();
        int j = i;
_L3:
        if(j != 1) goto _L2; else goto _L1
_L1:
        georesponseinfo.setSuccess(true);
        return georesponseinfo;
_L2:
        String s1 = xmlpullparser.getName();
        if(j == 2)
            if(CommonUtils.equalsIgnoreCase(s1, ConfigNameEnum.MAIN_SWITCH_STATE.getValue()))
                georesponseinfo.setMainSwitchState(xmlpullparser.nextText());
            else
            if(CommonUtils.equalsIgnoreCase(s1, ConfigNameEnum.MAIN_SWITCH_INTERVAL.getValue()))
                georesponseinfo.setMainSwitchInterval(CommonUtils.string2int(xmlpullparser.nextText()));
            else
            if(CommonUtils.equalsIgnoreCase(s1, ConfigNameEnum.LOCATE_INTERVAL.getValue()))
                georesponseinfo.setLocateInterval(CommonUtils.string2int(xmlpullparser.nextText()));
            else
            if(CommonUtils.equalsIgnoreCase(s1, ConfigNameEnum.LOCATION_MAX_LINES.getValue()))
                georesponseinfo.setLocationMaxLines(CommonUtils.string2int(xmlpullparser.nextText()));
            else
            if(CommonUtils.equalsIgnoreCase(s1, ConfigNameEnum.APP_INTERVAL.getValue()))
                georesponseinfo.setAppInterval(CommonUtils.string2int(xmlpullparser.nextText()));
        j = xmlpullparser.next();
          goto _L3
        Exception exception;
        exception;
        Log.i("ALP", exception.getMessage());
          goto _L1
        Exception exception1;
        exception1;
          goto _L1
    }

    public void cleanUploadFiles(String s)
    {
        File file = new File(s);
        if(file.exists())
            file.delete();
_L1:
        return;
        Exception exception;
        exception;
        Log.i("ALP", exception.getMessage());
          goto _L1
    }

    public SdkConfig getConfigs(String s)
    {
        SdkConfig sdkconfig;
        if(s.length() == 0)
            break MISSING_BLOCK_LABEL_280;
        String s1;
        SdkConfig sdkconfig1;
        Exception exception1;
        SdkConfig sdkconfig2;
        JSONObject jsonobject;
        try
        {
            File file = new File((new StringBuilder(String.valueOf(s))).append(File.separator).append("seccliconfig.xml").toString());
            if(!file.exists())
            {
                sdkconfig = GetDefaultConfig();
                break MISSING_BLOCK_LABEL_282;
            }
            s1 = CommonUtils.ReadFile(file.getPath());
            if(s1.length() <= 0)
            {
                Log.d("read json", "file size o");
                sdkconfig = GetDefaultConfig();
                break MISSING_BLOCK_LABEL_282;
            }
            sdkconfig1 = SdkConfig.getInstance();
        }
        catch(Exception exception)
        {
            SecurityClientMobile.setError(true);
            sdkconfig = GetDefaultConfig();
            break MISSING_BLOCK_LABEL_282;
        }
        sdkconfig = sdkconfig1;
        jsonobject = (new JSONObject(s1)).getJSONObject("configs");
        if(jsonobject == null)
        {
            sdkconfig = GetDefaultConfig();
        } else
        {
            sdkconfig.setAppInterval(jsonobject.getInt(ConfigNameEnum.APP_INTERVAL.getValue()));
            sdkconfig.setAppLUT(jsonobject.getLong(ConfigNameEnum.APP_LUT.getValue()));
            sdkconfig.setLocateInterval(jsonobject.getInt(ConfigNameEnum.LOCATE_INTERVAL.getValue()));
            sdkconfig.setLocateLUT(jsonobject.getLong(ConfigNameEnum.LOCATE_LUT.getValue()));
            sdkconfig.setLocationMaxLines(jsonobject.getInt(ConfigNameEnum.LOCATION_MAX_LINES.getValue()));
            sdkconfig.setMainSwitchInterval(jsonobject.getInt(ConfigNameEnum.MAIN_SWITCH_INTERVAL.getValue()));
            sdkconfig.setMainSwitchLUT(jsonobject.getLong(ConfigNameEnum.MAIN_SWITCH_LUT.getValue()));
            sdkconfig.setMainSwitchState(jsonobject.getString(ConfigNameEnum.MAIN_SWITCH_STATE.getValue()));
        }
        break MISSING_BLOCK_LABEL_282;
        exception1;
        sdkconfig2 = GetDefaultConfig();
        sdkconfig = sdkconfig2;
        break MISSING_BLOCK_LABEL_282;
        sdkconfig = null;
        return sdkconfig;
    }

    public List getTid()
    {
        return tid;
    }

    public void saveConfigs(SdkConfig sdkconfig, String s)
    {
        JSONObject jsonobject = new JSONObject();
        jsonobject.put(ConfigNameEnum.MAIN_SWITCH_LUT.getValue(), sdkconfig.getMainSwitchLUT());
        jsonobject.put(ConfigNameEnum.MAIN_SWITCH_STATE.getValue(), sdkconfig.getMainSwitchState());
        jsonobject.put(ConfigNameEnum.MAIN_SWITCH_INTERVAL.getValue(), sdkconfig.getMainSwitchInterval());
        jsonobject.put(ConfigNameEnum.LOCATE_LUT.getValue(), sdkconfig.getLocateLUT());
        jsonobject.put(ConfigNameEnum.LOCATE_INTERVAL.getValue(), sdkconfig.getLocateInterval());
        jsonobject.put(ConfigNameEnum.LOCATION_MAX_LINES.getValue(), sdkconfig.getLocationMaxLines());
        jsonobject.put(ConfigNameEnum.APP_LUT.getValue(), sdkconfig.getAppLUT());
        jsonobject.put(ConfigNameEnum.APP_INTERVAL.getValue(), sdkconfig.getAppInterval());
        JSONObject jsonobject1 = new JSONObject();
        jsonobject1.put(ConfigNameEnum.CONFIGS.getValue(), jsonobject);
        if(SecurityClientMobile.isDebug())
            Log.i("ALP", (new StringBuilder("loadConfig")).append(jsonobject1.toString()).toString());
        CommonUtils.WriteFile(s, jsonobject1.toString());
_L1:
        return;
        Exception exception;
        exception;
        SecurityClientMobile.setError(true);
          goto _L1
    }

    public void setTid(List list)
    {
        tid = list;
    }
}
