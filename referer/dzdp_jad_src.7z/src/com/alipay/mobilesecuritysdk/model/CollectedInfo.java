// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.alipay.mobilesecuritysdk.model;

import android.content.Context;
import android.content.pm.*;
import android.location.Location;
import android.location.LocationManager;
import android.net.wifi.*;
import android.os.Looper;
import android.telephony.TelephonyManager;
import android.telephony.cdma.CdmaCellLocation;
import android.telephony.gsm.GsmCellLocation;
import android.util.Base64;
import android.util.Log;
import com.alipay.mobilesecuritysdk.constant.LocationNameEnum;
import com.alipay.mobilesecuritysdk.datainfo.*;
import com.alipay.mobilesecuritysdk.util.CommonUtils;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.*;

// Referenced classes of package com.alipay.mobilesecuritysdk.model:
//            DataProfile, SecLocationListener

public class CollectedInfo
{

    private final int MODULUS_FIX = 8;
    private DataProfile profile;

    public CollectedInfo()
    {
        profile = new DataProfile();
    }

    private List GetWifiInfos(Context context)
    {
        ArrayList arraylist;
label0:
        {
            arraylist = new ArrayList();
            WifiManager wifimanager = (WifiManager)context.getSystemService("wifi");
            try
            {
                if(wifimanager.isWifiEnabled())
                {
                    WifiInfo wifiinfo = wifimanager.getConnectionInfo();
                    WifiCollectInfo wificollectinfo = new WifiCollectInfo();
                    wificollectinfo.setMbssid(wifiinfo.getBSSID());
                    wificollectinfo.setMssid(Base64.encodeToString(wifiinfo.getSSID().getBytes(), 8));
                    wificollectinfo.setMlevel(wifiinfo.getRssi());
                    wificollectinfo.setMiscurrent(true);
                    arraylist.add(wificollectinfo);
                    Iterator iterator = wifimanager.getScanResults().iterator();
                    do
                    {
                        if(!iterator.hasNext())
                            break;
                        ScanResult scanresult = (ScanResult)iterator.next();
                        if(!scanresult.BSSID.equals(wifiinfo.getBSSID()) && !scanresult.SSID.equals(wifiinfo.getSSID()))
                        {
                            WifiCollectInfo wificollectinfo1 = new WifiCollectInfo();
                            wificollectinfo1.setMbssid(scanresult.BSSID);
                            wificollectinfo1.setMssid(Base64.encodeToString(scanresult.SSID.getBytes(), 8));
                            wificollectinfo1.setMlevel(scanresult.level);
                            wificollectinfo1.setMiscurrent(false);
                            arraylist.add(wificollectinfo1);
                        }
                    } while(true);
                    break label0;
                }
            }
            catch(Exception exception)
            {
                Log.d("GetWifiInfos", (new StringBuilder()).append(exception.getLocalizedMessage()).toString());
            }
            arraylist = null;
        }
        return arraylist;
    }

    private void SetPhoneType(TelephonyManager telephonymanager, LocationInfo locationinfo, int i)
    {
        String s;
        String s1;
        String s2;
        String s3;
        s = "";
        s1 = "";
        s2 = "";
        s3 = "";
        if(i != 2) goto _L2; else goto _L1
_L1:
        try
        {
            CdmaCellLocation cdmacelllocation = (CdmaCellLocation)telephonymanager.getCellLocation();
            if(cdmacelllocation != null && CommonUtils.isBlank(locationinfo.getLatitude()) && CommonUtils.isBlank(locationinfo.getLongitude()))
            {
                s3 = String.valueOf(cdmacelllocation.getNetworkId());
                s = telephonymanager.getNetworkOperator().substring(0, 3);
                s1 = String.valueOf(cdmacelllocation.getSystemId());
                s2 = String.valueOf(cdmacelllocation.getBaseStationId());
                locationinfo.setLatitude(cdmacelllocation.getBaseStationLatitude());
                locationinfo.setLongitude(cdmacelllocation.getBaseStationLongitude());
            }
        }
        catch(Exception exception1)
        {
            Log.i("gettelphonetype PHONE_TYPE_CDMA", exception1.getLocalizedMessage());
        }
_L4:
        locationinfo.setMcc(s);
        locationinfo.setMnc(s1);
        locationinfo.setCid(s2);
        locationinfo.setLac(s3);
        return;
_L2:
        String s4;
        GsmCellLocation gsmcelllocation = (GsmCellLocation)telephonymanager.getCellLocation();
        if(gsmcelllocation == null)
            continue; /* Loop/switch isn't completed */
        s = telephonymanager.getNetworkOperator().substring(0, 3);
        s1 = telephonymanager.getNetworkOperator().substring(3, 5);
        s2 = String.valueOf(gsmcelllocation.getCid());
        s4 = String.valueOf(gsmcelllocation.getLac());
        s3 = s4;
        continue; /* Loop/switch isn't completed */
        Exception exception;
        exception;
        Log.i("gettelphonetype", exception.getLocalizedMessage());
        if(true) goto _L4; else goto _L3
_L3:
    }

    private String getSignatureHash(byte abyte0[])
    {
        String s1;
        int i;
        int j;
        int k;
        int l;
        s1 = ((X509Certificate)CertificateFactory.getInstance("X.509").generateCertificate(new ByteArrayInputStream(abyte0))).getPublicKey().toString();
        i = s1.indexOf("modulus");
        j = s1.indexOf("\n", i + 8);
        k = s1.indexOf(",", i + 8);
        l = -1;
        if(j >= 0 || k <= 0)
            break MISSING_BLOCK_LABEL_157;
        l = k;
_L5:
        if(l >= 0) goto _L2; else goto _L1
_L1:
        String s3 = s1.substring(i + 8).trim();
_L4:
        String s = CommonUtils.MD5(s3);
          goto _L3
_L2:
        String s2 = s1.substring(i + 8, l).trim();
        s3 = s2;
          goto _L4
        Exception exception;
        exception;
        Log.i("ALP", exception.getMessage());
        s = null;
_L3:
        return s;
        if(k < 0 && j > 0)
            l = j;
        else
        if(j < k)
            l = j;
        else
        if(k < j)
            l = k;
          goto _L5
    }

    public String GetLocationInfo(Context context, List list)
    {
        List list1 = collectLocateInfos(context);
        profile.setTid(list);
        return profile.LocationToString((new StringBuilder(String.valueOf(context.getFilesDir().getPath()))).append(File.separator).toString(), list1);
    }

    public List collectLocateInfos(Context context)
    {
        ArrayList arraylist;
        boolean flag;
        arraylist = new ArrayList();
        flag = false;
        LocationInfo locationinfo = new LocationInfo();
        locationinfo.setTime(CommonUtils.convertDate2String(new Date()));
        locationinfo.setCid("");
        locationinfo.setLac("");
        locationinfo.setLatitude("");
        locationinfo.setLongitude("");
        locationinfo.setMcc("");
        locationinfo.setMnc("");
        locationinfo.setPhonetype("");
        LocationManager locationmanager = (LocationManager)context.getSystemService("location");
        if(locationmanager.isProviderEnabled("network"))
        {
            SecLocationListener seclocationlistener = new SecLocationListener();
            locationmanager.requestLocationUpdates("network", 0x493e0L, 0.0F, seclocationlistener, Looper.getMainLooper());
            locationmanager.removeUpdates(seclocationlistener);
            Location location = locationmanager.getLastKnownLocation("network");
            if(location != null)
            {
                flag = true;
                locationinfo.setLatitude(location.getLatitude());
                locationinfo.setLongitude(location.getLongitude());
            }
        }
        TelephonyManager telephonymanager = (TelephonyManager)context.getSystemService("phone");
        List list;
        if(telephonymanager.getPhoneType() == 2)
        {
            locationinfo.setPhonetype(LocationNameEnum.CDMA.getValue());
            if(!flag)
                SetPhoneType(telephonymanager, locationinfo, 2);
        } else
        {
            locationinfo.setPhonetype(LocationNameEnum.GSM.getValue());
            SetPhoneType(telephonymanager, locationinfo, 1);
        }
        list = GetWifiInfos(context);
        if(list != null && list.size() > 0)
            locationinfo.setWifi(list);
        arraylist.add(locationinfo);
        Exception exception;
        if(arraylist.size() <= 0)
            arraylist = null;
        break MISSING_BLOCK_LABEL_315;
        exception;
        Log.i("ALP", exception.getMessage());
        arraylist = null;
        return arraylist;
    }

    public List collectappInfos(Context context)
    {
        ArrayList arraylist;
        try
        {
            arraylist = new ArrayList();
            PackageManager packagemanager = context.getPackageManager();
            Iterator iterator = packagemanager.getInstalledPackages(4096).iterator();
            do
            {
                if(!iterator.hasNext())
                    break;
                PackageInfo packageinfo = (PackageInfo)iterator.next();
                if((packagemanager.checkPermission("android.permission.READ_SMS", packageinfo.packageName) == 0 || packagemanager.checkPermission("android.permission.RECEIVE_SMS", packageinfo.packageName) == 0) && (packagemanager.checkPermission("android.permission.SEND_SMS", packageinfo.packageName) == 0 || packagemanager.checkPermission("android.permission.INTERNET", packageinfo.packageName) == 0))
                {
                    AppInfo appinfo = new AppInfo();
                    appinfo.setPkgName(packageinfo.packageName);
                    appinfo.setPkeyhash(getSignatureHash(packagemanager.getPackageInfo(packageinfo.packageName, 64).signatures[0].toByteArray()));
                    if(appinfo.validate())
                        arraylist.add(appinfo);
                }
            } while(true);
        }
        catch(Exception exception)
        {
            Log.i("ALP", exception.getMessage());
            arraylist = null;
        }
        return arraylist;
    }
}
