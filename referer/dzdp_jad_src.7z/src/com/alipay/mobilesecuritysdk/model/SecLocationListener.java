// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.alipay.mobilesecuritysdk.model;

import android.location.Location;
import android.location.LocationListener;
import android.os.Bundle;

public class SecLocationListener
    implements LocationListener
{

    public SecLocationListener()
    {
    }

    public void onLocationChanged(Location location)
    {
    }

    public void onProviderDisabled(String s)
    {
    }

    public void onProviderEnabled(String s)
    {
    }

    public void onStatusChanged(String s, int i, Bundle bundle)
    {
    }
}
