// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.alipay.mobilesecuritysdk.model;

import HttpUtils.HttpFetcher;
import android.content.Context;
import android.util.Log;
import com.alipay.mobilesecuritysdk.datainfo.*;
import com.alipay.mobilesecuritysdk.face.SecurityClientMobile;
import com.alipay.mobilesecuritysdk.util.CommonUtils;
import java.io.File;
import java.io.IOException;
import java.util.List;
import org.apache.http.HttpResponse;
import org.apache.http.StatusLine;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.util.EntityUtils;

// Referenced classes of package com.alipay.mobilesecuritysdk.model:
//            DataProfile

public class Upload
{

    private UploadInfo info;
    private Context mcontext;
    private DataProfile profile;

    public Upload(Context context)
    {
        profile = new DataProfile();
        mcontext = context;
    }

    public GeoResponseInfo communicateSwitch()
    {
        GeoResponseInfo georesponseinfo = new GeoResponseInfo();
        if(CommonUtils.isNetWorkActive(mcontext))
            try
            {
                HttpGet httpget = new HttpGet("http://secclientgw.alipay.com/mobile/switch.xml");
                HttpResponse httpresponse = (new HttpFetcher()).getHttpClient().execute(httpget);
                if(httpresponse.getStatusLine().getStatusCode() == 200)
                    georesponseinfo = profile.analysisServerRespond(EntityUtils.toString(httpresponse.getEntity()));
                else
                    georesponseinfo.setSuccess(false);
            }
            catch(Exception exception)
            {
                georesponseinfo.setSuccess(false);
            }
        return georesponseinfo;
    }

    public UploadInfo getInfo()
    {
        return info;
    }

    public void setInfo(UploadInfo uploadinfo)
    {
        info = uploadinfo;
    }

    public GeoResponseInfo uploadCollectedData(String s, String s1, String s2)
    {
        GeoResponseInfo georesponseinfo = new GeoResponseInfo();
        try
        {
            HttpResponse httpresponse = (new HttpFetcher()).uploadCollectedData(mcontext, "https://seccliprod.alipay.com/api/do.htm", s, s1, s2, true);
            if(httpresponse != null && httpresponse.getStatusLine().getStatusCode() == 200)
                georesponseinfo = profile.analysisServerRespond(EntityUtils.toString(httpresponse.getEntity()));
            else
                georesponseinfo.setSuccess(false);
        }
        catch(IOException ioexception)
        {
            Log.i("upload data  error", ioexception.getLocalizedMessage());
        }
        return georesponseinfo;
    }

    public GeoResponseInfo uploadData(List list, SdkConfig sdkconfig)
    {
        GeoResponseInfo georesponseinfo = new GeoResponseInfo();
        GeoResponseInfo georesponseinfo1;
        if(CommonUtils.isBlankCollection(list))
        {
            georesponseinfo.setSuccess(false);
            georesponseinfo1 = georesponseinfo;
        } else
        {
            if(info.getAppinfos().size() > 0)
            {
                profile.setTid(list);
                String s1 = profile.AppToString((new StringBuilder(String.valueOf(mcontext.getFilesDir().getPath()))).append(File.separator).append("appupload.xml").toString(), info.getAppinfos());
                if(SecurityClientMobile.isDebug())
                    Log.i("str app info", s1);
                if(s1 != null && s1.length() > 0)
                    georesponseinfo = uploadCollectedData("mobileClient", s1, "1");
                String s;
                if(!georesponseinfo.isSuccess())
                {
                    try
                    {
                        CommonUtils.WriteFile((new StringBuilder(String.valueOf(mcontext.getFilesDir().getPath()))).append(File.separator).append("appupload.xml").toString(), s1);
                    }
                    catch(IOException ioexception1)
                    {
                        Log.d("app write file", ioexception1.getLocalizedMessage());
                    }
                } else
                {
                    profile.cleanUploadFiles((new StringBuilder(String.valueOf(mcontext.getFilesDir().getPath()))).append(File.separator).append("appupload.xml").toString());
                    Log.i("app write file", "upload  suceess  delete file");
                }
            }
            if(info.getLocates().size() > 0)
            {
                profile.setTid(list);
                s = profile.LocationToString((new StringBuilder(String.valueOf(mcontext.getFilesDir().getPath()))).append(File.separator).append("locationupload.xml").toString(), info.getLocates());
                if(SecurityClientMobile.isDebug())
                    Log.i("str aloc info", s);
                if(s != null && s.length() > 0)
                    georesponseinfo = uploadCollectedData("mobileClient", s, "1");
                if(!georesponseinfo.isSuccess())
                {
                    try
                    {
                        CommonUtils.WriteFile((new StringBuilder(String.valueOf(mcontext.getFilesDir().getPath()))).append(File.separator).append("locationupload.xml").toString(), s);
                    }
                    catch(IOException ioexception)
                    {
                        Log.d("location write file", ioexception.getLocalizedMessage());
                    }
                } else
                {
                    profile.cleanUploadFiles((new StringBuilder(String.valueOf(mcontext.getFilesDir().getPath()))).append(File.separator).append("locationupload.xml").toString());
                    Log.i("location write file", "upload  suceess  delete file");
                }
            }
            georesponseinfo1 = georesponseinfo;
        }
        return georesponseinfo1;
    }
}
