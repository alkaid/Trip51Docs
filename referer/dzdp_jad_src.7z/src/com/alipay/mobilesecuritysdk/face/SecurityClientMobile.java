// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.alipay.mobilesecuritysdk.face;

import android.content.Context;
import android.util.Log;
import com.alipay.mobilesecuritysdk.MainHandler;
import com.alipay.mobilesecuritysdk.deviceID.DeviceIdManager;
import java.util.List;
import java.util.Map;

public class SecurityClientMobile
{

    private static boolean isDebug = false;
    private static boolean isError = false;
    private static Thread workThread;

    public SecurityClientMobile()
    {
    }

    /**
     * @deprecated Method GetApdid is deprecated
     */

    public static String GetApdid(Context context, Map map)
    {
        com/alipay/mobilesecuritysdk/face/SecurityClientMobile;
        JVM INSTR monitorenter ;
        String s = (new DeviceIdManager(context)).GetApDid(map);
        com/alipay/mobilesecuritysdk/face/SecurityClientMobile;
        JVM INSTR monitorexit ;
        return s;
        Exception exception;
        exception;
        throw exception;
    }

    public static boolean isDebug()
    {
        return isDebug;
    }

    public static void setDebug(boolean flag)
    {
        isDebug = flag;
    }

    public static void setError(boolean flag)
    {
        isError = flag;
    }

    /**
     * @deprecated Method start is deprecated
     */

    public static void start(final Context context, final List tid, final boolean isCollected)
    {
        com/alipay/mobilesecuritysdk/face/SecurityClientMobile;
        JVM INSTR monitorenter ;
        if(isDebug)
            Log.i("ALP", "start have been called.");
        if(context != null) goto _L2; else goto _L1
_L1:
        if(isDebug)
            Log.i("ALP", "Context is null.");
_L4:
        com/alipay/mobilesecuritysdk/face/SecurityClientMobile;
        JVM INSTR monitorexit ;
        return;
_L2:
        if(workThread != null && workThread.isAlive())
        {
            if(isDebug)
                Log.i("ALP", "mainThread is working, quit.");
            continue; /* Loop/switch isn't completed */
        }
        workThread = null;
        if(isError)
        {
            if(isDebug)
                Log.i("ALP", "some error happend, quit.");
            continue; /* Loop/switch isn't completed */
        }
        break MISSING_BLOCK_LABEL_104;
        Exception exception;
        exception;
        throw exception;
        try
        {
            workThread = new Thread(new Runnable() {

                private final Context val$context;
                private final boolean val$isCollected;
                private final List val$tid;

                public void run()
                {
                    (new MainHandler()).mainhandler(context, tid, isCollected);
_L1:
                    return;
                    Throwable throwable1;
                    throwable1;
                    if(SecurityClientMobile.isDebug)
                        Log.i("ALP", (new StringBuilder("mainThread error :")).append(throwable1.getMessage()).toString());
                      goto _L1
                }

            
            {
                context = context1;
                tid = list;
                isCollected = flag;
                super();
            }
            }
);
            workThread.start();
        }
        catch(Throwable throwable) { }
        if(true) goto _L4; else goto _L3
_L3:
    }

    public static void stop()
    {
        try
        {
            if(isDebug)
                Log.i("ALP", "stop have been called.");
            if(workThread != null && workThread.isAlive())
            {
                workThread.interrupt();
                workThread = null;
            }
        }
        catch(Throwable throwable) { }
    }


}
