// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.alipay.mobilesecuritysdk.constant;


public final class LocationNameEnum extends Enum
{

    public static final LocationNameEnum BSSID;
    public static final LocationNameEnum CDMA;
    public static final LocationNameEnum CURRENT;
    private static final LocationNameEnum ENUM$VALUES[];
    public static final LocationNameEnum GSM;
    public static final LocationNameEnum LEVEL;
    public static final LocationNameEnum LOCATE_CELL_ID;
    public static final LocationNameEnum LOCATE_LAC;
    public static final LocationNameEnum LOCATE_LATITUDE;
    public static final LocationNameEnum LOCATE_LONGITUDE;
    public static final LocationNameEnum LOCATE_WIFI;
    public static final LocationNameEnum LOCATION_ITEM;
    public static final LocationNameEnum MCC;
    public static final LocationNameEnum MNC;
    public static final LocationNameEnum PHONETYPE;
    public static final LocationNameEnum SSID;
    public static final LocationNameEnum START_TAG;
    public static final LocationNameEnum TIME;
    public static final LocationNameEnum TIME_STAMP;
    public static final LocationNameEnum VERSION;
    private String value;

    private LocationNameEnum(String s, int i, String s1)
    {
        super(s, i);
        setValue(s1);
    }

    public static LocationNameEnum valueOf(String s)
    {
        return (LocationNameEnum)Enum.valueOf(com/alipay/mobilesecuritysdk/constant/LocationNameEnum, s);
    }

    public static LocationNameEnum[] values()
    {
        LocationNameEnum alocationnameenum[] = ENUM$VALUES;
        int i = alocationnameenum.length;
        LocationNameEnum alocationnameenum1[] = new LocationNameEnum[i];
        System.arraycopy(alocationnameenum, 0, alocationnameenum1, 0, i);
        return alocationnameenum1;
    }

    public String getValue()
    {
        return value;
    }

    public void setValue(String s)
    {
        value = s;
    }

    static 
    {
        LOCATE_LATITUDE = new LocationNameEnum("LOCATE_LATITUDE", 0, "t");
        LOCATE_LONGITUDE = new LocationNameEnum("LOCATE_LONGITUDE", 1, "g");
        LOCATE_CELL_ID = new LocationNameEnum("LOCATE_CELL_ID", 2, "c");
        LOCATE_LAC = new LocationNameEnum("LOCATE_LAC", 3, "l");
        TIME_STAMP = new LocationNameEnum("TIME_STAMP", 4, "s");
        LOCATE_WIFI = new LocationNameEnum("LOCATE_WIFI", 5, "w");
        LOCATION_ITEM = new LocationNameEnum("LOCATION_ITEM", 6, "locationitem");
        START_TAG = new LocationNameEnum("START_TAG", 7, "locations");
        VERSION = new LocationNameEnum("VERSION", 8, "ver");
        MCC = new LocationNameEnum("MCC", 9, "mcc");
        MNC = new LocationNameEnum("MNC", 10, "mnc");
        PHONETYPE = new LocationNameEnum("PHONETYPE", 11, "phoneType");
        CDMA = new LocationNameEnum("CDMA", 12, "cdma");
        BSSID = new LocationNameEnum("BSSID", 13, "bssid");
        SSID = new LocationNameEnum("SSID", 14, "ssid");
        LEVEL = new LocationNameEnum("LEVEL", 15, "level");
        CURRENT = new LocationNameEnum("CURRENT", 16, "isCurrent");
        TIME = new LocationNameEnum("TIME", 17, "time");
        GSM = new LocationNameEnum("GSM", 18, "gsm");
        LocationNameEnum alocationnameenum[] = new LocationNameEnum[19];
        alocationnameenum[0] = LOCATE_LATITUDE;
        alocationnameenum[1] = LOCATE_LONGITUDE;
        alocationnameenum[2] = LOCATE_CELL_ID;
        alocationnameenum[3] = LOCATE_LAC;
        alocationnameenum[4] = TIME_STAMP;
        alocationnameenum[5] = LOCATE_WIFI;
        alocationnameenum[6] = LOCATION_ITEM;
        alocationnameenum[7] = START_TAG;
        alocationnameenum[8] = VERSION;
        alocationnameenum[9] = MCC;
        alocationnameenum[10] = MNC;
        alocationnameenum[11] = PHONETYPE;
        alocationnameenum[12] = CDMA;
        alocationnameenum[13] = BSSID;
        alocationnameenum[14] = SSID;
        alocationnameenum[15] = LEVEL;
        alocationnameenum[16] = CURRENT;
        alocationnameenum[17] = TIME;
        alocationnameenum[18] = GSM;
        ENUM$VALUES = alocationnameenum;
    }
}
