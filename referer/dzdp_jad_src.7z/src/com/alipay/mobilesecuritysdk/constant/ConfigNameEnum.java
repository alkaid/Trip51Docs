// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.alipay.mobilesecuritysdk.constant;


public final class ConfigNameEnum extends Enum
{

    public static final ConfigNameEnum APP_INTERVAL;
    public static final ConfigNameEnum APP_ITEM;
    public static final ConfigNameEnum APP_LUT;
    public static final ConfigNameEnum CONFIGS;
    private static final ConfigNameEnum ENUM$VALUES[];
    public static final ConfigNameEnum LOCATE_INTERVAL;
    public static final ConfigNameEnum LOCATE_LUT;
    public static final ConfigNameEnum LOCATION_MAX_LINES;
    public static final ConfigNameEnum MAIN_SWITCH_INTERVAL;
    public static final ConfigNameEnum MAIN_SWITCH_LUT;
    public static final ConfigNameEnum MAIN_SWITCH_STATE;
    public static final ConfigNameEnum PACKAGE_CHANGED;
    public static final ConfigNameEnum PKG_NAME;
    public static final ConfigNameEnum PUB_KEY_HASH;
    public static final ConfigNameEnum START_TAG;
    private String value;

    private ConfigNameEnum(String s, int i, String s1)
    {
        super(s, i);
        setValue(s1);
    }

    public static ConfigNameEnum valueOf(String s)
    {
        return (ConfigNameEnum)Enum.valueOf(com/alipay/mobilesecuritysdk/constant/ConfigNameEnum, s);
    }

    public static ConfigNameEnum[] values()
    {
        ConfigNameEnum aconfignameenum[] = ENUM$VALUES;
        int i = aconfignameenum.length;
        ConfigNameEnum aconfignameenum1[] = new ConfigNameEnum[i];
        System.arraycopy(aconfignameenum, 0, aconfignameenum1, 0, i);
        return aconfignameenum1;
    }

    public String getValue()
    {
        return value;
    }

    public void setValue(String s)
    {
        value = s;
    }

    static 
    {
        MAIN_SWITCH_LUT = new ConfigNameEnum("MAIN_SWITCH_LUT", 0, "mainSwitchLUT");
        MAIN_SWITCH_STATE = new ConfigNameEnum("MAIN_SWITCH_STATE", 1, "mainSwitchState");
        MAIN_SWITCH_INTERVAL = new ConfigNameEnum("MAIN_SWITCH_INTERVAL", 2, "mainSwitchInterval");
        LOCATE_LUT = new ConfigNameEnum("LOCATE_LUT", 3, "locateLUT");
        LOCATE_INTERVAL = new ConfigNameEnum("LOCATE_INTERVAL", 4, "locateInterval");
        APP_LUT = new ConfigNameEnum("APP_LUT", 5, "appLUT");
        APP_INTERVAL = new ConfigNameEnum("APP_INTERVAL", 6, "appInterval");
        PACKAGE_CHANGED = new ConfigNameEnum("PACKAGE_CHANGED", 7, "pkgchanged");
        LOCATION_MAX_LINES = new ConfigNameEnum("LOCATION_MAX_LINES", 8, "locationMaxLines");
        CONFIGS = new ConfigNameEnum("CONFIGS", 9, "configs");
        PKG_NAME = new ConfigNameEnum("PKG_NAME", 10, "n");
        PUB_KEY_HASH = new ConfigNameEnum("PUB_KEY_HASH", 11, "h");
        APP_ITEM = new ConfigNameEnum("APP_ITEM", 12, "appitem");
        START_TAG = new ConfigNameEnum("START_TAG", 13, "apps");
        ConfigNameEnum aconfignameenum[] = new ConfigNameEnum[14];
        aconfignameenum[0] = MAIN_SWITCH_LUT;
        aconfignameenum[1] = MAIN_SWITCH_STATE;
        aconfignameenum[2] = MAIN_SWITCH_INTERVAL;
        aconfignameenum[3] = LOCATE_LUT;
        aconfignameenum[4] = LOCATE_INTERVAL;
        aconfignameenum[5] = APP_LUT;
        aconfignameenum[6] = APP_INTERVAL;
        aconfignameenum[7] = PACKAGE_CHANGED;
        aconfignameenum[8] = LOCATION_MAX_LINES;
        aconfignameenum[9] = CONFIGS;
        aconfignameenum[10] = PKG_NAME;
        aconfignameenum[11] = PUB_KEY_HASH;
        aconfignameenum[12] = APP_ITEM;
        aconfignameenum[13] = START_TAG;
        ENUM$VALUES = aconfignameenum;
    }
}
