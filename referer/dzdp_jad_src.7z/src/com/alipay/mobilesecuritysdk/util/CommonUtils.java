// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.alipay.mobilesecuritysdk.util;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Environment;
import android.util.Base64;
import android.util.Log;
import java.io.*;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.zip.GZIPOutputStream;
import org.json.JSONObject;

public class CommonUtils
{

    public CommonUtils()
    {
    }

    public static JSONObject GetJsonFromFile(String s)
    {
        return null;
    }

    public static boolean GetSdCardFile()
    {
        String s = Environment.getExternalStorageState();
        boolean flag;
        if(!IsEmpty(s) && (s.equals("mounted") || s.equals("mounted_ro")) && Environment.getExternalStorageDirectory() != null)
            flag = true;
        else
            flag = false;
        return flag;
    }

    public static boolean IsEmpty(String s)
    {
        boolean flag;
        if(s != null && s.length() > 0)
            flag = false;
        else
            flag = true;
        return flag;
    }

    public static String MD5(String s)
    {
        String s1 = null;
        byte abyte0[];
        StringBuilder stringbuilder;
        int i;
        if(isBlank(s))
            break MISSING_BLOCK_LABEL_100;
        MessageDigest messagedigest = MessageDigest.getInstance("MD5");
        messagedigest.update(s.getBytes("UTF-8"));
        abyte0 = messagedigest.digest();
        stringbuilder = new StringBuilder();
        i = 0;
_L1:
        if(i >= 16)
        {
            s1 = stringbuilder.toString();
            break MISSING_BLOCK_LABEL_100;
        }
        Object aobj[] = new Object[1];
        aobj[0] = Byte.valueOf(abyte0[i]);
        stringbuilder.append(String.format("%02x", aobj));
        i++;
          goto _L1
        Exception exception;
        exception;
        return s1;
    }

    public static String ReadFile(String s)
    {
        if((new File(s)).exists()) goto _L2; else goto _L1
_L1:
        String s1 = null;
_L5:
        return s1;
_L2:
        StringBuilder stringbuilder = new StringBuilder();
        BufferedReader bufferedreader = new BufferedReader(new InputStreamReader(new FileInputStream(s), "UTF-8"));
_L6:
        String s2 = bufferedreader.readLine();
        if(s2 != null) goto _L4; else goto _L3
_L3:
        bufferedreader.close();
_L7:
        s1 = stringbuilder.toString();
          goto _L5
_L4:
        stringbuilder.append(s2);
          goto _L6
        IOException ioexception;
        ioexception;
_L8:
        ioexception.printStackTrace();
          goto _L7
        ioexception;
          goto _L8
    }

    public static void WriteFile(String s, String s1)
        throws IOException
    {
        File file;
        FileWriter filewriter;
        file = new File(s);
        filewriter = null;
        if(file == null)
            break MISSING_BLOCK_LABEL_37;
        FileWriter filewriter1 = new FileWriter(file, false);
        filewriter1.write(s1);
        filewriter1.close();
_L1:
        return;
        Exception exception;
        exception;
_L4:
        Log.d("ConfigNameEnum.CONFIGS.getValue()", exception.getLocalizedMessage());
        filewriter.close();
          goto _L1
        Exception exception1;
        exception1;
_L3:
        filewriter.close();
        throw exception1;
        exception1;
        filewriter = filewriter1;
        if(true) goto _L3; else goto _L2
_L2:
        exception;
        filewriter = filewriter1;
          goto _L4
    }

    public static String convertDate2String(Date date)
    {
        return (new SimpleDateFormat("yyyyMMddHHmmss")).format(date);
    }

    public static boolean equalsIgnoreCase(String s, String s1)
    {
        boolean flag;
        if(s == null)
        {
            if(s1 == null)
                flag = true;
            else
                flag = false;
        } else
        {
            flag = s.equalsIgnoreCase(s1);
        }
        return flag;
    }

    public static boolean isBlank(String s)
    {
        boolean flag = true;
        if(s == null) goto _L2; else goto _L1
_L1:
        int i = s.length();
        if(i != 0) goto _L3; else goto _L2
_L2:
        return flag;
_L3:
        int j = 0;
        do
        {
            if(j < i)
            {
label0:
                {
                    if(Character.isWhitespace(s.charAt(j)))
                        break label0;
                    flag = false;
                }
            }
            if(true)
                continue;
            j++;
        } while(true);
        if(true) goto _L2; else goto _L4
_L4:
    }

    public static boolean isBlankCollection(List list)
    {
        boolean flag;
        flag = true;
        break MISSING_BLOCK_LABEL_2;
label0:
        while(true) 
        {
            do
                return flag;
            while(list == null || list.size() <= 0);
            Iterator iterator = list.iterator();
            do
                if(!iterator.hasNext())
                    continue label0;
            while(isBlank((String)iterator.next()));
            flag = false;
        }
    }

    public static boolean isNetWorkActive(Context context)
    {
        boolean flag = true;
        NetworkInfo networkinfo = ((ConnectivityManager)context.getApplicationContext().getSystemService("connectivity")).getActiveNetworkInfo();
        if(networkinfo == null || !networkinfo.isConnected() || networkinfo.getType() != flag)
            flag = false;
        return flag;
    }

    public static boolean outOfDate(long l, long l1, int i)
    {
        boolean flag;
        flag = true;
        break MISSING_BLOCK_LABEL_3;
        if(l1 > 0L && (System.currentTimeMillis() - l) / l1 < (long)i)
            flag = false;
        return flag;
    }

    public static int string2int(String s)
    {
        int i = 0;
        int j;
        if(isBlank(s))
            break MISSING_BLOCK_LABEL_23;
        j = Integer.parseInt(s);
        i = j;
        break MISSING_BLOCK_LABEL_23;
        Exception exception;
        exception;
        return i;
    }

    public static long string2long(String s)
    {
        long l = 0L;
        long l1;
        if(isBlank(s))
            break MISSING_BLOCK_LABEL_25;
        l1 = Long.parseLong(s);
        l = l1;
        break MISSING_BLOCK_LABEL_25;
        Exception exception;
        exception;
        return l;
    }

    public static String textCompress(String s)
    {
        String s2;
        byte abyte0[] = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(s.length()).array();
        ByteArrayOutputStream bytearrayoutputstream = new ByteArrayOutputStream(s.length());
        GZIPOutputStream gzipoutputstream = new GZIPOutputStream(bytearrayoutputstream);
        gzipoutputstream.write(s.getBytes("UTF-8"));
        gzipoutputstream.close();
        bytearrayoutputstream.close();
        byte abyte1[] = new byte[4 + bytearrayoutputstream.toByteArray().length];
        System.arraycopy(abyte0, 0, abyte1, 0, 4);
        System.arraycopy(bytearrayoutputstream.toByteArray(), 0, abyte1, 4, bytearrayoutputstream.toByteArray().length);
        s2 = Base64.encodeToString(abyte1, 8);
        String s1 = s2;
_L2:
        return s1;
        Exception exception;
        exception;
        Log.i("ALP", exception.getMessage());
        s1 = "";
        if(true) goto _L2; else goto _L1
_L1:
    }
}
