// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.alipay.mobilesecuritysdk.datainfo;

import com.alipay.mobilesecuritysdk.util.CommonUtils;

public class AppInfo
{

    private String pkeyhash;
    private String pkgName;

    public AppInfo()
    {
    }

    public String getPkeyhash()
    {
        return pkeyhash;
    }

    public String getPkgName()
    {
        return pkgName;
    }

    public void setPkeyhash(String s)
    {
        pkeyhash = s;
    }

    public void setPkgName(String s)
    {
        pkgName = s;
    }

    public boolean validate()
    {
        boolean flag;
        if(CommonUtils.isBlank(pkgName) || CommonUtils.isBlank(pkeyhash))
            flag = false;
        else
            flag = true;
        return flag;
    }
}
