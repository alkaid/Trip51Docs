// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.alipay.mobilesecuritysdk.datainfo;

import java.util.ArrayList;
import java.util.List;

public class UploadInfo
{

    private List appinfos;
    private List locates;
    private List tid;

    public UploadInfo()
    {
        locates = new ArrayList();
        appinfos = new ArrayList();
    }

    public List getAppinfos()
    {
        return appinfos;
    }

    public List getLocates()
    {
        return locates;
    }

    public List getTid()
    {
        return tid;
    }

    public void setAppinfos(List list)
    {
        appinfos = list;
    }

    public void setLocates(List list)
    {
        locates = list;
    }

    public void setTid(List list)
    {
        tid = list;
    }
}
