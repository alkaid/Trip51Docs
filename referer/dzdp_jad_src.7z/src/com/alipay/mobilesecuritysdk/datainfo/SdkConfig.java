// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.alipay.mobilesecuritysdk.datainfo;


public class SdkConfig
{

    private static SdkConfig configSingleton = new SdkConfig();
    private int appInterval;
    private long appLUT;
    private int locateInterval;
    private long locateLUT;
    private int locationMaxLines;
    private int mainSwitchInterval;
    private long mainSwitchLUT;
    private String mainSwitchState;

    private SdkConfig()
    {
    }

    public static SdkConfig getInstance()
    {
        return configSingleton;
    }

    public int getAppInterval()
    {
        return appInterval;
    }

    public long getAppLUT()
    {
        return appLUT;
    }

    public int getLocateInterval()
    {
        return locateInterval;
    }

    public long getLocateLUT()
    {
        return locateLUT;
    }

    public int getLocationMaxLines()
    {
        return locationMaxLines;
    }

    public int getMainSwitchInterval()
    {
        return mainSwitchInterval;
    }

    public long getMainSwitchLUT()
    {
        return mainSwitchLUT;
    }

    public String getMainSwitchState()
    {
        return mainSwitchState;
    }

    public void setAppInterval(int i)
    {
        appInterval = i;
    }

    public void setAppLUT(long l)
    {
        appLUT = l;
    }

    public void setLocateInterval(int i)
    {
        locateInterval = i;
    }

    public void setLocateLUT(long l)
    {
        locateLUT = l;
    }

    public void setLocationMaxLines(int i)
    {
        locationMaxLines = i;
    }

    public void setMainSwitchInterval(int i)
    {
        mainSwitchInterval = i;
    }

    public void setMainSwitchLUT(long l)
    {
        mainSwitchLUT = l;
    }

    public void setMainSwitchState(String s)
    {
        mainSwitchState = s;
    }

}
