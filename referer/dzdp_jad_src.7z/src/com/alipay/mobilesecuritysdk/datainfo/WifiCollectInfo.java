// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.alipay.mobilesecuritysdk.datainfo;

import com.alipay.mobilesecuritysdk.util.CommonUtils;

public class WifiCollectInfo
{

    private String mbssid;
    private boolean miscurrent;
    private int mlevel;
    private String mssid;
    private String time;

    public WifiCollectInfo()
    {
        miscurrent = false;
    }

    public String getMbssid()
    {
        return mbssid;
    }

    public int getMlevel()
    {
        return mlevel;
    }

    public String getMssid()
    {
        return mssid;
    }

    public String getTime()
    {
        return time;
    }

    public boolean isMiscurrent()
    {
        return miscurrent;
    }

    public void setMbssid(String s)
    {
        mbssid = s;
    }

    public void setMiscurrent(boolean flag)
    {
        miscurrent = flag;
    }

    public void setMlevel(int i)
    {
        mlevel = i;
    }

    public void setMssid(String s)
    {
        mssid = s;
    }

    public void setTime(String s)
    {
        time = s;
    }

    public boolean validate()
    {
        boolean flag;
        if(CommonUtils.isBlank(mbssid) || CommonUtils.isBlank(mssid))
            flag = false;
        else
            flag = true;
        return flag;
    }
}
