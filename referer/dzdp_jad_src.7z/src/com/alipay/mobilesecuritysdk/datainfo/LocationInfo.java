// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.alipay.mobilesecuritysdk.datainfo;

import com.alipay.mobilesecuritysdk.util.CommonUtils;
import java.math.BigDecimal;
import java.util.List;

public class LocationInfo
{

    private final int DEFINE_NUM = 14400;
    private final double MAX_LATITUDE = 90D;
    private final double MAX_LONGITUDE = 180D;
    private final double MIN_LATITUDE = -90D;
    private final double MIN_LONGITUDE = -180D;
    private String cid;
    private String lac;
    private String latitude;
    private String longitude;
    private String mcc;
    private String mnc;
    private String phonetype;
    private List tid;
    private String time;
    private List wifi;

    public LocationInfo()
    {
    }

    private String toString(double d)
    {
        return String.valueOf((new BigDecimal(d)).setScale(5, 4).doubleValue());
    }

    public String getCid()
    {
        return cid;
    }

    public String getLac()
    {
        return lac;
    }

    public String getLatitude()
    {
        return latitude;
    }

    public String getLongitude()
    {
        return longitude;
    }

    public String getMcc()
    {
        return mcc;
    }

    public String getMnc()
    {
        return mnc;
    }

    public String getPhonetype()
    {
        return phonetype;
    }

    public List getTid()
    {
        return tid;
    }

    public String getTime()
    {
        return time;
    }

    public List getWifi()
    {
        return wifi;
    }

    public void setCid(String s)
    {
        cid = s;
    }

    public void setLac(String s)
    {
        lac = s;
    }

    public void setLatitude(double d)
    {
        if(d < 90D && d > -90D)
            latitude = toString(d);
    }

    public void setLatitude(int i)
    {
        setLatitude((double)i / 14400D);
    }

    public void setLatitude(String s)
    {
        latitude = s;
    }

    public void setLongitude(double d)
    {
        if(d < 180D && d > -180D)
            longitude = toString(d);
    }

    public void setLongitude(int i)
    {
        setLongitude((double)i / 14400D);
    }

    public void setLongitude(String s)
    {
        longitude = s;
    }

    public void setMcc(String s)
    {
        mcc = s;
    }

    public void setMnc(String s)
    {
        mnc = s;
    }

    public void setPhonetype(String s)
    {
        phonetype = s;
    }

    public void setTid(List list)
    {
        tid = list;
    }

    public void setTime(String s)
    {
        time = s;
    }

    public void setWifi(List list)
    {
        wifi = list;
    }

    public boolean validate()
    {
        boolean flag;
        if((CommonUtils.isBlank(latitude) || CommonUtils.isBlank(longitude)) && (CommonUtils.isBlank(cid) || CommonUtils.isBlank(lac)))
            flag = false;
        else
            flag = true;
        return flag;
    }
}
