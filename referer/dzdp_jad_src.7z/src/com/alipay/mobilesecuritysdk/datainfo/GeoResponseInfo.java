// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.alipay.mobilesecuritysdk.datainfo;


public class GeoResponseInfo
{

    private int appInterval;
    private boolean isSuccess;
    private int locateInterval;
    private int locationMaxLines;
    private int mainSwitchInterval;
    private String mainSwitchState;

    public GeoResponseInfo()
    {
    }

    public int getAppInterval()
    {
        return appInterval;
    }

    public int getLocateInterval()
    {
        return locateInterval;
    }

    public int getLocationMaxLines()
    {
        return locationMaxLines;
    }

    public int getMainSwitchInterval()
    {
        return mainSwitchInterval;
    }

    public String getMainSwitchState()
    {
        return mainSwitchState;
    }

    public boolean isSuccess()
    {
        return isSuccess;
    }

    public void setAppInterval(int i)
    {
        appInterval = i;
    }

    public void setLocateInterval(int i)
    {
        locateInterval = i;
    }

    public void setLocationMaxLines(int i)
    {
        locationMaxLines = i;
    }

    public void setMainSwitchInterval(int i)
    {
        mainSwitchInterval = i;
    }

    public void setMainSwitchState(String s)
    {
        mainSwitchState = s;
    }

    public void setSuccess(boolean flag)
    {
        isSuccess = flag;
    }
}
