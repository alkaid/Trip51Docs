// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.alipay.mobilesecuritysdk;

import android.content.Context;
import android.util.Log;
import com.alipay.mobilesecuritysdk.datainfo.GeoResponseInfo;
import com.alipay.mobilesecuritysdk.datainfo.SdkConfig;
import com.alipay.mobilesecuritysdk.datainfo.UploadInfo;
import com.alipay.mobilesecuritysdk.face.SecurityClientMobile;
import com.alipay.mobilesecuritysdk.model.CollectedInfo;
import com.alipay.mobilesecuritysdk.model.DataProfile;
import com.alipay.mobilesecuritysdk.model.Upload;
import com.alipay.mobilesecuritysdk.util.CommonUtils;
import java.io.File;
import java.util.List;

public class MainHandler
{

    public MainHandler()
    {
    }

    public int mainhandler(Context context, List list, boolean flag)
    {
        if(flag) goto _L2; else goto _L1
_L1:
        int i = 1;
_L4:
        return i;
_L2:
label0:
        {
label1:
            {
                DataProfile dataprofile = new DataProfile();
                Upload upload = new Upload(context);
                UploadInfo uploadinfo = new UploadInfo();
                CollectedInfo collectedinfo = new CollectedInfo();
                try
                {
                    if(CommonUtils.isBlankCollection(list))
                    {
                        if(SecurityClientMobile.isDebug())
                            Log.i("ALP", "tid is empty, quit!");
                        break label1;
                    }
                    long l = System.currentTimeMillis();
                    SdkConfig sdkconfig = dataprofile.getConfigs(context.getFilesDir().getPath());
                    if(sdkconfig == null)
                    {
                        if(SecurityClientMobile.isDebug())
                            Log.i("ALP", "loadConfig is null");
                        break label0;
                    }
                    if(Thread.currentThread().isInterrupted())
                    {
                        i = 1;
                        continue; /* Loop/switch isn't completed */
                    }
                    if(CommonUtils.outOfDate(sdkconfig.getMainSwitchLUT(), 0x5265c00L, sdkconfig.getMainSwitchInterval()))
                    {
                        GeoResponseInfo georesponseinfo1 = upload.communicateSwitch();
                        if(georesponseinfo1 != null && georesponseinfo1.isSuccess())
                        {
                            if(!CommonUtils.isBlank(georesponseinfo1.getMainSwitchState()))
                            {
                                if(SecurityClientMobile.isDebug())
                                    Log.i("ALP", "main switch updated.");
                                if(CommonUtils.equalsIgnoreCase(georesponseinfo1.getMainSwitchState(), "on"))
                                    sdkconfig.setMainSwitchState("on");
                                else
                                    sdkconfig.setMainSwitchState("off");
                            }
                            sdkconfig.setMainSwitchLUT(l);
                            dataprofile.saveConfigs(sdkconfig, (new StringBuilder(String.valueOf(context.getFilesDir().getPath()))).append(File.separator).append("seccliconfig.xml").toString());
                        }
                    }
                    if(Thread.currentThread().isInterrupted())
                    {
                        i = 1;
                        continue; /* Loop/switch isn't completed */
                    }
                    if(!CommonUtils.equalsIgnoreCase("on", sdkconfig.getMainSwitchState()))
                    {
                        if(SecurityClientMobile.isDebug())
                            Log.i("ALP", "main switch is off, quit!");
                        break MISSING_BLOCK_LABEL_673;
                    }
                    if(CommonUtils.outOfDate(sdkconfig.getLocateLUT(), 60000L, sdkconfig.getLocateInterval()))
                    {
                        List list2 = collectedinfo.collectLocateInfos(context);
                        if(list2 != null && list2.size() > 0)
                        {
                            if(SecurityClientMobile.isDebug())
                                Log.i("ALP", "location collected.");
                            uploadinfo.setLocates(list2);
                            sdkconfig.setLocateLUT(l);
                        }
                    }
                    if(Thread.currentThread().isInterrupted())
                    {
                        i = 1;
                        continue; /* Loop/switch isn't completed */
                    }
                    if(CommonUtils.outOfDate(sdkconfig.getAppLUT(), 0x5265c00L, sdkconfig.getAppInterval()))
                    {
                        List list1 = collectedinfo.collectappInfos(context);
                        if(list1 != null && list1.size() > 0)
                        {
                            if(SecurityClientMobile.isDebug())
                                Log.i("ALP", "app info collected.");
                            uploadinfo.setAppinfos(list1);
                            sdkconfig.setAppLUT(l);
                        }
                    }
                    if(Thread.currentThread().isInterrupted())
                    {
                        i = 1;
                        continue; /* Loop/switch isn't completed */
                    }
                    upload.setInfo(uploadinfo);
                    GeoResponseInfo georesponseinfo = upload.uploadData(list, sdkconfig);
                    if(georesponseinfo != null && georesponseinfo.isSuccess())
                    {
                        if(SecurityClientMobile.isDebug())
                            Log.i("ALP", "data have been upload.");
                        if(georesponseinfo.getMainSwitchInterval() > 0)
                            sdkconfig.setMainSwitchInterval(georesponseinfo.getMainSwitchInterval());
                        if(georesponseinfo.getLocateInterval() > 0)
                            sdkconfig.setLocateInterval(georesponseinfo.getLocateInterval());
                        if(georesponseinfo.getAppInterval() > 0)
                            sdkconfig.setAppInterval(georesponseinfo.getAppInterval());
                        if(georesponseinfo.getLocationMaxLines() > 0)
                            sdkconfig.setLocationMaxLines(georesponseinfo.getLocationMaxLines());
                        dataprofile.cleanUploadFiles(context.getFilesDir().getPath());
                    }
                    dataprofile.saveConfigs(sdkconfig, (new StringBuilder(String.valueOf(context.getFilesDir().getPath()))).append(File.separator).append("seccliconfig.xml").toString());
                }
                catch(Exception exception)
                {
                    i = 1;
                    continue; /* Loop/switch isn't completed */
                }
                i = 0;
                continue; /* Loop/switch isn't completed */
            }
            i = 1;
            continue; /* Loop/switch isn't completed */
        }
        i = 1;
        continue; /* Loop/switch isn't completed */
        i = 0;
        if(true) goto _L4; else goto _L3
_L3:
    }
}
