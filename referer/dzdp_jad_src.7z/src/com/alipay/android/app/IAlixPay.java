// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.alipay.android.app;

import android.os.*;

// Referenced classes of package com.alipay.android.app:
//            IRemoteServiceCallback

public interface IAlixPay
    extends IInterface
{
    public static abstract class Stub extends Binder
        implements IAlixPay
    {
        private static class a
            implements IAlixPay
        {

            private IBinder a;

            private static String a()
            {
                return "com.alipay.android.app.IAlixPay";
            }

            public final String Pay(String s)
                throws RemoteException
            {
                Parcel parcel;
                Parcel parcel1;
                parcel = Parcel.obtain();
                parcel1 = Parcel.obtain();
                String s1;
                parcel.writeInterfaceToken("com.alipay.android.app.IAlixPay");
                parcel.writeString(s);
                a.transact(1, parcel, parcel1, 0);
                parcel1.readException();
                s1 = parcel1.readString();
                parcel1.recycle();
                parcel.recycle();
                return s1;
                Exception exception;
                exception;
                parcel1.recycle();
                parcel.recycle();
                throw exception;
            }

            public final IBinder asBinder()
            {
                return a;
            }

            public final String prePay(String s)
                throws RemoteException
            {
                Parcel parcel;
                Parcel parcel1;
                parcel = Parcel.obtain();
                parcel1 = Parcel.obtain();
                String s1;
                parcel.writeInterfaceToken("com.alipay.android.app.IAlixPay");
                parcel.writeString(s);
                a.transact(5, parcel, parcel1, 0);
                parcel1.readException();
                s1 = parcel1.readString();
                parcel1.recycle();
                parcel.recycle();
                return s1;
                Exception exception;
                exception;
                parcel1.recycle();
                parcel.recycle();
                throw exception;
            }

            public final void registerCallback(IRemoteServiceCallback iremoteservicecallback)
                throws RemoteException
            {
                Parcel parcel;
                Parcel parcel1;
                parcel = Parcel.obtain();
                parcel1 = Parcel.obtain();
                IBinder ibinder;
                parcel.writeInterfaceToken("com.alipay.android.app.IAlixPay");
                if(iremoteservicecallback == null)
                    break MISSING_BLOCK_LABEL_59;
                ibinder = iremoteservicecallback.asBinder();
_L1:
                parcel.writeStrongBinder(ibinder);
                a.transact(3, parcel, parcel1, 0);
                parcel1.readException();
                parcel1.recycle();
                parcel.recycle();
                return;
                ibinder = null;
                  goto _L1
                Exception exception;
                exception;
                parcel1.recycle();
                parcel.recycle();
                throw exception;
            }

            public final String test()
                throws RemoteException
            {
                Parcel parcel;
                Parcel parcel1;
                parcel = Parcel.obtain();
                parcel1 = Parcel.obtain();
                String s;
                parcel.writeInterfaceToken("com.alipay.android.app.IAlixPay");
                a.transact(2, parcel, parcel1, 0);
                parcel1.readException();
                s = parcel1.readString();
                parcel1.recycle();
                parcel.recycle();
                return s;
                Exception exception;
                exception;
                parcel1.recycle();
                parcel.recycle();
                throw exception;
            }

            public final void unregisterCallback(IRemoteServiceCallback iremoteservicecallback)
                throws RemoteException
            {
                Parcel parcel;
                Parcel parcel1;
                parcel = Parcel.obtain();
                parcel1 = Parcel.obtain();
                IBinder ibinder;
                parcel.writeInterfaceToken("com.alipay.android.app.IAlixPay");
                if(iremoteservicecallback == null)
                    break MISSING_BLOCK_LABEL_59;
                ibinder = iremoteservicecallback.asBinder();
_L1:
                parcel.writeStrongBinder(ibinder);
                a.transact(4, parcel, parcel1, 0);
                parcel1.readException();
                parcel1.recycle();
                parcel.recycle();
                return;
                ibinder = null;
                  goto _L1
                Exception exception;
                exception;
                parcel1.recycle();
                parcel.recycle();
                throw exception;
            }

            a(IBinder ibinder)
            {
                a = ibinder;
            }
        }


        private static final String DESCRIPTOR = "com.alipay.android.app.IAlixPay";
        static final int TRANSACTION_Pay = 1;
        static final int TRANSACTION_prePay = 5;
        static final int TRANSACTION_registerCallback = 3;
        static final int TRANSACTION_test = 2;
        static final int TRANSACTION_unregisterCallback = 4;

        public static IAlixPay asInterface(IBinder ibinder)
        {
            Object obj;
            if(ibinder == null)
            {
                obj = null;
            } else
            {
                IInterface iinterface = ibinder.queryLocalInterface("com.alipay.android.app.IAlixPay");
                if(iinterface != null && (iinterface instanceof IAlixPay))
                    obj = (IAlixPay)iinterface;
                else
                    obj = new a(ibinder);
            }
            return ((IAlixPay) (obj));
        }

        public IBinder asBinder()
        {
            return this;
        }

        public boolean onTransact(int i, Parcel parcel, Parcel parcel1, int j)
            throws RemoteException
        {
            boolean flag = true;
            i;
            JVM INSTR lookupswitch 6: default 64
        //                       1: 87
        //                       2: 116
        //                       3: 141
        //                       4: 165
        //                       5: 189
        //                       1598968902: 78;
               goto _L1 _L2 _L3 _L4 _L5 _L6 _L7
_L1:
            flag = super.onTransact(i, parcel, parcel1, j);
_L9:
            return flag;
_L7:
            parcel1.writeString("com.alipay.android.app.IAlixPay");
            continue; /* Loop/switch isn't completed */
_L2:
            parcel.enforceInterface("com.alipay.android.app.IAlixPay");
            String s2 = Pay(parcel.readString());
            parcel1.writeNoException();
            parcel1.writeString(s2);
            continue; /* Loop/switch isn't completed */
_L3:
            parcel.enforceInterface("com.alipay.android.app.IAlixPay");
            String s1 = test();
            parcel1.writeNoException();
            parcel1.writeString(s1);
            continue; /* Loop/switch isn't completed */
_L4:
            parcel.enforceInterface("com.alipay.android.app.IAlixPay");
            registerCallback(IRemoteServiceCallback.Stub.asInterface(parcel.readStrongBinder()));
            parcel1.writeNoException();
            continue; /* Loop/switch isn't completed */
_L5:
            parcel.enforceInterface("com.alipay.android.app.IAlixPay");
            unregisterCallback(IRemoteServiceCallback.Stub.asInterface(parcel.readStrongBinder()));
            parcel1.writeNoException();
            continue; /* Loop/switch isn't completed */
_L6:
            parcel.enforceInterface("com.alipay.android.app.IAlixPay");
            String s = prePay(parcel.readString());
            parcel1.writeNoException();
            parcel1.writeString(s);
            if(true) goto _L9; else goto _L8
_L8:
        }

        public Stub()
        {
            attachInterface(this, "com.alipay.android.app.IAlixPay");
        }
    }


    public abstract String Pay(String s)
        throws RemoteException;

    public abstract String prePay(String s)
        throws RemoteException;

    public abstract void registerCallback(IRemoteServiceCallback iremoteservicecallback)
        throws RemoteException;

    public abstract String test()
        throws RemoteException;

    public abstract void unregisterCallback(IRemoteServiceCallback iremoteservicecallback)
        throws RemoteException;
}
