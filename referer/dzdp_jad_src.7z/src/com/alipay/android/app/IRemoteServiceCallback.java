// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.alipay.android.app;

import android.os.*;

public interface IRemoteServiceCallback
    extends IInterface
{
    public static abstract class Stub extends Binder
        implements IRemoteServiceCallback
    {
        private static class a
            implements IRemoteServiceCallback
        {

            private IBinder a;

            private static String a()
            {
                return "com.alipay.android.app.IRemoteServiceCallback";
            }

            public final IBinder asBinder()
            {
                return a;
            }

            public final boolean isHideLoadingScreen()
                throws RemoteException
            {
                boolean flag;
                Parcel parcel;
                Parcel parcel1;
                flag = false;
                parcel = Parcel.obtain();
                parcel1 = Parcel.obtain();
                int i;
                parcel.writeInterfaceToken("com.alipay.android.app.IRemoteServiceCallback");
                a.transact(3, parcel, parcel1, 0);
                parcel1.readException();
                i = parcel1.readInt();
                if(i != 0)
                    flag = true;
                parcel1.recycle();
                parcel.recycle();
                return flag;
                Exception exception;
                exception;
                parcel1.recycle();
                parcel.recycle();
                throw exception;
            }

            public final void payEnd(boolean flag, String s)
                throws RemoteException
            {
                int i;
                Parcel parcel;
                Parcel parcel1;
                i = 0;
                parcel = Parcel.obtain();
                parcel1 = Parcel.obtain();
                parcel.writeInterfaceToken("com.alipay.android.app.IRemoteServiceCallback");
                if(flag)
                    i = 1;
                parcel.writeInt(i);
                parcel.writeString(s);
                a.transact(2, parcel, parcel1, 0);
                parcel1.readException();
                parcel1.recycle();
                parcel.recycle();
                return;
                Exception exception;
                exception;
                parcel1.recycle();
                parcel.recycle();
                throw exception;
            }

            public final void startActivity(String s, String s1, int i, Bundle bundle)
                throws RemoteException
            {
                Parcel parcel;
                Parcel parcel1;
                parcel = Parcel.obtain();
                parcel1 = Parcel.obtain();
                parcel.writeInterfaceToken("com.alipay.android.app.IRemoteServiceCallback");
                parcel.writeString(s);
                parcel.writeString(s1);
                parcel.writeInt(i);
                if(bundle == null)
                    break MISSING_BLOCK_LABEL_86;
                parcel.writeInt(1);
                bundle.writeToParcel(parcel, 0);
_L1:
                a.transact(1, parcel, parcel1, 0);
                parcel1.readException();
                parcel1.recycle();
                parcel.recycle();
                return;
                parcel.writeInt(0);
                  goto _L1
                Exception exception;
                exception;
                parcel1.recycle();
                parcel.recycle();
                throw exception;
            }

            a(IBinder ibinder)
            {
                a = ibinder;
            }
        }


        private static final String DESCRIPTOR = "com.alipay.android.app.IRemoteServiceCallback";
        static final int TRANSACTION_isHideLoadingScreen = 3;
        static final int TRANSACTION_payEnd = 2;
        static final int TRANSACTION_startActivity = 1;

        public static IRemoteServiceCallback asInterface(IBinder ibinder)
        {
            Object obj;
            if(ibinder == null)
            {
                obj = null;
            } else
            {
                IInterface iinterface = ibinder.queryLocalInterface("com.alipay.android.app.IRemoteServiceCallback");
                if(iinterface != null && (iinterface instanceof IRemoteServiceCallback))
                    obj = (IRemoteServiceCallback)iinterface;
                else
                    obj = new a(ibinder);
            }
            return ((IRemoteServiceCallback) (obj));
        }

        public IBinder asBinder()
        {
            return this;
        }

        public boolean onTransact(int i, Parcel parcel, Parcel parcel1, int j)
            throws RemoteException
        {
            boolean flag;
            boolean flag1;
            flag = false;
            flag1 = true;
            i;
            JVM INSTR lookupswitch 4: default 48
        //                       1: 71
        //                       2: 141
        //                       3: 175
        //                       1598968902: 62;
               goto _L1 _L2 _L3 _L4 _L5
_L1:
            flag1 = super.onTransact(i, parcel, parcel1, j);
_L7:
            return flag1;
_L5:
            parcel1.writeString("com.alipay.android.app.IRemoteServiceCallback");
            continue; /* Loop/switch isn't completed */
_L2:
            parcel.enforceInterface("com.alipay.android.app.IRemoteServiceCallback");
            String s = parcel.readString();
            String s1 = parcel.readString();
            int k = parcel.readInt();
            Bundle bundle;
            if(parcel.readInt() != 0)
                bundle = (Bundle)Bundle.CREATOR.createFromParcel(parcel);
            else
                bundle = null;
            startActivity(s, s1, k, bundle);
            parcel1.writeNoException();
            continue; /* Loop/switch isn't completed */
_L3:
            parcel.enforceInterface("com.alipay.android.app.IRemoteServiceCallback");
            if(parcel.readInt() != 0)
                flag = flag1;
            payEnd(flag, parcel.readString());
            parcel1.writeNoException();
            continue; /* Loop/switch isn't completed */
_L4:
            parcel.enforceInterface("com.alipay.android.app.IRemoteServiceCallback");
            boolean flag2 = isHideLoadingScreen();
            parcel1.writeNoException();
            if(flag2)
                flag = flag1;
            parcel1.writeInt(flag);
            if(true) goto _L7; else goto _L6
_L6:
        }

        public Stub()
        {
            attachInterface(this, "com.alipay.android.app.IRemoteServiceCallback");
        }
    }


    public abstract boolean isHideLoadingScreen()
        throws RemoteException;

    public abstract void payEnd(boolean flag, String s)
        throws RemoteException;

    public abstract void startActivity(String s, String s1, int i, Bundle bundle)
        throws RemoteException;
}
