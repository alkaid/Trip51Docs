// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.alipay.sdk.auth;

import android.app.Activity;
import android.content.*;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;

// Referenced classes of package com.alipay.sdk.auth:
//            APAuthInfo, AuthActivity

public class AuthHelper
{

    private static final String a = "com.eg.android.AlipayGphone";
    private static final int b = 65;

    public AuthHelper()
    {
    }

    public static void a(Activity activity, APAuthInfo apauthinfo)
    {
        if(a(((Context) (activity))))
        {
            StringBuilder stringbuilder = new StringBuilder();
            stringbuilder.append("alipayauth://platformapi/startapp");
            stringbuilder.append("?appId=20000122");
            stringbuilder.append("&approveType=005");
            stringbuilder.append("&scope=kuaijie");
            stringbuilder.append("&productId=");
            stringbuilder.append(apauthinfo.getProductId());
            stringbuilder.append("&thirdpartyId=");
            stringbuilder.append(apauthinfo.getAppId());
            stringbuilder.append("&redirectUri=");
            stringbuilder.append(apauthinfo.getRedirectUri());
            a(activity, stringbuilder.toString());
        } else
        {
            StringBuilder stringbuilder1 = new StringBuilder();
            stringbuilder1.append("app_id=");
            stringbuilder1.append(apauthinfo.getAppId());
            stringbuilder1.append("&partner=");
            stringbuilder1.append(apauthinfo.getPid());
            stringbuilder1.append("&scope=kuaijie");
            stringbuilder1.append("&login_goal=auth");
            stringbuilder1.append("&redirect_url=");
            stringbuilder1.append(apauthinfo.getRedirectUri());
            stringbuilder1.append("&view=wap");
            stringbuilder1.append("&prod_code=");
            stringbuilder1.append(apauthinfo.getProductId());
            Intent intent = new Intent(activity, com/alipay/sdk/auth/AuthActivity);
            intent.putExtra("params", stringbuilder1.toString());
            intent.putExtra("redirectUri", apauthinfo.getRedirectUri());
            activity.startActivity(intent);
        }
    }

    public static void a(Activity activity, String s)
    {
        Intent intent = new Intent("android.intent.action.VIEW");
        intent.setData(Uri.parse(s));
        activity.startActivity(intent);
_L2:
        return;
        ActivityNotFoundException activitynotfoundexception;
        activitynotfoundexception;
        if(true) goto _L2; else goto _L1
_L1:
    }

    private static boolean a(Context context)
    {
        boolean flag = false;
        int i;
        PackageInfo packageinfo = context.getPackageManager().getPackageInfo("com.eg.android.AlipayGphone", 128);
        if(packageinfo == null)
            break MISSING_BLOCK_LABEL_41;
        i = packageinfo.versionCode;
        if(i >= 65)
            flag = true;
        break MISSING_BLOCK_LABEL_41;
        android.content.pm.PackageManager.NameNotFoundException namenotfoundexception;
        namenotfoundexception;
        return flag;
    }

    private static void b(Activity activity, APAuthInfo apauthinfo)
    {
        StringBuilder stringbuilder = new StringBuilder();
        stringbuilder.append("alipayauth://platformapi/startapp");
        stringbuilder.append("?appId=20000122");
        stringbuilder.append("&approveType=005");
        stringbuilder.append("&scope=kuaijie");
        stringbuilder.append("&productId=");
        stringbuilder.append(apauthinfo.getProductId());
        stringbuilder.append("&thirdpartyId=");
        stringbuilder.append(apauthinfo.getAppId());
        stringbuilder.append("&redirectUri=");
        stringbuilder.append(apauthinfo.getRedirectUri());
        a(activity, stringbuilder.toString());
    }

    private static void c(Activity activity, APAuthInfo apauthinfo)
    {
        StringBuilder stringbuilder = new StringBuilder();
        stringbuilder.append("app_id=");
        stringbuilder.append(apauthinfo.getAppId());
        stringbuilder.append("&partner=");
        stringbuilder.append(apauthinfo.getPid());
        stringbuilder.append("&scope=kuaijie");
        stringbuilder.append("&login_goal=auth");
        stringbuilder.append("&redirect_url=");
        stringbuilder.append(apauthinfo.getRedirectUri());
        stringbuilder.append("&view=wap");
        stringbuilder.append("&prod_code=");
        stringbuilder.append(apauthinfo.getProductId());
        Intent intent = new Intent(activity, com/alipay/sdk/auth/AuthActivity);
        intent.putExtra("params", stringbuilder.toString());
        intent.putExtra("redirectUri", apauthinfo.getRedirectUri());
        activity.startActivity(intent);
    }
}
