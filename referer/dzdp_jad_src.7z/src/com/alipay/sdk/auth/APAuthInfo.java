// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.alipay.sdk.auth;


public class APAuthInfo
{

    private String a;
    private String b;
    private String c;
    private String d;

    public APAuthInfo(String s, String s1, String s2)
    {
        this(s, s1, s2, null);
    }

    public APAuthInfo(String s, String s1, String s2, String s3)
    {
        a = s;
        b = s1;
        d = s2;
        c = s3;
    }

    public String getAppId()
    {
        return a;
    }

    public String getPid()
    {
        return c;
    }

    public String getProductId()
    {
        return b;
    }

    public String getRedirectUri()
    {
        return d;
    }
}
