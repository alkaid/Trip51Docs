// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.alipay.sdk.auth;

import android.app.Activity;

// Referenced classes of package com.alipay.sdk.auth:
//            AuthHelper, APAuthInfo

public class AlipaySDK
{

    public AlipaySDK()
    {
    }

    public static void auth(Activity activity, APAuthInfo apauthinfo)
    {
        AuthHelper.a(activity, apauthinfo);
    }
}
