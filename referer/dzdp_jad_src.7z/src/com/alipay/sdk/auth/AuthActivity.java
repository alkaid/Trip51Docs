// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.alipay.sdk.auth;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.net.http.SslError;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.webkit.*;
import android.widget.LinearLayout;
import com.alipay.sdk.authjs.CallInfo;
import com.alipay.sdk.authjs.JsBridge;
import com.alipay.sdk.data.*;
import com.alipay.sdk.exception.FailOperatingException;
import com.alipay.sdk.exception.NetErrorException;
import com.alipay.sdk.net.RequestWrapper;
import com.alipay.sdk.protocol.*;
import com.alipay.sdk.sys.GlobalContext;
import com.alipay.sdk.util.ActionUtil;
import com.alipay.sdk.util.Utils;
import com.alipay.sdk.widget.Loading;
import java.lang.reflect.Method;
import org.json.JSONException;
import org.json.JSONObject;

// Referenced classes of package com.alipay.sdk.auth:
//            AuthHelper

public class AuthActivity extends Activity
{
    private class MyWebChromeClient extends WebChromeClient
    {

        final AuthActivity a;

        public boolean onConsoleMessage(ConsoleMessage consolemessage)
        {
            String s = consolemessage.message();
            boolean flag;
            if(TextUtils.isEmpty(s))
            {
                flag = super.onConsoleMessage(consolemessage);
            } else
            {
                String s1 = null;
                if(s.startsWith("h5container.message: "))
                    s1 = s.replaceFirst("h5container.message: ", "");
                if(TextUtils.isEmpty(s1))
                {
                    flag = super.onConsoleMessage(consolemessage);
                } else
                {
                    AuthActivity.b(a, s1);
                    flag = super.onConsoleMessage(consolemessage);
                }
            }
            return flag;
        }

        private MyWebChromeClient()
        {
            a = AuthActivity.this;
            super();
        }

        MyWebChromeClient(byte byte0)
        {
            this();
        }
    }

    private class MyWebViewClient extends WebViewClient
    {

        final AuthActivity a;

        public void onPageFinished(WebView webview, String s)
        {
            AuthActivity.i(a);
            AuthActivity.h(a).removeCallbacks(AuthActivity.g(a));
        }

        public void onPageStarted(WebView webview, String s, Bitmap bitmap)
        {
            AuthActivity.f(a);
            AuthActivity.h(a).postDelayed(AuthActivity.g(a), 30000L);
            super.onPageStarted(webview, s, bitmap);
        }

        public void onReceivedSslError(WebView webview, SslErrorHandler sslerrorhandler, SslError sslerror)
        {
            class _cls1
                implements Runnable
            {

                final SslErrorHandler a;
                final MyWebViewClient b;

                public void run()
                {
                    class _cls1
                        implements android.content.DialogInterface.OnClickListener
                    {

                        final _cls1 a;

                        public void onClick(DialogInterface dialoginterface, int j)
                        {
                            AuthActivity.a(a.b.a, true);
                            a.a.proceed();
                            dialoginterface.dismiss();
                        }

                            _cls1()
                            {
                                a = _cls1.this;
                                super();
                            }
                    }

                    class _cls2
                        implements android.content.DialogInterface.OnClickListener
                    {

                        final _cls1 a;

                        public void onClick(DialogInterface dialoginterface, int j)
                        {
                            a.a.cancel();
                            AuthActivity.a(a.b.a, false);
                            Result.a(Result.b());
                            a.b.a.finish();
                        }

                            _cls2()
                            {
                                a = _cls1.this;
                                super();
                            }
                    }

                    SystemDefaultDialog.a(b.a, "\u5B89\u5168\u8B66\u544A", "\u7531\u4E8E\u60A8\u7684\u8BBE\u5907\u7F3A\u5C11\u6839\u8BC1\u4E66\uFF0C\u5C06\u65E0\u6CD5\u6821\u9A8C\u8BE5\u8BBF\u95EE\u7AD9\u70B9\u7684\u5B89\u5168\u6027\uFF0C\u53EF\u80FD\u5B58\u5728\u98CE\u9669\uFF0C\u8BF7\u9009\u62E9\u662F\u5426\u7EE7\u7EED\uFF1F", "\u7EE7\u7EED", new _cls1(), "\u9000\u51FA", new _cls2());
                }

                _cls1(SslErrorHandler sslerrorhandler)
                {
                    b = MyWebViewClient.this;
                    a = sslerrorhandler;
                    super();
                }
            }

            if(AuthActivity.e(a))
            {
                sslerrorhandler.proceed();
                AuthActivity.a(a, false);
            } else
            {
                a.runOnUiThread(new _cls1(sslerrorhandler));
            }
        }

        public boolean shouldOverrideUrlLoading(WebView webview, String s)
        {
            boolean flag;
            if(AuthActivity.a(a, s))
            {
                webview.stopLoading();
                flag = true;
            } else
            {
                flag = super.shouldOverrideUrlLoading(webview, s);
            }
            return flag;
        }

        private MyWebViewClient()
        {
            a = AuthActivity.this;
            super();
        }

        MyWebViewClient(byte byte0)
        {
            this();
        }
    }


    static final String a = "params";
    static final String b = "redirectUri";
    private WebView c;
    private String d;
    private Loading e;
    private Handler f;
    private boolean g;
    private Runnable h;

    public AuthActivity()
    {
        f = new Handler();
        h = new _cls11();
    }

    private void a()
    {
        d();
        String s;
        s = getIntent().getExtras().getString("params");
        d = getIntent().getExtras().getString("redirectUri");
        Request request;
        RequestWrapper requestwrapper;
        request = FrameUtils.a(new InteractionData(), s, new JSONObject());
        request.d().c("com.alipay.mobilecashier");
        request.d().a("com.alipay.mcpay");
        request.d().e("4.0.0");
        request.d().d("/cashier/main");
        requestwrapper = new RequestWrapper(new InteractionData());
        JSONObject jsonobject = requestwrapper.a(this, request, false).c();
        e();
        a(jsonobject);
        e();
_L1:
        return;
        Exception exception;
        exception;
        e();
        finish();
          goto _L1
        NetErrorException neterrorexception;
        neterrorexception;
        runOnUiThread(new _cls3());
        e();
          goto _L1
        Exception exception2;
        exception2;
        runOnUiThread(new _cls4());
        e();
          goto _L1
        Exception exception1;
        exception1;
        e();
        throw exception1;
    }

    static void a(AuthActivity authactivity)
    {
        authactivity.d();
        String s;
        s = authactivity.getIntent().getExtras().getString("params");
        authactivity.d = authactivity.getIntent().getExtras().getString("redirectUri");
        Request request;
        RequestWrapper requestwrapper;
        request = FrameUtils.a(new InteractionData(), s, new JSONObject());
        request.d().c("com.alipay.mobilecashier");
        request.d().a("com.alipay.mcpay");
        request.d().e("4.0.0");
        request.d().d("/cashier/main");
        requestwrapper = new RequestWrapper(new InteractionData());
        JSONObject jsonobject = requestwrapper.a(authactivity, request, false).c();
        authactivity.e();
        authactivity.a(jsonobject);
        authactivity.e();
_L1:
        return;
        Exception exception;
        exception;
        authactivity.e();
        authactivity.finish();
          goto _L1
        NetErrorException neterrorexception;
        neterrorexception;
        authactivity.runOnUiThread(authactivity. new _cls3());
        authactivity.e();
          goto _L1
        Exception exception2;
        exception2;
        authactivity.runOnUiThread(authactivity. new _cls4());
        authactivity.e();
          goto _L1
        Exception exception1;
        exception1;
        authactivity.e();
        throw exception1;
    }

    static void a(AuthActivity authactivity, CallInfo callinfo)
    {
        if(authactivity.c != null && callinfo != null)
            try
            {
                String s = callinfo.d();
                Object aobj[] = new Object[1];
                aobj[0] = s;
                authactivity.runOnUiThread(authactivity. new _cls10(String.format("AlipayJSBridge._invokeJS(%s)", aobj)));
            }
            catch(JSONException jsonexception)
            {
                jsonexception.printStackTrace();
            }
    }

    private void a(CallInfo callinfo)
    {
        if(c != null && callinfo != null)
            try
            {
                String s = callinfo.d();
                Object aobj[] = new Object[1];
                aobj[0] = s;
                runOnUiThread(new _cls10(String.format("AlipayJSBridge._invokeJS(%s)", aobj)));
            }
            catch(JSONException jsonexception)
            {
                jsonexception.printStackTrace();
            }
    }

    private void a(JSONObject jsonobject)
        throws FailOperatingException
    {
        ElementAction elementaction = ElementAction.a(jsonobject.optJSONObject("form"), "onload");
        if(elementaction == null)
            throw new FailOperatingException();
        ActionType aactiontype[] = ActionType.a(elementaction);
        int j = aactiontype.length;
        int k = 0;
        do
        {
label0:
            {
                if(k < j)
                {
                    ActionType actiontype = aactiontype[k];
                    if(actiontype != ActionType.a)
                        break label0;
                    String s = ActionUtil.a(actiontype.e())[0];
                    if(!Utils.a(s))
                        finish();
                    else
                        runOnUiThread(new _cls5(s));
                }
                return;
            }
            k++;
        } while(true);
    }

    static boolean a(AuthActivity authactivity, String s)
    {
        boolean flag;
        flag = false;
        break MISSING_BLOCK_LABEL_2;
        if(!TextUtils.isEmpty(s) && !s.startsWith("http://") && !s.startsWith("https://"))
        {
            if(!"SDKLite://h5quit".equalsIgnoreCase(s))
            {
                if(TextUtils.equals(s, authactivity.d))
                    s = (new StringBuilder()).append(s).append("?resultCode=150").toString();
                AuthHelper.a(authactivity, s);
            }
            authactivity.finish();
            flag = true;
        }
        return flag;
    }

    static boolean a(AuthActivity authactivity, boolean flag)
    {
        authactivity.g = flag;
        return flag;
    }

    private boolean a(String s)
    {
        boolean flag;
        flag = false;
        break MISSING_BLOCK_LABEL_2;
        if(!TextUtils.isEmpty(s) && !s.startsWith("http://") && !s.startsWith("https://"))
        {
            if(!"SDKLite://h5quit".equalsIgnoreCase(s))
            {
                if(TextUtils.equals(s, d))
                    s = (new StringBuilder()).append(s).append("?resultCode=150").toString();
                AuthHelper.a(this, s);
            }
            finish();
            flag = true;
        }
        return flag;
    }

    private void b()
    {
        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        builder.setMessage("\u4E0D\u80FD\u8FDE\u63A5\u5230\u670D\u52A1\u5668\uFF0C\u662F\u5426\u91CD\u8BD5\uFF1F");
        builder.setPositiveButton("\u786E\u5B9A", new _cls6());
        builder.setNeutralButton("\u53D6\u6D88", new _cls7());
        builder.create().show();
    }

    static void b(AuthActivity authactivity)
    {
        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(authactivity);
        builder.setMessage("\u4E0D\u80FD\u8FDE\u63A5\u5230\u670D\u52A1\u5668\uFF0C\u662F\u5426\u91CD\u8BD5\uFF1F");
        builder.setPositiveButton("\u786E\u5B9A", authactivity. new _cls6());
        builder.setNeutralButton("\u53D6\u6D88", authactivity. new _cls7());
        builder.create().show();
    }

    static void b(AuthActivity authactivity, String s)
    {
        (new JsBridge(authactivity, authactivity. new _cls9())).a(s);
    }

    private void b(String s)
    {
        (new JsBridge(this, new _cls9())).a(s);
    }

    private void c()
    {
        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        builder.setMessage("\u7CFB\u7EDF\u7E41\u5FD9\uFF0C\u8BF7\u7A0D\u540E\u518D\u8BD5");
        builder.setNeutralButton("\u786E\u5B9A", new _cls8());
        builder.create().show();
    }

    static void c(AuthActivity authactivity)
    {
        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(authactivity);
        builder.setMessage("\u7CFB\u7EDF\u7E41\u5FD9\uFF0C\u8BF7\u7A0D\u540E\u518D\u8BD5");
        builder.setNeutralButton("\u786E\u5B9A", authactivity. new _cls8());
        builder.create().show();
    }

    static WebView d(AuthActivity authactivity)
    {
        return authactivity.c;
    }

    private void d()
    {
        if(e == null)
            e = new Loading(this);
        e.b();
_L1:
        return;
        Exception exception;
        exception;
        e = null;
          goto _L1
    }

    private void e()
    {
        if(e != null && e.a())
            e.c();
        e = null;
    }

    static boolean e(AuthActivity authactivity)
    {
        return authactivity.g;
    }

    static void f(AuthActivity authactivity)
    {
        authactivity.d();
    }

    static Runnable g(AuthActivity authactivity)
    {
        return authactivity.h;
    }

    static Handler h(AuthActivity authactivity)
    {
        return authactivity.f;
    }

    static void i(AuthActivity authactivity)
    {
        authactivity.e();
    }

    public void onConfigurationChanged(Configuration configuration)
    {
        super.onConfigurationChanged(configuration);
    }

    protected void onCreate(Bundle bundle)
    {
        super.onCreate(bundle);
        if(getIntent().getExtras() != null) goto _L2; else goto _L1
_L1:
        finish();
_L4:
        return;
_L2:
        super.requestWindowFeature(1);
        GlobalContext.a().a(this, MspConfig.a());
        LinearLayout linearlayout = new LinearLayout(this);
        android.widget.LinearLayout.LayoutParams layoutparams = new android.widget.LinearLayout.LayoutParams(-1, -1);
        linearlayout.setOrientation(1);
        setContentView(linearlayout, layoutparams);
        c = new WebView(this);
        layoutparams.weight = 1.0F;
        c.setVisibility(0);
        linearlayout.addView(c, layoutparams);
        WebSettings websettings = c.getSettings();
        websettings.setUserAgentString((new StringBuilder()).append(websettings.getUserAgentString()).append(Utils.c(this)).toString());
        websettings.setRenderPriority(android.webkit.WebSettings.RenderPriority.HIGH);
        websettings.setSupportMultipleWindows(true);
        websettings.setJavaScriptEnabled(true);
        websettings.setSavePassword(false);
        websettings.setJavaScriptCanOpenWindowsAutomatically(true);
        websettings.setMinimumFontSize(8 + websettings.getMinimumFontSize());
        websettings.setAllowFileAccess(false);
        c.setVerticalScrollbarOverlay(true);
        c.setWebViewClient(new MyWebViewClient((byte)0));
        c.setWebChromeClient(new MyWebChromeClient((byte)0));
        c.setDownloadListener(new _cls1());
        (new Thread(new _cls2())).start();
        if(android.os.Build.VERSION.SDK_INT >= 7)
            try
            {
                Class class1 = c.getSettings().getClass();
                Class aclass[] = new Class[1];
                aclass[0] = Boolean.TYPE;
                Method method1 = class1.getMethod("setDomStorageEnabled", aclass);
                if(method1 != null)
                {
                    WebSettings websettings1 = c.getSettings();
                    Object aobj1[] = new Object[1];
                    aobj1[0] = Boolean.valueOf(true);
                    method1.invoke(websettings1, aobj1);
                }
            }
            catch(Exception exception1) { }
        try
        {
            Method method = c.getClass().getMethod("removeJavascriptInterface", new Class[0]);
            if(method != null)
            {
                WebView webview = c;
                Object aobj[] = new Object[1];
                aobj[0] = "searchBoxJavaBridge_";
                method.invoke(webview, aobj);
            }
        }
        catch(Exception exception) { }
        if(true) goto _L4; else goto _L3
_L3:
    }

    protected void onDestroy()
    {
        super.onDestroy();
    }

    private class _cls11
        implements Runnable
    {

        final AuthActivity a;

        public void run()
        {
            AuthActivity.i(a);
            AuthActivity.b(a);
        }

        _cls11()
        {
            a = AuthActivity.this;
            super();
        }
    }


    private class _cls3
        implements Runnable
    {

        final AuthActivity a;

        public void run()
        {
            AuthActivity.b(a);
        }

        _cls3()
        {
            a = AuthActivity.this;
            super();
        }
    }


    private class _cls4
        implements Runnable
    {

        final AuthActivity a;

        public void run()
        {
            AuthActivity.c(a);
        }

        _cls4()
        {
            a = AuthActivity.this;
            super();
        }
    }


    private class _cls10
        implements Runnable
    {

        final String a;
        final AuthActivity b;

        public void run()
        {
            AuthActivity.d(b).loadUrl((new StringBuilder("javascript:")).append(a).toString());
_L1:
            return;
            Exception exception;
            exception;
            exception.printStackTrace();
              goto _L1
        }

        _cls10(String s)
        {
            b = AuthActivity.this;
            a = s;
            super();
        }
    }


    private class _cls5
        implements Runnable
    {

        final String a;
        final AuthActivity b;

        public void run()
        {
            AuthActivity.d(b).loadUrl(a);
        }

        _cls5(String s)
        {
            b = AuthActivity.this;
            a = s;
            super();
        }
    }


    private class _cls6
        implements android.content.DialogInterface.OnClickListener
    {

        final AuthActivity a;

        public void onClick(DialogInterface dialoginterface, int j)
        {
            class _cls1 extends Thread
            {

                final _cls6 a;

                public void run()
                {
                    AuthActivity.a(a.a);
                }

                _cls1()
                {
                    a = _cls6.this;
                    super();
                }
            }

            (new _cls1()).start();
        }

        _cls6()
        {
            a = AuthActivity.this;
            super();
        }
    }


    private class _cls7
        implements android.content.DialogInterface.OnClickListener
    {

        final AuthActivity a;

        public void onClick(DialogInterface dialoginterface, int j)
        {
            a.finish();
        }

        _cls7()
        {
            a = AuthActivity.this;
            super();
        }
    }


    private class _cls9
        implements IJsCallback
    {

        final AuthActivity a;

        public final void a(CallInfo callinfo)
        {
            AuthActivity.a(a, callinfo);
        }

        _cls9()
        {
            a = AuthActivity.this;
            super();
        }
    }


    private class _cls8
        implements android.content.DialogInterface.OnClickListener
    {

        final AuthActivity a;

        public void onClick(DialogInterface dialoginterface, int j)
        {
            a.finish();
        }

        _cls8()
        {
            a = AuthActivity.this;
            super();
        }
    }


    private class _cls1
        implements DownloadListener
    {

        final AuthActivity a;

        public void onDownloadStart(String s, String s1, String s2, String s3, long l)
        {
            Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(s));
            a.startActivity(intent);
        }

        _cls1()
        {
            a = AuthActivity.this;
            super();
        }
    }


    private class _cls2
        implements Runnable
    {

        final AuthActivity a;

        public void run()
        {
            AuthActivity.a(a);
        }

        _cls2()
        {
            a = AuthActivity.this;
            super();
        }
    }

}
