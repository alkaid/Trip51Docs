// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.alipay.sdk.sys;

import android.content.Context;
import android.text.TextUtils;
import com.alipay.sdk.data.MspConfig;
import com.alipay.sdk.util.Utils;
import com.ta.utdid2.device.UTDevice;
import java.io.*;

public class GlobalContext
{

    private static GlobalContext a;
    private Context b;
    private MspConfig c;

    private GlobalContext()
    {
    }

    public static GlobalContext a()
    {
        if(a == null)
            a = new GlobalContext();
        return a;
    }

    private static String a(String as[])
    {
        Process process1;
        ProcessBuilder processbuilder = new ProcessBuilder(as);
        processbuilder.redirectErrorStream(false);
        process1 = processbuilder.start();
        Process process = process1;
        Exception exception;
        Exception exception1;
        Exception exception2;
        Exception exception3;
        String s;
        Exception exception4;
        DataOutputStream dataoutputstream;
        String s1;
        Exception exception7;
        try
        {
            dataoutputstream = new DataOutputStream(process.getOutputStream());
            s1 = (new DataInputStream(process.getInputStream())).readLine();
        }
        catch(Exception exception5)
        {
            s = "";
            continue; /* Loop/switch isn't completed */
        }
_L1:
        s = s1;
        dataoutputstream.writeBytes("exit\n");
        dataoutputstream.flush();
        process.waitFor();
        try
        {
            process.destroy();
        }
        // Misplaced declaration of an exception variable
        catch(Exception exception7) { }
        return s;
        exception3;
        process = null;
        s = "";
_L4:
        try
        {
            process.destroy();
        }
        // Misplaced declaration of an exception variable
        catch(Exception exception4) { }
        if(true)
            break MISSING_BLOCK_LABEL_78;
        exception;
        process = null;
        exception1 = exception;
_L2:
        try
        {
            process.destroy();
        }
        // Misplaced declaration of an exception variable
        catch(Exception exception2) { }
        throw exception1;
        exception1;
        if(true) goto _L2; else goto _L1
        Exception exception6;
        exception6;
        if(true) goto _L4; else goto _L3
_L3:
    }

    private static boolean a(String s)
    {
        char ac[] = new char[65];
        ac[0] = 'A';
        ac[1] = 'B';
        ac[2] = 'C';
        ac[3] = 'D';
        ac[4] = 'E';
        ac[5] = 'F';
        ac[6] = 'G';
        ac[7] = 'H';
        ac[8] = 'I';
        ac[9] = 'J';
        ac[10] = 'K';
        ac[11] = 'L';
        ac[12] = 'M';
        ac[13] = 'N';
        ac[14] = 'O';
        ac[15] = 'P';
        ac[16] = 'Q';
        ac[17] = 'R';
        ac[18] = 'S';
        ac[19] = 'T';
        ac[20] = 'U';
        ac[21] = 'V';
        ac[22] = 'W';
        ac[23] = 'X';
        ac[24] = 'Y';
        ac[25] = 'Z';
        ac[26] = 'a';
        ac[27] = 'b';
        ac[28] = 'c';
        ac[29] = 'd';
        ac[30] = 'e';
        ac[31] = 'f';
        ac[32] = 'g';
        ac[33] = 'h';
        ac[34] = 'i';
        ac[35] = 'j';
        ac[36] = 'k';
        ac[37] = 'l';
        ac[38] = 'm';
        ac[39] = 'n';
        ac[40] = 'o';
        ac[41] = 'p';
        ac[42] = 'q';
        ac[43] = 'r';
        ac[44] = 's';
        ac[45] = 't';
        ac[46] = 'u';
        ac[47] = 'v';
        ac[48] = 'w';
        ac[49] = 'x';
        ac[50] = 'y';
        ac[51] = 'z';
        ac[52] = '0';
        ac[53] = '1';
        ac[54] = '2';
        ac[55] = '3';
        ac[56] = '4';
        ac[57] = '5';
        ac[58] = '6';
        ac[59] = '7';
        ac[60] = '8';
        ac[61] = '9';
        ac[62] = '+';
        ac[63] = '/';
        ac[64] = '=';
        char ac1[] = s.toCharArray();
        int i = ac1.length;
        int j = 0;
        boolean flag = false;
        do
        {
            if(j >= i)
                break;
            char c1 = ac1[j];
            int k = ac.length;
            int l = 0;
            flag = false;
            for(; l < k; l++)
                if(c1 == ac[l])
                    flag = true;

            if(!flag)
                break;
            j++;
        } while(true);
        return flag;
    }

    public static boolean d()
    {
        return false;
    }

    public static boolean e()
    {
        boolean flag;
        String as[];
        int i;
        flag = true;
        as = new String[5];
        as[0] = "/system/xbin/";
        as[flag] = "/system/bin/";
        as[2] = "/system/sbin/";
        as[3] = "/sbin/";
        as[4] = "/vendor/bin/";
        i = 0;
_L6:
        String s;
        if(i >= as.length)
            break MISSING_BLOCK_LABEL_153;
        s = (new StringBuilder()).append(as[i]).append("su").toString();
        if(!(new File(s)).exists()) goto _L2; else goto _L1
_L1:
        String s1;
        String as1[] = new String[3];
        as1[0] = "ls";
        as1[1] = "-l";
        as1[2] = s;
        s1 = a(as1);
        if(TextUtils.isEmpty(s1)) goto _L4; else goto _L3
_L3:
        int j;
        int k;
        j = s1.indexOf("root");
        k = s1.lastIndexOf("root");
        if(j != k) goto _L5; else goto _L4
_L4:
        flag = false;
_L5:
        return flag;
_L2:
        i++;
          goto _L6
        Exception exception;
        exception;
        flag = false;
          goto _L5
    }

    public static String f()
    {
        return Utils.d();
    }

    public final void a(Context context, MspConfig mspconfig)
    {
        b = context.getApplicationContext();
        c = mspconfig;
    }

    public final Context b()
    {
        return b;
    }

    public final MspConfig c()
    {
        return c;
    }

    public final String g()
    {
        String s = UTDevice.getUtdid(b);
        if(TextUtils.isEmpty(s)) goto _L2; else goto _L1
_L1:
        boolean flag;
        char ac[] = new char[65];
        ac[0] = 'A';
        ac[1] = 'B';
        ac[2] = 'C';
        ac[3] = 'D';
        ac[4] = 'E';
        ac[5] = 'F';
        ac[6] = 'G';
        ac[7] = 'H';
        ac[8] = 'I';
        ac[9] = 'J';
        ac[10] = 'K';
        ac[11] = 'L';
        ac[12] = 'M';
        ac[13] = 'N';
        ac[14] = 'O';
        ac[15] = 'P';
        ac[16] = 'Q';
        ac[17] = 'R';
        ac[18] = 'S';
        ac[19] = 'T';
        ac[20] = 'U';
        ac[21] = 'V';
        ac[22] = 'W';
        ac[23] = 'X';
        ac[24] = 'Y';
        ac[25] = 'Z';
        ac[26] = 'a';
        ac[27] = 'b';
        ac[28] = 'c';
        ac[29] = 'd';
        ac[30] = 'e';
        ac[31] = 'f';
        ac[32] = 'g';
        ac[33] = 'h';
        ac[34] = 'i';
        ac[35] = 'j';
        ac[36] = 'k';
        ac[37] = 'l';
        ac[38] = 'm';
        ac[39] = 'n';
        ac[40] = 'o';
        ac[41] = 'p';
        ac[42] = 'q';
        ac[43] = 'r';
        ac[44] = 's';
        ac[45] = 't';
        ac[46] = 'u';
        ac[47] = 'v';
        ac[48] = 'w';
        ac[49] = 'x';
        ac[50] = 'y';
        ac[51] = 'z';
        ac[52] = '0';
        ac[53] = '1';
        ac[54] = '2';
        ac[55] = '3';
        ac[56] = '4';
        ac[57] = '5';
        ac[58] = '6';
        ac[59] = '7';
        ac[60] = '8';
        ac[61] = '9';
        ac[62] = '+';
        ac[63] = '/';
        ac[64] = '=';
        char ac1[] = s.toCharArray();
        int i = ac1.length;
        int j = 0;
        flag = false;
        do
        {
            if(j >= i)
                break;
            char c1 = ac1[j];
            int k = ac.length;
            int l = 0;
            flag = false;
            for(; l < k; l++)
                if(c1 == ac[l])
                    flag = true;

            if(!flag)
                break;
            j++;
        } while(true);
        if(!flag) goto _L2; else goto _L3
_L3:
        String s1 = s;
_L5:
        return s1;
_L2:
        s1 = "";
        if(true) goto _L5; else goto _L4
_L4:
    }
}
