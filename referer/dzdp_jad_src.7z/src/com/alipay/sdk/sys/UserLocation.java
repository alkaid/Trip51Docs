// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.alipay.sdk.sys;

import android.content.Context;
import android.location.Location;
import android.location.LocationManager;

public class UserLocation
{

    private static double a = -1D;
    private static double b = -1D;

    public UserLocation()
    {
    }

    public static String a()
    {
        return (new StringBuilder()).append(b).append(";").append(a).toString();
    }

    private static void a(Context context)
    {
        LocationManager locationmanager = (LocationManager)context.getSystemService("location");
        if(locationmanager.isProviderEnabled("gps"))
        {
            Location location = locationmanager.getLastKnownLocation("gps");
            if(location != null)
            {
                a = location.getLatitude();
                b = location.getLongitude();
            }
        }
_L2:
        return;
        Exception exception;
        exception;
        if(true) goto _L2; else goto _L1
_L1:
    }

    private static double b()
    {
        return a;
    }

    private static double c()
    {
        return b;
    }

}
