// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.alipay.sdk.protocol;

import android.text.TextUtils;
import com.alipay.sdk.data.*;
import com.alipay.sdk.exception.*;
import com.alipay.sdk.tid.TidInfo;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import org.json.JSONException;
import org.json.JSONObject;

// Referenced classes of package com.alipay.sdk.protocol:
//            FrameData, MiniWindowFrame, MiniStatus

public class MiniFrameFactory
{

    public MiniFrameFactory()
    {
    }

    public static MiniWindowFrame a(FrameData framedata)
        throws NetErrorException, FailOperatingException, AppErrorException
    {
        Request request;
        Response response;
        JSONObject jsonobject;
        String s;
        request = framedata.a();
        response = framedata.b();
        jsonobject = framedata.c();
        s = "\u7A0B\u5E8F\u53D1\u751F\u9519\u8BEF";
        if(!jsonobject.has("form")) goto _L2; else goto _L1
_L1:
        MiniWindowFrame miniwindowframe;
        miniwindowframe = new MiniWindowFrame(request, response);
        miniwindowframe.a(framedata.c());
_L4:
        return miniwindowframe;
_L2:
        if(jsonobject.has("status"))
        {
            MiniStatus ministatus = MiniStatus.a(jsonobject.optString("status"));
            class _cls1
            {

                static final int a[];

                static 
                {
                    a = new int[MiniStatus.values().length];
                    NoSuchFieldError nosuchfielderror3;
                    try
                    {
                        a[MiniStatus.a.ordinal()] = 1;
                    }
                    catch(NoSuchFieldError nosuchfielderror) { }
                    try
                    {
                        a[MiniStatus.d.ordinal()] = 2;
                    }
                    catch(NoSuchFieldError nosuchfielderror1) { }
                    try
                    {
                        a[MiniStatus.c.ordinal()] = 3;
                    }
                    catch(NoSuchFieldError nosuchfielderror2) { }
                    a[MiniStatus.b.ordinal()] = 4;
_L2:
                    return;
                    nosuchfielderror3;
                    if(true) goto _L2; else goto _L1
_L1:
                }
            }

            switch(_cls1.a[ministatus.ordinal()])
            {
            default:
                String s1 = jsonobject.optString("msg");
                if(!TextUtils.isEmpty(s1))
                    s = s1;
                throw new FailOperatingException(s);

            case 1: // '\001'
            case 2: // '\002'
            case 3: // '\003'
                miniwindowframe = new MiniWindowFrame(request, response);
                miniwindowframe.a(jsonobject);
                break;

            case 4: // '\004'
                TidInfo.d();
                miniwindowframe = null;
                break;
            }
        } else
        {
            throw new FailOperatingException(s);
        }
        if(true) goto _L4; else goto _L3
_L3:
    }

    public final void b(FrameData framedata)
        throws NetErrorException, FailOperatingException, AppErrorException
    {
        Response response = framedata.b();
        JSONObject jsonobject = framedata.c();
        Envelope envelope = framedata.a().d();
        Envelope envelope1 = framedata.b().a();
        if(TextUtils.isEmpty(envelope1.d()))
            envelope1.d(envelope.d());
        if(TextUtils.isEmpty(envelope1.e()))
            envelope1.e(envelope.e());
        if(TextUtils.isEmpty(envelope1.c()))
            envelope1.c(envelope.c());
        if(TextUtils.isEmpty(envelope1.b()))
            envelope1.b(envelope.b());
        JSONObject jsonobject1 = jsonobject.optJSONObject("reflected_data");
        String s1;
        String s2;
        if(jsonobject1 != null)
        {
            (new StringBuilder("session = ")).append(jsonobject1.optString("session", "")).toString();
            framedata.b().a(jsonobject1);
        } else
        if(jsonobject.has("session"))
        {
            JSONObject jsonobject2 = new JSONObject();
            try
            {
                jsonobject2.put("session", jsonobject.optString("session"));
                String s = TidInfo.c().a();
                if(!TextUtils.isEmpty(s))
                    jsonobject2.put("tid", s);
                response.a(jsonobject2);
            }
            catch(JSONException jsonexception)
            {
                throw new AppErrorException(getClass(), "can not put reflected values");
            }
        }
        response.b(jsonobject.optString("end_code", "0"));
        response.e(jsonobject.optString("user_id", ""));
        s1 = jsonobject.optString("result");
        s2 = URLDecoder.decode(jsonobject.optString("result"), "UTF-8");
        s1 = s2;
_L2:
        response.c(s1);
        response.d(jsonobject.optString("memo", ""));
        return;
        UnsupportedEncodingException unsupportedencodingexception;
        unsupportedencodingexception;
        if(true) goto _L2; else goto _L1
_L1:
    }
}
