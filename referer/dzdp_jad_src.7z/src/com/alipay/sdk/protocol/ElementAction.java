// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.alipay.sdk.protocol;

import android.text.TextUtils;
import com.alipay.sdk.cons.GlobalConstants;
import org.json.JSONObject;

// Referenced classes of package com.alipay.sdk.protocol:
//            ActionType

public class ElementAction
{

    private String a;
    private String b;
    private String c;
    private String d;
    private String e;
    private boolean f;
    private boolean g;
    private boolean h;
    private String i;
    private String j;
    private String k;
    private JSONObject l;

    private ElementAction(String s)
    {
        g = true;
        h = true;
        a = s;
    }

    public static ElementAction a(String s, ActionType actiontype)
    {
        return a(s, actiontype.f(), actiontype.l(), actiontype.g(), actiontype.h(), actiontype.i(), actiontype.j(), actiontype.k(), actiontype.c(), actiontype.d(), actiontype.b(), actiontype.a());
    }

    private static ElementAction a(String s, String s1, String s2, String s3, String s4, boolean flag, boolean flag1, boolean flag2, 
            String s5, String s6, String s7, JSONObject jsonobject)
    {
        Object obj = null;
        if(!TextUtils.isEmpty(s))
        {
            ElementAction elementaction = new ElementAction(s);
            elementaction.a = s;
            if(!TextUtils.isEmpty(s1))
                obj = s1.trim();
            elementaction.b = ((String) (obj));
            elementaction.c = s2;
            elementaction.d = s3;
            elementaction.e = s4;
            elementaction.f = flag;
            elementaction.g = flag1;
            elementaction.h = flag2;
            elementaction.i = s5;
            elementaction.j = s6;
            elementaction.k = s7;
            elementaction.l = jsonobject;
            obj = elementaction;
        }
        return ((ElementAction) (obj));
    }

    private static ElementAction a(JSONObject jsonobject)
    {
        String s = null;
        boolean flag = true;
        String s1;
        String s2;
        String s3;
        String s4;
        boolean flag1;
        boolean flag2;
        String s5;
        String s6;
        String s7;
        if(jsonobject != null && jsonobject.has("name"))
            s1 = jsonobject.optString("name");
        else
            s1 = null;
        if(jsonobject != null && jsonobject.has("host"))
            s2 = jsonobject.optString("host");
        else
            s2 = null;
        if(jsonobject != null && jsonobject.has("params"))
            s3 = jsonobject.optString("params");
        else
            s3 = null;
        if(jsonobject != null && jsonobject.has("enctype"))
            s4 = jsonobject.optString("enctype");
        else
            s4 = null;
        if(jsonobject != null && jsonobject.has("request_param"))
            s = jsonobject.optString("request_param");
        if(jsonobject != null && jsonobject.has("validate"))
            flag1 = jsonobject.optBoolean("validate", flag);
        else
            flag1 = flag;
        if(jsonobject != null && jsonobject.has("https"))
        {
            if(!jsonobject.optBoolean("https"))
                flag2 = flag;
            else
                flag2 = false;
        } else
        {
            flag2 = flag;
        }
        if(jsonobject != null && jsonobject.has("formSubmit"))
            flag = jsonobject.optBoolean("formSubmit");
        s5 = "";
        if(jsonobject != null && jsonobject.has("namespace"))
            s5 = jsonobject.optString("namespace");
        s6 = "";
        if(jsonobject != null && jsonobject.has("apiVersion"))
            s6 = jsonobject.optString("apiVersion");
        s7 = "";
        if(jsonobject != null && jsonobject.has("apiName"))
            s7 = jsonobject.optString("apiName");
        return a(s1, s2, s3, s4, s, flag1, flag2, flag, s5, s6, s7, jsonobject);
    }

    public static ElementAction a(JSONObject jsonobject, String s)
    {
        String s1 = null;
        boolean flag = true;
        JSONObject jsonobject1 = jsonobject.optJSONObject(s);
        String s2;
        String s3;
        String s4;
        String s5;
        boolean flag1;
        boolean flag2;
        String s6;
        String s7;
        String s8;
        if(jsonobject1 != null && jsonobject1.has("name"))
            s2 = jsonobject1.optString("name");
        else
            s2 = null;
        if(jsonobject1 != null && jsonobject1.has("host"))
            s3 = jsonobject1.optString("host");
        else
            s3 = null;
        if(jsonobject1 != null && jsonobject1.has("params"))
            s4 = jsonobject1.optString("params");
        else
            s4 = null;
        if(jsonobject1 != null && jsonobject1.has("enctype"))
            s5 = jsonobject1.optString("enctype");
        else
            s5 = null;
        if(jsonobject1 != null && jsonobject1.has("request_param"))
            s1 = jsonobject1.optString("request_param");
        if(jsonobject1 != null && jsonobject1.has("validate"))
            flag1 = jsonobject1.optBoolean("validate", flag);
        else
            flag1 = flag;
        if(jsonobject1 != null && jsonobject1.has("https"))
        {
            if(!jsonobject1.optBoolean("https"))
                flag2 = flag;
            else
                flag2 = false;
        } else
        {
            flag2 = flag;
        }
        if(jsonobject1 != null && jsonobject1.has("formSubmit"))
            flag = jsonobject1.optBoolean("formSubmit");
        s6 = "";
        if(jsonobject1 != null && jsonobject1.has("namespace"))
            s6 = jsonobject1.optString("namespace");
        s7 = "";
        if(jsonobject1 != null && jsonobject1.has("apiVersion"))
            s7 = jsonobject1.optString("apiVersion");
        s8 = "";
        if(jsonobject1 != null && jsonobject1.has("apiName"))
            s8 = jsonobject1.optString("apiName");
        return a(s2, s3, s4, s5, s1, flag1, flag2, flag, s6, s7, s8, jsonobject1);
    }

    public final JSONObject a()
    {
        return l;
    }

    public final String b()
    {
        return k;
    }

    public final String c()
    {
        return i;
    }

    public final String d()
    {
        return j;
    }

    public final String e()
    {
        return a;
    }

    public final String f()
    {
        if(TextUtils.isEmpty(b))
            b = GlobalConstants.b;
        return b;
    }

    public final String g()
    {
        return c;
    }

    public final JSONObject h()
    {
        JSONObject jsonobject;
        try
        {
            jsonobject = new JSONObject(c);
        }
        catch(Exception exception)
        {
            jsonobject = null;
        }
        return jsonobject;
    }

    public final String i()
    {
        return d;
    }

    public final String j()
    {
        return e;
    }

    public final boolean k()
    {
        return f;
    }

    public final boolean l()
    {
        return g;
    }

    public final boolean m()
    {
        return h;
    }
}
