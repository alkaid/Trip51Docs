// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.alipay.sdk.protocol;

import android.text.TextUtils;
import org.json.JSONObject;

// Referenced classes of package com.alipay.sdk.protocol:
//            ElementAction

public final class ActionType extends Enum
{

    public static final ActionType a;
    public static final ActionType b;
    public static final ActionType c;
    public static final ActionType d;
    public static final ActionType e;
    public static final ActionType f;
    public static final ActionType g;
    private static final ActionType v[];
    private String h;
    private String i;
    private String j;
    private JSONObject k;
    private String l;
    private String m;
    private String n;
    private boolean o;
    private boolean p;
    private boolean q;
    private String r;
    private String s;
    private String t;
    private JSONObject u;

    private ActionType(String s1, int i1, String s2)
    {
        super(s1, i1);
        h = s2;
    }

    public static ActionType[] a(ElementAction elementaction)
    {
        if(elementaction == null) goto _L2; else goto _L1
_L1:
        String s1 = elementaction.e();
        ActionType aactiontype[];
        String as[];
        ActionType aactiontype1[];
        int i1;
        int j1;
        int k1;
        String s2;
        ActionType actiontype;
        ActionType aactiontype2[];
        int l1;
        int i2;
        ActionType actiontype1;
        int j2;
        if(!TextUtils.isEmpty(s1))
            as = s1.split(";");
        else
            as = null;
        if(as != null) goto _L4; else goto _L3
_L3:
        aactiontype = new ActionType[1];
        aactiontype[0] = c;
_L11:
        return aactiontype;
_L4:
        aactiontype1 = new ActionType[as.length];
        i1 = as.length;
        j1 = 0;
        k1 = 0;
_L9:
        if(j1 >= i1) goto _L6; else goto _L5
_L5:
        s2 = as[j1];
        actiontype = c;
        aactiontype2 = values();
        l1 = aactiontype2.length;
        i2 = 0;
_L10:
        if(i2 >= l1)
            break MISSING_BLOCK_LABEL_279;
        actiontype1 = aactiontype2[i2];
        if(!s2.startsWith(actiontype1.h)) goto _L8; else goto _L7
_L7:
        actiontype1.i = s2;
        actiontype1.j = elementaction.f();
        actiontype1.k = elementaction.h();
        actiontype1.l = elementaction.g();
        actiontype1.m = elementaction.i();
        actiontype1.n = elementaction.j();
        actiontype1.o = elementaction.k();
        actiontype1.p = elementaction.l();
        actiontype1.q = elementaction.m();
        actiontype1.r = elementaction.c();
        actiontype1.s = elementaction.d();
        actiontype1.t = elementaction.b();
        actiontype1.u = elementaction.a();
        aactiontype1[k1] = actiontype1;
        j2 = k1 + 1;
        j1++;
        k1 = j2;
          goto _L9
_L8:
        i2++;
          goto _L10
_L6:
        aactiontype = aactiontype1;
          goto _L11
_L2:
        aactiontype = new ActionType[1];
        aactiontype[0] = c;
          goto _L11
        actiontype1 = actiontype;
          goto _L7
    }

    private static String[] a(String s1)
    {
        String as[] = null;
        if(!TextUtils.isEmpty(s1))
            as = s1.split(";");
        return as;
    }

    private JSONObject m()
    {
        return k;
    }

    public static ActionType valueOf(String s1)
    {
        return (ActionType)Enum.valueOf(com/alipay/sdk/protocol/ActionType, s1);
    }

    public static ActionType[] values()
    {
        return (ActionType[])v.clone();
    }

    public final JSONObject a()
    {
        return u;
    }

    public final String b()
    {
        return t;
    }

    public final String c()
    {
        return r;
    }

    public final String d()
    {
        return s;
    }

    public final String e()
    {
        return i;
    }

    public final String f()
    {
        return j;
    }

    public final String g()
    {
        return m;
    }

    public final String h()
    {
        return n;
    }

    public final boolean i()
    {
        return o;
    }

    public final boolean j()
    {
        return p;
    }

    public final boolean k()
    {
        return q;
    }

    public final String l()
    {
        return l;
    }

    static 
    {
        a = new ActionType("WapPay", 0, "js://wappay");
        b = new ActionType("DownLoad", 1, "js://download");
        c = new ActionType("Submit", 2, "submit");
        d = new ActionType("Confirm", 3, "js://confirm");
        e = new ActionType("Alert", 4, "js://alert");
        f = new ActionType("Update", 5, "js://update");
        g = new ActionType("Exit", 6, "js://exit");
        ActionType aactiontype[] = new ActionType[7];
        aactiontype[0] = a;
        aactiontype[1] = b;
        aactiontype[2] = c;
        aactiontype[3] = d;
        aactiontype[4] = e;
        aactiontype[5] = f;
        aactiontype[6] = g;
        v = aactiontype;
    }
}
