// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.alipay.sdk.protocol;

import android.text.TextUtils;
import com.alipay.sdk.data.Request;
import com.alipay.sdk.data.Response;
import org.json.JSONObject;

// Referenced classes of package com.alipay.sdk.protocol:
//            WindowData, ElementAction, ActionType, MiniStatus

public class MiniWindowFrame extends WindowData
{

    private int i;
    private boolean j;

    protected MiniWindowFrame(Request request, Response response)
    {
        super(request, response);
        j = false;
    }

    private boolean g()
    {
        return j;
    }

    public final void a(JSONObject jsonobject)
    {
        int k;
        k = 0;
        super.a(jsonobject);
        if(!jsonobject.has("form")) goto _L2; else goto _L1
_L1:
        JSONObject jsonobject1;
        String s;
        jsonobject1 = jsonobject.optJSONObject("form");
        s = jsonobject1.optString("type");
        super.h = Boolean.parseBoolean(jsonobject1.optString("oneTime"));
        if(!TextUtils.equals("page", s)) goto _L4; else goto _L3
_L3:
        j = true;
        i = 9;
_L6:
        return;
_L4:
        if(TextUtils.equals("dialog", s))
        {
            i = 7;
            j = false;
        } else
        if(TextUtils.equals("toast", s))
        {
            ElementAction elementaction = ElementAction.a(jsonobject1, "onload");
            i = 6;
            if(elementaction != null)
            {
                ActionType aactiontype[] = ActionType.a(elementaction);
                int l = aactiontype.length;
                while(k < l) 
                {
                    ActionType actiontype = aactiontype[k];
                    if(actiontype == ActionType.d || actiontype == ActionType.e)
                        i = 10;
                    k++;
                }
            }
        } else
        if(!TextUtils.equals("confirm", s))
        {
            j = TextUtils.equals(s, "fullscreen");
            i = 4;
        }
        continue; /* Loop/switch isn't completed */
_L2:
        if(MiniStatus.a(jsonobject.optString("status")) == MiniStatus.c)
            i = -10;
        else
            i = 8;
        if(true) goto _L6; else goto _L5
_L5:
    }

    public final boolean d()
    {
        boolean flag;
        if(i == 4 || i == 9)
            flag = true;
        else
            flag = false;
        return flag;
    }

    public final int e()
    {
        return i;
    }

    public final String f()
    {
        return null;
    }
}
