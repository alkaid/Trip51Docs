// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.alipay.sdk.protocol;

import com.alipay.sdk.data.Request;
import com.alipay.sdk.data.Response;
import org.json.JSONObject;

public class FrameData
{

    private Request a;
    private Response b;
    private JSONObject c;

    public FrameData(Request request, Response response)
    {
        a = request;
        b = response;
    }

    public final Request a()
    {
        return a;
    }

    public void a(JSONObject jsonobject)
    {
        c = jsonobject;
    }

    public final Response b()
    {
        return b;
    }

    public final JSONObject c()
    {
        return c;
    }
}
