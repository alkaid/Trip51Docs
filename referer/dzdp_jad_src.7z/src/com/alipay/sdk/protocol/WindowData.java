// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.alipay.sdk.protocol;

import com.alipay.sdk.data.Request;
import com.alipay.sdk.data.Response;

// Referenced classes of package com.alipay.sdk.protocol:
//            FrameData

public abstract class WindowData extends FrameData
{

    public static final int a = 4;
    public static final int b = 6;
    public static final int c = 7;
    public static final int d = 8;
    public static final int e = 9;
    public static final int f = 10;
    public static final int g = -10;
    boolean h;

    protected WindowData(Request request, Response response)
    {
        super(request, response);
        h = false;
    }

    private void a(boolean flag)
    {
        h = flag;
    }

    private boolean g()
    {
        return h;
    }

    public abstract boolean d();

    public abstract int e();

    public abstract String f();
}
