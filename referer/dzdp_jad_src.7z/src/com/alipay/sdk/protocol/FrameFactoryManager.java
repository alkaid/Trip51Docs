// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.alipay.sdk.protocol;

import com.alipay.sdk.exception.*;

// Referenced classes of package com.alipay.sdk.protocol:
//            MiniFrameFactory, FrameData

public class FrameFactoryManager
{

    public FrameFactoryManager()
    {
    }

    public static FrameData a(FrameData framedata)
        throws NetErrorException, FailOperatingException, AppErrorException
    {
        if(framedata == null)
            throw new AppErrorException(com/alipay/sdk/protocol/FrameFactoryManager, "frame data is null");
        MiniFrameFactory miniframefactory = new MiniFrameFactory();
        MiniWindowFrame miniwindowframe = MiniFrameFactory.a(framedata);
        if(miniwindowframe != null)
            framedata = miniwindowframe;
        miniframefactory.b(framedata);
        return framedata;
    }
}
