// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.alipay.sdk.protocol;


public final class MiniStatus extends Enum
{

    public static final MiniStatus a;
    public static final MiniStatus b;
    public static final MiniStatus c;
    public static final MiniStatus d;
    private static final MiniStatus f[];
    private String e;

    private MiniStatus(String s, int i, String s1)
    {
        super(s, i);
        e = s1;
    }

    public static MiniStatus a(String s)
    {
        MiniStatus ministatus = null;
        MiniStatus aministatus[] = values();
        int i = aministatus.length;
        int j = 0;
        while(j < i) 
        {
            MiniStatus ministatus1 = aministatus[j];
            if(!s.startsWith(ministatus1.e))
                ministatus1 = ministatus;
            j++;
            ministatus = ministatus1;
        }
        return ministatus;
    }

    private String a()
    {
        return e;
    }

    public static MiniStatus valueOf(String s)
    {
        return (MiniStatus)Enum.valueOf(com/alipay/sdk/protocol/MiniStatus, s);
    }

    public static MiniStatus[] values()
    {
        return (MiniStatus[])f.clone();
    }

    static 
    {
        a = new MiniStatus("SUCCESS", 0, "0");
        b = new MiniStatus("TID_REFRESH", 1, "tid_refresh_invalid");
        c = new MiniStatus("POP_TYPE", 2, "pop_type");
        d = new MiniStatus("NOT_POP_TYPE", 3, "not_pop_type");
        MiniStatus aministatus[] = new MiniStatus[4];
        aministatus[0] = a;
        aministatus[1] = b;
        aministatus[2] = c;
        aministatus[3] = d;
        f = aministatus;
    }
}
