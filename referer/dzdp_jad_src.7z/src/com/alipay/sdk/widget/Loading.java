// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.alipay.sdk.widget;

import android.app.Activity;
import android.app.ProgressDialog;

public class Loading
{

    private Activity a;
    private ProgressDialog b;

    public Loading(Activity activity)
    {
        a = activity;
    }

    static ProgressDialog a(Loading loading)
    {
        return loading.b;
    }

    static ProgressDialog a(Loading loading, ProgressDialog progressdialog)
    {
        loading.b = progressdialog;
        return progressdialog;
    }

    private void a(String s)
    {
        a(((CharSequence) (s)), false, null);
    }

    static Activity b(Loading loading)
    {
        return loading.a;
    }

    public final void a(CharSequence charsequence, boolean flag, android.content.DialogInterface.OnCancelListener oncancellistener)
    {
        _cls1 _lcls1 = new _cls1(flag, oncancellistener, charsequence);
        a.runOnUiThread(_lcls1);
    }

    public final boolean a()
    {
        boolean flag;
        if(b != null && b.isShowing())
            flag = true;
        else
            flag = false;
        return flag;
    }

    public final void b()
    {
        a("\u6B63\u5728\u52A0\u8F7D", false, null);
    }

    public final void c()
    {
        _cls2 _lcls2 = new _cls2();
        a.runOnUiThread(_lcls2);
    }

    private class _cls1
        implements Runnable
    {

        final boolean a;
        final android.content.DialogInterface.OnCancelListener b;
        final CharSequence c;
        final Loading d;

        public void run()
        {
            if(Loading.a(d) == null)
                Loading.a(d, new ProgressDialog(Loading.b(d)));
            Loading.a(d).setCancelable(a);
            Loading.a(d).setOnCancelListener(b);
            Loading.a(d).setMessage(c);
            Loading.a(d).show();
_L1:
            return;
            Exception exception;
            exception;
            Loading.a(d, null);
              goto _L1
        }

        _cls1(boolean flag, android.content.DialogInterface.OnCancelListener oncancellistener, CharSequence charsequence)
        {
            d = Loading.this;
            a = flag;
            b = oncancellistener;
            c = charsequence;
            super();
        }
    }


    private class _cls2
        implements Runnable
    {

        final Loading a;

        public void run()
        {
            if(Loading.a(a) != null && a.a())
                Loading.a(a).dismiss();
            Loading.a(a, null);
_L2:
            return;
            Exception exception1;
            exception1;
            Loading.a(a, null);
            if(true) goto _L2; else goto _L1
_L1:
            Exception exception;
            exception;
            Loading.a(a, null);
            throw exception;
        }

        _cls2()
        {
            a = Loading.this;
            super();
        }
    }

}
