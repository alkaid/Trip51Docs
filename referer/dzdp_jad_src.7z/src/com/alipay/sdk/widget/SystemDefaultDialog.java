// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.alipay.sdk.widget;

import android.app.Dialog;
import android.content.Context;
import android.text.TextUtils;

public class SystemDefaultDialog
{

    private static boolean a;

    public SystemDefaultDialog()
    {
    }

    private static android.app.AlertDialog.Builder a(Context context, String s, android.content.DialogInterface.OnClickListener onclicklistener, String s1, android.content.DialogInterface.OnClickListener onclicklistener1)
    {
        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(context);
        if(!a) goto _L2; else goto _L1
_L1:
        if(!TextUtils.isEmpty(s1) && onclicklistener1 != null)
            builder.setPositiveButton(s1, onclicklistener1);
        if(!TextUtils.isEmpty(s) && onclicklistener != null)
            builder.setNegativeButton(s, onclicklistener);
_L4:
        return builder;
_L2:
        if(!TextUtils.isEmpty(s) && onclicklistener != null)
            builder.setPositiveButton(s, onclicklistener);
        if(!TextUtils.isEmpty(s1) && onclicklistener1 != null)
            builder.setNegativeButton(s1, onclicklistener1);
        if(true) goto _L4; else goto _L3
_L3:
    }

    public static Dialog a(Context context, String s, String s1, String s2, android.content.DialogInterface.OnClickListener onclicklistener, String s3, android.content.DialogInterface.OnClickListener onclicklistener1)
    {
        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(context);
        if(!a) goto _L2; else goto _L1
_L1:
        if(!TextUtils.isEmpty(s3) && onclicklistener1 != null)
            builder.setPositiveButton(s3, onclicklistener1);
        if(!TextUtils.isEmpty(s2) && onclicklistener != null)
            builder.setNegativeButton(s2, onclicklistener);
_L4:
        builder.setTitle(s);
        builder.setMessage(s1);
        android.app.AlertDialog alertdialog = builder.create();
        alertdialog.setCanceledOnTouchOutside(false);
        alertdialog.setOnKeyListener(new _cls1());
        alertdialog.show();
        return alertdialog;
_L2:
        if(!TextUtils.isEmpty(s2) && onclicklistener != null)
            builder.setPositiveButton(s2, onclicklistener);
        if(!TextUtils.isEmpty(s3) && onclicklistener1 != null)
            builder.setNegativeButton(s3, onclicklistener1);
        if(true) goto _L4; else goto _L3
_L3:
    }

    static 
    {
        boolean flag;
        if(android.os.Build.VERSION.SDK_INT >= 11)
            flag = true;
        else
            flag = false;
        a = flag;
    }

    private class _cls1
        implements android.content.DialogInterface.OnKeyListener
    {

        public final boolean onKey(DialogInterface dialoginterface, int i, KeyEvent keyevent)
        {
            boolean flag;
            if(i == 4)
                flag = true;
            else
                flag = false;
            return flag;
        }

        _cls1()
        {
        }
    }

}
