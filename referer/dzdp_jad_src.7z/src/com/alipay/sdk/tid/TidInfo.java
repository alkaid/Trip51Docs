// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.alipay.sdk.tid;

import android.content.Context;
import android.text.TextUtils;
import com.alipay.sdk.sys.GlobalContext;
import com.alipay.sdk.util.DeviceInfo;

// Referenced classes of package com.alipay.sdk.tid:
//            TidDbHelper

public class TidInfo
{

    private static TidInfo a;
    private String b;
    private String c;

    private TidInfo()
    {
    }

    /**
     * @deprecated Method c is deprecated
     */

    public static TidInfo c()
    {
        com/alipay/sdk/tid/TidInfo;
        JVM INSTR monitorenter ;
        TidInfo tidinfo;
        if(a == null)
        {
            a = new TidInfo();
            Context context = GlobalContext.a().b();
            TidDbHelper tiddbhelper = new TidDbHelper(context);
            String s = DeviceInfo.a(context).a();
            String s1 = DeviceInfo.a(context).b();
            a.b = tiddbhelper.b(s, s1);
            a.c = tiddbhelper.c(s, s1);
            if(TextUtils.isEmpty(a.c))
            {
                TidInfo tidinfo1 = a;
                String s2 = Long.toHexString(System.currentTimeMillis());
                if(s2.length() > 10)
                    s2 = s2.substring(-10 + s2.length());
                tidinfo1.c = s2;
            }
            tiddbhelper.a(s, s1, a.b, a.c);
        }
        tidinfo = a;
        com/alipay/sdk/tid/TidInfo;
        JVM INSTR monitorexit ;
        return tidinfo;
        Exception exception;
        exception;
        throw exception;
    }

    public static void d()
    {
        Context context = GlobalContext.a().b();
        String s = DeviceInfo.a(context).a();
        String s1 = DeviceInfo.a(context).b();
        TidDbHelper tiddbhelper = new TidDbHelper(context);
        tiddbhelper.a(s, s1);
        tiddbhelper.close();
    }

    private boolean e()
    {
        return TextUtils.isEmpty(b);
    }

    private static String f()
    {
        String s = Long.toHexString(System.currentTimeMillis());
        if(s.length() > 10)
            s = s.substring(-10 + s.length());
        return s;
    }

    public final String a()
    {
        return b;
    }

    public final void a(Context context)
    {
        TidDbHelper tiddbhelper = new TidDbHelper(context);
        tiddbhelper.a(DeviceInfo.a(context).a(), DeviceInfo.a(context).b(), b, c);
        tiddbhelper.close();
_L2:
        return;
        Exception exception1;
        exception1;
        exception1.printStackTrace();
        tiddbhelper.close();
        if(true) goto _L2; else goto _L1
_L1:
        Exception exception;
        exception;
        tiddbhelper.close();
        throw exception;
    }

    public final void a(String s)
    {
        b = s;
    }

    public final String b()
    {
        return c;
    }

    public final void b(String s)
    {
        c = s;
    }
}
