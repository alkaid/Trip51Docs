// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.alipay.sdk.tid;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.text.TextUtils;
import com.alipay.sdk.encrypt.Des;
import com.alipay.sdk.util.DeviceInfo;
import java.lang.ref.WeakReference;
import java.text.SimpleDateFormat;
import java.util.*;

final class TidDbHelper extends SQLiteOpenHelper
{

    private static final String a = "msp.db";
    private static final int b = 1;
    private WeakReference c;

    public TidDbHelper(Context context)
    {
        super(context, "msp.db", null, 1);
        c = new WeakReference(context);
    }

    private List a()
    {
        Cursor cursor;
        ArrayList arraylist;
        cursor = null;
        arraylist = new ArrayList();
        SQLiteDatabase sqlitedatabase;
        SQLiteDatabase sqlitedatabase1;
        Exception exception1;
        Exception exception2;
        Cursor cursor1;
        SQLiteDatabase sqlitedatabase2;
        Exception exception4;
        Cursor cursor2;
        Exception exception5;
        String s;
        try
        {
            sqlitedatabase2 = getReadableDatabase();
        }
        catch(Exception exception)
        {
            sqlitedatabase = null;
            continue; /* Loop/switch isn't completed */
        }
        sqlitedatabase1 = sqlitedatabase2;
        cursor2 = sqlitedatabase1.rawQuery("select tid from tb_tid", null);
        cursor1 = cursor2;
        do
        {
            if(!cursor1.moveToNext())
                break;
            s = cursor1.getString(0);
            if(!TextUtils.isEmpty(s))
                arraylist.add(Des.b(s, DeviceInfo.c((Context)c.get())));
        } while(true);
        if(cursor1 != null)
            cursor1.close();
        if(sqlitedatabase1 != null && sqlitedatabase1.isOpen())
            sqlitedatabase1.close();
          goto _L1
        exception5;
        cursor = cursor1;
        sqlitedatabase = sqlitedatabase1;
_L7:
        if(cursor != null)
            cursor.close();
        if(sqlitedatabase != null && sqlitedatabase.isOpen())
            sqlitedatabase.close();
_L3:
        return arraylist;
_L1:
        if(true) goto _L3; else goto _L2
_L2:
        exception1;
        sqlitedatabase1 = null;
        exception2 = exception1;
        cursor1 = null;
_L5:
        if(cursor1 != null)
            cursor1.close();
        if(sqlitedatabase1 != null && sqlitedatabase1.isOpen())
            sqlitedatabase1.close();
        throw exception2;
        exception4;
        cursor1 = null;
        exception2 = exception4;
        continue; /* Loop/switch isn't completed */
        exception2;
        if(true) goto _L5; else goto _L4
_L4:
        Exception exception3;
        exception3;
        sqlitedatabase = sqlitedatabase1;
        if(true) goto _L7; else goto _L6
_L6:
    }

    private static void a(SQLiteDatabase sqlitedatabase)
    {
        int i = 0;
        Cursor cursor = sqlitedatabase.rawQuery("select name from tb_tid where tid!='' order by dt asc", null);
        if(cursor.getCount() <= 14)
        {
            cursor.close();
        } else
        {
            int j = -14 + cursor.getCount();
            String as[] = new String[j];
            if(cursor.moveToFirst())
            {
                int k = 0;
                do
                {
                    as[k] = cursor.getString(0);
                    k++;
                } while(cursor.moveToNext() && j > k);
            }
            cursor.close();
            while(i < as.length) 
            {
                if(!TextUtils.isEmpty(as[i]))
                    a(sqlitedatabase, as[i]);
                i++;
            }
        }
    }

    private static void a(SQLiteDatabase sqlitedatabase, String s)
    {
        String as[] = new String[1];
        as[0] = s;
        sqlitedatabase.delete("tb_tid", "name=?", as);
_L2:
        return;
        Exception exception;
        exception;
        if(true) goto _L2; else goto _L1
_L1:
    }

    private void a(SQLiteDatabase sqlitedatabase, String s, String s1, String s2, String s3)
    {
        int i = 0;
        String s4 = Des.a(s2, DeviceInfo.c((Context)c.get()));
        Object aobj[] = new Object[3];
        aobj[i] = e(s, s1);
        aobj[1] = s4;
        aobj[2] = s3;
        sqlitedatabase.execSQL("insert into tb_tid (name, tid, key_tid, dt) values (?, ?, ?, datetime('now', 'localtime'))", aobj);
        Cursor cursor = sqlitedatabase.rawQuery("select name from tb_tid where tid!='' order by dt asc", null);
        if(cursor.getCount() <= 14)
        {
            cursor.close();
        } else
        {
            int j = -14 + cursor.getCount();
            String as[] = new String[j];
            if(cursor.moveToFirst())
            {
                int k = 0;
                do
                {
                    as[k] = cursor.getString(0);
                    k++;
                } while(cursor.moveToNext() && j > k);
            }
            cursor.close();
            while(i < as.length) 
            {
                if(!TextUtils.isEmpty(as[i]))
                    a(sqlitedatabase, as[i]);
                i++;
            }
        }
    }

    private static boolean a(SQLiteDatabase sqlitedatabase, String s, String s1)
    {
        boolean flag;
        Cursor cursor;
        flag = true;
        cursor = null;
        String as[] = new String[1];
        as[0] = e(s, s1);
        cursor = sqlitedatabase.rawQuery("select count(*) from tb_tid where name=?", as);
        if(!cursor.moveToFirst()) goto _L2; else goto _L1
_L1:
        int k = cursor.getInt(0);
        int j = k;
_L6:
        Exception exception;
        Exception exception1;
        int i;
        if(cursor != null)
        {
            cursor.close();
            i = j;
        } else
        {
            i = j;
        }
_L4:
        if(i <= 0)
            flag = false;
        return flag;
        exception1;
        if(cursor != null)
        {
            cursor.close();
            i = 0;
        } else
        {
            i = 0;
        }
        if(true) goto _L4; else goto _L3
_L3:
        exception;
        if(cursor != null)
            cursor.close();
        throw exception;
_L2:
        j = 0;
        if(true) goto _L6; else goto _L5
_L5:
    }

    private void b(SQLiteDatabase sqlitedatabase, String s, String s1, String s2, String s3)
    {
        String s4 = Des.a(s2, DeviceInfo.c((Context)c.get()));
        Object aobj[] = new Object[3];
        aobj[0] = s4;
        aobj[1] = s3;
        aobj[2] = e(s, s1);
        sqlitedatabase.execSQL("update tb_tid set tid=?, key_tid=?, dt=datetime('now', 'localtime') where name=?", aobj);
    }

    private long d(String s, String s1)
    {
        Cursor cursor;
        long l;
        cursor = null;
        l = 0L;
        SQLiteDatabase sqlitedatabase1 = getReadableDatabase();
        SQLiteDatabase sqlitedatabase = sqlitedatabase1;
        long l1;
        String as[] = new String[1];
        as[0] = e(s, s1);
        cursor = sqlitedatabase.rawQuery("select dt from tb_tid where name=?", as);
        if(!cursor.moveToFirst())
            break MISSING_BLOCK_LABEL_80;
        l1 = (new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())).parse(cursor.getString(0)).getTime();
        l = l1;
        if(cursor != null)
            cursor.close();
        if(sqlitedatabase != null && sqlitedatabase.isOpen())
            sqlitedatabase.close();
_L2:
        return l;
        Exception exception1;
        exception1;
        sqlitedatabase = null;
_L5:
        if(cursor != null)
            cursor.close();
        if(sqlitedatabase != null && sqlitedatabase.isOpen())
            sqlitedatabase.close();
        if(true) goto _L2; else goto _L1
_L1:
        Exception exception;
        exception;
        sqlitedatabase = null;
_L4:
        if(cursor != null)
            cursor.close();
        if(sqlitedatabase != null && sqlitedatabase.isOpen())
            sqlitedatabase.close();
        throw exception;
        exception;
        if(true) goto _L4; else goto _L3
_L3:
        Exception exception2;
        exception2;
          goto _L5
    }

    private static String e(String s, String s1)
    {
        return (new StringBuilder()).append(s).append(s1).toString();
    }

    public final void a(String s, String s1)
    {
        SQLiteDatabase sqlitedatabase = null;
        sqlitedatabase = getWritableDatabase();
        b(sqlitedatabase, s, s1, "", "");
        a(sqlitedatabase, e(s, s1));
        if(sqlitedatabase != null && sqlitedatabase.isOpen())
            sqlitedatabase.close();
_L2:
        return;
        Exception exception1;
        exception1;
        if(sqlitedatabase != null && sqlitedatabase.isOpen())
            sqlitedatabase.close();
        if(true) goto _L2; else goto _L1
_L1:
        Exception exception;
        exception;
        if(sqlitedatabase != null && sqlitedatabase.isOpen())
            sqlitedatabase.close();
        throw exception;
    }

    public final void a(String s, String s1, String s2, String s3)
    {
        SQLiteDatabase sqlitedatabase = null;
        sqlitedatabase = getWritableDatabase();
        if(!a(sqlitedatabase, s, s1)) goto _L2; else goto _L1
_L1:
        b(sqlitedatabase, s, s1, s2, s3);
_L7:
        if(sqlitedatabase != null && sqlitedatabase.isOpen())
            sqlitedatabase.close();
_L4:
        return;
_L2:
        Cursor cursor;
        try
        {
            String s4 = Des.a(s2, DeviceInfo.c((Context)c.get()));
            Object aobj[] = new Object[3];
            aobj[0] = e(s, s1);
            aobj[1] = s4;
            aobj[2] = s3;
            sqlitedatabase.execSQL("insert into tb_tid (name, tid, key_tid, dt) values (?, ?, ?, datetime('now', 'localtime'))", aobj);
            cursor = sqlitedatabase.rawQuery("select name from tb_tid where tid!='' order by dt asc", null);
            if(cursor.getCount() > 14)
                break; /* Loop/switch isn't completed */
            cursor.close();
            continue; /* Loop/switch isn't completed */
        }
        catch(Exception exception1)
        {
            if(sqlitedatabase != null && sqlitedatabase.isOpen())
                sqlitedatabase.close();
        }
        if(true) goto _L4; else goto _L3
_L3:
        String as[];
        int j;
        int i = -14 + cursor.getCount();
        as = new String[i];
        if(cursor.moveToFirst())
        {
            int k = 0;
            do
            {
                as[k] = cursor.getString(0);
                k++;
            } while(cursor.moveToNext() && i > k);
        }
        cursor.close();
        j = 0;
_L5:
        if(j >= as.length)
            continue; /* Loop/switch isn't completed */
        if(!TextUtils.isEmpty(as[j]))
            a(sqlitedatabase, as[j]);
        j++;
          goto _L5
        if(true) goto _L7; else goto _L6
_L6:
        Exception exception;
        exception;
        if(sqlitedatabase != null && sqlitedatabase.isOpen())
            sqlitedatabase.close();
        throw exception;
    }

    public final String b(String s, String s1)
    {
        String s2 = null;
        SQLiteDatabase sqlitedatabase1 = getReadableDatabase();
        SQLiteDatabase sqlitedatabase = sqlitedatabase1;
        Cursor cursor1;
        String as[] = new String[1];
        as[0] = e(s, s1);
        cursor1 = sqlitedatabase.rawQuery("select tid from tb_tid where name=?", as);
        Cursor cursor = cursor1;
        String s4;
        if(!cursor.moveToFirst())
            break MISSING_BLOCK_LABEL_65;
        s4 = cursor.getString(0);
        s2 = s4;
        if(cursor != null)
            cursor.close();
        Exception exception;
        Exception exception1;
        Exception exception2;
        String s3;
        Exception exception3;
        Exception exception4;
        Exception exception5;
        if(sqlitedatabase != null && sqlitedatabase.isOpen())
        {
            sqlitedatabase.close();
            s3 = s2;
        } else
        {
            s3 = s2;
        }
        if(!TextUtils.isEmpty(s3))
            s3 = Des.b(s3, DeviceInfo.c((Context)c.get()));
        return s3;
        exception2;
        cursor = null;
        sqlitedatabase = null;
_L3:
        if(cursor != null)
            cursor.close();
        if(sqlitedatabase != null && sqlitedatabase.isOpen())
        {
            sqlitedatabase.close();
            s3 = null;
        } else
        {
            s3 = null;
        }
        if(false)
            break MISSING_BLOCK_LABEL_173;
        else
            break MISSING_BLOCK_LABEL_98;
        exception;
        sqlitedatabase = null;
        exception1 = exception;
        cursor = null;
_L2:
        if(cursor != null)
            cursor.close();
        if(sqlitedatabase != null && sqlitedatabase.isOpen())
            sqlitedatabase.close();
        throw exception1;
        exception4;
        cursor = null;
        exception1 = exception4;
        continue; /* Loop/switch isn't completed */
        exception1;
        if(true) goto _L2; else goto _L1
_L1:
        exception3;
        cursor = null;
          goto _L3
        exception5;
          goto _L3
    }

    public final String c(String s, String s1)
    {
        String s2 = null;
        SQLiteDatabase sqlitedatabase1 = getReadableDatabase();
        SQLiteDatabase sqlitedatabase = sqlitedatabase1;
        Cursor cursor1;
        String as[] = new String[1];
        as[0] = e(s, s1);
        cursor1 = sqlitedatabase.rawQuery("select key_tid from tb_tid where name=?", as);
        Cursor cursor = cursor1;
        String s3;
        if(!cursor.moveToFirst())
            break MISSING_BLOCK_LABEL_65;
        s3 = cursor.getString(0);
        s2 = s3;
        if(cursor != null)
            cursor.close();
        if(sqlitedatabase != null && sqlitedatabase.isOpen())
            sqlitedatabase.close();
_L2:
        return s2;
        Exception exception2;
        exception2;
        cursor = null;
        sqlitedatabase = null;
_L5:
        if(cursor != null)
            cursor.close();
        if(sqlitedatabase != null && sqlitedatabase.isOpen())
            sqlitedatabase.close();
        if(true) goto _L2; else goto _L1
_L1:
        Exception exception;
        exception;
        Exception exception1;
        sqlitedatabase = null;
        exception1 = exception;
        cursor = null;
_L4:
        if(cursor != null)
            cursor.close();
        if(sqlitedatabase != null && sqlitedatabase.isOpen())
            sqlitedatabase.close();
        throw exception1;
        Exception exception4;
        exception4;
        cursor = null;
        exception1 = exception4;
        continue; /* Loop/switch isn't completed */
        exception1;
        if(true) goto _L4; else goto _L3
_L3:
        Exception exception3;
        exception3;
        cursor = null;
          goto _L5
        Exception exception5;
        exception5;
          goto _L5
    }

    public final void onCreate(SQLiteDatabase sqlitedatabase)
    {
        sqlitedatabase.execSQL("create table if not exists tb_tid (name text primary key, tid text, key_tid text, dt datetime);");
    }

    public final void onUpgrade(SQLiteDatabase sqlitedatabase, int i, int j)
    {
        sqlitedatabase.execSQL("drop table if exists tb_tid");
        sqlitedatabase.execSQL("create table if not exists tb_tid (name text primary key, tid text, key_tid text, dt datetime);");
    }
}
