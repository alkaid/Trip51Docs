// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.alipay.sdk.data;

import android.text.TextUtils;
import com.alipay.sdk.cons.GlobalConstants;
import com.alipay.sdk.exception.UnZipException;
import com.alipay.sdk.sys.GlobalContext;
import com.alipay.sdk.tid.TidInfo;
import com.alipay.sdk.util.*;
import java.io.*;
import java.util.zip.GZIPInputStream;
import org.apache.http.Header;
import org.apache.http.HttpResponse;
import org.apache.http.message.BasicHeader;
import org.json.JSONException;
import org.json.JSONObject;

// Referenced classes of package com.alipay.sdk.data:
//            Envelope, Request, MspConfig, InteractionData

public class FrameUtils
{

    private static final String a = "Msp-Param";

    public FrameUtils()
    {
    }

    public static Request a()
    {
        Envelope envelope;
        GlobalContext globalcontext;
        TidInfo tidinfo;
        JSONObject jsonobject;
        envelope = new Envelope();
        envelope.b(GlobalConstants.b);
        envelope.c("com.alipay.mobilecashier");
        envelope.d("/device/findAccount");
        envelope.e("3.0.0");
        globalcontext = GlobalContext.a();
        tidinfo = TidInfo.c();
        jsonobject = new JSONObject();
        if(TextUtils.isEmpty(tidinfo.a())) goto _L2; else goto _L1
_L1:
        jsonobject.put("tid", tidinfo.a());
_L3:
        jsonobject.put("utdid", globalcontext.g());
        jsonobject.put("app_key", "2014052600006128");
        jsonobject.put("new_client_key", tidinfo.b());
        jsonobject.put("imei", DeviceInfo.a(globalcontext.b()).b());
        jsonobject.put("imsi", DeviceInfo.a(globalcontext.b()).a());
_L4:
        return new Request(envelope, jsonobject);
_L2:
        tidinfo.b(tidinfo.b());
          goto _L3
        JSONException jsonexception;
        jsonexception;
          goto _L4
    }

    public static Request a(InteractionData interactiondata, String s, JSONObject jsonobject)
    {
        GlobalContext globalcontext = GlobalContext.a();
        TidInfo tidinfo = TidInfo.c();
        JSONObject jsonobject1 = JsonUtils.a(null, jsonobject);
        Envelope envelope;
        Request request1;
        try
        {
            jsonobject1.put("tid", tidinfo.a());
            jsonobject1.put("user_agent", globalcontext.c().a(tidinfo));
            jsonobject1.put("has_alipay", Utils.b(globalcontext.b()));
            jsonobject1.put("has_msp_app", Utils.a(globalcontext.b()));
            jsonobject1.put("external_info", s);
            jsonobject1.put("app_key", "2014052600006128");
            jsonobject1.put("utdid", globalcontext.g());
            jsonobject1.put("new_client_key", tidinfo.b());
        }
        catch(JSONException jsonexception) { }
        envelope = new Envelope();
        envelope.b(GlobalConstants.b);
        envelope.c("com.alipay.mobilecashier");
        envelope.d("/cashier/main");
        envelope.e("4.0.2");
        if(jsonobject1 != null)
        {
            Request request = new Request(envelope, jsonobject1);
            request.a(true);
            request1 = request;
        } else
        {
            request1 = null;
        }
        if(request1 != null && !TextUtils.isEmpty(s))
        {
            String as[] = s.split("&");
            if(as.length != 0)
            {
                int i = as.length;
                int j = 0;
                Object obj = null;
                Object obj1 = null;
                Object obj2 = null;
                Object obj3 = null;
                while(j < i) 
                {
                    String s2 = as[j];
                    if(TextUtils.isEmpty(((CharSequence) (obj3))))
                        if(!s2.contains("biz_type"))
                            obj3 = null;
                        else
                            obj3 = d(s2);
                    if(TextUtils.isEmpty(((CharSequence) (obj2))))
                        if(!s2.contains("biz_no"))
                            obj2 = null;
                        else
                            obj2 = d(s2);
                    if(TextUtils.isEmpty(((CharSequence) (obj1))))
                        if(!s2.contains("trade_no") || s2.startsWith("out_trade_no"))
                            obj1 = null;
                        else
                            obj1 = d(s2);
                    if(TextUtils.isEmpty(((CharSequence) (obj))))
                        if(!s2.contains("app_userid"))
                            obj = null;
                        else
                            obj = d(s2);
                    j++;
                }
                StringBuilder stringbuilder = new StringBuilder();
                if(!TextUtils.isEmpty(((CharSequence) (obj3))))
                    stringbuilder.append((new StringBuilder("biz_type=")).append(((String) (obj3))).append(";").toString());
                if(!TextUtils.isEmpty(((CharSequence) (obj2))))
                    stringbuilder.append((new StringBuilder("biz_no=")).append(((String) (obj2))).append(";").toString());
                if(!TextUtils.isEmpty(((CharSequence) (obj1))))
                    stringbuilder.append((new StringBuilder("trade_no=")).append(((String) (obj1))).append(";").toString());
                if(!TextUtils.isEmpty(((CharSequence) (obj))))
                    stringbuilder.append((new StringBuilder("app_userid=")).append(((String) (obj))).append(";").toString());
                if(stringbuilder.length() != 0)
                {
                    String s1 = stringbuilder.toString();
                    if(s1.endsWith(";"))
                        s1 = s1.substring(0, -1 + s1.length());
                    Header aheader[] = new Header[1];
                    aheader[0] = new BasicHeader("Msp-Param", s1);
                    interactiondata.a(aheader);
                    request1.a(interactiondata);
                }
            }
        }
        return request1;
    }

    private static Request a(JSONObject jsonobject, boolean flag)
    {
        Envelope envelope = new Envelope();
        envelope.b(GlobalConstants.b);
        envelope.c("com.alipay.mobilecashier");
        envelope.d("/cashier/main");
        envelope.e("4.0.2");
        Request request = null;
        if(jsonobject != null)
        {
            request = new Request(envelope, jsonobject);
            request.a(flag);
        }
        return request;
    }

    private static String a(String s)
    {
        String s1;
        if(!s.contains("biz_type"))
            s1 = null;
        else
            s1 = d(s);
        return s1;
    }

    private static void a(InteractionData interactiondata, Request request, String s)
    {
        if(!TextUtils.isEmpty(s)) goto _L2; else goto _L1
_L1:
        return;
_L2:
        String as[] = s.split("&");
        if(as.length != 0)
        {
            int i = as.length;
            int j = 0;
            Object obj = null;
            Object obj1 = null;
            Object obj2 = null;
            Object obj3 = null;
            while(j < i) 
            {
                String s2 = as[j];
                if(TextUtils.isEmpty(((CharSequence) (obj3))))
                    if(!s2.contains("biz_type"))
                        obj3 = null;
                    else
                        obj3 = d(s2);
                if(TextUtils.isEmpty(((CharSequence) (obj2))))
                    if(!s2.contains("biz_no"))
                        obj2 = null;
                    else
                        obj2 = d(s2);
                if(TextUtils.isEmpty(((CharSequence) (obj1))))
                    if(!s2.contains("trade_no") || s2.startsWith("out_trade_no"))
                        obj1 = null;
                    else
                        obj1 = d(s2);
                if(TextUtils.isEmpty(((CharSequence) (obj))))
                    if(!s2.contains("app_userid"))
                        obj = null;
                    else
                        obj = d(s2);
                j++;
            }
            StringBuilder stringbuilder = new StringBuilder();
            if(!TextUtils.isEmpty(((CharSequence) (obj3))))
                stringbuilder.append((new StringBuilder("biz_type=")).append(((String) (obj3))).append(";").toString());
            if(!TextUtils.isEmpty(((CharSequence) (obj2))))
                stringbuilder.append((new StringBuilder("biz_no=")).append(((String) (obj2))).append(";").toString());
            if(!TextUtils.isEmpty(((CharSequence) (obj1))))
                stringbuilder.append((new StringBuilder("trade_no=")).append(((String) (obj1))).append(";").toString());
            if(!TextUtils.isEmpty(((CharSequence) (obj))))
                stringbuilder.append((new StringBuilder("app_userid=")).append(((String) (obj))).append(";").toString());
            if(stringbuilder.length() != 0)
            {
                String s1 = stringbuilder.toString();
                if(s1.endsWith(";"))
                    s1 = s1.substring(0, -1 + s1.length());
                Header aheader[] = new Header[1];
                aheader[0] = new BasicHeader("Msp-Param", s1);
                interactiondata.a(aheader);
                request.a(interactiondata);
            }
        }
        if(true) goto _L1; else goto _L3
_L3:
    }

    public static void a(InteractionData interactiondata, HttpResponse httpresponse)
    {
        Header aheader[] = httpresponse.getHeaders("Msp-Param");
        if(interactiondata != null && aheader.length > 0)
            interactiondata.a(aheader);
    }

    public static byte[] a(byte abyte0[])
        throws UnZipException
    {
        ByteArrayInputStream bytearrayinputstream;
        GZIPInputStream gzipinputstream;
        ByteArrayOutputStream bytearrayoutputstream;
        byte abyte2[];
        try
        {
            bytearrayinputstream = new ByteArrayInputStream(abyte0);
            gzipinputstream = new GZIPInputStream(bytearrayinputstream);
            byte abyte1[] = new byte[4096];
            bytearrayoutputstream = new ByteArrayOutputStream();
            do
            {
                int i = gzipinputstream.read(abyte1, 0, abyte1.length);
                if(i == -1)
                    break;
                bytearrayoutputstream.write(abyte1, 0, i);
            } while(true);
        }
        catch(UnsupportedEncodingException unsupportedencodingexception)
        {
            unsupportedencodingexception.printStackTrace();
            throw new UnZipException("UnsupportedEncodingException");
        }
        catch(IOException ioexception)
        {
            ioexception.printStackTrace();
            throw new UnZipException("IOException");
        }
        abyte2 = bytearrayoutputstream.toByteArray();
        bytearrayoutputstream.flush();
        bytearrayoutputstream.close();
        gzipinputstream.close();
        bytearrayinputstream.close();
        return abyte2;
    }

    private static String b(String s)
    {
        String s1;
        if(!s.contains("biz_no"))
            s1 = null;
        else
            s1 = d(s);
        return s1;
    }

    private static String c(String s)
    {
        String s1;
        if(!s.contains("trade_no") || s.startsWith("out_trade_no"))
            s1 = null;
        else
            s1 = d(s);
        return s1;
    }

    private static String d(String s)
    {
        String as[] = s.split("=");
        String s1 = null;
        if(as.length > 1)
        {
            s1 = as[1];
            if(s1.contains("\""))
                s1 = s1.replaceAll("\"", "");
        }
        return s1;
    }

    private static String e(String s)
    {
        String s1;
        if(!s.contains("app_userid"))
            s1 = null;
        else
            s1 = d(s);
        return s1;
    }
}
