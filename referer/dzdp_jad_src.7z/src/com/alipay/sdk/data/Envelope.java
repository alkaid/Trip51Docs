// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.alipay.sdk.data;


public class Envelope
{

    private String a;
    private String b;
    private String c;
    private String d;
    private String e;

    public Envelope()
    {
        e = "com.alipay.mcpay";
    }

    private static String f(String s)
    {
        return s;
    }

    public final String a()
    {
        return e;
    }

    public final void a(String s)
    {
        e = s;
    }

    public final String b()
    {
        return a;
    }

    public final void b(String s)
    {
        a = s;
    }

    public final String c()
    {
        return b;
    }

    public final void c(String s)
    {
        b = s;
    }

    public final String d()
    {
        return c;
    }

    public final void d(String s)
    {
        c = s;
    }

    public final String e()
    {
        return d;
    }

    public final void e(String s)
    {
        d = s;
    }

    public String toString()
    {
        return (new StringBuilder("requestUrl = ")).append(a).append(", namespace = ").append(b).append(", apiName = ").append(c).append(", apiVersion = ").append(d).toString();
    }
}
