// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.alipay.sdk.data;

import android.os.Build;
import android.text.TextUtils;
import com.alipay.sdk.util.JsonUtils;
import java.lang.ref.WeakReference;
import org.json.JSONObject;

// Referenced classes of package com.alipay.sdk.data:
//            Envelope, InteractionData

public class Request
{

    private Envelope a;
    private JSONObject b;
    private JSONObject c;
    private long d;
    private WeakReference e;
    private boolean f;
    private boolean g;

    public Request(Envelope envelope, JSONObject jsonobject)
    {
        this(envelope, jsonobject, (byte)0);
    }

    private Request(Envelope envelope, JSONObject jsonobject, byte byte0)
    {
        e = null;
        f = true;
        g = true;
        a = envelope;
        b = jsonobject;
        c = null;
        e = new WeakReference(null);
    }

    private void a(long l)
    {
        d = l;
    }

    private void a(JSONObject jsonobject)
    {
        c = jsonobject;
    }

    private void b(boolean flag)
    {
        f = flag;
    }

    private boolean e()
    {
        return g;
    }

    private long f()
    {
        return d;
    }

    public final String a()
    {
        return a.b();
    }

    public final JSONObject a(String s)
    {
        JSONObject jsonobject = new JSONObject();
        JSONObject jsonobject2;
        JSONObject jsonobject3;
        String s1;
        boolean flag;
        JSONObject jsonobject1 = new JSONObject();
        jsonobject1.put("device", Build.MODEL);
        jsonobject2 = new JSONObject();
        jsonobject3 = JsonUtils.a(jsonobject1, c);
        jsonobject3.put("namespace", a.c());
        jsonobject3.put("api_name", a.a());
        jsonobject3.put("api_version", a.e());
        if(b == null)
            b = new JSONObject();
        b.put("action", jsonobject2);
        s1 = a.d();
        flag = TextUtils.isEmpty(s1);
        Exception exception;
        if(!flag)
            try
            {
                String as[] = s1.split("/");
                jsonobject2.put("type", as[1]);
                if(as.length > 1)
                    jsonobject2.put("method", as[2]);
            }
            catch(Exception exception1) { }
        b.put("gzip", g);
        if(!f) goto _L2; else goto _L1
_L1:
        JSONObject jsonobject4 = new JSONObject();
        (new StringBuilder("requestData before: ")).append(b.toString()).toString();
        jsonobject4.put("req_data", JsonUtils.a(s, b.toString()));
        jsonobject3.put("params", jsonobject4);
_L3:
        jsonobject.put("data", jsonobject3);
_L4:
        (new StringBuilder("requestData : ")).append(jsonobject.toString()).toString();
        return jsonobject;
_L2:
        jsonobject3.put("params", b);
          goto _L3
        exception;
          goto _L4
    }

    public final void a(InteractionData interactiondata)
    {
        e = new WeakReference(interactiondata);
    }

    public final void a(boolean flag)
    {
        g = flag;
    }

    public final InteractionData b()
    {
        return (InteractionData)e.get();
    }

    public final boolean c()
    {
        return f;
    }

    public final Envelope d()
    {
        return a;
    }

    public String toString()
    {
        return (new StringBuilder()).append(a.toString()).append(", requestData = ").append(JsonUtils.a(b, c)).append(", timeStamp = ").append(d).toString();
    }
}
