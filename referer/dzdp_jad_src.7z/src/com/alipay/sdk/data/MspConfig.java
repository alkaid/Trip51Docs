// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.alipay.sdk.data;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.preference.PreferenceManager;
import android.text.TextUtils;
import android.widget.TextView;
import com.alipay.mobilesecuritysdk.face.SecurityClientMobile;
import com.alipay.sdk.cons.GlobalConstants;
import com.alipay.sdk.sys.GlobalContext;
import com.alipay.sdk.sys.UserLocation;
import com.alipay.sdk.tid.TidInfo;
import com.alipay.sdk.util.*;
import java.util.HashMap;
import java.util.Random;

public class MspConfig
{

    private static final String a = "virtualImeiAndImsi";
    private static final String b = "virtual_imei";
    private static final String c = "virtual_imsi";
    private static MspConfig d;
    private String e;
    private String f;
    private String g;

    private MspConfig()
    {
        f = "sdk-and-lite";
    }

    /**
     * @deprecated Method a is deprecated
     */

    public static MspConfig a()
    {
        com/alipay/sdk/data/MspConfig;
        JVM INSTR monitorenter ;
        MspConfig mspconfig;
        if(d == null)
            d = new MspConfig();
        mspconfig = d;
        com/alipay/sdk/data/MspConfig;
        JVM INSTR monitorexit ;
        return mspconfig;
        Exception exception;
        exception;
        throw exception;
    }

    private static String a(Context context)
    {
        return Float.toString((new TextView(context)).getTextSize());
    }

    private static String a(Context context, HashMap hashmap)
    {
        return SecurityClientMobile.GetApdid(context, hashmap);
    }

    private String b()
    {
        return g;
    }

    private static String b(Context context)
    {
        WifiInfo wifiinfo = ((WifiManager)context.getSystemService("wifi")).getConnectionInfo();
        String s;
        if(wifiinfo != null)
            s = wifiinfo.getSSID();
        else
            s = "-1";
        return s;
    }

    private static String c()
    {
        return "1";
    }

    private static String c(Context context)
    {
        WifiInfo wifiinfo = ((WifiManager)context.getSystemService("wifi")).getConnectionInfo();
        String s;
        if(wifiinfo != null)
            s = wifiinfo.getBSSID();
        else
            s = "00";
        return s;
    }

    private static String d()
    {
        Context context = GlobalContext.a().b();
        SharedPreferences sharedpreferences = context.getSharedPreferences("virtualImeiAndImsi", 0);
        String s = sharedpreferences.getString("virtual_imei", null);
        if(TextUtils.isEmpty(s))
        {
            if(TextUtils.isEmpty(TidInfo.c().a()))
                s = f();
            else
                s = DeviceInfo.a(context).b();
            sharedpreferences.edit().putString("virtual_imei", s).commit();
        }
        return s;
    }

    private static String e()
    {
        Context context = GlobalContext.a().b();
        SharedPreferences sharedpreferences = context.getSharedPreferences("virtualImeiAndImsi", 0);
        String s = sharedpreferences.getString("virtual_imsi", null);
        if(TextUtils.isEmpty(s))
        {
            if(TextUtils.isEmpty(TidInfo.c().a()))
            {
                String s1 = GlobalContext.a().g();
                if(TextUtils.isEmpty(s1))
                    s = f();
                else
                    s = s1.substring(3, 18);
            } else
            {
                s = DeviceInfo.a(context).a();
            }
            sharedpreferences.edit().putString("virtual_imsi", s).commit();
        }
        return s;
    }

    private static String f()
    {
        String s = Long.toHexString(System.currentTimeMillis());
        Random random = new Random();
        return (new StringBuilder()).append(s).append(1000 + random.nextInt(9000)).toString();
    }

    public final String a(TidInfo tidinfo)
    {
        Context context = GlobalContext.a().b();
        DeviceInfo deviceinfo = DeviceInfo.a(context);
        if(TextUtils.isEmpty(e))
        {
            String s15 = Utils.a();
            String s16 = Utils.b();
            String s17 = Utils.d(context);
            String s18 = Utils.c();
            String s19 = Utils.e(context);
            String s20 = Float.toString((new TextView(context)).getTextSize());
            e = (new StringBuilder()).append("Msp/9.1.8").append(" (").append(s15).append(";").append(s16).append(";").append(s17).append(";").append(s18).append(";").append(s19).append(";").append(s20).toString();
        }
        String s = DeviceInfo.b(context).a();
        String s1 = Utils.f(context);
        String s2 = deviceinfo.a();
        String s3 = deviceinfo.b();
        Context context1 = GlobalContext.a().b();
        SharedPreferences sharedpreferences = context1.getSharedPreferences("virtualImeiAndImsi", 0);
        String s4 = sharedpreferences.getString("virtual_imsi", null);
        Context context2;
        String s6;
        String s11;
        String s12;
        if(TextUtils.isEmpty(s4))
        {
            if(TextUtils.isEmpty(TidInfo.c().a()))
            {
                String s14 = GlobalContext.a().g();
                String s5;
                SharedPreferences sharedpreferences1;
                String s7;
                String s8;
                String s9;
                boolean flag;
                String s10;
                WifiInfo wifiinfo;
                WifiInfo wifiinfo1;
                StringBuilder stringbuilder;
                HashMap hashmap;
                String s13;
                if(TextUtils.isEmpty(s14))
                    s4 = f();
                else
                    s4 = s14.substring(3, 18);
            } else
            {
                s4 = DeviceInfo.a(context1).a();
            }
            sharedpreferences.edit().putString("virtual_imsi", s4).commit();
        }
        s5 = s4;
        context2 = GlobalContext.a().b();
        sharedpreferences1 = context2.getSharedPreferences("virtualImeiAndImsi", 0);
        s6 = sharedpreferences1.getString("virtual_imei", null);
        if(TextUtils.isEmpty(s6))
        {
            if(TextUtils.isEmpty(TidInfo.c().a()))
                s6 = f();
            else
                s6 = DeviceInfo.a(context2).b();
            sharedpreferences1.edit().putString("virtual_imei", s6).commit();
        }
        s7 = s6;
        if(tidinfo != null)
            g = tidinfo.b();
        s8 = Build.MANUFACTURER.replace(";", " ");
        s9 = Build.MODEL.replace(";", " ");
        flag = GlobalContext.e();
        s10 = deviceinfo.c();
        wifiinfo = ((WifiManager)context.getSystemService("wifi")).getConnectionInfo();
        if(wifiinfo != null)
            s11 = wifiinfo.getSSID();
        else
            s11 = "-1";
        wifiinfo1 = ((WifiManager)context.getSystemService("wifi")).getConnectionInfo();
        if(wifiinfo1 != null)
            s12 = wifiinfo1.getBSSID();
        else
            s12 = "00";
        stringbuilder = new StringBuilder();
        stringbuilder.append(e).append(";").append(s).append(";").append(s1).append(";").append("1").append(";").append(s2).append(";").append(s3).append(";").append(g).append(";").append(s8).append(";").append(s9).append(";").append(flag).append(";").append(s10).append(";").append(UserLocation.a()).append(";").append(f).append(";").append(s5).append(";").append(s7).append(";").append(s11).append(";").append(s12);
        if(tidinfo != null)
        {
            hashmap = new HashMap();
            hashmap.put("tid", tidinfo.a());
            hashmap.put("utdid", GlobalContext.a().g());
            s13 = SecurityClientMobile.GetApdid(context, hashmap);
            if(!TextUtils.isEmpty(s13))
                stringbuilder.append(";").append(s13);
        }
        stringbuilder.append(")");
        return stringbuilder.toString();
    }

    /**
     * @deprecated Method a is deprecated
     */

    public final void a(String s)
    {
        this;
        JVM INSTR monitorenter ;
        boolean flag = TextUtils.isEmpty(s);
        if(!flag) goto _L2; else goto _L1
_L1:
        this;
        JVM INSTR monitorexit ;
        return;
_L2:
        PreferenceManager.getDefaultSharedPreferences(GlobalContext.a().b()).edit().putString("trideskey", s).commit();
        GlobalConstants.d = s;
        if(true) goto _L1; else goto _L3
_L3:
        Exception exception;
        exception;
        throw exception;
    }
}
