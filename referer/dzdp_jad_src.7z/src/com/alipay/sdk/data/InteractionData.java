// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.alipay.sdk.data;

import java.util.ArrayList;
import org.apache.http.Header;
import org.apache.http.message.BasicHeader;

public class InteractionData
{

    public static final String a = "application/octet-stream;binary/octet-stream";
    private Header b[];
    private String c;
    private String d;

    public InteractionData()
    {
        b = null;
        c = null;
        d = null;
    }

    private void a(String s)
    {
        c = s;
    }

    private void b(String s)
    {
        d = s;
    }

    private Header[] d()
    {
        return b;
    }

    private void e()
    {
        d = null;
        c = null;
    }

    public final ArrayList a()
    {
        ArrayList arraylist;
        if(b == null || b.length == 0)
        {
            arraylist = null;
        } else
        {
            arraylist = new ArrayList();
            Header aheader[] = b;
            int i = aheader.length;
            int j = 0;
            while(j < i) 
            {
                Header header = aheader[j];
                arraylist.add(new BasicHeader(header.getName(), header.getValue()));
                j++;
            }
        }
        return arraylist;
    }

    public final void a(Header aheader[])
    {
        b = aheader;
    }

    public final String b()
    {
        return c;
    }

    public final String c()
    {
        return d;
    }
}
