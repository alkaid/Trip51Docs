// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.alipay.sdk.data;

import org.apache.http.Header;
import org.json.JSONObject;

// Referenced classes of package com.alipay.sdk.data:
//            Envelope

public class Response
{

    public static final int a = 1000;
    public static final int b = 503;
    public static final int c;
    Envelope d;
    Header e[];
    private int f;
    private String g;
    private long h;
    private String i;
    private String j;
    private String k;
    private JSONObject l;
    private String m;
    private boolean n;

    public Response()
    {
        f = 0;
        g = "";
        h = 0L;
        i = "";
        j = null;
        k = null;
        l = null;
        n = true;
        d = null;
        e = null;
    }

    private boolean e()
    {
        return n;
    }

    private String f()
    {
        return i;
    }

    private String g()
    {
        return j;
    }

    private String h()
    {
        return k;
    }

    private String i()
    {
        return m;
    }

    public final Envelope a()
    {
        return d;
    }

    public final void a(int i1)
    {
        f = i1;
    }

    public final void a(long l1)
    {
        h = l1;
    }

    public final void a(Envelope envelope)
    {
        d = envelope;
    }

    public final void a(String s)
    {
        g = s;
    }

    public final void a(JSONObject jsonobject)
    {
        l = jsonobject;
    }

    public final void b()
    {
        n = false;
    }

    public final void b(String s)
    {
        i = s;
    }

    public final int c()
    {
        return f;
    }

    public final void c(String s)
    {
        j = s;
    }

    public final String d()
    {
        return g;
    }

    public final void d(String s)
    {
        k = s;
    }

    public final void e(String s)
    {
        m = s;
    }

    public String toString()
    {
        String s = (new StringBuilder()).append(d.toString()).append(", code = ").append(f).append(", errorMsg = ").append(g).append(", timeStamp = ").append(h).append(", endCode = ").append(i).toString();
        if(l != null)
            s = (new StringBuilder()).append(s).append(", reflectedData = ").append(l).toString();
        return s;
    }
}
