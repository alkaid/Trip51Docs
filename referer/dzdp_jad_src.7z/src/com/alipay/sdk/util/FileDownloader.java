// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.alipay.sdk.util;

import android.os.*;
import java.io.*;
import java.lang.ref.WeakReference;
import javax.net.ssl.SSLException;
import org.apache.http.*;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

// Referenced classes of package com.alipay.sdk.util:
//            FileFetch

public final class FileDownloader
{
    public static interface IDownloadProgress
    {

        public abstract void a();

        public abstract void b();

        public abstract void c();
    }

    private static class ProgressOutput extends Handler
    {

        WeakReference a;
        private boolean b;

        static boolean a(ProgressOutput progressoutput)
        {
            progressoutput.b = false;
            return false;
        }

        public void handleMessage(Message message)
        {
            if(FileDownloader.g((FileDownloader)a.get()) != null) goto _L2; else goto _L1
_L1:
            return;
_L2:
            float f1 = 50F;
            if(!((FileDownloader)a.get()).a) goto _L4; else goto _L3
_L3:
            f1 = (100L * FileDownloader.f((FileDownloader)a.get()).a()) / FileDownloader.f((FileDownloader)a.get()).b();
_L6:
            if(!FileDownloader.f((FileDownloader)a.get()).c())
                break MISSING_BLOCK_LABEL_250;
            if(f1 != 100F || b)
                break MISSING_BLOCK_LABEL_181;
            FileDownloader.g((FileDownloader)a.get()).a();
            b = true;
              goto _L1
            Exception exception;
            exception;
            FileDownloader.g((FileDownloader)a.get()).c();
              goto _L1
_L4:
            if(!FileDownloader.f((FileDownloader)a.get()).c()) goto _L6; else goto _L5
_L5:
            f1 = 100F;
              goto _L6
            if(f1 > 100F)
            {
                FileDownloader.d((FileDownloader)a.get());
                FileDownloader.g((FileDownloader)a.get()).c();
            } else
            if(!b)
                FileDownloader.g((FileDownloader)a.get()).c();
              goto _L1
            FileDownloader.g((FileDownloader)a.get()).b();
              goto _L1
        }

        private ProgressOutput(Looper looper, FileDownloader filedownloader)
        {
            super(looper);
            b = false;
            a = new WeakReference(filedownloader);
        }

        ProgressOutput(Looper looper, FileDownloader filedownloader, byte byte0)
        {
            this(looper, filedownloader);
        }
    }


    public boolean a;
    private String b;
    private String c;
    private String d;
    private IDownloadProgress e;
    private FileFetch f;

    public FileDownloader()
    {
        a = false;
    }

    private FileDownloader(boolean flag)
    {
        a = flag;
    }

    static FileFetch a(FileDownloader filedownloader, FileFetch filefetch)
    {
        filedownloader.f = filefetch;
        return filefetch;
    }

    static String a(FileDownloader filedownloader)
    {
        return filedownloader.b;
    }

    private void a(boolean flag)
    {
        a = flag;
    }

    static String b(FileDownloader filedownloader)
    {
        return filedownloader.c;
    }

    static long c(FileDownloader filedownloader)
    {
        return filedownloader.e();
    }

    private static HttpEntity c(String s)
        throws Exception
    {
        HttpEntity httpentity;
        HttpGet httpget = new HttpGet(s);
        HttpResponse httpresponse = (new DefaultHttpClient()).execute(httpget);
        int i = httpresponse.getStatusLine().getStatusCode();
        if(i == 200)
            httpentity = httpresponse.getEntity();
        else
            throw new Exception((new StringBuilder("net work exception,ErrorCode :")).append(i).toString());
          goto _L1
        SSLException sslexception;
        sslexception;
        sslexception.printStackTrace();
_L2:
        httpentity = null;
        break; /* Loop/switch isn't completed */
        Exception exception;
        exception;
        exception.printStackTrace();
        if(true) goto _L2; else goto _L1
_L1:
        return httpentity;
    }

    static void d(FileDownloader filedownloader)
    {
        File file = new File(filedownloader.c);
        if(file.exists())
            file.delete();
        File file1 = new File(filedownloader.d);
        if(file1.exists())
            file1.delete();
    }

    private long e()
    {
        long l = -1L;
        long l1 = c(b).getContentLength();
        l = l1;
_L2:
        return l;
        Exception exception;
        exception;
        exception.printStackTrace();
        if(true) goto _L2; else goto _L1
_L1:
    }

    static void e(FileDownloader filedownloader)
    {
        FileInputStream fileinputstream = null;
        FileInputStream fileinputstream1 = new FileInputStream(filedownloader.d);
        ObjectInputStream objectinputstream = new ObjectInputStream(fileinputstream1);
        filedownloader.f.a(objectinputstream.readLong());
        filedownloader.f.b(objectinputstream.readLong());
        Exception exception;
        Exception exception1;
        try
        {
            fileinputstream1.close();
        }
        catch(Exception exception6) { }
        objectinputstream.close();
_L1:
        return;
        exception;
        objectinputstream = null;
_L3:
        exception.printStackTrace();
        Exception exception7;
        try
        {
            fileinputstream.close();
        }
        catch(Exception exception4) { }
        try
        {
            objectinputstream.close();
        }
        catch(Exception exception5) { }
          goto _L1
        exception1;
        objectinputstream = null;
        fileinputstream1 = null;
_L2:
        try
        {
            fileinputstream1.close();
        }
        catch(Exception exception2) { }
        try
        {
            objectinputstream.close();
        }
        catch(Exception exception3) { }
        throw exception1;
        exception7;
          goto _L1
        exception1;
        objectinputstream = null;
          goto _L2
        exception1;
          goto _L2
        exception1;
        fileinputstream1 = fileinputstream;
          goto _L2
        exception;
        objectinputstream = null;
        fileinputstream = fileinputstream1;
          goto _L3
        exception;
        fileinputstream = fileinputstream1;
          goto _L3
    }

    static FileFetch f(FileDownloader filedownloader)
    {
        return filedownloader.f;
    }

    private void f()
    {
        File file = new File(c);
        if(file.exists())
            file.delete();
        File file1 = new File(d);
        if(file1.exists())
            file1.delete();
    }

    static IDownloadProgress g(FileDownloader filedownloader)
    {
        return filedownloader.e;
    }

    private void g()
    {
        FileInputStream fileinputstream = null;
        FileInputStream fileinputstream1 = new FileInputStream(d);
        ObjectInputStream objectinputstream = new ObjectInputStream(fileinputstream1);
        f.a(objectinputstream.readLong());
        f.b(objectinputstream.readLong());
        Exception exception;
        Exception exception1;
        try
        {
            fileinputstream1.close();
        }
        catch(Exception exception6) { }
        objectinputstream.close();
_L1:
        return;
        exception;
        objectinputstream = null;
_L3:
        exception.printStackTrace();
        Exception exception7;
        try
        {
            fileinputstream.close();
        }
        catch(Exception exception4) { }
        try
        {
            objectinputstream.close();
        }
        catch(Exception exception5) { }
          goto _L1
        exception1;
        objectinputstream = null;
        fileinputstream1 = null;
_L2:
        try
        {
            fileinputstream1.close();
        }
        catch(Exception exception2) { }
        try
        {
            objectinputstream.close();
        }
        catch(Exception exception3) { }
        throw exception1;
        exception7;
          goto _L1
        exception1;
        objectinputstream = null;
          goto _L2
        exception1;
          goto _L2
        exception1;
        fileinputstream1 = fileinputstream;
          goto _L2
        exception;
        objectinputstream = null;
        fileinputstream = fileinputstream1;
          goto _L3
        exception;
        fileinputstream = fileinputstream1;
          goto _L3
    }

    public final void a(IDownloadProgress idownloadprogress)
    {
        if(idownloadprogress != null)
            e = idownloadprogress;
    }

    public final void a(String s)
    {
        b = s;
    }

    protected final boolean a()
    {
        return a;
    }

    public final void b()
    {
        (new Thread(new _cls1(new ProgressOutput(Looper.getMainLooper(), this, (byte)0)))).start();
    }

    public final void b(String s)
    {
        c = s;
        d = (new StringBuilder()).append(s).append(".tmp").toString();
    }

    public final void c()
    {
        f.d();
    }

    protected final void d()
    {
        FileOutputStream fileoutputstream = null;
        FileOutputStream fileoutputstream1 = new FileOutputStream(d);
        ObjectOutputStream objectoutputstream = new ObjectOutputStream(fileoutputstream1);
        objectoutputstream.writeLong(f.a());
        objectoutputstream.writeLong(f.b());
        objectoutputstream.flush();
        Exception exception;
        Exception exception1;
        try
        {
            fileoutputstream1.close();
        }
        catch(Exception exception6) { }
        objectoutputstream.close();
_L1:
        return;
        exception;
        objectoutputstream = null;
_L3:
        exception.printStackTrace();
        Exception exception7;
        try
        {
            fileoutputstream.close();
        }
        catch(Exception exception4) { }
        try
        {
            objectoutputstream.close();
        }
        catch(Exception exception5) { }
          goto _L1
        exception1;
        objectoutputstream = null;
        fileoutputstream1 = null;
_L2:
        try
        {
            fileoutputstream1.close();
        }
        catch(Exception exception2) { }
        try
        {
            objectoutputstream.close();
        }
        catch(Exception exception3) { }
        throw exception1;
        exception7;
          goto _L1
        exception1;
        objectoutputstream = null;
          goto _L2
        exception1;
          goto _L2
        exception1;
        fileoutputstream1 = fileoutputstream;
          goto _L2
        exception;
        objectoutputstream = null;
        fileoutputstream = fileoutputstream1;
          goto _L3
        exception;
        fileoutputstream = fileoutputstream1;
          goto _L3
    }

    private class _cls1
        implements Runnable
    {

        final ProgressOutput a;
        final FileDownloader b;

        public void run()
        {
            long l;
            FileDownloader.a(b, new FileFetch(FileDownloader.a(b), FileDownloader.b(b), b));
            l = -1L;
            if(!b.a) goto _L2; else goto _L1
_L1:
            l = FileDownloader.c(b);
            if(l > 0L) goto _L4; else goto _L3
_L3:
            a.sendEmptyMessage(0);
_L6:
            return;
_L2:
            FileDownloader.d(b);
_L4:
            if(b.a)
            {
                FileDownloader.e(b);
                if(FileDownloader.f(b).b() != l)
                {
                    FileDownloader.d(b);
                    FileDownloader.f(b).a(0L);
                    FileDownloader.f(b).b(l);
                }
            }
            (new Thread(FileDownloader.f(b))).start();
            ProgressOutput.a(a);
            while(!FileDownloader.f(b).c()) 
            {
                try
                {
                    Thread.sleep(1500L);
                }
                catch(InterruptedException interruptedexception)
                {
                    interruptedexception.printStackTrace();
                }
                a.sendEmptyMessage(0);
            }
            a.sendEmptyMessage(0);
            if(true) goto _L6; else goto _L5
_L5:
        }

        _cls1(ProgressOutput progressoutput)
        {
            b = FileDownloader.this;
            a = progressoutput;
            super();
        }
    }

}
