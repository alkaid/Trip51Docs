// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.alipay.sdk.util;


public class LogUtils
{

    private static final boolean a = false;
    private static final String b = "sdk";

    public LogUtils()
    {
    }

    private static void a()
    {
    }

    private static void a(Object obj)
    {
        if(obj instanceof Exception);
    }

    private static void b()
    {
    }

    private static void c()
    {
    }

    private static void d()
    {
    }

    private static void e()
    {
    }

    private static void f()
    {
    }

    private static void g()
    {
    }

    private static void h()
    {
    }

    private static void i()
    {
    }

    private static void j()
    {
    }
}
