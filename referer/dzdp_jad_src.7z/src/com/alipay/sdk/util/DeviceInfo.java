// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.alipay.sdk.util;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.telephony.TelephonyManager;
import android.text.TextUtils;

// Referenced classes of package com.alipay.sdk.util:
//            NetConnectionType

public class DeviceInfo
{

    static final String a = "com.alipay.android.app";
    static final String b = "com.eg.android.AlipayGphone";
    static final String c = "com.eg.android.AlipayGphoneRC";
    private static final String d = "00:00:00:00:00:00";
    private static DeviceInfo h = null;
    private String e;
    private String f;
    private String g;

    private DeviceInfo(Context context)
    {
        TelephonyManager telephonymanager = (TelephonyManager)context.getSystemService("phone");
        b(telephonymanager.getDeviceId());
        String s = telephonymanager.getSubscriberId();
        if(s != null)
            s = (new StringBuilder()).append(s).append("000000000000000").toString().substring(0, 15);
        e = s;
        g = ((WifiManager)context.getSystemService("wifi")).getConnectionInfo().getMacAddress();
        if(TextUtils.isEmpty(g))
            g = "00:00:00:00:00:00";
_L2:
        return;
        Exception exception1;
        exception1;
        if(TextUtils.isEmpty(g))
            g = "00:00:00:00:00:00";
        if(true) goto _L2; else goto _L1
_L1:
        Exception exception;
        exception;
        if(TextUtils.isEmpty(g))
            g = "00:00:00:00:00:00";
        throw exception;
    }

    public static DeviceInfo a(Context context)
    {
        if(h == null)
            h = new DeviceInfo(context);
        return h;
    }

    private void a(String s)
    {
        if(s != null)
            s = (new StringBuilder()).append(s).append("000000000000000").toString().substring(0, 15);
        e = s;
    }

    public static NetConnectionType b(Context context)
    {
        ConnectivityManager connectivitymanager = (ConnectivityManager)context.getSystemService("connectivity");
        NetConnectionType netconnectiontype;
        try
        {
            NetworkInfo networkinfo = connectivitymanager.getActiveNetworkInfo();
            if(networkinfo != null && networkinfo.getType() == 0)
                netconnectiontype = NetConnectionType.a(networkinfo.getSubtype());
            else
            if(networkinfo != null && networkinfo.getType() == 1)
                netconnectiontype = NetConnectionType.a;
            else
                netconnectiontype = NetConnectionType.o;
        }
        catch(Exception exception)
        {
            netconnectiontype = NetConnectionType.o;
        }
        return netconnectiontype;
    }

    private void b(String s)
    {
        if(s != null)
        {
            byte abyte0[] = s.getBytes();
            for(int i = 0; i < abyte0.length; i++)
                if(abyte0[i] < 48 || abyte0[i] > 57)
                    abyte0[i] = 48;

            String s1 = new String(abyte0);
            s = (new StringBuilder()).append(s1).append("000000000000000").toString().substring(0, 15);
        }
        f = s;
    }

    public static String c(Context context)
    {
        DeviceInfo deviceinfo = a(context);
        String s = deviceinfo.b();
        String s1 = (new StringBuilder()).append(s).append("|").toString();
        String s2 = deviceinfo.a();
        String s3;
        if(TextUtils.isEmpty(s2))
            s3 = (new StringBuilder()).append(s1).append("000000000000000").toString();
        else
            s3 = (new StringBuilder()).append(s1).append(s2).toString();
        return s3.substring(0, 8);
    }

    private String d()
    {
        String s = b();
        String s1 = (new StringBuilder()).append(s).append("|").toString();
        String s2 = a();
        String s3;
        if(TextUtils.isEmpty(s2))
            s3 = (new StringBuilder()).append(s1).append("000000000000000").toString();
        else
            s3 = (new StringBuilder()).append(s1).append(s2).toString();
        return s3;
    }

    public final String a()
    {
        if(TextUtils.isEmpty(e))
            e = "000000000000000";
        return e;
    }

    public final String b()
    {
        if(TextUtils.isEmpty(f))
            f = "000000000000000";
        return f;
    }

    public final String c()
    {
        return g;
    }

}
