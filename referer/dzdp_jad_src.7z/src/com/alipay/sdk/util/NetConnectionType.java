// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.alipay.sdk.util;


public final class NetConnectionType extends Enum
{

    public static final NetConnectionType a;
    public static final NetConnectionType b;
    public static final NetConnectionType c;
    public static final NetConnectionType d;
    public static final NetConnectionType e;
    public static final NetConnectionType f;
    public static final NetConnectionType g;
    public static final NetConnectionType h;
    public static final NetConnectionType i;
    public static final NetConnectionType j;
    public static final NetConnectionType k;
    public static final NetConnectionType l;
    public static final NetConnectionType m;
    public static final NetConnectionType n;
    public static final NetConnectionType o;
    private static final NetConnectionType r[];
    private int p;
    private String q;

    private NetConnectionType(String s, int i1, int j1, String s1)
    {
        super(s, i1);
        p = j1;
        q = s1;
    }

    public static NetConnectionType a(int i1)
    {
        NetConnectionType anetconnectiontype[];
        int j1;
        int k1;
        anetconnectiontype = values();
        j1 = anetconnectiontype.length;
        k1 = 0;
_L3:
        NetConnectionType netconnectiontype;
        if(k1 >= j1)
            break MISSING_BLOCK_LABEL_37;
        netconnectiontype = anetconnectiontype[k1];
        if(netconnectiontype.p != i1) goto _L2; else goto _L1
_L1:
        return netconnectiontype;
_L2:
        k1++;
          goto _L3
        netconnectiontype = o;
          goto _L1
    }

    private void a(String s)
    {
        q = s;
    }

    private int b()
    {
        return p;
    }

    public static NetConnectionType valueOf(String s)
    {
        return (NetConnectionType)Enum.valueOf(com/alipay/sdk/util/NetConnectionType, s);
    }

    public static NetConnectionType[] values()
    {
        return (NetConnectionType[])r.clone();
    }

    public final String a()
    {
        return q;
    }

    static 
    {
        a = new NetConnectionType("WIFI", 0, 0, "WIFI");
        b = new NetConnectionType("NETWORK_TYPE_1", 1, 1, "unicom2G");
        c = new NetConnectionType("NETWORK_TYPE_2", 2, 2, "mobile2G");
        d = new NetConnectionType("NETWORK_TYPE_4", 3, 4, "telecom2G");
        e = new NetConnectionType("NETWORK_TYPE_5", 4, 5, "telecom3G");
        f = new NetConnectionType("NETWORK_TYPE_6", 5, 6, "telecom3G");
        g = new NetConnectionType("NETWORK_TYPE_12", 6, 12, "telecom3G");
        h = new NetConnectionType("NETWORK_TYPE_8", 7, 8, "unicom3G");
        i = new NetConnectionType("NETWORK_TYPE_3", 8, 3, "unicom3G");
        j = new NetConnectionType("NETWORK_TYPE_13", 9, 13, "LTE");
        k = new NetConnectionType("NETWORK_TYPE_11", 10, 11, "IDEN");
        l = new NetConnectionType("NETWORK_TYPE_9", 11, 9, "HSUPA");
        m = new NetConnectionType("NETWORK_TYPE_10", 12, 10, "HSPA");
        n = new NetConnectionType("NETWORK_TYPE_15", 13, 15, "HSPAP");
        o = new NetConnectionType("NONE", 14, -1, "none");
        NetConnectionType anetconnectiontype[] = new NetConnectionType[15];
        anetconnectiontype[0] = a;
        anetconnectiontype[1] = b;
        anetconnectiontype[2] = c;
        anetconnectiontype[3] = d;
        anetconnectiontype[4] = e;
        anetconnectiontype[5] = f;
        anetconnectiontype[6] = g;
        anetconnectiontype[7] = h;
        anetconnectiontype[8] = i;
        anetconnectiontype[9] = j;
        anetconnectiontype[10] = k;
        anetconnectiontype[11] = l;
        anetconnectiontype[12] = m;
        anetconnectiontype[13] = n;
        anetconnectiontype[14] = o;
        r = anetconnectiontype;
    }
}
