// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.alipay.sdk.util;

import android.text.TextUtils;
import com.alipay.sdk.sys.GlobalContext;
import com.alipay.sdk.tid.TidInfo;

public class ActionUtil
{

    public ActionUtil()
    {
    }

    public static String[] a(String s)
    {
        int i = 1 + s.indexOf('(');
        int j = s.lastIndexOf(')');
        String as[];
        if(i == 0 || j == -1)
        {
            as = null;
        } else
        {
            String as1[] = s.substring(i, j).split(",");
            if(as1 != null)
            {
                for(int k = 0; k < as1.length; k++)
                    if(!TextUtils.isEmpty(as1[k]))
                    {
                        as1[k] = as1[k].trim();
                        as1[k] = as1[k].replaceAll("'", "").replaceAll("\"", "");
                    }

            }
            as = as1;
        }
        return as;
    }

    public static void b(String s)
    {
        String as[];
        as = a(s);
        break MISSING_BLOCK_LABEL_5;
        while(true) 
        {
            do
                return;
            while(as.length != 3 || !TextUtils.equals("tid", as[0]));
            android.content.Context context = GlobalContext.a().b();
            TidInfo tidinfo = TidInfo.c();
            if(!TextUtils.isEmpty(as[1]) && !TextUtils.isEmpty(as[2]))
            {
                tidinfo.a(as[1]);
                tidinfo.b(as[2]);
                tidinfo.a(context);
            }
        }
    }
}
