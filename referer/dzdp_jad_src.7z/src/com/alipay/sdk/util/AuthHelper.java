// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.alipay.sdk.util;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.text.TextUtils;
import com.alipay.sdk.app.*;

// Referenced classes of package com.alipay.sdk.util:
//            PayHelper

public class AuthHelper
{

    public static final Object a = com/alipay/sdk/app/AuthTask;
    private static final String b = "com.eg.android.AlipayGphone";
    private static final int c = 73;

    public AuthHelper()
    {
    }

    public static String a(Activity activity, String s)
    {
        String s2;
        if(a(((Context) (activity))))
        {
            PayHelper payhelper = new PayHelper(activity);
            String s1;
            if(s.contains("\""))
                s1 = (new StringBuilder()).append(s).append("&bizcontext=\"{\"appkey\":\"2014052600006128\"}\"").toString();
            else
                s1 = (new StringBuilder()).append(s).append("&bizcontext={\"appkey\":\"2014052600006128\"}").toString();
            s2 = payhelper.a(s1);
            if(TextUtils.isEmpty(s2))
                s2 = b(activity, s);
        } else
        {
            s2 = b(activity, s);
        }
        return s2;
    }

    private static boolean a(Context context)
    {
        boolean flag = false;
        int i;
        PackageInfo packageinfo = context.getPackageManager().getPackageInfo("com.eg.android.AlipayGphone", 128);
        if(packageinfo == null)
            break MISSING_BLOCK_LABEL_41;
        i = packageinfo.versionCode;
        if(i >= 73)
            flag = true;
        break MISSING_BLOCK_LABEL_41;
        android.content.pm.PackageManager.NameNotFoundException namenotfoundexception;
        namenotfoundexception;
        return flag;
    }

    private static String b(Activity activity, String s)
    {
        InterruptedException interruptedexception;
        Intent intent = new Intent(activity, com/alipay/sdk/app/H5AuthActivity);
        intent.putExtra("params", s);
        activity.startActivity(intent);
        String s1;
        synchronized(a)
        {
            try
            {
                a.wait();
            }
            // Misplaced declaration of an exception variable
            catch(InterruptedException interruptedexception) { }
        }
        s1 = Result.a();
        if(TextUtils.isEmpty(s1))
            s1 = Result.b();
        return s1;
    }

}
