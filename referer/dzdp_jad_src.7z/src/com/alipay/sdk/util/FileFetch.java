// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.alipay.sdk.util;

import java.io.*;
import java.net.SocketTimeoutException;
import org.apache.http.*;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

// Referenced classes of package com.alipay.sdk.util:
//            FileDownloader

final class FileFetch
    implements Runnable
{
    final class FileAccess
    {

        final FileFetch a;
        private FileOutputStream b;

        /**
         * @deprecated Method a is deprecated
         */

        public final int a(byte abyte0[], int i)
            throws IOException
        {
            this;
            JVM INSTR monitorenter ;
            b.write(abyte0, 0, i);
            this;
            JVM INSTR monitorexit ;
            return i;
            Exception exception;
            exception;
            throw exception;
        }

        public final void a()
        {
            b.close();
_L2:
            return;
            Exception exception;
            exception;
            if(true) goto _L2; else goto _L1
_L1:
        }

        public FileAccess()
        {
            a = FileFetch.this;
            super();
            b = new FileOutputStream(FileFetch.a(FileFetch.this), true);
_L1:
            return;
            FileNotFoundException filenotfoundexception;
            filenotfoundexception;
            filenotfoundexception.printStackTrace();
              goto _L1
        }
    }


    private String a;
    private String b;
    private FileDownloader c;
    private boolean d;
    private long e;
    private long f;

    public FileFetch(String s, String s1, FileDownloader filedownloader)
    {
        d = false;
        a = s;
        b = s1;
        c = filedownloader;
    }

    static String a(FileFetch filefetch)
    {
        return filefetch.b;
    }

    public final long a()
    {
        return e;
    }

    public final void a(long l)
    {
        e = l;
    }

    public final long b()
    {
        return f;
    }

    public final void b(long l)
    {
        f = l;
    }

    public final boolean c()
    {
        return d;
    }

    public final void d()
    {
        d = true;
    }

    public final void run()
    {
        if(!c.a() || f > 0L && e < f) goto _L2; else goto _L1
_L1:
        d = true;
_L9:
        return;
_L2:
        FileAccess fileaccess = new FileAccess();
_L13:
        if(d) goto _L4; else goto _L3
_L3:
        InputStream inputstream = null;
        HttpResponse httpresponse;
        int k;
        HttpGet httpget = new HttpGet(a);
        DefaultHttpClient defaulthttpclient = new DefaultHttpClient();
        if(c.a())
            httpget.addHeader("Range", (new StringBuilder("bytes=")).append(e).append("-").append(f).toString());
        httpresponse = defaulthttpclient.execute(httpget);
        k = httpresponse.getStatusLine().getStatusCode();
        int i = k;
        i;
        JVM INSTR tableswitch 200 207: default 200
    //                   200 231
    //                   201 231
    //                   202 231
    //                   203 231
    //                   204 231
    //                   205 231
    //                   206 231
    //                   207 231;
           goto _L5 _L6 _L6 _L6 _L6 _L6 _L6 _L6 _L6
_L5:
        d = true;
_L10:
        boolean flag2 = d;
        if(!flag2) goto _L8; else goto _L7
_L7:
        Exception exception;
        Exception exception2;
        SocketTimeoutException sockettimeoutexception;
        IOException ioexception;
        IOException ioexception1;
        byte abyte0[];
        int j;
        boolean flag;
        boolean flag1;
        InputStream inputstream1;
        if(inputstream != null)
            try
            {
                inputstream.close();
            }
            catch(Exception exception8) { }
_L4:
        fileaccess.a();
          goto _L9
_L6:
        inputstream1 = httpresponse.getEntity().getContent();
        inputstream = inputstream1;
          goto _L10
        ioexception;
        i = 0;
_L23:
        ioexception.printStackTrace();
        d = true;
_L8:
        if(inputstream != null) goto _L12; else goto _L11
_L11:
        if(inputstream != null)
            try
            {
                inputstream.close();
            }
            catch(Exception exception7) { }
          goto _L13
_L12:
        abyte0 = new byte[1024];
_L25:
        j = inputstream.read(abyte0, 0, abyte0.length);
        if(j != -1)
        {
            e = e + (long)fileaccess.a(abyte0, j);
            c.d();
        }
        if(!c.a() || e < f) goto _L15; else goto _L14
_L14:
        flag = false;
_L19:
        if(d || !flag) goto _L17; else goto _L16
_L16:
        flag1 = true;
          goto _L18
_L24:
        d = true;
        if(inputstream != null)
            try
            {
                inputstream.close();
            }
            catch(Exception exception6) { }
          goto _L13
_L15:
        flag = true;
          goto _L19
_L17:
        flag1 = false;
        continue; /* Loop/switch isn't completed */
        sockettimeoutexception;
        i = 0;
_L22:
        if(i != 0) goto _L21; else goto _L20
_L20:
        d = true;
_L21:
        if(inputstream != null)
            try
            {
                inputstream.close();
            }
            catch(Exception exception4) { }
          goto _L13
        ioexception1;
        d = true;
        if(inputstream != null)
            try
            {
                inputstream.close();
            }
            catch(Exception exception5) { }
          goto _L13
        exception2;
        d = true;
        if(inputstream != null)
            try
            {
                inputstream.close();
            }
            catch(Exception exception3) { }
          goto _L13
        exception;
        if(inputstream != null)
            try
            {
                inputstream.close();
            }
            catch(Exception exception1) { }
        throw exception;
        SocketTimeoutException sockettimeoutexception1;
        sockettimeoutexception1;
          goto _L22
        ioexception;
          goto _L23
_L18:
        if(j >= 0 && flag1) goto _L25; else goto _L24
    }
}
