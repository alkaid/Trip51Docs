// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.alipay.sdk.util;

import com.alipay.sdk.cons.GlobalConstants;
import com.alipay.sdk.encrypt.Rsa;
import com.alipay.sdk.encrypt.TriDes;
import java.util.Iterator;
import java.util.Locale;
import org.json.JSONException;
import org.json.JSONObject;

public class JsonUtils
{

    public JsonUtils()
    {
    }

    public static String a(String s, String s1)
    {
        String s2 = Rsa.a(s, GlobalConstants.d);
        String s3 = TriDes.a(s, s1);
        Locale locale = Locale.getDefault();
        Object aobj[] = new Object[4];
        aobj[0] = Integer.valueOf(s2.length());
        aobj[1] = s2;
        aobj[2] = Integer.valueOf(s3.length());
        aobj[3] = s3;
        return String.format(locale, "%08X%s%08X%s", aobj);
    }

    public static JSONObject a(JSONObject jsonobject, JSONObject jsonobject1)
    {
        JSONObject jsonobject2 = new JSONObject();
        JSONObject ajsonobject[];
        int i;
        ajsonobject = new JSONObject[2];
        ajsonobject[0] = jsonobject;
        ajsonobject[1] = jsonobject1;
        i = ajsonobject.length;
        JSONException jsonexception;
        for(int j = 0; j < i; j++)
        {
            JSONObject jsonobject3 = ajsonobject[j];
            if(jsonobject3 != null)
            {
                String s;
                for(Iterator iterator = jsonobject3.keys(); iterator.hasNext(); jsonobject2.put(s, jsonobject3.get(s)))
                    s = (String)iterator.next();

            }
            break MISSING_BLOCK_LABEL_100;
        }

        break MISSING_BLOCK_LABEL_98;
        jsonexception;
        return jsonobject2;
    }
}
