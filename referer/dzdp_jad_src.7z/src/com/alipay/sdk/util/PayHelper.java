// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.alipay.sdk.util;

import android.app.Activity;
import android.content.*;
import android.text.TextUtils;
import com.alipay.android.app.IAlixPay;
import com.alipay.android.app.IRemoteServiceCallback;
import com.alipay.sdk.app.Result;

// Referenced classes of package com.alipay.sdk.util:
//            Utils

public class PayHelper
{

    public static final String a = "failed";
    private Activity b;
    private IAlixPay c;
    private Object d;
    private boolean e;
    private ServiceConnection f;
    private IRemoteServiceCallback g;

    public PayHelper(Activity activity)
    {
        d = com/alipay/android/app/IAlixPay;
        e = false;
        f = new _cls1();
        g = new _cls2();
        b = activity;
    }

    static IAlixPay a(PayHelper payhelper, IAlixPay ialixpay)
    {
        payhelper.c = ialixpay;
        return ialixpay;
    }

    static Object a(PayHelper payhelper)
    {
        return payhelper.d;
    }

    private String a(String s, Intent intent)
    {
        if(!e) goto _L2; else goto _L1
_L1:
        String s1 = "";
_L5:
        return s1;
_L2:
        e = true;
        if(c == null)
            b.getApplicationContext().bindService(intent, f, 1);
        synchronized(d)
        {
            if(c == null)
                d.wait(3000L);
        }
        if(c != null) goto _L4; else goto _L3
_L3:
        s1 = "failed";
        Exception exception2;
        try
        {
            b.unbindService(f);
        }
        catch(Exception exception7)
        {
            c = null;
        }
        e = false;
          goto _L5
        exception4;
        obj;
        JVM INSTR monitorexit ;
        throw exception4;
        exception2;
        s1 = null;
_L6:
        String s2;
        Exception exception6;
        try
        {
            b.unbindService(f);
        }
        catch(Exception exception3)
        {
            c = null;
        }
        e = false;
          goto _L5
_L4:
        c.registerCallback(g);
        s2 = c.Pay(s);
        s1 = s2;
        c.unregisterCallback(g);
        c = null;
        try
        {
            b.unbindService(f);
        }
        // Misplaced declaration of an exception variable
        catch(Exception exception6)
        {
            c = null;
        }
        e = false;
          goto _L5
        Exception exception;
        exception;
        try
        {
            b.unbindService(f);
        }
        catch(Exception exception1)
        {
            c = null;
        }
        e = false;
        throw exception;
        Exception exception5;
        exception5;
          goto _L6
    }

    static Activity b(PayHelper payhelper)
    {
        return payhelper.b;
    }

    public final String a(String s)
    {
        String s1 = Utils.a(Utils.a(b, "com.eg.android.AlipayGphone"));
        String s2;
        if(s1 != null && !TextUtils.equals(s1, "b6cbad6cbd5ed0d209afc69ad3b7a617efaae9b3c47eabe0be42d924936fa78c8001b1fd74b079e5ff9690061dacfa4768e981a526b9ca77156ca36251cf2f906d105481374998a7e6e6e18f75ca98b8ed2eaf86ff402c874cca0a263053f22237858206867d210020daa38c48b20cc9dfd82b44a51aeb5db459b22794e2d649"))
        {
            s2 = Result.c();
        } else
        {
            Intent intent = new Intent();
            intent.setClassName("com.eg.android.AlipayGphone", "com.alipay.android.app.MspService");
            intent.setAction("com.eg.android.AlipayGphone.IAlixPay");
            s2 = a(s, intent);
        }
        return s2;
    }

    private class _cls1
        implements ServiceConnection
    {

        final PayHelper a;

        public void onServiceConnected(ComponentName componentname, IBinder ibinder)
        {
            synchronized(PayHelper.a(a))
            {
                PayHelper.a(a, com.alipay.android.app.IAlixPay.Stub.asInterface(ibinder));
                PayHelper.a(a).notify();
            }
        }

        public void onServiceDisconnected(ComponentName componentname)
        {
            PayHelper.a(a, null);
        }

        _cls1()
        {
            a = PayHelper.this;
            super();
        }
    }


    private class _cls2 extends com.alipay.android.app.IRemoteServiceCallback.Stub
    {

        final PayHelper a;

        public boolean isHideLoadingScreen()
            throws RemoteException
        {
            return false;
        }

        public void payEnd(boolean flag, String s)
            throws RemoteException
        {
        }

        public void startActivity(String s, String s1, int i, Bundle bundle)
            throws RemoteException
        {
            Intent intent = new Intent("android.intent.action.MAIN", null);
            if(bundle == null)
                bundle = new Bundle();
            try
            {
                bundle.putInt("CallingPid", i);
                intent.putExtras(bundle);
            }
            catch(Exception exception)
            {
                exception.printStackTrace();
            }
            intent.setClassName(s, s1);
            PayHelper.b(a).startActivity(intent);
        }

        _cls2()
        {
            a = PayHelper.this;
            super();
        }
    }

}
