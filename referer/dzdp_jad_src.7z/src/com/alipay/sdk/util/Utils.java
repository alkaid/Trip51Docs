// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.alipay.sdk.util;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.*;
import android.content.res.*;
import android.net.Uri;
import android.telephony.TelephonyManager;
import android.telephony.gsm.GsmCellLocation;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.WindowManager;
import com.alipay.sdk.cons.GlobalConstants;
import java.io.*;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Utils
{

    static final String a = "com.alipay.android.app";
    static final String b = "com.eg.android.AlipayGphone";
    private static final String c = "7.0.0";
    private static final String d = "5.0.0";

    public Utils()
    {
    }

    public static String a()
    {
        return (new StringBuilder("Android ")).append(android.os.Build.VERSION.RELEASE).toString();
    }

    public static String a(byte abyte0[])
    {
        String s1 = ((X509Certificate)CertificateFactory.getInstance("X.509").generateCertificate(new ByteArrayInputStream(abyte0))).getPublicKey().toString();
        if(s1.indexOf("modulus") == -1) goto _L2; else goto _L1
_L1:
        String s2 = s1.substring(8 + s1.indexOf("modulus"), s1.lastIndexOf(",")).trim();
        String s = s2;
_L4:
        return s;
        Exception exception;
        exception;
_L2:
        s = null;
        if(true) goto _L4; else goto _L3
_L3:
    }

    public static void a(Activity activity, String s)
    {
        Intent intent;
        try
        {
            String s1 = (new StringBuilder("chmod ")).append("777").append(" ").append(s).toString();
            Runtime.getRuntime().exec(s1);
        }
        catch(IOException ioexception) { }
        intent = new Intent("android.intent.action.VIEW");
        intent.addFlags(0x10000000);
        intent.setDataAndType(Uri.parse((new StringBuilder("file://")).append(s).toString()), "application/vnd.android.package-archive");
        activity.startActivity(intent);
    }

    private static void a(String s, String s1)
    {
        String s2 = (new StringBuilder("chmod ")).append(s).append(" ").append(s1).toString();
        Runtime.getRuntime().exec(s2);
_L2:
        return;
        IOException ioexception;
        ioexception;
        if(true) goto _L2; else goto _L1
_L1:
    }

    public static boolean a(Context context)
    {
        boolean flag = false;
        PackageInfo packageinfo = context.getPackageManager().getPackageInfo("com.alipay.android.app", 128);
        if(packageinfo != null)
            flag = true;
_L2:
        return flag;
        android.content.pm.PackageManager.NameNotFoundException namenotfoundexception;
        namenotfoundexception;
        if(true) goto _L2; else goto _L1
_L1:
    }

    private static boolean a(Context context, String s, String s1)
    {
        boolean flag = false;
        InputStream inputstream = context.getAssets().open(s);
        File file = new File(s1);
        file.createNewFile();
        FileOutputStream fileoutputstream = new FileOutputStream(file);
        byte abyte0[] = new byte[1024];
        do
        {
            int i = inputstream.read(abyte0);
            if(i <= 0)
                break;
            fileoutputstream.write(abyte0, 0, i);
        } while(true);
        fileoutputstream.close();
        inputstream.close();
        flag = true;
        break MISSING_BLOCK_LABEL_90;
        IOException ioexception;
        ioexception;
        return flag;
    }

    public static boolean a(String s)
    {
        return Pattern.compile("^http(s)?://([a-z0-9_\\-]+\\.)*(alipay|taobao)\\.(com|net)(:\\d+)?(/.*)?$").matcher(s).matches();
    }

    public static byte[] a(Context context, String s)
    {
        Iterator iterator = context.getPackageManager().getInstalledPackages(64).iterator();
_L4:
        if(!iterator.hasNext()) goto _L2; else goto _L1
_L1:
        PackageInfo packageinfo = (PackageInfo)iterator.next();
        if(!packageinfo.packageName.equals(s)) goto _L4; else goto _L3
_L3:
        byte abyte0[] = packageinfo.signatures[0].toByteArray();
_L6:
        return abyte0;
_L2:
        abyte0 = null;
        if(true) goto _L6; else goto _L5
_L5:
    }

    private static int b(String s, String s1)
    {
        ArrayList arraylist;
        ArrayList arraylist1;
        int i;
        int j;
        arraylist = new ArrayList();
        arraylist1 = new ArrayList();
        arraylist.addAll(Arrays.asList(s.split("\\.")));
        arraylist1.addAll(Arrays.asList(s1.split("\\.")));
        for(i = Math.max(arraylist.size(), arraylist1.size()); arraylist.size() < i; arraylist.add("0"));
        for(; arraylist1.size() < i; arraylist1.add("0"));
        j = 0;
_L3:
        if(j >= i)
            break MISSING_BLOCK_LABEL_194;
        if(Integer.parseInt((String)arraylist.get(j)) == Integer.parseInt((String)arraylist1.get(j))) goto _L2; else goto _L1
_L1:
        int k = Integer.parseInt((String)arraylist.get(j)) - Integer.parseInt((String)arraylist1.get(j));
_L4:
        return k;
_L2:
        j++;
          goto _L3
        k = 0;
          goto _L4
    }

    public static String b()
    {
        String s = e();
        int i = s.indexOf("-");
        if(i != -1)
            s = s.substring(0, i);
        int j = s.indexOf("\n");
        if(j != -1)
            s = s.substring(0, j);
        return (new StringBuilder("Linux ")).append(s).toString();
    }

    public static boolean b(Context context)
    {
        boolean flag = false;
        int i;
        PackageInfo packageinfo = context.getPackageManager().getPackageInfo("com.eg.android.AlipayGphone", 128);
        if(packageinfo == null)
            break MISSING_BLOCK_LABEL_44;
        i = b(packageinfo.versionName, "7.0.0");
        if(i >= 0)
            flag = true;
        break MISSING_BLOCK_LABEL_44;
        android.content.pm.PackageManager.NameNotFoundException namenotfoundexception;
        namenotfoundexception;
        return flag;
    }

    public static boolean b(Context context, String s)
    {
        boolean flag = true;
        PackageInfo packageinfo = context.getPackageManager().getPackageArchiveInfo(s, 1);
        if(packageinfo == null)
            flag = false;
_L2:
        return flag;
        Exception exception;
        exception;
        flag = false;
        if(true) goto _L2; else goto _L1
_L1:
    }

    public static String c()
    {
        String s = GlobalConstants.b;
        return s.substring(0, s.indexOf("://"));
    }

    public static String c(Context context)
    {
        String s = a();
        String s1 = b();
        String s2 = d(context);
        String s3 = e(context);
        return (new StringBuilder(" (")).append(s).append(";").append(s1).append(";").append(s2).append(";;").append(s3).append(")(sdk android)").toString();
    }

    public static String d()
    {
        Random random;
        StringBuffer stringbuffer;
        int i;
        random = new Random();
        stringbuffer = new StringBuffer();
        i = 0;
_L6:
        if(i >= 24)
            break MISSING_BLOCK_LABEL_139;
        random.nextInt(3);
        JVM INSTR tableswitch 0 2: default 56
    //                   0 62
    //                   1 89
    //                   2 116;
           goto _L1 _L2 _L3 _L4
_L4:
        break MISSING_BLOCK_LABEL_116;
_L1:
        break; /* Loop/switch isn't completed */
_L2:
        break; /* Loop/switch isn't completed */
_L7:
        i++;
        if(true) goto _L6; else goto _L5
_L5:
        stringbuffer.append(String.valueOf((char)(int)Math.round(65D + 25D * Math.random())));
          goto _L7
_L3:
        stringbuffer.append(String.valueOf((char)(int)Math.round(97D + 25D * Math.random())));
          goto _L7
        stringbuffer.append(String.valueOf((new Random()).nextInt(10)));
          goto _L7
        return stringbuffer.toString();
    }

    public static String d(Context context)
    {
        return context.getResources().getConfiguration().locale.toString();
    }

    private static String e()
    {
        BufferedReader bufferedreader;
        Exception exception;
        String s;
        String s1;
        Matcher matcher;
        try
        {
            bufferedreader = new BufferedReader(new FileReader("/proc/version"), 256);
        }
        catch(IOException ioexception)
        {
            s = "Unavailable";
            break MISSING_BLOCK_LABEL_155;
        }
        s1 = bufferedreader.readLine();
        bufferedreader.close();
        matcher = Pattern.compile("\\w+\\s+\\w+\\s+([^\\s]+)\\s+\\(([^\\s@]+(?:@[^\\s.]+)?)[^)]*\\)\\s+\\((?:[^(]*\\([^)]*\\))?[^)]*\\)\\s+([^\\s]+)\\s+(?:PREEMPT\\s+)?(.+)").matcher(s1);
        if(!matcher.matches())
        {
            s = "Unavailable";
            break MISSING_BLOCK_LABEL_155;
        }
        break MISSING_BLOCK_LABEL_74;
        exception;
        bufferedreader.close();
        throw exception;
        String s2;
        if(matcher.groupCount() < 4)
        {
            s = "Unavailable";
            break MISSING_BLOCK_LABEL_155;
        }
        s2 = (new StringBuilder(matcher.group(1))).append("\n").append(matcher.group(2)).append(" ").append(matcher.group(3)).append("\n").append(matcher.group(4)).toString();
        s = s2;
        return s;
    }

    public static String e(Context context)
    {
        DisplayMetrics displaymetrics = new DisplayMetrics();
        ((WindowManager)context.getSystemService("window")).getDefaultDisplay().getMetrics(displaymetrics);
        StringBuilder stringbuilder = new StringBuilder();
        stringbuilder.append(displaymetrics.widthPixels);
        stringbuilder.append("*");
        stringbuilder.append(displaymetrics.heightPixels);
        return stringbuilder.toString();
    }

    public static String f(Context context)
    {
        GsmCellLocation gsmcelllocation = (GsmCellLocation)((TelephonyManager)context.getSystemService("phone")).getCellLocation();
        if(gsmcelllocation == null) goto _L2; else goto _L1
_L1:
        String s1;
        int i = gsmcelllocation.getCid();
        int j = gsmcelllocation.getLac();
        StringBuilder stringbuilder = new StringBuilder();
        stringbuilder.append(j);
        stringbuilder.append(";");
        stringbuilder.append(i);
        s1 = stringbuilder.toString();
        String s = s1;
_L4:
        return s;
        Exception exception;
        exception;
_L2:
        s = "-1;-1";
        if(true) goto _L4; else goto _L3
_L3:
    }

    private static boolean g(Context context)
    {
        boolean flag = false;
        int i = b(context.getPackageManager().getPackageInfo("com.alipay.android.app", 128).versionName, "5.0.0");
        if(i >= 0)
            flag = true;
_L2:
        return flag;
        android.content.pm.PackageManager.NameNotFoundException namenotfoundexception;
        namenotfoundexception;
        if(true) goto _L2; else goto _L1
_L1:
    }

    private static DisplayMetrics h(Context context)
    {
        DisplayMetrics displaymetrics = new DisplayMetrics();
        ((WindowManager)context.getSystemService("window")).getDefaultDisplay().getMetrics(displaymetrics);
        return displaymetrics;
    }
}
