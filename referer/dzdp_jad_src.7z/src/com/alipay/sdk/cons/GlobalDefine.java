// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.alipay.sdk.cons;


public class GlobalDefine
{

    public static final String a = "https";
    public static final String b = "user_agent";
    public static final String c = "tid";
    public static final String d = "external_info";
    public static final String e = "has_alipay";
    public static final String f = "has_msp_app";
    public static final String g = "result";
    public static final String h = "memo";
    public static final String i = "resultStatus";
    public static final String j = "call_back_url";
    public static final String k = "utdid";
    public static final String l = "app_key";
    public static final String m = "trideskey";
    public static final String n = "new_client_key";

    public GlobalDefine()
    {
    }
}
