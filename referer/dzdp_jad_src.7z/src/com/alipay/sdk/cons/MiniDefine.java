// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.alipay.sdk.cons;


public class MiniDefine
{

    public static final String a = "value";
    public static final String b = "status";
    public static final String c = "msg";
    public static final String d = "form";
    public static final String e = "onload";
    public static final String f = "action";
    public static final String g = "name";
    public static final String h = "host";
    public static final String i = "params";
    public static final String j = "enctype";
    public static final String k = "request_param";
    public static final String l = "validate";
    public static final String m = "https";
    public static final String n = "formSubmit";
    public static final String o = "namespace";
    public static final String p = "apiVersion";
    public static final String q = "apiName";
    public static final String r = "tid";

    public MiniDefine()
    {
    }
}
