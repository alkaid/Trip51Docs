// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.alipay.sdk.encrypt;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class MD5
{

    public MD5()
    {
    }

    private static String a(String s)
    {
        String s2;
        MessageDigest messagedigest = MessageDigest.getInstance("MD5");
        messagedigest.update(s.getBytes());
        s2 = b(messagedigest.digest());
        String s1 = s2;
_L2:
        return s1;
        NoSuchAlgorithmException nosuchalgorithmexception;
        nosuchalgorithmexception;
        nosuchalgorithmexception.printStackTrace();
        s1 = "";
        if(true) goto _L2; else goto _L1
_L1:
    }

    public static String a(byte abyte0[])
    {
        String s1;
        MessageDigest messagedigest = MessageDigest.getInstance("MD5");
        messagedigest.update(abyte0);
        s1 = b(messagedigest.digest());
        String s = s1;
_L2:
        return s;
        NoSuchAlgorithmException nosuchalgorithmexception;
        nosuchalgorithmexception;
        nosuchalgorithmexception.printStackTrace();
        s = "";
        if(true) goto _L2; else goto _L1
_L1:
    }

    private static String b(byte abyte0[])
    {
        StringBuffer stringbuffer = new StringBuffer(2 * abyte0.length);
        for(int i = 0; i < abyte0.length; i++)
        {
            stringbuffer.append(Character.forDigit((0xf0 & abyte0[i]) >> 4, 16));
            stringbuffer.append(Character.forDigit(0xf & abyte0[i], 16));
        }

        return stringbuffer.toString();
    }
}
