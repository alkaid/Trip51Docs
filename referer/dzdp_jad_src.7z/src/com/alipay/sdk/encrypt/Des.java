// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.alipay.sdk.encrypt;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

// Referenced classes of package com.alipay.sdk.encrypt:
//            Base64

public class Des
{

    public Des()
    {
    }

    private static String a(int i, String s, String s1)
    {
        String s2;
        String s3;
        SecretKeySpec secretkeyspec = new SecretKeySpec(s1.getBytes(), "DES");
        Cipher cipher = Cipher.getInstance("DES");
        cipher.init(i, secretkeyspec);
        byte abyte0[];
        byte abyte1[];
        if(i == 2)
            abyte0 = Base64.a(s);
        else
            abyte0 = s.getBytes("UTF-8");
        abyte1 = cipher.doFinal(abyte0);
        if(i == 2)
        {
            s2 = new String(abyte1);
            break MISSING_BLOCK_LABEL_97;
        }
        s3 = Base64.a(abyte1);
        s2 = s3;
        break MISSING_BLOCK_LABEL_97;
        Exception exception;
        exception;
        s2 = null;
        return s2;
    }

    public static String a(String s, String s1)
    {
        return a(1, s, s1);
    }

    public static String b(String s, String s1)
    {
        return a(2, s, s1);
    }
}
