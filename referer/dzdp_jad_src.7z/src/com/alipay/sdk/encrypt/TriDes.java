// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.alipay.sdk.encrypt;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

// Referenced classes of package com.alipay.sdk.encrypt:
//            Base64

public class TriDes
{

    private static String a = "DESede/ECB/PKCS5Padding";

    public TriDes()
    {
    }

    public static String a(String s, String s1)
    {
        String s2 = null;
        String s3;
        SecretKeySpec secretkeyspec = new SecretKeySpec(s.getBytes(), "DESede");
        Cipher cipher = Cipher.getInstance(a);
        cipher.init(1, secretkeyspec);
        s3 = Base64.a(cipher.doFinal(s1.getBytes()));
        s2 = s3;
_L2:
        return s2;
        Exception exception;
        exception;
        exception.printStackTrace();
        if(true) goto _L2; else goto _L1
_L1:
    }

    public static String b(String s, String s1)
    {
        String s2;
        try
        {
            SecretKeySpec secretkeyspec = new SecretKeySpec(s.getBytes(), "DESede");
            Cipher cipher = Cipher.getInstance(a);
            cipher.init(2, secretkeyspec);
            s2 = new String(cipher.doFinal(Base64.a(s1)));
        }
        catch(Exception exception)
        {
            exception.printStackTrace();
            s2 = null;
        }
        return s2;
    }

}
