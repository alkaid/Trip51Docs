// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.alipay.sdk.encrypt;


public final class Base64
{

    private static final int a = 128;
    private static final int b = 64;
    private static final int c = 24;
    private static final int d = 8;
    private static final int e = 16;
    private static final int f = 4;
    private static final int g = -128;
    private static final char h = 61;
    private static final byte i[];
    private static final char j[];

    public Base64()
    {
    }

    private static int a(char ac[])
    {
        int i1;
        if(ac == null)
        {
            i1 = 0;
        } else
        {
            int k = ac.length;
            int l = 0;
            i1 = 0;
            while(l < k) 
            {
                char c1 = ac[l];
                boolean flag;
                int j1;
                if(c1 == ' ' || c1 == '\r' || c1 == '\n' || c1 == '\t')
                    flag = true;
                else
                    flag = false;
                if(!flag)
                {
                    j1 = i1 + 1;
                    ac[i1] = ac[l];
                } else
                {
                    j1 = i1;
                }
                l++;
                i1 = j1;
            }
        }
        return i1;
    }

    public static String a(byte abyte0[])
    {
        int k = 0;
        if(abyte0 != null) goto _L2; else goto _L1
_L1:
        String s = null;
_L4:
        return s;
_L2:
        int i1;
        char ac[];
        int i2;
        int l = 8 * abyte0.length;
        if(l == 0)
        {
            s = "";
            continue; /* Loop/switch isn't completed */
        }
        i1 = l % 24;
        int j1 = l / 24;
        int k1;
        int l1;
        if(i1 != 0)
            k1 = j1 + 1;
        else
            k1 = j1;
        ac = new char[k1 * 4];
        l1 = 0;
        i2 = 0;
        while(l1 < j1) 
        {
            int l3 = k + 1;
            byte byte9 = abyte0[k];
            int i4 = l3 + 1;
            byte byte10 = abyte0[l3];
            int j4 = i4 + 1;
            byte byte11 = abyte0[i4];
            byte byte12 = (byte)(byte10 & 0xf);
            byte byte13 = (byte)(byte9 & 3);
            byte byte14;
            byte byte15;
            byte byte16;
            int k4;
            int l4;
            int i5;
            int j5;
            if((byte9 & 0xffffff80) == 0)
                byte14 = (byte)(byte9 >> 2);
            else
                byte14 = (byte)(0xc0 ^ byte9 >> 2);
            if((byte10 & 0xffffff80) == 0)
                byte15 = (byte)(byte10 >> 4);
            else
                byte15 = (byte)(0xf0 ^ byte10 >> 4);
            if((byte11 & 0xffffff80) == 0)
                byte16 = (byte)(byte11 >> 6);
            else
                byte16 = (byte)(0xfc ^ byte11 >> 6);
            k4 = i2 + 1;
            ac[i2] = j[byte14];
            l4 = k4 + 1;
            ac[k4] = j[byte15 | byte13 << 4];
            i5 = l4 + 1;
            ac[l4] = j[byte16 | byte12 << 2];
            j5 = i5 + 1;
            ac[i5] = j[byte11 & 0x3f];
            l1++;
            i2 = j5;
            k = j4;
        }
        if(i1 != 8)
            break; /* Loop/switch isn't completed */
        byte byte6 = abyte0[k];
        byte byte7 = (byte)(byte6 & 3);
        byte byte8;
        int i3;
        int j3;
        int k3;
        if((byte6 & 0xffffff80) == 0)
            byte8 = (byte)(byte6 >> 2);
        else
            byte8 = (byte)(0xc0 ^ byte6 >> 2);
        i3 = i2 + 1;
        ac[i2] = j[byte8];
        j3 = i3 + 1;
        ac[i3] = j[byte7 << 4];
        k3 = j3 + 1;
        ac[j3] = '=';
        ac[k3] = '=';
_L6:
        s = new String(ac);
        if(true) goto _L4; else goto _L3
_L3:
        if(i1 != 16) goto _L6; else goto _L5
_L5:
        byte byte0 = abyte0[k];
        byte byte1 = abyte0[k + 1];
        byte byte2 = (byte)(byte1 & 0xf);
        byte byte3 = (byte)(byte0 & 3);
        byte byte4;
        byte byte5;
        int j2;
        int k2;
        int l2;
        if((byte0 & 0xffffff80) == 0)
            byte4 = (byte)(byte0 >> 2);
        else
            byte4 = (byte)(0xc0 ^ byte0 >> 2);
        if((byte1 & 0xffffff80) == 0)
            byte5 = (byte)(byte1 >> 4);
        else
            byte5 = (byte)(0xf0 ^ byte1 >> 4);
        j2 = i2 + 1;
        ac[i2] = j[byte4];
        k2 = j2 + 1;
        ac[j2] = j[byte5 | byte3 << 4];
        l2 = k2 + 1;
        ac[k2] = j[byte2 << 2];
        ac[l2] = '=';
          goto _L6
    }

    private static boolean a(char c1)
    {
        boolean flag;
        if(c1 == ' ' || c1 == '\r' || c1 == '\n' || c1 == '\t')
            flag = true;
        else
            flag = false;
        return flag;
    }

    public static byte[] a(String s)
    {
        if(s != null) goto _L2; else goto _L1
_L1:
        byte abyte0[] = null;
_L4:
        return abyte0;
_L2:
        char ac[] = s.toCharArray();
        int i1;
        if(ac == null)
        {
            i1 = 0;
        } else
        {
            int k = ac.length;
            int l = 0;
            i1 = 0;
            while(l < k) 
            {
                char c1 = ac[l];
                boolean flag;
                int j1;
                if(c1 == ' ' || c1 == '\r' || c1 == '\n' || c1 == '\t')
                    flag = true;
                else
                    flag = false;
                int k1;
                int l1;
                int i2;
                int j2;
                int k2;
                char c2;
                int l2;
                char c3;
                byte byte0;
                byte byte1;
                int i3;
                char c4;
                char c5;
                byte byte2;
                byte abyte1[];
                int j3;
                byte abyte2[];
                byte byte3;
                byte byte4;
                int k3;
                int l3;
                int i4;
                char c6;
                int j4;
                char c7;
                int k4;
                char c8;
                char c9;
                byte byte5;
                byte byte6;
                byte byte7;
                byte byte8;
                int l4;
                int i5;
                if(!flag)
                {
                    j1 = i1 + 1;
                    ac[i1] = ac[l];
                } else
                {
                    j1 = i1;
                }
                l++;
                i1 = j1;
            }
        }
        if(i1 % 4 != 0)
        {
            abyte0 = null;
            continue; /* Loop/switch isn't completed */
        }
        k1 = i1 / 4;
        if(k1 == 0)
        {
            abyte0 = new byte[0];
            continue; /* Loop/switch isn't completed */
        }
        abyte0 = new byte[k1 * 3];
        l1 = 0;
        i2 = 0;
        j2 = 0;
label0:
        do
        {
label1:
            {
                if(j2 >= k1 - 1)
                    break label0;
                i4 = l1 + 1;
                c6 = ac[l1];
                if(c(c6))
                {
                    j4 = i4 + 1;
                    c7 = ac[i4];
                    if(c(c7))
                    {
                        k4 = j4 + 1;
                        c8 = ac[j4];
                        if(c(c8))
                        {
                            l1 = k4 + 1;
                            c9 = ac[k4];
                            if(c(c9))
                                break label1;
                        }
                    }
                }
                abyte0 = null;
                continue; /* Loop/switch isn't completed */
            }
            byte5 = i[c6];
            byte6 = i[c7];
            byte7 = i[c8];
            byte8 = i[c9];
            l4 = i2 + 1;
            abyte0[i2] = (byte)(byte5 << 2 | byte6 >> 4);
            i5 = l4 + 1;
            abyte0[l4] = (byte)((byte6 & 0xf) << 4 | 0xf & byte7 >> 2);
            i2 = i5 + 1;
            abyte0[i5] = (byte)(byte8 | byte7 << 6);
            j2++;
        } while(true);
label2:
        {
            k2 = l1 + 1;
            c2 = ac[l1];
            if(c(c2))
            {
                l2 = k2 + 1;
                c3 = ac[k2];
                if(c(c3))
                    break label2;
            }
            abyte0 = null;
            continue; /* Loop/switch isn't completed */
        }
        byte0 = i[c2];
        byte1 = i[c3];
        i3 = l2 + 1;
        c4 = ac[l2];
        c5 = ac[i3];
        if(!c(c4) || !c(c5))
        {
            if(b(c4) && b(c5))
            {
                if((byte1 & 0xf) != 0)
                {
                    abyte0 = null;
                } else
                {
                    abyte2 = new byte[1 + j2 * 3];
                    System.arraycopy(abyte0, 0, abyte2, 0, j2 * 3);
                    abyte2[i2] = (byte)(byte0 << 2 | byte1 >> 4);
                    abyte0 = abyte2;
                }
            } else
            if(!b(c4) && b(c5))
            {
                byte2 = i[c4];
                if((byte2 & 3) != 0)
                {
                    abyte0 = null;
                } else
                {
                    abyte1 = new byte[2 + j2 * 3];
                    System.arraycopy(abyte0, 0, abyte1, 0, j2 * 3);
                    j3 = i2 + 1;
                    abyte1[i2] = (byte)(byte0 << 2 | byte1 >> 4);
                    abyte1[j3] = (byte)((byte1 & 0xf) << 4 | 0xf & byte2 >> 2);
                    abyte0 = abyte1;
                }
            } else
            {
                abyte0 = null;
            }
        } else
        {
            byte3 = i[c4];
            byte4 = i[c5];
            k3 = i2 + 1;
            abyte0[i2] = (byte)(byte0 << 2 | byte1 >> 4);
            l3 = k3 + 1;
            abyte0[k3] = (byte)((byte1 & 0xf) << 4 | 0xf & byte3 >> 2);
            abyte0[l3] = (byte)(byte4 | byte3 << 6);
        }
        if(true) goto _L4; else goto _L3
_L3:
    }

    private static boolean b(char c1)
    {
        boolean flag;
        if(c1 == '=')
            flag = true;
        else
            flag = false;
        return flag;
    }

    private static boolean c(char c1)
    {
        boolean flag;
        if(c1 < '\200' && i[c1] != -1)
            flag = true;
        else
            flag = false;
        return flag;
    }

    static 
    {
        int k = 0;
        i = new byte[128];
        j = new char[64];
        for(int l = 0; l < 128; l++)
            i[l] = -1;

        for(int i1 = 90; i1 >= 65; i1--)
            i[i1] = (byte)(i1 - 65);

        for(int j1 = 122; j1 >= 97; j1--)
            i[j1] = (byte)(26 + (j1 - 97));

        for(int k1 = 57; k1 >= 48; k1--)
            i[k1] = (byte)(52 + (k1 - 48));

        i[43] = 62;
        i[47] = 63;
        for(int l1 = 0; l1 <= 25; l1++)
            j[l1] = (char)(l1 + 65);

        int i2 = 26;
        for(int j2 = 0; i2 <= 51; j2++)
        {
            j[i2] = (char)(j2 + 97);
            i2++;
        }

        for(int k2 = 52; k2 <= 61;)
        {
            j[k2] = (char)(k + 48);
            k2++;
            k++;
        }

        j[62] = '+';
        j[63] = '/';
    }
}
