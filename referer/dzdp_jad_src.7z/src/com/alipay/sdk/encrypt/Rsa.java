// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.alipay.sdk.encrypt;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.security.*;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import javax.crypto.Cipher;

// Referenced classes of package com.alipay.sdk.encrypt:
//            Base64

public class Rsa
{

    public static final String a = "SHA1WithRSA";
    private static final String b = "RSA";

    public Rsa()
    {
    }

    public static String a(String s, String s1)
    {
        ByteArrayOutputStream bytearrayoutputstream = null;
        ByteArrayOutputStream bytearrayoutputstream1;
        Cipher cipher;
        byte abyte0[];
        int i;
        X509EncodedKeySpec x509encodedkeyspec = new X509EncodedKeySpec(Base64.a(s1));
        PublicKey publickey = KeyFactory.getInstance("RSA").generatePublic(x509encodedkeyspec);
        cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
        cipher.init(1, publickey);
        abyte0 = s.getBytes("UTF-8");
        i = cipher.getBlockSize();
        bytearrayoutputstream1 = new ByteArrayOutputStream();
        int j = 0;
_L5:
        if(j >= abyte0.length) goto _L2; else goto _L1
_L1:
        if(abyte0.length - j >= i) goto _L4; else goto _L3
_L3:
        int k = abyte0.length - j;
_L11:
        bytearrayoutputstream1.write(cipher.doFinal(abyte0, j, k));
        j += i;
          goto _L5
_L2:
        String s2 = new String(Base64.a(bytearrayoutputstream1.toByteArray()));
        try
        {
            bytearrayoutputstream1.close();
        }
        catch(IOException ioexception2)
        {
            ioexception2.printStackTrace();
        }
_L10:
        return s2;
        Exception exception1;
        exception1;
        bytearrayoutputstream1 = null;
_L9:
        exception1.printStackTrace();
        if(bytearrayoutputstream1 != null)
        {
            try
            {
                bytearrayoutputstream1.close();
            }
            catch(IOException ioexception1)
            {
                ioexception1.printStackTrace();
                s2 = null;
                continue; /* Loop/switch isn't completed */
            }
            s2 = null;
            continue; /* Loop/switch isn't completed */
        }
        break MISSING_BLOCK_LABEL_230;
        Exception exception;
        exception;
_L7:
        if(bytearrayoutputstream != null)
            try
            {
                bytearrayoutputstream.close();
            }
            catch(IOException ioexception)
            {
                ioexception.printStackTrace();
            }
        throw exception;
        exception;
        bytearrayoutputstream = bytearrayoutputstream1;
        if(true) goto _L7; else goto _L6
_L6:
        exception1;
        if(true) goto _L9; else goto _L8
_L8:
        s2 = null;
        if(true) goto _L10; else goto _L4
_L4:
        k = i;
          goto _L11
    }

    private static boolean a(String s, String s1, String s2)
    {
        boolean flag1;
        PublicKey publickey = KeyFactory.getInstance("RSA").generatePublic(new X509EncodedKeySpec(Base64.a(s2)));
        Signature signature = Signature.getInstance("SHA1WithRSA");
        signature.initVerify(publickey);
        signature.update(s.getBytes("utf-8"));
        flag1 = signature.verify(Base64.a(s1));
        boolean flag = flag1;
_L2:
        return flag;
        Exception exception;
        exception;
        exception.printStackTrace();
        flag = false;
        if(true) goto _L2; else goto _L1
_L1:
    }

    private static PublicKey b(String s, String s1)
        throws NoSuchAlgorithmException, Exception
    {
        X509EncodedKeySpec x509encodedkeyspec = new X509EncodedKeySpec(Base64.a(s1));
        return KeyFactory.getInstance(s).generatePublic(x509encodedkeyspec);
    }

    private static String c(String s, String s1)
    {
        ByteArrayOutputStream bytearrayoutputstream = null;
        ByteArrayOutputStream bytearrayoutputstream1;
        Cipher cipher;
        byte abyte0[];
        int i;
        PKCS8EncodedKeySpec pkcs8encodedkeyspec = new PKCS8EncodedKeySpec(Base64.a(s1));
        java.security.PrivateKey privatekey = KeyFactory.getInstance("RSA").generatePrivate(pkcs8encodedkeyspec);
        cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
        cipher.init(2, privatekey);
        abyte0 = Base64.a(s);
        i = cipher.getBlockSize();
        bytearrayoutputstream1 = new ByteArrayOutputStream();
        int j = 0;
_L5:
        if(j >= abyte0.length) goto _L2; else goto _L1
_L1:
        if(abyte0.length - j >= i) goto _L4; else goto _L3
_L3:
        int k = abyte0.length - j;
_L11:
        bytearrayoutputstream1.write(cipher.doFinal(abyte0, j, k));
        j += i;
          goto _L5
_L2:
        String s2 = new String(bytearrayoutputstream1.toByteArray());
        try
        {
            bytearrayoutputstream1.close();
        }
        catch(IOException ioexception2)
        {
            ioexception2.printStackTrace();
        }
_L10:
        return s2;
        Exception exception1;
        exception1;
        bytearrayoutputstream1 = null;
_L9:
        exception1.printStackTrace();
        if(bytearrayoutputstream1 != null)
        {
            try
            {
                bytearrayoutputstream1.close();
            }
            catch(IOException ioexception1)
            {
                ioexception1.printStackTrace();
                s2 = null;
                continue; /* Loop/switch isn't completed */
            }
            s2 = null;
            continue; /* Loop/switch isn't completed */
        }
        break MISSING_BLOCK_LABEL_225;
        Exception exception;
        exception;
_L7:
        if(bytearrayoutputstream != null)
            try
            {
                bytearrayoutputstream.close();
            }
            catch(IOException ioexception)
            {
                ioexception.printStackTrace();
            }
        throw exception;
        exception;
        bytearrayoutputstream = bytearrayoutputstream1;
        if(true) goto _L7; else goto _L6
_L6:
        exception1;
        if(true) goto _L9; else goto _L8
_L8:
        s2 = null;
        if(true) goto _L10; else goto _L4
_L4:
        k = i;
          goto _L11
    }

    private static String d(String s, String s1)
    {
        String s3;
        PKCS8EncodedKeySpec pkcs8encodedkeyspec = new PKCS8EncodedKeySpec(Base64.a(s1));
        java.security.PrivateKey privatekey = KeyFactory.getInstance("RSA").generatePrivate(pkcs8encodedkeyspec);
        Signature signature = Signature.getInstance("SHA1WithRSA");
        signature.initSign(privatekey);
        signature.update(s.getBytes("utf-8"));
        s3 = Base64.a(signature.sign());
        String s2 = s3;
_L2:
        return s2;
        Exception exception;
        exception;
        exception.printStackTrace();
        s2 = null;
        if(true) goto _L2; else goto _L1
_L1:
    }
}
