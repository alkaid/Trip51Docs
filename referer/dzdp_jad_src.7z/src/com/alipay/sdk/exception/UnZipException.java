// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.alipay.sdk.exception;

import android.text.TextUtils;
import android.util.Log;

public final class UnZipException extends Exception
{

    private static final long serialVersionUID = 0x66c507f08b0d20cbL;

    public UnZipException()
    {
        this(null, null);
    }

    public UnZipException(String s)
    {
        this(s, null);
    }

    public UnZipException(String s, Throwable throwable)
    {
        super(s, throwable);
        printException(s, throwable);
    }

    public UnZipException(Throwable throwable)
    {
        this(null, throwable);
    }

    public static void printException(String s, Throwable throwable)
    {
        if(!TextUtils.isEmpty(s))
            Log.e("Validation", (new StringBuilder("Validation--")).append(s).toString());
        if(throwable == null)
            break MISSING_BLOCK_LABEL_62;
        Log.e("Validation", (new StringBuilder("Validation--")).append(throwable.getMessage()).toString());
        throwable.printStackTrace();
_L2:
        return;
        Exception exception;
        exception;
        if(true) goto _L2; else goto _L1
_L1:
    }
}
