// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.alipay.sdk.exception;

import android.text.TextUtils;
import android.util.Log;

public final class NetErrorException extends Exception
{

    public static final int NET_CONNECTION_ERROR = 0;
    public static final int SERVER_ERROR = 1;
    public static final int SSL_ERROR = 2;
    private static final long serialVersionUID = 0x743720ff0041e99bL;
    private int errorCode;

    public NetErrorException()
    {
        this(null, null);
    }

    public NetErrorException(String s)
    {
        this(s, null);
    }

    public NetErrorException(String s, Throwable throwable)
    {
        super(s, throwable);
        errorCode = 0;
        printException(s, throwable);
    }

    public NetErrorException(Throwable throwable)
    {
        this(null, throwable);
    }

    public static void printException(String s, Throwable throwable)
    {
        if(!TextUtils.isEmpty(s))
            Log.w("NetError", (new StringBuilder("NetError--")).append(s).toString());
        if(throwable == null)
            break MISSING_BLOCK_LABEL_58;
        Log.w("NetError", (new StringBuilder("NetError--")).append(throwable.getMessage()).toString());
_L2:
        return;
        Exception exception;
        exception;
        if(true) goto _L2; else goto _L1
_L1:
    }

    public final int getErrorCode()
    {
        return errorCode;
    }

    public final void setErrorCode(int i)
    {
        errorCode = i;
    }
}
