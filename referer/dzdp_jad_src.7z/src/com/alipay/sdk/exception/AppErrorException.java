// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.alipay.sdk.exception;

import android.text.TextUtils;
import android.util.Log;

public final class AppErrorException extends Exception
{

    private static final long serialVersionUID = 0x4441637b2fc1092bL;

    public AppErrorException(Class class1)
    {
        this(class1, null, null);
    }

    public AppErrorException(Class class1, String s)
    {
        this(class1, s, null);
    }

    public AppErrorException(Class class1, String s, Throwable throwable)
    {
        super(s, throwable);
        printException(class1, s, throwable);
    }

    public AppErrorException(Class class1, Throwable throwable)
    {
        this(class1, null, throwable);
    }

    public static void printException(Class class1, String s, Throwable throwable)
    {
        if(class1 != null)
            Log.e("AppError", (new StringBuilder("AppError--")).append(class1.getCanonicalName()).toString());
        if(!TextUtils.isEmpty(s))
            Log.e("AppError", (new StringBuilder("AppError--")).append(s).toString());
        if(throwable == null)
            break MISSING_BLOCK_LABEL_91;
        Log.e("AppError", (new StringBuilder("AppError--")).append(throwable.getMessage()).toString());
        throwable.printStackTrace();
_L2:
        return;
        Exception exception;
        exception;
        if(true) goto _L2; else goto _L1
_L1:
    }
}
