// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.alipay.sdk.authjs;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.widget.Toast;
import java.util.Timer;
import org.json.JSONException;
import org.json.JSONObject;

// Referenced classes of package com.alipay.sdk.authjs:
//            CallInfo, IJsCallback

public class JsBridge
{

    private IJsCallback a;
    private Context b;

    public JsBridge(Context context, IJsCallback ijscallback)
    {
        b = context;
        a = ijscallback;
    }

    static CallInfo.CallError a(JsBridge jsbridge, CallInfo callinfo)
    {
        if(callinfo != null && "toast".equals(callinfo.b()))
        {
            JSONObject jsonobject = callinfo.c();
            String s = jsonobject.optString("content");
            int i = jsonobject.optInt("duration");
            int j = 1;
            if(i < 2500)
                j = 0;
            Toast.makeText(jsbridge.b, s, j).show();
            (new Timer()).schedule(jsbridge. new _cls2(callinfo), j);
        }
        return CallInfo.CallError.a;
    }

    static IJsCallback a(JsBridge jsbridge)
    {
        return jsbridge.a;
    }

    private void a(CallInfo callinfo)
        throws JSONException
    {
        if(callinfo != null)
            if(TextUtils.isEmpty(callinfo.b()))
            {
                a(callinfo.a(), CallInfo.CallError.c);
            } else
            {
                _cls1 _lcls1 = new _cls1(callinfo);
                boolean flag;
                if(Looper.getMainLooper() == Looper.myLooper())
                    flag = true;
                else
                    flag = false;
                if(flag)
                    _lcls1.run();
                else
                    (new Handler(Looper.getMainLooper())).post(_lcls1);
            }
    }

    static void a(JsBridge jsbridge, String s, CallInfo.CallError callerror)
        throws JSONException
    {
        jsbridge.a(s, callerror);
    }

    private static void a(Runnable runnable)
    {
        if(runnable != null)
        {
            boolean flag;
            if(Looper.getMainLooper() == Looper.myLooper())
                flag = true;
            else
                flag = false;
            if(flag)
                runnable.run();
            else
                (new Handler(Looper.getMainLooper())).post(runnable);
        }
    }

    private void a(String s, CallInfo.CallError callerror)
        throws JSONException
    {
        if(!TextUtils.isEmpty(s))
        {
            JSONObject jsonobject = new JSONObject();
            jsonobject.put("error", callerror.ordinal());
            CallInfo callinfo = new CallInfo("callback");
            callinfo.a(jsonobject);
            callinfo.a(s);
            a.a(callinfo);
        }
    }

    private CallInfo.CallError b(CallInfo callinfo)
    {
        if(callinfo != null && "toast".equals(callinfo.b()))
        {
            JSONObject jsonobject = callinfo.c();
            String s = jsonobject.optString("content");
            int i = jsonobject.optInt("duration");
            int j = 1;
            if(i < 2500)
                j = 0;
            Toast.makeText(b, s, j).show();
            (new Timer()).schedule(new _cls2(callinfo), j);
        }
        return CallInfo.CallError.a;
    }

    private void c(CallInfo callinfo)
    {
        JSONObject jsonobject = callinfo.c();
        String s = jsonobject.optString("content");
        int i = jsonobject.optInt("duration");
        int j = 1;
        if(i < 2500)
            j = 0;
        Toast.makeText(b, s, j).show();
        (new Timer()).schedule(new _cls2(callinfo), j);
    }

    public final void a(String s)
    {
        JSONObject jsonobject;
        String s2;
        jsonobject = new JSONObject(s);
        s2 = jsonobject.getString("clientId");
        String s1 = s2;
        if(!TextUtils.isEmpty(s1)) goto _L2; else goto _L1
_L2:
        JSONObject jsonobject1 = jsonobject.getJSONObject("param");
        if(!(jsonobject1 instanceof JSONObject)) goto _L4; else goto _L3
_L3:
        JSONObject jsonobject2 = (JSONObject)jsonobject1;
_L8:
        CallInfo callinfo;
        String s3 = jsonobject.getString("func");
        String s4 = jsonobject.getString("bundleName");
        callinfo = new CallInfo("call");
        callinfo.b(s4);
        callinfo.c(s3);
        callinfo.a(jsonobject2);
        callinfo.a(s1);
        if(!TextUtils.isEmpty(callinfo.b())) goto _L6; else goto _L5
_L5:
        a(callinfo.a(), CallInfo.CallError.c);
          goto _L1
        Exception exception;
        exception;
_L7:
        exception.printStackTrace();
        if(!TextUtils.isEmpty(s1))
            try
            {
                a(s1, CallInfo.CallError.d);
            }
            catch(JSONException jsonexception)
            {
                jsonexception.printStackTrace();
            }
          goto _L1
_L6:
        _cls1 _lcls1;
        boolean flag;
        _lcls1 = new _cls1(callinfo);
        if(Looper.getMainLooper() != Looper.myLooper())
            break MISSING_BLOCK_LABEL_243;
        flag = true;
_L9:
        if(flag)
            _lcls1.run();
        else
            (new Handler(Looper.getMainLooper())).post(_lcls1);
          goto _L1
        exception;
        s1 = null;
          goto _L7
_L4:
        jsonobject2 = null;
          goto _L8
_L1:
        return;
        flag = false;
          goto _L9
    }

    private class _cls2 extends TimerTask
    {

        final CallInfo a;
        final JsBridge b;

        public void run()
        {
            JSONObject jsonobject = new JSONObject();
            CallInfo callinfo;
            try
            {
                jsonobject.put("toastCallBack", "true");
            }
            catch(JSONException jsonexception)
            {
                jsonexception.printStackTrace();
            }
            callinfo = new CallInfo("callback");
            callinfo.a(a.a());
            callinfo.a(jsonobject);
            JsBridge.a(b).a(callinfo);
        }

        _cls2(CallInfo callinfo)
        {
            b = JsBridge.this;
            a = callinfo;
            super();
        }
    }


    private class _cls1
        implements Runnable
    {

        final CallInfo a;
        final JsBridge b;

        public void run()
        {
            CallInfo.CallError callerror;
            callerror = JsBridge.a(b, a);
            if(callerror == CallInfo.CallError.a)
                break MISSING_BLOCK_LABEL_34;
            JsBridge.a(b, a.a(), callerror);
_L1:
            return;
            JSONException jsonexception;
            jsonexception;
            jsonexception.printStackTrace();
              goto _L1
        }

        _cls1(CallInfo callinfo)
        {
            b = JsBridge.this;
            a = callinfo;
            super();
        }
    }

}
