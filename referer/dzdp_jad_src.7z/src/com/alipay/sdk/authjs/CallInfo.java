// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.alipay.sdk.authjs;

import org.json.JSONException;
import org.json.JSONObject;

public class CallInfo
{
    class CallError extends Enum
    {

        public static final CallError a;
        public static final CallError b;
        public static final CallError c;
        public static final CallError d;
        public static final CallError e;
        private static final CallError f[];

        public static CallError valueOf(String s)
        {
            return (CallError)Enum.valueOf(com/alipay/sdk/authjs/CallInfo$CallError, s);
        }

        public static CallError[] values()
        {
            return (CallError[])f.clone();
        }

        static 
        {
            a = new CallError("NONE_ERROR", 0);
            b = new CallError("FUNCTION_NOT_FOUND", 1);
            c = new CallError("INVALID_PARAMETER", 2);
            d = new CallError("RUNTIME_ERROR", 3);
            e = new CallError("NONE_PERMISS", 4);
            CallError acallerror[] = new CallError[5];
            acallerror[0] = a;
            acallerror[1] = b;
            acallerror[2] = c;
            acallerror[3] = d;
            acallerror[4] = e;
            f = acallerror;
        }

        private CallError(String s, int i1)
        {
            super(s, i1);
        }
    }


    public static final String a = "CallInfo";
    public static final String b = "call";
    public static final String c = "callback";
    public static final String d = "bundleName";
    public static final String e = "clientId";
    public static final String f = "param";
    public static final String g = "func";
    public static final String h = "msgType";
    private String i;
    private String j;
    private String k;
    private String l;
    private JSONObject m;
    private boolean n;

    public CallInfo(String s)
    {
        n = false;
        l = s;
    }

    private static String a(CallError callerror)
    {
        class _cls1
        {

            static final int a[];

            static 
            {
                a = new int[CallError.values().length];
                NoSuchFieldError nosuchfielderror2;
                try
                {
                    a[CallError.b.ordinal()] = 1;
                }
                catch(NoSuchFieldError nosuchfielderror) { }
                try
                {
                    a[CallError.c.ordinal()] = 2;
                }
                catch(NoSuchFieldError nosuchfielderror1) { }
                a[CallError.d.ordinal()] = 3;
_L2:
                return;
                nosuchfielderror2;
                if(true) goto _L2; else goto _L1
_L1:
            }
        }

        _cls1.a[callerror.ordinal()];
        JVM INSTR tableswitch 1 3: default 36
    //                   1 41
    //                   2 47
    //                   3 53;
           goto _L1 _L2 _L3 _L4
_L1:
        String s = "none";
_L6:
        return s;
_L2:
        s = "function not found";
        continue; /* Loop/switch isn't completed */
_L3:
        s = "invalid parameter";
        continue; /* Loop/switch isn't completed */
_L4:
        s = "runtime error";
        if(true) goto _L6; else goto _L5
_L5:
    }

    private void a(boolean flag)
    {
        n = flag;
    }

    private void d(String s)
    {
        l = s;
    }

    private boolean e()
    {
        return n;
    }

    private String f()
    {
        return j;
    }

    private String g()
    {
        return l;
    }

    public final String a()
    {
        return i;
    }

    public final void a(String s)
    {
        i = s;
    }

    public final void a(JSONObject jsonobject)
    {
        m = jsonobject;
    }

    public final String b()
    {
        return k;
    }

    public final void b(String s)
    {
        j = s;
    }

    public final JSONObject c()
    {
        return m;
    }

    public final void c(String s)
    {
        k = s;
    }

    public final String d()
        throws JSONException
    {
        JSONObject jsonobject = new JSONObject();
        jsonobject.put("clientId", i);
        jsonobject.put("func", k);
        jsonobject.put("param", m);
        jsonobject.put("msgType", l);
        return jsonobject.toString();
    }
}
