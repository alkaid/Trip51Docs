// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.alipay.sdk.authjs;


// Referenced classes of package com.alipay.sdk.authjs:
//            CallInfo

public interface IJsCallback
{

    public abstract void a(CallInfo callinfo);
}
