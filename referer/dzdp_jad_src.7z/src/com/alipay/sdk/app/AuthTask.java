// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.alipay.sdk.app;

import android.app.Activity;
import com.alipay.sdk.data.MspConfig;
import com.alipay.sdk.sys.GlobalContext;
import com.alipay.sdk.util.AuthHelper;

public class AuthTask
{

    private Activity a;

    public AuthTask(Activity activity)
    {
        a = activity;
    }

    /**
     * @deprecated Method auth is deprecated
     */

    public String auth(String s)
    {
        this;
        JVM INSTR monitorenter ;
        String s1;
        GlobalContext.a().a(a, MspConfig.a());
        s1 = AuthHelper.a(a, s);
        this;
        JVM INSTR monitorexit ;
        return s1;
        Exception exception;
        exception;
        throw exception;
    }
}
