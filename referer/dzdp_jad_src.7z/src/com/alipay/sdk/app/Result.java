// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.alipay.sdk.app;


// Referenced classes of package com.alipay.sdk.app:
//            ResultStatus

public class Result
{

    private static String a;

    public Result()
    {
    }

    public static String a()
    {
        return a;
    }

    public static String a(int i, String s, String s1)
    {
        StringBuilder stringbuilder = new StringBuilder();
        stringbuilder.append("resultStatus={").append(i).append("};memo={").append(s).append("};result={").append(s1).append("}");
        return stringbuilder.toString();
    }

    public static void a(String s)
    {
        a = s;
    }

    public static String b()
    {
        ResultStatus resultstatus = ResultStatus.a(ResultStatus.c.a());
        return a(resultstatus.a(), resultstatus.b(), "");
    }

    public static String c()
    {
        ResultStatus resultstatus = ResultStatus.a(ResultStatus.e.a());
        return a(resultstatus.a(), resultstatus.b(), "");
    }
}
