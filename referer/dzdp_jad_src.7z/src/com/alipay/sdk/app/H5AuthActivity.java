// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.alipay.sdk.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.net.http.SslError;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.webkit.*;
import android.widget.LinearLayout;
import com.alipay.sdk.authjs.CallInfo;
import com.alipay.sdk.authjs.JsBridge;
import com.alipay.sdk.data.*;
import com.alipay.sdk.exception.FailOperatingException;
import com.alipay.sdk.exception.NetErrorException;
import com.alipay.sdk.net.RequestWrapper;
import com.alipay.sdk.protocol.*;
import com.alipay.sdk.sys.GlobalContext;
import com.alipay.sdk.util.*;
import com.alipay.sdk.widget.Loading;
import java.lang.reflect.Method;
import java.net.URLDecoder;
import org.json.JSONException;
import org.json.JSONObject;

// Referenced classes of package com.alipay.sdk.app:
//            Result, ResultStatus

public class H5AuthActivity extends Activity
{
    private class MyWebChromeClient extends WebChromeClient
    {

        final H5AuthActivity a;

        public boolean onConsoleMessage(ConsoleMessage consolemessage)
        {
            String s = consolemessage.message();
            boolean flag;
            if(TextUtils.isEmpty(s))
            {
                flag = super.onConsoleMessage(consolemessage);
            } else
            {
                String s1 = null;
                if(s.startsWith("h5container.message: "))
                    s1 = s.replaceFirst("h5container.message: ", "");
                if(TextUtils.isEmpty(s1))
                {
                    flag = super.onConsoleMessage(consolemessage);
                } else
                {
                    H5AuthActivity.a(a, s1);
                    flag = super.onConsoleMessage(consolemessage);
                }
            }
            return flag;
        }

        private MyWebChromeClient()
        {
            a = H5AuthActivity.this;
            super();
        }

        MyWebChromeClient(byte byte0)
        {
            this();
        }
    }

    private class MyWebViewClient extends WebViewClient
    {

        final H5AuthActivity a;

        public void onPageFinished(WebView webview, String s)
        {
            H5AuthActivity.i(a);
            H5AuthActivity.h(a).removeCallbacks(H5AuthActivity.g(a));
        }

        public void onPageStarted(WebView webview, String s, Bitmap bitmap)
        {
            H5AuthActivity.f(a);
            H5AuthActivity.h(a).postDelayed(H5AuthActivity.g(a), 30000L);
            super.onPageStarted(webview, s, bitmap);
        }

        public void onReceivedSslError(WebView webview, SslErrorHandler sslerrorhandler, SslError sslerror)
        {
            class _cls1
                implements Runnable
            {

                final SslErrorHandler a;
                final MyWebViewClient b;

                public void run()
                {
                    class _cls1
                        implements android.content.DialogInterface.OnClickListener
                    {

                        final _cls1 a;

                        public void onClick(DialogInterface dialoginterface, int j)
                        {
                            H5AuthActivity.a(a.b.a, true);
                            a.a.proceed();
                            dialoginterface.dismiss();
                        }

                            _cls1()
                            {
                                a = _cls1.this;
                                super();
                            }
                    }

                    class _cls2
                        implements android.content.DialogInterface.OnClickListener
                    {

                        final _cls1 a;

                        public void onClick(DialogInterface dialoginterface, int j)
                        {
                            a.a.cancel();
                            H5AuthActivity.a(a.b.a, false);
                            Result.a(Result.b());
                            a.b.a.finish();
                        }

                            _cls2()
                            {
                                a = _cls1.this;
                                super();
                            }
                    }

                    SystemDefaultDialog.a(b.a, "\u5B89\u5168\u8B66\u544A", "\u7531\u4E8E\u60A8\u7684\u8BBE\u5907\u7F3A\u5C11\u6839\u8BC1\u4E66\uFF0C\u5C06\u65E0\u6CD5\u6821\u9A8C\u8BE5\u8BBF\u95EE\u7AD9\u70B9\u7684\u5B89\u5168\u6027\uFF0C\u53EF\u80FD\u5B58\u5728\u98CE\u9669\uFF0C\u8BF7\u9009\u62E9\u662F\u5426\u7EE7\u7EED\uFF1F", "\u7EE7\u7EED", new _cls1(), "\u9000\u51FA", new _cls2());
                }

                _cls1(SslErrorHandler sslerrorhandler)
                {
                    b = MyWebViewClient.this;
                    a = sslerrorhandler;
                    super();
                }
            }

            if(H5AuthActivity.e(a))
            {
                sslerrorhandler.proceed();
                H5AuthActivity.a(a, false);
            } else
            {
                a.runOnUiThread(new _cls1(sslerrorhandler));
            }
        }

        public boolean shouldOverrideUrlLoading(WebView webview, String s)
        {
            if(!TextUtils.equals(s, "sdklite://h5quit") && !TextUtils.equals(s, "http://m.alipay.com/?action=h5quit")) goto _L2; else goto _L1
_L1:
            Result.a(Result.b());
            a.finish();
_L9:
            return true;
_L2:
            if(!s.startsWith("sdklite://h5quit?result=")) goto _L4; else goto _L3
_L3:
            int j;
            String s1 = s.substring(24 + s.indexOf("sdklite://h5quit?result="));
            j = Integer.parseInt(s1.substring(10 + s1.lastIndexOf("&end_code=")));
            if(j != ResultStatus.a.a()) goto _L6; else goto _L5
_L5:
            String s2 = URLDecoder.decode(s);
            String s3 = s2.substring(24 + s2.indexOf("sdklite://h5quit?result="), s2.lastIndexOf("&end_code="));
            ResultStatus resultstatus1 = ResultStatus.a(j);
            Result.a(Result.a(resultstatus1.a(), resultstatus1.b(), s3));
_L7:
            class _cls2
                implements Runnable
            {

                final MyWebViewClient a;

                public void run()
                {
                    a.a.finish();
                }

                _cls2()
                {
                    a = MyWebViewClient.this;
                    super();
                }
            }

            _cls2 _lcls2 = new _cls2();
            a.runOnUiThread(_lcls2);
            continue; /* Loop/switch isn't completed */
_L6:
            try
            {
                ResultStatus resultstatus = ResultStatus.a(ResultStatus.b.a());
                Result.a(Result.a(resultstatus.a(), resultstatus.b(), ""));
            }
            catch(Exception exception)
            {
                Result.a(Result.c());
            }
            if(true) goto _L7; else goto _L4
_L4:
            webview.loadUrl(s);
            if(true) goto _L9; else goto _L8
_L8:
        }

        private MyWebViewClient()
        {
            a = H5AuthActivity.this;
            super();
        }

        MyWebViewClient(byte byte0)
        {
            this();
        }
    }


    private WebView a;
    private Loading b;
    private Handler c;
    private boolean d;
    private Runnable e;

    public H5AuthActivity()
    {
        c = new Handler();
        e = new _cls11();
    }

    private static void a()
    {
        synchronized(AuthHelper.a)
        {
            try
            {
                obj.notify();
            }
            catch(Exception exception1)
            {
                exception1.printStackTrace();
            }
        }
    }

    static void a(H5AuthActivity h5authactivity)
    {
        Request request;
        RequestWrapper requestwrapper;
        h5authactivity.e();
        String s = h5authactivity.getIntent().getExtras().getString("params");
        request = FrameUtils.a(new InteractionData(), s, new JSONObject());
        request.d().c("com.alipay.mobilecashier");
        request.d().a("com.alipay.mcpay");
        request.d().e("4.0.3");
        request.d().d("/cashier/main");
        requestwrapper = new RequestWrapper(new InteractionData());
        JSONObject jsonobject = requestwrapper.a(h5authactivity, request, false).c();
        h5authactivity.f();
        h5authactivity.a(jsonobject);
        h5authactivity.f();
_L1:
        return;
        NetErrorException neterrorexception;
        neterrorexception;
        h5authactivity.runOnUiThread(h5authactivity. new _cls3());
        h5authactivity.f();
          goto _L1
        Exception exception1;
        exception1;
        h5authactivity.runOnUiThread(h5authactivity. new _cls4());
        h5authactivity.f();
          goto _L1
        Exception exception;
        exception;
        h5authactivity.f();
        throw exception;
    }

    static void a(H5AuthActivity h5authactivity, CallInfo callinfo)
    {
        if(h5authactivity.a != null && callinfo != null)
            try
            {
                String s = callinfo.d();
                Object aobj[] = new Object[1];
                aobj[0] = s;
                h5authactivity.runOnUiThread(h5authactivity. new _cls10(String.format("AlipayJSBridge._invokeJS(%s)", aobj)));
            }
            catch(JSONException jsonexception)
            {
                jsonexception.printStackTrace();
            }
    }

    static void a(H5AuthActivity h5authactivity, String s)
    {
        (new JsBridge(h5authactivity, h5authactivity. new _cls9())).a(s);
    }

    private void a(CallInfo callinfo)
    {
        if(a != null && callinfo != null)
            try
            {
                String s = callinfo.d();
                Object aobj[] = new Object[1];
                aobj[0] = s;
                runOnUiThread(new _cls10(String.format("AlipayJSBridge._invokeJS(%s)", aobj)));
            }
            catch(JSONException jsonexception)
            {
                jsonexception.printStackTrace();
            }
    }

    private void a(String s)
    {
        (new JsBridge(this, new _cls9())).a(s);
    }

    private void a(JSONObject jsonobject)
        throws FailOperatingException
    {
        ElementAction elementaction = ElementAction.a(jsonobject.optJSONObject("form"), "onload");
        if(elementaction == null)
            throw new FailOperatingException();
        ActionType aactiontype[] = ActionType.a(elementaction);
        int j = aactiontype.length;
        int k = 0;
        do
        {
label0:
            {
                if(k < j)
                {
                    ActionType actiontype = aactiontype[k];
                    if(actiontype != ActionType.a)
                        break label0;
                    String s = ActionUtil.a(actiontype.e())[0];
                    if(!Utils.a(s))
                        finish();
                    else
                        runOnUiThread(new _cls5(s));
                }
                return;
            }
            k++;
        } while(true);
    }

    static boolean a(H5AuthActivity h5authactivity, boolean flag)
    {
        h5authactivity.d = flag;
        return flag;
    }

    private void b()
    {
        Request request;
        RequestWrapper requestwrapper;
        e();
        String s = getIntent().getExtras().getString("params");
        request = FrameUtils.a(new InteractionData(), s, new JSONObject());
        request.d().c("com.alipay.mobilecashier");
        request.d().a("com.alipay.mcpay");
        request.d().e("4.0.3");
        request.d().d("/cashier/main");
        requestwrapper = new RequestWrapper(new InteractionData());
        JSONObject jsonobject = requestwrapper.a(this, request, false).c();
        f();
        a(jsonobject);
        f();
_L1:
        return;
        NetErrorException neterrorexception;
        neterrorexception;
        runOnUiThread(new _cls3());
        f();
          goto _L1
        Exception exception1;
        exception1;
        runOnUiThread(new _cls4());
        f();
          goto _L1
        Exception exception;
        exception;
        f();
        throw exception;
    }

    static void b(H5AuthActivity h5authactivity)
    {
        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(h5authactivity);
        builder.setMessage("\u4E0D\u80FD\u8FDE\u63A5\u5230\u670D\u52A1\u5668\uFF0C\u662F\u5426\u91CD\u8BD5\uFF1F");
        builder.setPositiveButton("\u786E\u5B9A", h5authactivity. new _cls6());
        builder.setNeutralButton("\u53D6\u6D88", h5authactivity. new _cls7());
        builder.create().show();
    }

    private void c()
    {
        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        builder.setMessage("\u4E0D\u80FD\u8FDE\u63A5\u5230\u670D\u52A1\u5668\uFF0C\u662F\u5426\u91CD\u8BD5\uFF1F");
        builder.setPositiveButton("\u786E\u5B9A", new _cls6());
        builder.setNeutralButton("\u53D6\u6D88", new _cls7());
        builder.create().show();
    }

    static void c(H5AuthActivity h5authactivity)
    {
        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(h5authactivity);
        builder.setMessage("\u7CFB\u7EDF\u7E41\u5FD9\uFF0C\u8BF7\u7A0D\u540E\u518D\u8BD5");
        builder.setNeutralButton("\u786E\u5B9A", h5authactivity. new _cls8());
        builder.create().show();
    }

    static WebView d(H5AuthActivity h5authactivity)
    {
        return h5authactivity.a;
    }

    private void d()
    {
        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        builder.setMessage("\u7CFB\u7EDF\u7E41\u5FD9\uFF0C\u8BF7\u7A0D\u540E\u518D\u8BD5");
        builder.setNeutralButton("\u786E\u5B9A", new _cls8());
        builder.create().show();
    }

    private void e()
    {
        if(b == null)
            b = new Loading(this);
        b.b();
_L1:
        return;
        Exception exception;
        exception;
        b = null;
          goto _L1
    }

    static boolean e(H5AuthActivity h5authactivity)
    {
        return h5authactivity.d;
    }

    private void f()
    {
        if(b != null && b.a())
            b.c();
        b = null;
    }

    static void f(H5AuthActivity h5authactivity)
    {
        h5authactivity.e();
    }

    static Runnable g(H5AuthActivity h5authactivity)
    {
        return h5authactivity.e;
    }

    static Handler h(H5AuthActivity h5authactivity)
    {
        return h5authactivity.c;
    }

    static void i(H5AuthActivity h5authactivity)
    {
        h5authactivity.f();
    }

    public void finish()
    {
        Object obj = AuthHelper.a;
        obj;
        JVM INSTR monitorenter ;
        obj.notify();
_L2:
        super.finish();
        return;
        Exception exception1;
        exception1;
        exception1.printStackTrace();
        if(true) goto _L2; else goto _L1
_L1:
        Exception exception;
        exception;
        throw exception;
    }

    public void onConfigurationChanged(Configuration configuration)
    {
        super.onConfigurationChanged(configuration);
    }

    protected void onCreate(Bundle bundle)
    {
        super.onCreate(bundle);
        if(getIntent().getExtras() != null) goto _L2; else goto _L1
_L1:
        finish();
_L4:
        return;
_L2:
        super.requestWindowFeature(1);
        GlobalContext.a().a(this, MspConfig.a());
        LinearLayout linearlayout = new LinearLayout(this);
        android.widget.LinearLayout.LayoutParams layoutparams = new android.widget.LinearLayout.LayoutParams(-1, -1);
        linearlayout.setOrientation(1);
        setContentView(linearlayout, layoutparams);
        a = new WebView(this);
        layoutparams.weight = 1.0F;
        a.setVisibility(0);
        linearlayout.addView(a, layoutparams);
        WebSettings websettings = a.getSettings();
        websettings.setUserAgentString((new StringBuilder()).append(websettings.getUserAgentString()).append(Utils.c(this)).toString());
        websettings.setRenderPriority(android.webkit.WebSettings.RenderPriority.HIGH);
        websettings.setSupportMultipleWindows(true);
        websettings.setJavaScriptEnabled(true);
        websettings.setSavePassword(false);
        websettings.setJavaScriptCanOpenWindowsAutomatically(true);
        websettings.setMinimumFontSize(8 + websettings.getMinimumFontSize());
        websettings.setAllowFileAccess(false);
        a.setVerticalScrollbarOverlay(true);
        a.setWebViewClient(new MyWebViewClient((byte)0));
        a.setWebChromeClient(new MyWebChromeClient((byte)0));
        a.setDownloadListener(new _cls1());
        (new Thread(new _cls2())).start();
        if(android.os.Build.VERSION.SDK_INT >= 7)
            try
            {
                Class class1 = a.getSettings().getClass();
                Class aclass[] = new Class[1];
                aclass[0] = Boolean.TYPE;
                Method method1 = class1.getMethod("setDomStorageEnabled", aclass);
                if(method1 != null)
                {
                    WebSettings websettings1 = a.getSettings();
                    Object aobj1[] = new Object[1];
                    aobj1[0] = Boolean.valueOf(true);
                    method1.invoke(websettings1, aobj1);
                }
            }
            catch(Exception exception1) { }
        try
        {
            Method method = a.getClass().getMethod("removeJavascriptInterface", new Class[0]);
            if(method != null)
            {
                WebView webview = a;
                Object aobj[] = new Object[1];
                aobj[0] = "searchBoxJavaBridge_";
                method.invoke(webview, aobj);
            }
        }
        catch(Exception exception) { }
        if(true) goto _L4; else goto _L3
_L3:
    }

    protected void onDestroy()
    {
        super.onDestroy();
    }

    private class _cls11
        implements Runnable
    {

        final H5AuthActivity a;

        public void run()
        {
            H5AuthActivity.i(a);
            H5AuthActivity.b(a);
        }

        _cls11()
        {
            a = H5AuthActivity.this;
            super();
        }
    }


    private class _cls3
        implements Runnable
    {

        final H5AuthActivity a;

        public void run()
        {
            H5AuthActivity.b(a);
        }

        _cls3()
        {
            a = H5AuthActivity.this;
            super();
        }
    }


    private class _cls4
        implements Runnable
    {

        final H5AuthActivity a;

        public void run()
        {
            H5AuthActivity.c(a);
        }

        _cls4()
        {
            a = H5AuthActivity.this;
            super();
        }
    }


    private class _cls10
        implements Runnable
    {

        final String a;
        final H5AuthActivity b;

        public void run()
        {
            H5AuthActivity.d(b).loadUrl((new StringBuilder("javascript:")).append(a).toString());
_L1:
            return;
            Exception exception;
            exception;
            exception.printStackTrace();
              goto _L1
        }

        _cls10(String s)
        {
            b = H5AuthActivity.this;
            a = s;
            super();
        }
    }


    private class _cls9
        implements IJsCallback
    {

        final H5AuthActivity a;

        public final void a(CallInfo callinfo)
        {
            H5AuthActivity.a(a, callinfo);
        }

        _cls9()
        {
            a = H5AuthActivity.this;
            super();
        }
    }


    private class _cls5
        implements Runnable
    {

        final String a;
        final H5AuthActivity b;

        public void run()
        {
            H5AuthActivity.d(b).loadUrl(a);
        }

        _cls5(String s)
        {
            b = H5AuthActivity.this;
            a = s;
            super();
        }
    }


    private class _cls6
        implements android.content.DialogInterface.OnClickListener
    {

        final H5AuthActivity a;

        public void onClick(DialogInterface dialoginterface, int j)
        {
            class _cls1 extends Thread
            {

                final _cls6 a;

                public void run()
                {
                    H5AuthActivity.a(a.a);
                }

                _cls1()
                {
                    a = _cls6.this;
                    super();
                }
            }

            (new _cls1()).start();
        }

        _cls6()
        {
            a = H5AuthActivity.this;
            super();
        }
    }


    private class _cls7
        implements android.content.DialogInterface.OnClickListener
    {

        final H5AuthActivity a;

        public void onClick(DialogInterface dialoginterface, int j)
        {
            a.finish();
        }

        _cls7()
        {
            a = H5AuthActivity.this;
            super();
        }
    }


    private class _cls8
        implements android.content.DialogInterface.OnClickListener
    {

        final H5AuthActivity a;

        public void onClick(DialogInterface dialoginterface, int j)
        {
            a.finish();
        }

        _cls8()
        {
            a = H5AuthActivity.this;
            super();
        }
    }


    private class _cls1
        implements DownloadListener
    {

        final H5AuthActivity a;

        public void onDownloadStart(String s, String s1, String s2, String s3, long l)
        {
            Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(s));
            a.startActivity(intent);
        }

        _cls1()
        {
            a = H5AuthActivity.this;
            super();
        }
    }


    private class _cls2
        implements Runnable
    {

        final H5AuthActivity a;

        public void run()
        {
            H5AuthActivity.a(a);
        }

        _cls2()
        {
            a = H5AuthActivity.this;
            super();
        }
    }

}
