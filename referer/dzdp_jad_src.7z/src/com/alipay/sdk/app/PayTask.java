// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.alipay.sdk.app;

import android.app.Activity;
import android.app.Dialog;
import android.content.*;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import com.alipay.sdk.cons.GlobalConstants;
import com.alipay.sdk.data.*;
import com.alipay.sdk.exception.*;
import com.alipay.sdk.net.RequestWrapper;
import com.alipay.sdk.protocol.*;
import com.alipay.sdk.sys.GlobalContext;
import com.alipay.sdk.util.*;
import com.alipay.sdk.widget.Loading;
import java.io.File;
import org.json.JSONObject;

// Referenced classes of package com.alipay.sdk.app:
//            H5PayActivity, Result, ResultStatus

public class PayTask
{

    static final Object a = com/alipay/sdk/util/PayHelper;
    private Activity b;
    private String c;
    private Dialog d;
    private FileDownloader e;
    private Handler f;
    private String g;
    private boolean h;
    private String i;
    private Runnable j;
    private BroadcastReceiver k;

    public PayTask(Activity activity)
    {
        j = new _cls4();
        k = new _cls5();
        b = activity;
    }

    static Activity a(PayTask paytask)
    {
        return paytask.b;
    }

    static Dialog a(PayTask paytask, Dialog dialog)
    {
        paytask.d = dialog;
        return dialog;
    }

    private String a()
    {
        PayHelper payhelper;
        String s;
        if(GlobalConstants.n)
            if(c.startsWith("https://wappaygw.alipay.com/home/exterfaceAssign.htm?"))
                c = c.substring(53 + c.indexOf("https://wappaygw.alipay.com/home/exterfaceAssign.htm?"));
            else
            if(c.startsWith("https://mclient.alipay.com/home/exterfaceAssign.htm?"))
                c = c.substring(52 + c.indexOf("https://mclient.alipay.com/home/exterfaceAssign.htm?"));
            else
            if(c.startsWith("http://mcashier.stable.alipay.net/home/exterfaceAssign.htm?"))
                c = c.substring(59 + c.indexOf("http://mcashier.stable.alipay.net/home/exterfaceAssign.htm?"));
            else
            if(c.startsWith("http://mobileclientgw.stable.alipay.net/home/exterfaceAssign.htm?"))
                c = c.substring(65 + c.indexOf("http://mobileclientgw.stable.alipay.net/home/exterfaceAssign.htm?"));
        payhelper = new PayHelper(b);
        if(c.contains("bizcontext="))
            s = payhelper.a(c);
        else
        if(c.contains("\""))
            s = payhelper.a((new StringBuilder()).append(c).append("&bizcontext=\"{\"appkey\":\"2014052600006128\"}\"").toString());
        else
            s = payhelper.a((new StringBuilder()).append(c).append("&bizcontext={\"appkey\":\"2014052600006128\"}").toString());
        return s;
    }

    private String a(ActionType actiontype)
    {
        InterruptedException interruptedexception;
        String as[] = ActionUtil.a(actiontype.e());
        Intent intent = new Intent(b, com/alipay/sdk/app/H5PayActivity);
        Bundle bundle = new Bundle();
        bundle.putString("url", as[0]);
        if(as.length == 2)
            bundle.putString("cookie", as[1]);
        intent.putExtras(bundle);
        b.startActivity(intent);
        String s;
        synchronized(a)
        {
            try
            {
                a.wait();
            }
            // Misplaced declaration of an exception variable
            catch(InterruptedException interruptedexception) { }
        }
        s = Result.a();
        if(TextUtils.isEmpty(s))
            s = Result.b();
        return s;
    }

    static void a(PayTask paytask, ActionType aactiontype[])
    {
        int l;
        int i1;
        l = aactiontype.length;
        i1 = 0;
_L2:
        if(i1 >= l)
            break; /* Loop/switch isn't completed */
        ActionType actiontype = aactiontype[i1];
        if(actiontype == ActionType.b)
        {
            paytask.g = ActionUtil.a(actiontype.e())[0];
            paytask.c();
        }
        if(actiontype != ActionType.g)
            break MISSING_BLOCK_LABEL_71;
        Object obj = a;
        obj;
        JVM INSTR monitorenter ;
        Result.a(Result.b());
        Exception exception;
        try
        {
            a.notify();
        }
        catch(Exception exception1) { }
        i1++;
        if(true) goto _L2; else goto _L1
        exception;
        throw exception;
_L1:
    }

    private void a(String s, String s1, String s2, ActionType aactiontype[], String s3, ActionType aactiontype1[])
    {
        b.runOnUiThread(new _cls1(aactiontype, aactiontype1, s, s1, s2, s3));
    }

    private void a(ActionType aactiontype[])
    {
        int l;
        int i1;
        l = aactiontype.length;
        i1 = 0;
_L2:
        if(i1 >= l)
            break; /* Loop/switch isn't completed */
        ActionType actiontype = aactiontype[i1];
        if(actiontype == ActionType.b)
        {
            g = ActionUtil.a(actiontype.e())[0];
            c();
        }
        if(actiontype != ActionType.g)
            break MISSING_BLOCK_LABEL_71;
        Object obj = a;
        obj;
        JVM INSTR monitorenter ;
        Result.a(Result.b());
        Exception exception;
        try
        {
            a.notify();
        }
        catch(Exception exception1) { }
        i1++;
        if(true) goto _L2; else goto _L1
        exception;
        throw exception;
_L1:
    }

    static boolean a(PayTask paytask, boolean flag)
    {
        paytask.h = flag;
        return flag;
    }

    static FileDownloader b(PayTask paytask)
    {
        return paytask.e;
    }

    private String b()
    {
        int l = 0;
        if(b == null || b.isFinishing()) goto _L2; else goto _L1
_L1:
        Loading loading;
        loading = new Loading(b);
        loading.b();
_L17:
        if(!GlobalConstants.n) goto _L4; else goto _L3
_L3:
        if(!c.startsWith("https://wappaygw.alipay.com/home/exterfaceAssign.htm?")) goto _L6; else goto _L5
_L5:
        c = c.substring(53 + c.indexOf("https://wappaygw.alipay.com/home/exterfaceAssign.htm?"));
_L4:
        com.alipay.sdk.data.Request request;
        RequestWrapper requestwrapper;
        request = FrameUtils.a(new InteractionData(), c, new JSONObject());
        requestwrapper = new RequestWrapper(new InteractionData());
        ActionType aactiontype[];
        int i1;
        int j1;
        aactiontype = ActionType.a(ElementAction.a(requestwrapper.a(b, request, false).c().optJSONObject("form"), "onload"));
        i1 = aactiontype.length;
        j1 = 0;
_L7:
        if(j1 >= i1)
            break; /* Loop/switch isn't completed */
        ActionType actiontype1 = aactiontype[j1];
        if(actiontype1 == ActionType.f)
            ActionUtil.b(actiontype1.e());
        j1++;
          goto _L7
        Exception exception;
        exception;
        loading = null;
        continue; /* Loop/switch isn't completed */
_L6:
        if(c.startsWith("https://mclient.alipay.com/home/exterfaceAssign.htm?"))
            c = c.substring(52 + c.indexOf("https://mclient.alipay.com/home/exterfaceAssign.htm?"));
        else
        if(c.startsWith("http://mcashier.stable.alipay.net/home/exterfaceAssign.htm?"))
        {
            c = c.substring(59 + c.indexOf("http://mcashier.stable.alipay.net/home/exterfaceAssign.htm?"));
            GlobalConstants.b = "https://mobiletestabc.alipaydev.com/mobileclientgw/stable/gateway.do";
        } else
        if(c.startsWith("http://mobileclientgw.stable.alipay.net/home/exterfaceAssign.htm?"))
        {
            c = c.substring(65 + c.indexOf("http://mobileclientgw.stable.alipay.net/home/exterfaceAssign.htm?"));
            GlobalConstants.b = "https://mobiletestabc.alipaydev.com/mobileclientgw/stable/gateway.do";
        }
        if(true) goto _L4; else goto _L8
_L8:
        if(loading == null)
            break MISSING_BLOCK_LABEL_329;
        loading.c();
        int k1 = aactiontype.length;
_L14:
        if(l >= k1) goto _L10; else goto _L9
_L9:
        ActionType actiontype = aactiontype[l];
        if(actiontype != ActionType.a) goto _L12; else goto _L11
_L11:
        String s2 = a(actiontype);
        String s;
        if(loading != null)
            loading.c();
        s = s2;
_L13:
        return s;
_L12:
        String s1;
        if(actiontype != ActionType.d)
            break MISSING_BLOCK_LABEL_459;
        f = new Handler(b.getMainLooper());
        i = (new StringBuilder()).append(b.getCacheDir().getAbsolutePath()).append("/temp.apk").toString();
        s1 = b(actiontype);
        if(loading != null)
            loading.c();
        s = s1;
          goto _L13
        l++;
          goto _L14
_L10:
        ResultStatus resultstatus;
        if(loading == null)
            break MISSING_BLOCK_LABEL_602;
        loading.c();
        resultstatus = null;
_L15:
        if(resultstatus == null)
            resultstatus = ResultStatus.a(ResultStatus.b.a());
        s = Result.a(resultstatus.a(), resultstatus.b(), "");
          goto _L13
        NetErrorException neterrorexception;
        neterrorexception;
        ResultStatus resultstatus1 = ResultStatus.a(ResultStatus.d.a());
        Exception exception1;
        UnZipException unzipexception;
        AppErrorException apperrorexception;
        FailOperatingException failoperatingexception;
        if(loading != null)
        {
            loading.c();
            resultstatus = resultstatus1;
        } else
        {
            resultstatus = resultstatus1;
        }
          goto _L15
        failoperatingexception;
        if(loading == null)
            break MISSING_BLOCK_LABEL_602;
        loading.c();
        resultstatus = null;
          goto _L15
        apperrorexception;
        if(loading == null)
            break MISSING_BLOCK_LABEL_602;
        loading.c();
        resultstatus = null;
          goto _L15
        unzipexception;
        if(loading == null)
            break MISSING_BLOCK_LABEL_602;
        loading.c();
        resultstatus = null;
          goto _L15
        exception1;
        if(loading != null)
            loading.c();
        throw exception1;
        resultstatus = null;
          goto _L15
_L2:
        loading = null;
        if(true) goto _L17; else goto _L16
_L16:
    }

    private String b(ActionType actiontype)
    {
        String as[] = ActionUtil.a(actiontype.e());
        ActionType aactiontype[];
        ActionType aactiontype1[];
        String s;
        String s1;
        String s2;
        String s3;
        Object obj;
        Exception exception;
        InterruptedException interruptedexception;
        String s4;
        if(as.length > 4 && !TextUtils.isEmpty(as[4]))
            aactiontype = ActionType.a(ElementAction.a(as[4], actiontype));
        else
            aactiontype = null;
        if(as.length > 5 && !TextUtils.isEmpty(as[5]))
            aactiontype1 = ActionType.a(ElementAction.a(as[5], actiontype));
        else
            aactiontype1 = null;
        s = as[0];
        s1 = as[1];
        s2 = as[2];
        s3 = as[3];
        b.runOnUiThread(new _cls1(aactiontype, aactiontype1, s, s1, s2, s3));
        obj = a;
        obj;
        JVM INSTR monitorenter ;
        a.wait();
_L1:
        if(h)
        {
            s4 = a();
        } else
        {
            s4 = Result.a();
            if(TextUtils.isEmpty(s4))
                s4 = Result.b();
        }
        return s4;
        interruptedexception;
        interruptedexception.printStackTrace();
          goto _L1
        exception;
        throw exception;
    }

    static BroadcastReceiver c(PayTask paytask)
    {
        return paytask.k;
    }

    private void c()
    {
        Loading loading = new Loading(b);
        loading.a("\u6B63\u5728\u4E0B\u8F7D\u4E2D", true, new _cls2(loading));
        e = new FileDownloader();
        e.a(g);
        e.b(i);
        e.a(new _cls3(loading));
        e.b();
        IntentFilter intentfilter = new IntentFilter();
        intentfilter.addAction("android.intent.action.PACKAGE_ADDED");
        intentfilter.addDataScheme("package");
        b.registerReceiver(k, intentfilter);
        f.postDelayed(j, 0x2bf20L);
    }

    static Runnable d(PayTask paytask)
    {
        return paytask.j;
    }

    private void d()
    {
        _cls6 _lcls6 = new _cls6();
        f.post(_lcls6);
    }

    static Handler e(PayTask paytask)
    {
        return paytask.f;
    }

    static void f(PayTask paytask)
    {
        _cls6 _lcls6 = paytask. new _cls6();
        paytask.f.post(_lcls6);
    }

    static void g(PayTask paytask)
    {
        paytask.c();
    }

    static Dialog h(PayTask paytask)
    {
        return paytask.d;
    }

    static String i(PayTask paytask)
    {
        return paytask.i;
    }

    public boolean checkAccountIfExist()
    {
        boolean flag;
        com.alipay.sdk.data.Request request;
        flag = false;
        request = FrameUtils.a();
        boolean flag1 = (new RequestWrapper()).a(b, request, true).c().optBoolean("hasAccount", false);
        flag = flag1;
_L2:
        return flag;
        Exception exception;
        exception;
        if(true) goto _L2; else goto _L1
_L1:
    }

    public String getVersion()
    {
        return "9.1.8";
    }

    /**
     * @deprecated Method pay is deprecated
     */

    public String pay(String s)
    {
        this;
        JVM INSTR monitorenter ;
        c = s;
        GlobalContext.a().a(b, MspConfig.a());
        if(c.contains("service=alipay.acquire.mr.ord.createandpay"))
            GlobalConstants.n = true;
        if(!s.contains("paymethod=\"expressGateway\"")) goto _L2; else goto _L1
_L1:
        String s3 = b();
        String s2 = s3;
_L4:
        this;
        JVM INSTR monitorexit ;
        return s2;
_L2:
        String s1;
        if(Utils.b(b))
        {
            s2 = a();
            if(TextUtils.equals(s2, "failed"))
                s2 = b();
            else
            if(TextUtils.isEmpty(s2))
                s2 = Result.b();
            continue; /* Loop/switch isn't completed */
        }
        s1 = b();
        s2 = s1;
        if(true) goto _L4; else goto _L3
_L3:
        Exception exception;
        exception;
        throw exception;
    }


    private class _cls4
        implements Runnable
    {

        final PayTask a;

        public void run()
        {
            if(PayTask.b(a) != null)
                PayTask.b(a).c();
            class _cls1
                implements android.content.DialogInterface.OnClickListener
            {

                final _cls4 a;

                public void onClick(DialogInterface dialoginterface, int l)
                {
                    PayTask.g(a.a);
                }

                _cls1()
                {
                    a = _cls4.this;
                    super();
                }
            }

            class _cls2
                implements android.content.DialogInterface.OnClickListener
            {

                final _cls4 a;

                public void onClick(DialogInterface dialoginterface, int l)
                {
                    Object obj = PayTask.a;
                    obj;
                    JVM INSTR monitorenter ;
                    Result.a(Result.b());
                    Exception exception;
                    try
                    {
                        PayTask.a.notify();
                    }
                    catch(Exception exception1) { }
                    return;
                    exception;
                    obj;
                    JVM INSTR monitorexit ;
                    throw exception;
                }

                _cls2()
                {
                    a = _cls4.this;
                    super();
                }
            }

            SystemDefaultDialog.a(PayTask.a(a), "\u63D0\u793A", "\u4E0B\u8F7D\u5B89\u88C5\u5305\u5931\u8D25\uFF0C\u662F\u5426\u91CD\u8BD5\uFF1F", "\u91CD\u8BD5", new _cls1(), "\u53D6\u6D88", new _cls2());
        }

        _cls4()
        {
            a = PayTask.this;
            super();
        }
    }


    private class _cls5 extends BroadcastReceiver
    {

        final PayTask a;

        public void onReceive(Context context, Intent intent)
        {
            if(intent.getAction().equalsIgnoreCase("android.intent.action.PACKAGE_ADDED"))
            {
                class _cls1
                    implements Runnable
                {

                    final _cls5 a;

                    public void run()
                    {
                        if(PayTask.h(a.a) != null)
                            PayTask.h(a.a).dismiss();
                        PayTask.a(a.a, true);
                        PayTask.a(a.a).unregisterReceiver(PayTask.c(a.a));
                    }

                _cls1()
                {
                    a = _cls5.this;
                    super();
                }
                }

                _cls1 _lcls1 = new _cls1();
                PayTask.e(a).post(_lcls1);
            }
        }

        _cls5()
        {
            a = PayTask.this;
            super();
        }
    }


    private class _cls1
        implements Runnable
    {

        final ActionType a[];
        final ActionType b[];
        final String c;
        final String d;
        final String e;
        final String f;
        final PayTask g;

        public void run()
        {
            class _cls1
                implements android.content.DialogInterface.OnClickListener
            {

                final _cls1 a;

                public void onClick(DialogInterface dialoginterface, int l)
                {
                    PayTask.a(a.g, a.a);
                }

                _cls1()
                {
                    a = _cls1.this;
                    super();
                }
            }

            class _cls2
                implements android.content.DialogInterface.OnClickListener
            {

                final _cls1 a;

                public void onClick(DialogInterface dialoginterface, int l)
                {
                    PayTask.a(a.g, a.b);
                }

                _cls2()
                {
                    a = _cls1.this;
                    super();
                }
            }

            _cls1 _lcls1;
            _cls2 _lcls2;
            if(a != null)
                _lcls1 = new _cls1();
            else
                _lcls1 = null;
            if(b != null)
                _lcls2 = new _cls2();
            else
                _lcls2 = null;
            SystemDefaultDialog.a(PayTask.a(g), c, d, e, _lcls1, f, _lcls2);
        }

        _cls1(ActionType aactiontype[], ActionType aactiontype1[], String s, String s1, String s2, String s3)
        {
            g = PayTask.this;
            a = aactiontype;
            b = aactiontype1;
            c = s;
            d = s1;
            e = s2;
            f = s3;
            super();
        }
    }


    private class _cls2
        implements android.content.DialogInterface.OnCancelListener
    {

        final Loading a;
        final PayTask b;

        public void onCancel(DialogInterface dialoginterface)
        {
            a.c();
            PayTask.b(b).c();
            PayTask.a(b).unregisterReceiver(PayTask.c(b));
            PayTask.e(b).removeCallbacks(PayTask.d(b));
            Object obj = PayTask.a;
            obj;
            JVM INSTR monitorenter ;
            Result.a(Result.b());
            Exception exception;
            try
            {
                PayTask.a.notify();
            }
            catch(Exception exception1) { }
            return;
            exception;
            obj;
            JVM INSTR monitorexit ;
            throw exception;
        }

        _cls2(Loading loading)
        {
            b = PayTask.this;
            a = loading;
            super();
        }
    }


    private class _cls3
        implements com.alipay.sdk.util.FileDownloader.IDownloadProgress
    {

        final Loading a;
        final PayTask b;

        public final void a()
        {
            a.c();
            PayTask.e(b).removeCallbacks(PayTask.d(b));
            PayTask.f(b);
        }

        public final void b()
        {
        }

        public final void c()
        {
            a.c();
            PayTask.e(b).post(PayTask.d(b));
        }

        _cls3(Loading loading)
        {
            b = PayTask.this;
            a = loading;
            super();
        }
    }


    private class _cls6
        implements Runnable
    {

        final PayTask a;

        public void run()
        {
            if(!Utils.b(PayTask.a(a), PayTask.i(a))) goto _L2; else goto _L1
_L1:
            Utils.a(PayTask.a(a), PayTask.i(a));
            class _cls1
                implements android.content.DialogInterface.OnClickListener
            {

                final _cls6 a;

                public void onClick(DialogInterface dialoginterface, int l)
                {
                    PayTask.f(a.a);
                }

                _cls1()
                {
                    a = _cls6.this;
                    super();
                }
            }

            class _cls2
                implements android.content.DialogInterface.OnClickListener
            {

                final _cls6 a;

                public void onClick(DialogInterface dialoginterface, int l)
                {
                    Exception exception2;
                    PayTask.a(a.a).unregisterReceiver(PayTask.c(a.a));
                    PayTask.a(a.a, false);
                    Result.a(Result.b());
                    synchronized(PayTask.a)
                    {
                        try
                        {
                            PayTask.a.notify();
                        }
                        // Misplaced declaration of an exception variable
                        catch(Exception exception2) { }
                    }
                }

                _cls2()
                {
                    a = _cls6.this;
                    super();
                }
            }

            PayTask.a(a, SystemDefaultDialog.a(PayTask.a(a), "\u63D0\u793A", "\u662F\u5426\u53D6\u6D88\u5B89\u88C5\uFF1F", "\u91CD\u65B0\u5B89\u88C5", new _cls1(), "\u53D6\u6D88", new _cls2()));
_L4:
            return;
_L2:
            Object obj = PayTask.a;
            obj;
            JVM INSTR monitorenter ;
            Result.a(Result.c());
            Exception exception;
            try
            {
                PayTask.a.notify();
            }
            catch(Exception exception1) { }
            if(true) goto _L4; else goto _L3
_L3:
            exception;
            throw exception;
        }

        _cls6()
        {
            a = PayTask.this;
            super();
        }
    }

}
