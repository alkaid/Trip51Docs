// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.alipay.sdk.app;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.net.http.SslError;
import android.os.*;
import android.text.TextUtils;
import android.webkit.*;
import android.widget.LinearLayout;
import com.alipay.sdk.cons.GlobalConstants;
import com.alipay.sdk.util.Utils;
import com.alipay.sdk.widget.Loading;
import java.lang.reflect.Method;
import java.net.URLDecoder;

// Referenced classes of package com.alipay.sdk.app:
//            PayTask, ResultStatus, Result

public class H5PayActivity extends Activity
{
    private class MyWebChromeClient extends WebChromeClient
    {

        final H5PayActivity a;

        public boolean onJsAlert(WebView webview, String s, String s1, JsResult jsresult)
        {
            class _cls2
                implements android.content.DialogInterface.OnClickListener
            {

                final JsResult a;
                final MyWebChromeClient b;

                public void onClick(DialogInterface dialoginterface, int i)
                {
                    a.confirm();
                }

                _cls2(JsResult jsresult)
                {
                    b = MyWebChromeClient.this;
                    a = jsresult;
                    super();
                }
            }

            class _cls1
                implements android.content.DialogInterface.OnClickListener
            {

                final JsResult a;
                final MyWebChromeClient b;

                public void onClick(DialogInterface dialoginterface, int i)
                {
                    a.cancel();
                }

                _cls1(JsResult jsresult)
                {
                    b = MyWebChromeClient.this;
                    a = jsresult;
                    super();
                }
            }

            (new android.app.AlertDialog.Builder(a)).setTitle("\u63D0\u793A").setMessage(s1).setPositiveButton("\u786E\u5B9A", new _cls2(jsresult)).setNegativeButton("\u53D6\u6D88", new _cls1(jsresult)).show();
            return true;
        }

        public boolean onJsConfirm(WebView webview, String s, String s1, JsResult jsresult)
        {
            class _cls4
                implements android.content.DialogInterface.OnClickListener
            {

                final JsResult a;
                final MyWebChromeClient b;

                public void onClick(DialogInterface dialoginterface, int i)
                {
                    a.confirm();
                }

                _cls4(JsResult jsresult)
                {
                    b = MyWebChromeClient.this;
                    a = jsresult;
                    super();
                }
            }

            class _cls3
                implements android.content.DialogInterface.OnClickListener
            {

                final JsResult a;
                final MyWebChromeClient b;

                public void onClick(DialogInterface dialoginterface, int i)
                {
                    a.cancel();
                }

                _cls3(JsResult jsresult)
                {
                    b = MyWebChromeClient.this;
                    a = jsresult;
                    super();
                }
            }

            (new android.app.AlertDialog.Builder(a)).setTitle("\u63D0\u793A").setMessage(s1).setPositiveButton("\u786E\u5B9A", new _cls4(jsresult)).setNegativeButton("\u53D6\u6D88", new _cls3(jsresult)).show();
            return true;
        }

        public boolean onJsPrompt(WebView webview, String s, String s1, String s2, JsPromptResult jspromptresult)
        {
            class _cls6
                implements android.content.DialogInterface.OnClickListener
            {

                final JsPromptResult a;
                final MyWebChromeClient b;

                public void onClick(DialogInterface dialoginterface, int i)
                {
                    a.confirm();
                }

                _cls6(JsPromptResult jspromptresult)
                {
                    b = MyWebChromeClient.this;
                    a = jspromptresult;
                    super();
                }
            }

            class _cls5
                implements android.content.DialogInterface.OnClickListener
            {

                final JsPromptResult a;
                final MyWebChromeClient b;

                public void onClick(DialogInterface dialoginterface, int i)
                {
                    a.cancel();
                }

                _cls5(JsPromptResult jspromptresult)
                {
                    b = MyWebChromeClient.this;
                    a = jspromptresult;
                    super();
                }
            }

            (new android.app.AlertDialog.Builder(a)).setTitle("\u63D0\u793A").setMessage(s1).setPositiveButton("\u786E\u5B9A", new _cls6(jspromptresult)).setNegativeButton("\u53D6\u6D88", new _cls5(jspromptresult)).show();
            return true;
        }

        private MyWebChromeClient()
        {
            a = H5PayActivity.this;
            super();
        }

        MyWebChromeClient(byte byte0)
        {
            this();
        }
    }

    private class MyWebViewClient extends WebViewClient
    {

        final H5PayActivity a;

        public void onFormResubmission(WebView webview, Message message, Message message1)
        {
        }

        public void onLoadResource(WebView webview, String s)
        {
        }

        public void onPageFinished(WebView webview, String s)
        {
            H5PayActivity.f(a);
            H5PayActivity.e(a).removeCallbacks(H5PayActivity.d(a));
        }

        public void onPageStarted(WebView webview, String s, Bitmap bitmap)
        {
            H5PayActivity.c(a);
            H5PayActivity.e(a).postDelayed(H5PayActivity.d(a), 30000L);
            super.onPageStarted(webview, s, bitmap);
        }

        public void onReceivedError(WebView webview, int i, String s, String s1)
        {
            H5PayActivity.a(a);
            super.onReceivedError(webview, i, s, s1);
        }

        public void onReceivedSslError(WebView webview, SslErrorHandler sslerrorhandler, SslError sslerror)
        {
            class _cls1
                implements Runnable
            {

                final SslErrorHandler a;
                final MyWebViewClient b;

                public void run()
                {
                    class _cls1
                        implements android.content.DialogInterface.OnClickListener
                    {

                        final _cls1 a;

                        public void onClick(DialogInterface dialoginterface, int i)
                        {
                            H5PayActivity.a(a.b.a, true);
                            a.a.proceed();
                            dialoginterface.dismiss();
                        }

                            _cls1()
                            {
                                a = _cls1.this;
                                super();
                            }
                    }

                    class _cls2
                        implements android.content.DialogInterface.OnClickListener
                    {

                        final _cls1 a;

                        public void onClick(DialogInterface dialoginterface, int i)
                        {
                            a.a.cancel();
                            H5PayActivity.a(a.b.a, false);
                            Result.a(Result.b());
                            a.b.a.finish();
                        }

                            _cls2()
                            {
                                a = _cls1.this;
                                super();
                            }
                    }

                    SystemDefaultDialog.a(b.a, "\u5B89\u5168\u8B66\u544A", "\u7531\u4E8E\u60A8\u7684\u8BBE\u5907\u7F3A\u5C11\u6839\u8BC1\u4E66\uFF0C\u5C06\u65E0\u6CD5\u6821\u9A8C\u8BE5\u8BBF\u95EE\u7AD9\u70B9\u7684\u5B89\u5168\u6027\uFF0C\u53EF\u80FD\u5B58\u5728\u98CE\u9669\uFF0C\u8BF7\u9009\u62E9\u662F\u5426\u7EE7\u7EED\uFF1F", "\u7EE7\u7EED", new _cls1(), "\u9000\u51FA", new _cls2());
                }

                _cls1(SslErrorHandler sslerrorhandler)
                {
                    b = MyWebViewClient.this;
                    a = sslerrorhandler;
                    super();
                }
            }

            if(H5PayActivity.b(a))
            {
                sslerrorhandler.proceed();
                H5PayActivity.a(a, false);
            } else
            {
                a.runOnUiThread(new _cls1(sslerrorhandler));
            }
        }

        public boolean shouldOverrideUrlLoading(WebView webview, String s)
        {
            boolean flag = false;
            if(!s.startsWith("alipays://platformapi/startApp?")) goto _L2; else goto _L1
_L1:
            return flag;
_L2:
            if(TextUtils.equals(s, "sdklite://h5quit") || TextUtils.equals(s, "http://m.alipay.com/?action=h5quit"))
            {
                Result.a(Result.b());
                a.finish();
                flag = true;
                continue; /* Loop/switch isn't completed */
            }
            if(!s.startsWith("sdklite://h5quit?result="))
                break MISSING_BLOCK_LABEL_456;
            int i;
            String s1 = s.substring(24 + s.indexOf("sdklite://h5quit?result="));
            i = Integer.parseInt(s1.substring(10 + s1.lastIndexOf("&end_code=")));
            if(i != ResultStatus.a.a() && i != ResultStatus.f.a()) goto _L4; else goto _L3
_L3:
            StringBuilder stringbuilder = new StringBuilder();
            if(!GlobalConstants.n) goto _L6; else goto _L5
_L5:
            String s3;
            String s5 = URLDecoder.decode(s);
            String s6 = URLDecoder.decode(s5);
            String s7 = s6.substring(24 + s6.indexOf("sdklite://h5quit?result="), s6.lastIndexOf("&end_code=")).split("&return_url=")[0];
            int k = 12 + s5.indexOf("&return_url=");
            stringbuilder.append(s7).append("&return_url=").append(s5.substring(k, s5.indexOf("&", k))).append(s5.substring(s5.indexOf("&", k)));
            s3 = stringbuilder.toString();
_L7:
            ResultStatus resultstatus = ResultStatus.a(i);
            Result.a(Result.a(resultstatus.a(), resultstatus.b(), s3));
_L8:
            class _cls2
                implements Runnable
            {

                final MyWebViewClient a;

                public void run()
                {
                    a.a.finish();
                }

                _cls2()
                {
                    a = MyWebViewClient.this;
                    super();
                }
            }

            _cls2 _lcls2 = new _cls2();
            a.runOnUiThread(_lcls2);
            flag = true;
            continue; /* Loop/switch isn't completed */
_L6:
            String s2 = URLDecoder.decode(s);
            s3 = s2.substring(24 + s2.indexOf("sdklite://h5quit?result="), s2.lastIndexOf("&end_code="));
            if(s3.contains("&return_url=\""))
            {
                String s4 = s3.split("&return_url=\"")[0];
                int j = 13 + s3.indexOf("&return_url=\"");
                stringbuilder.append(s4).append("&return_url=\"").append(s3.substring(j, s3.indexOf("\"&", j))).append(s3.substring(s3.indexOf("\"&", j)));
                s3 = stringbuilder.toString();
            }
              goto _L7
_L4:
            ResultStatus resultstatus1 = ResultStatus.a(ResultStatus.b.a());
            Result.a(Result.a(resultstatus1.a(), resultstatus1.b(), ""));
              goto _L8
            Exception exception;
            exception;
            Result.a(Result.c());
              goto _L8
            webview.loadUrl(s);
            flag = true;
            if(true) goto _L1; else goto _L9
_L9:
        }

        private MyWebViewClient()
        {
            a = H5PayActivity.this;
            super();
        }

        MyWebViewClient(byte byte0)
        {
            this();
        }
    }


    private WebView a;
    private Loading b;
    private Handler c;
    private boolean d;
    private boolean e;
    private Runnable f;

    public H5PayActivity()
    {
        c = new Handler();
        f = new _cls1();
    }

    private static void a()
    {
        synchronized(PayTask.a)
        {
            try
            {
                obj.notify();
            }
            catch(Exception exception1)
            {
                exception1.printStackTrace();
            }
        }
    }

    static boolean a(H5PayActivity h5payactivity)
    {
        h5payactivity.d = true;
        return true;
    }

    static boolean a(H5PayActivity h5payactivity, boolean flag)
    {
        h5payactivity.e = flag;
        return flag;
    }

    private void b()
    {
        if(b == null)
            b = new Loading(this);
        b.b();
    }

    static boolean b(H5PayActivity h5payactivity)
    {
        return h5payactivity.e;
    }

    private void c()
    {
        if(b != null && b.a())
            b.c();
        b = null;
    }

    static void c(H5PayActivity h5payactivity)
    {
        if(h5payactivity.b == null)
            h5payactivity.b = new Loading(h5payactivity);
        h5payactivity.b.b();
    }

    static Runnable d(H5PayActivity h5payactivity)
    {
        return h5payactivity.f;
    }

    static Handler e(H5PayActivity h5payactivity)
    {
        return h5payactivity.c;
    }

    static void f(H5PayActivity h5payactivity)
    {
        if(h5payactivity.b != null && h5payactivity.b.a())
            h5payactivity.b.c();
        h5payactivity.b = null;
    }

    public void finish()
    {
        Object obj = PayTask.a;
        obj;
        JVM INSTR monitorenter ;
        obj.notify();
_L2:
        super.finish();
        return;
        Exception exception1;
        exception1;
        exception1.printStackTrace();
        if(true) goto _L2; else goto _L1
_L1:
        Exception exception;
        exception;
        throw exception;
    }

    public void onBackPressed()
    {
        if(a.canGoBack())
        {
            if(d)
            {
                ResultStatus resultstatus = ResultStatus.a(ResultStatus.d.a());
                Result.a(Result.a(resultstatus.a(), resultstatus.b(), ""));
                finish();
            }
        } else
        {
            Result.a(Result.b());
            finish();
        }
    }

    public void onConfigurationChanged(Configuration configuration)
    {
        super.onConfigurationChanged(configuration);
    }

    protected void onCreate(Bundle bundle)
    {
        Bundle bundle1;
        super.onCreate(bundle);
        bundle1 = getIntent().getExtras();
        if(bundle1 != null) goto _L2; else goto _L1
_L1:
        finish();
_L4:
        return;
_L2:
        String s = bundle1.getString("url");
        Exception exception;
        if(!Utils.a(s))
        {
            finish();
        } else
        {
            super.requestWindowFeature(1);
            String s1 = bundle1.getString("cookie");
            if(!TextUtils.isEmpty(s1))
            {
                CookieSyncManager.createInstance(this).sync();
                CookieManager.getInstance().setCookie(s, s1);
                CookieSyncManager.getInstance().sync();
            }
            LinearLayout linearlayout = new LinearLayout(this);
            android.widget.LinearLayout.LayoutParams layoutparams = new android.widget.LinearLayout.LayoutParams(-1, -1);
            linearlayout.setOrientation(1);
            setContentView(linearlayout, layoutparams);
            a = new WebView(this);
            layoutparams.weight = 1.0F;
            a.setVisibility(0);
            linearlayout.addView(a, layoutparams);
            WebSettings websettings = a.getSettings();
            websettings.setUserAgentString((new StringBuilder()).append(websettings.getUserAgentString()).append(Utils.c(this)).toString());
            websettings.setRenderPriority(android.webkit.WebSettings.RenderPriority.HIGH);
            websettings.setSupportMultipleWindows(true);
            websettings.setJavaScriptEnabled(true);
            websettings.setSavePassword(false);
            websettings.setJavaScriptCanOpenWindowsAutomatically(true);
            websettings.setMinimumFontSize(8 + websettings.getMinimumFontSize());
            websettings.setAllowFileAccess(false);
            a.setVerticalScrollbarOverlay(true);
            a.setWebViewClient(new MyWebViewClient((byte)0));
            a.setWebChromeClient(new MyWebChromeClient((byte)0));
            a.loadUrl(s);
            if(android.os.Build.VERSION.SDK_INT >= 7)
                try
                {
                    Class class1 = a.getSettings().getClass();
                    Class aclass[] = new Class[1];
                    aclass[0] = Boolean.TYPE;
                    Method method1 = class1.getMethod("setDomStorageEnabled", aclass);
                    if(method1 != null)
                    {
                        WebSettings websettings1 = a.getSettings();
                        Object aobj1[] = new Object[1];
                        aobj1[0] = Boolean.valueOf(true);
                        method1.invoke(websettings1, aobj1);
                    }
                }
                catch(Exception exception2) { }
            try
            {
                Method method = a.getClass().getMethod("removeJavascriptInterface", new Class[0]);
                if(method != null)
                {
                    WebView webview = a;
                    Object aobj[] = new Object[1];
                    aobj[0] = "searchBoxJavaBridge_";
                    method.invoke(webview, aobj);
                }
            }
            catch(Exception exception1) { }
        }
        continue; /* Loop/switch isn't completed */
        exception;
        finish();
        if(true) goto _L4; else goto _L3
_L3:
    }

    private class _cls1
        implements Runnable
    {

        final H5PayActivity a;

        public void run()
        {
            H5PayActivity.f(a);
        }

        _cls1()
        {
            a = H5PayActivity.this;
            super();
        }
    }

}
