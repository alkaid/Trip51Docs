// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.alipay.sdk.app;


public final class ResultStatus extends Enum
{

    public static final ResultStatus a;
    public static final ResultStatus b;
    public static final ResultStatus c;
    public static final ResultStatus d;
    public static final ResultStatus e;
    public static final ResultStatus f;
    private static final ResultStatus i[];
    private int g;
    private String h;

    private ResultStatus(String s, int j, int k, String s1)
    {
        super(s, j);
        g = k;
        h = s1;
    }

    public static ResultStatus a(int j)
    {
        j;
        JVM INSTR lookupswitch 5: default 52
    //                   4001: 79
    //                   6001: 65
    //                   6002: 72
    //                   8000: 86
    //                   9000: 58;
           goto _L1 _L2 _L3 _L4 _L5 _L6
_L1:
        ResultStatus resultstatus = b;
_L8:
        return resultstatus;
_L6:
        resultstatus = a;
        continue; /* Loop/switch isn't completed */
_L3:
        resultstatus = c;
        continue; /* Loop/switch isn't completed */
_L4:
        resultstatus = d;
        continue; /* Loop/switch isn't completed */
_L2:
        resultstatus = e;
        continue; /* Loop/switch isn't completed */
_L5:
        resultstatus = f;
        if(true) goto _L8; else goto _L7
_L7:
    }

    private void a(String s)
    {
        h = s;
    }

    private void b(int j)
    {
        g = j;
    }

    public static ResultStatus valueOf(String s)
    {
        return (ResultStatus)Enum.valueOf(com/alipay/sdk/app/ResultStatus, s);
    }

    public static ResultStatus[] values()
    {
        return (ResultStatus[])i.clone();
    }

    public final int a()
    {
        return g;
    }

    public final String b()
    {
        return h;
    }

    static 
    {
        a = new ResultStatus("SUCCEEDED", 0, 9000, "\u5904\u7406\u6210\u529F");
        b = new ResultStatus("FAILED", 1, 4000, "\u7CFB\u7EDF\u7E41\u5FD9\uFF0C\u8BF7\u7A0D\u540E\u518D\u8BD5");
        c = new ResultStatus("CANCELED", 2, 6001, "\u7528\u6237\u53D6\u6D88");
        d = new ResultStatus("NETWORK_ERROR", 3, 6002, "\u7F51\u7EDC\u8FDE\u63A5\u5F02\u5E38");
        e = new ResultStatus("PARAMS_ERROR", 4, 4001, "\u53C2\u6570\u9519\u8BEF");
        f = new ResultStatus("PAY_WAITTING", 5, 8000, "\u652F\u4ED8\u7ED3\u679C\u786E\u8BA4\u4E2D");
        ResultStatus aresultstatus[] = new ResultStatus[6];
        aresultstatus[0] = a;
        aresultstatus[1] = b;
        aresultstatus[2] = c;
        aresultstatus[3] = d;
        aresultstatus[4] = e;
        aresultstatus[5] = f;
        i = aresultstatus;
    }
}
