// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.alipay.sdk.net;

import java.util.concurrent.TimeUnit;
import org.apache.http.*;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.client.params.HttpClientParams;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.conn.params.ConnManagerParams;
import org.apache.http.conn.params.ConnPerRouteBean;
import org.apache.http.conn.scheme.*;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.tsccm.ThreadSafeClientConnManager;
import org.apache.http.params.*;
import org.apache.http.protocol.HttpContext;

public final class MspHttpClient
{

    public static final String a = "msp";
    private static MspHttpClient b;
    private final DefaultHttpClient c;

    private MspHttpClient(ClientConnectionManager clientconnectionmanager, HttpParams httpparams)
    {
        c = new DefaultHttpClient(clientconnectionmanager, httpparams);
    }

    private MspHttpClient(HttpParams httpparams)
    {
        c = new DefaultHttpClient(httpparams);
    }

    public static MspHttpClient a()
    {
        if(b == null)
        {
            BasicHttpParams basichttpparams = new BasicHttpParams();
            HttpProtocolParams.setVersion(basichttpparams, HttpVersion.HTTP_1_1);
            HttpConnectionParams.setStaleCheckingEnabled(basichttpparams, true);
            basichttpparams.setBooleanParameter("http.protocol.expect-continue", false);
            ConnManagerParams.setMaxTotalConnections(basichttpparams, 50);
            ConnManagerParams.setMaxConnectionsPerRoute(basichttpparams, new ConnPerRouteBean(30));
            ConnManagerParams.setTimeout(basichttpparams, 1000L);
            HttpConnectionParams.setConnectionTimeout(basichttpparams, 20000);
            HttpConnectionParams.setSoTimeout(basichttpparams, 30000);
            HttpConnectionParams.setSocketBufferSize(basichttpparams, 16384);
            HttpProtocolParams.setUseExpectContinue(basichttpparams, false);
            HttpClientParams.setRedirecting(basichttpparams, true);
            HttpClientParams.setAuthenticating(basichttpparams, false);
            HttpProtocolParams.setUserAgent(basichttpparams, "msp");
            try
            {
                SSLSocketFactory sslsocketfactory = SSLSocketFactory.getSocketFactory();
                sslsocketfactory.setHostnameVerifier(SSLSocketFactory.STRICT_HOSTNAME_VERIFIER);
                Scheme scheme = new Scheme("https", sslsocketfactory, 443);
                Scheme scheme1 = new Scheme("http", PlainSocketFactory.getSocketFactory(), 80);
                SchemeRegistry schemeregistry = new SchemeRegistry();
                schemeregistry.register(scheme);
                schemeregistry.register(scheme1);
                b = new MspHttpClient(new ThreadSafeClientConnManager(basichttpparams, schemeregistry), basichttpparams);
            }
            catch(Exception exception)
            {
                b = new MspHttpClient(basichttpparams);
            }
        }
        return b;
    }

    private Object a(HttpHost httphost, HttpRequest httprequest, ResponseHandler responsehandler)
        throws Exception
    {
        Object obj;
        try
        {
            obj = c.execute(httphost, httprequest, responsehandler);
        }
        catch(Exception exception)
        {
            throw new Exception(exception);
        }
        return obj;
    }

    private Object a(HttpHost httphost, HttpRequest httprequest, ResponseHandler responsehandler, HttpContext httpcontext)
        throws Exception
    {
        Object obj;
        try
        {
            obj = c.execute(httphost, httprequest, responsehandler, httpcontext);
        }
        catch(Exception exception)
        {
            throw new Exception(exception);
        }
        return obj;
    }

    private Object a(HttpUriRequest httpurirequest, ResponseHandler responsehandler)
        throws Exception
    {
        Object obj;
        try
        {
            obj = c.execute(httpurirequest, responsehandler);
        }
        catch(Exception exception)
        {
            throw new Exception(exception);
        }
        return obj;
    }

    private Object a(HttpUriRequest httpurirequest, ResponseHandler responsehandler, HttpContext httpcontext)
        throws Exception
    {
        Object obj;
        try
        {
            obj = c.execute(httpurirequest, responsehandler, httpcontext);
        }
        catch(Exception exception)
        {
            throw new Exception(exception);
        }
        return obj;
    }

    private HttpResponse a(HttpHost httphost, HttpRequest httprequest)
        throws Exception
    {
        HttpResponse httpresponse;
        try
        {
            httpresponse = c.execute(httphost, httprequest);
        }
        catch(Exception exception)
        {
            throw new Exception(exception);
        }
        return httpresponse;
    }

    private HttpResponse a(HttpHost httphost, HttpRequest httprequest, HttpContext httpcontext)
        throws Exception
    {
        HttpResponse httpresponse;
        try
        {
            httpresponse = c.execute(httphost, httprequest, httpcontext);
        }
        catch(Exception exception)
        {
            throw new Exception(exception);
        }
        return httpresponse;
    }

    private HttpResponse a(HttpUriRequest httpurirequest, HttpContext httpcontext)
        throws Exception
    {
        HttpResponse httpresponse;
        try
        {
            httpresponse = c.execute(httpurirequest, httpcontext);
        }
        catch(Exception exception)
        {
            throw new Exception(exception);
        }
        return httpresponse;
    }

    private static MspHttpClient d()
    {
        return b;
    }

    private static void e()
    {
        b = null;
    }

    private void f()
    {
        ClientConnectionManager clientconnectionmanager = c.getConnectionManager();
        if(clientconnectionmanager != null)
        {
            clientconnectionmanager.closeExpiredConnections();
            if(android.os.Build.VERSION.SDK_INT >= 9)
                clientconnectionmanager.closeIdleConnections(30L, TimeUnit.MINUTES);
        }
    }

    private ClientConnectionManager g()
    {
        return c.getConnectionManager();
    }

    public final HttpResponse a(HttpUriRequest httpurirequest)
        throws Exception
    {
        HttpResponse httpresponse;
        try
        {
            httpresponse = c.execute(httpurirequest);
        }
        catch(Exception exception)
        {
            throw new Exception(exception);
        }
        return httpresponse;
    }

    public final void b()
    {
        ClientConnectionManager clientconnectionmanager = c.getConnectionManager();
        if(clientconnectionmanager != null)
        {
            clientconnectionmanager.shutdown();
            b = null;
        }
    }

    public final HttpParams c()
    {
        return c.getParams();
    }
}
