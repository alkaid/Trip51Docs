// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.alipay.sdk.net;

import android.content.Context;
import android.text.TextUtils;
import com.alipay.sdk.data.InteractionData;
import com.alipay.sdk.exception.NetErrorException;
import java.io.*;
import java.util.zip.GZIPInputStream;
import org.apache.http.*;
import org.apache.http.util.CharArrayBuffer;
import org.apache.http.util.EntityUtils;

// Referenced classes of package com.alipay.sdk.net:
//            MspClient

public class RequestUtils
{

    private static MspClient a;

    public RequestUtils()
    {
    }

    public static String a(HttpResponse httpresponse)
        throws NetErrorException
    {
        StatusLine statusline;
        int i;
        HttpEntity httpentity;
        Object obj;
        statusline = httpresponse.getStatusLine();
        i = statusline.getStatusCode();
        httpentity = httpresponse.getEntity();
        obj = null;
        InputStream inputstream = httpentity.getContent();
        obj = inputstream;
        if(statusline.getStatusCode() != 200 || obj == null)
            throw new NetErrorException((new StringBuilder()).append(i).append(" ").append(statusline.getReasonPhrase()).toString());
          goto _L1
        Exception exception3;
        exception3;
        throw new NetErrorException();
        Exception exception4;
        exception4;
        Object obj1;
        Exception exception1;
        obj1 = obj;
        exception1 = exception4;
_L2:
        int j;
        int k;
        Header header;
        String s;
        InputStreamReader inputstreamreader;
        CharArrayBuffer chararraybuffer;
        char ac[];
        int l;
        String s1;
        Exception exception6;
        GZIPInputStream gzipinputstream;
        try
        {
            ((InputStream) (obj1)).close();
        }
        catch(Exception exception2) { }
        throw exception1;
_L1:
        header = httpentity.getContentEncoding();
        if(header == null || !header.getValue().contains("gzip"))
            break MISSING_BLOCK_LABEL_160;
        gzipinputstream = new GZIPInputStream(((InputStream) (obj)));
        obj = gzipinputstream;
        j = (int)httpentity.getContentLength();
        if(j >= 0)
            break MISSING_BLOCK_LABEL_304;
        k = 4096;
_L3:
        s = EntityUtils.getContentCharSet(httpentity);
        if(s == null)
            s = "UTF-8";
        inputstreamreader = new InputStreamReader(((InputStream) (obj)), s);
        chararraybuffer = new CharArrayBuffer(k);
        ac = new char[1024];
        do
        {
            l = inputstreamreader.read(ac);
            if(l == -1)
                break;
            chararraybuffer.append(ac, 0, l);
        } while(true);
        s1 = chararraybuffer.toString();
        try
        {
            ((InputStream) (obj)).close();
        }
        // Misplaced declaration of an exception variable
        catch(Exception exception6) { }
        return s1;
        Exception exception;
        exception;
        obj1 = null;
        exception1 = exception;
          goto _L2
        Exception exception5;
        exception5;
        obj1 = obj;
        exception1 = exception5;
          goto _L2
        k = j;
          goto _L3
    }

    public static HttpResponse a(Context context, String s, String s1, InteractionData interactiondata)
        throws NetErrorException
    {
        HttpResponse httpresponse;
        if(a == null)
            a = new MspClient(context, s);
        else
        if(!TextUtils.equals(s, a.a()))
            a.a(s);
        if(interactiondata != null)
            httpresponse = a.a(s1, interactiondata);
        else
            httpresponse = a.b(s1);
        return httpresponse;
    }

    public static void a()
    {
        a = null;
    }
}
