// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.alipay.sdk.net;

import android.content.Context;
import android.net.*;
import android.text.TextUtils;
import com.alipay.sdk.data.InteractionData;
import com.alipay.sdk.exception.NetErrorException;
import com.alipay.sdk.sys.GlobalContext;
import java.io.IOException;
import java.net.*;
import java.util.ArrayList;
import java.util.Iterator;
import org.apache.http.*;
import org.apache.http.client.methods.*;
import org.apache.http.conn.ConnectTimeoutException;
import org.apache.http.entity.ByteArrayEntity;
import org.apache.http.params.HttpParams;

// Referenced classes of package com.alipay.sdk.net:
//            MspHttpClient

public class MspClient
{

    private Context a;
    private String b;

    private MspClient(Context context)
    {
        this(context, null);
    }

    public MspClient(Context context, String s)
    {
        a = context;
        b = s;
    }

    private static ByteArrayEntity a(InteractionData interactiondata, String s)
        throws IOException
    {
        String s1 = null;
        if(interactiondata != null)
        {
            s1 = interactiondata.b();
            if(!TextUtils.isEmpty(interactiondata.c()))
                s = (new StringBuilder()).append(interactiondata.c()).append("=").append(s).toString();
        }
        if(TextUtils.isEmpty(s1))
            s1 = "application/octet-stream;binary/octet-stream";
        ByteArrayEntity bytearrayentity = new ByteArrayEntity(s.getBytes("utf-8"));
        bytearrayentity.setContentType(s1);
        return bytearrayentity;
    }

    private URL b()
    {
        URL url;
        try
        {
            url = new URL(b);
        }
        catch(Exception exception)
        {
            url = null;
        }
        return url;
    }

    private HttpHost c()
    {
        HttpHost httphost = null;
        if(android.os.Build.VERSION.SDK_INT < 11) goto _L2; else goto _L1
_L1:
        String s1 = g();
        if(s1 == null || s1.contains("wap")) goto _L4; else goto _L3
_L3:
        return httphost;
_L4:
        URL url = b();
        if(url != null)
        {
            "https".equalsIgnoreCase(url.getProtocol());
            String s2 = System.getProperty("https.proxyHost");
            String s3 = System.getProperty("https.proxyPort");
            if(!TextUtils.isEmpty(s2))
                httphost = new HttpHost(s2, Integer.parseInt(s3));
        }
        continue; /* Loop/switch isn't completed */
_L2:
        NetworkInfo networkinfo = f();
        if(networkinfo != null && networkinfo.isAvailable() && networkinfo.getType() == 0)
        {
            String s = Proxy.getDefaultHost();
            int i = Proxy.getDefaultPort();
            if(s != null)
                httphost = new HttpHost(s, i);
        }
        if(true) goto _L3; else goto _L5
_L5:
    }

    private HttpHost d()
    {
        HttpHost httphost = null;
        NetworkInfo networkinfo = f();
        if(networkinfo != null && networkinfo.isAvailable() && networkinfo.getType() == 0)
        {
            String s = Proxy.getDefaultHost();
            int i = Proxy.getDefaultPort();
            if(s != null)
                httphost = new HttpHost(s, i);
        }
        return httphost;
    }

    private HttpHost e()
    {
        HttpHost httphost;
        String s;
        httphost = null;
        s = g();
        if(s == null || s.contains("wap")) goto _L2; else goto _L1
_L1:
        return httphost;
_L2:
        URL url = b();
        if(url != null)
        {
            "https".equalsIgnoreCase(url.getProtocol());
            String s1 = System.getProperty("https.proxyHost");
            String s2 = System.getProperty("https.proxyPort");
            if(!TextUtils.isEmpty(s1))
                httphost = new HttpHost(s1, Integer.parseInt(s2));
        }
        if(true) goto _L1; else goto _L3
_L3:
    }

    private NetworkInfo f()
    {
        NetworkInfo networkinfo1 = ((ConnectivityManager)a.getSystemService("connectivity")).getActiveNetworkInfo();
        NetworkInfo networkinfo = networkinfo1;
_L2:
        return networkinfo;
        Exception exception;
        exception;
        networkinfo = null;
        if(true) goto _L2; else goto _L1
_L1:
    }

    private String g()
    {
        String s;
        String s1;
        NetworkInfo networkinfo = f();
        if(networkinfo == null || !networkinfo.isAvailable())
            break MISSING_BLOCK_LABEL_45;
        if(networkinfo.getType() == 1)
        {
            s = "wifi";
            break MISSING_BLOCK_LABEL_55;
        }
        s1 = networkinfo.getExtraInfo().toLowerCase();
        s = s1;
        break MISSING_BLOCK_LABEL_55;
        s = "none";
        break MISSING_BLOCK_LABEL_55;
        Exception exception;
        exception;
        s = "none";
        return s;
    }

    public final String a()
    {
        return b;
    }

    public final HttpResponse a(String s, InteractionData interactiondata)
        throws NetErrorException
    {
        HttpResponse httpresponse;
        MspHttpClient msphttpclient;
        httpresponse = null;
        msphttpclient = MspHttpClient.a();
        if(msphttpclient != null) goto _L2; else goto _L1
_L1:
        return httpresponse;
_L2:
        HttpParams httpparams = msphttpclient.c();
        if(android.os.Build.VERSION.SDK_INT < 11) goto _L4; else goto _L3
_L3:
        String s3 = g();
        if(s3 == null || s3.contains("wap")) goto _L6; else goto _L5
_L5:
        HttpHost httphost = null;
_L10:
        if(httphost != null)
            httpparams.setParameter("http.route.default-proxy", httphost);
        (new StringBuilder("requestUrl : ")).append(b).toString();
        if(!TextUtils.isEmpty(s)) goto _L8; else goto _L7
_L7:
        Object obj = new HttpGet(b);
_L16:
        NetErrorException neterrorexception;
        if(interactiondata != null)
        {
            ArrayList arraylist = interactiondata.a();
            if(arraylist != null)
            {
                for(Iterator iterator = arraylist.iterator(); iterator.hasNext(); ((HttpUriRequest) (obj)).addHeader((Header)iterator.next()));
            }
        }
          goto _L9
_L6:
        ConnectTimeoutException connecttimeoutexception;
        URL url = b();
        if(url == null)
            break MISSING_BLOCK_LABEL_618;
        "https".equalsIgnoreCase(url.getProtocol());
        String s4 = System.getProperty("https.proxyHost");
        String s5 = System.getProperty("https.proxyPort");
        if(TextUtils.isEmpty(s4))
            break MISSING_BLOCK_LABEL_618;
        httphost = new HttpHost(s4, Integer.parseInt(s5));
          goto _L10
_L4:
        NetworkInfo networkinfo = f();
        if(networkinfo == null || !networkinfo.isAvailable() || networkinfo.getType() != 0) goto _L12; else goto _L11
_L11:
        String s2;
        int i;
        s2 = Proxy.getDefaultHost();
        i = Proxy.getDefaultPort();
        if(s2 == null) goto _L12; else goto _L13
_L13:
        SocketException socketexception;
        httphost = new HttpHost(s2, i);
          goto _L10
_L8:
        obj = new HttpPost(b);
        if(interactiondata == null) goto _L15; else goto _L14
_L14:
        String s1;
        s1 = interactiondata.b();
        if(!TextUtils.isEmpty(interactiondata.c()))
            s = (new StringBuilder()).append(interactiondata.c()).append("=").append(s).toString();
_L17:
        SocketTimeoutException sockettimeoutexception;
        if(TextUtils.isEmpty(s1))
            s1 = "application/octet-stream;binary/octet-stream";
        ByteArrayEntity bytearrayentity = new ByteArrayEntity(s.getBytes("utf-8"));
        bytearrayentity.setContentType(s1);
        ((HttpPost)obj).setEntity(bytearrayentity);
        ((HttpUriRequest) (obj)).addHeader("Accept-Charset", "UTF-8");
        ((HttpUriRequest) (obj)).addHeader("Accept-Encoding", "gzip");
        ((HttpUriRequest) (obj)).addHeader("Connection", "Keep-Alive");
        ((HttpUriRequest) (obj)).addHeader("Keep-Alive", "timeout=180, max=100");
          goto _L16
_L9:
        try
        {
            GlobalContext.a();
            GlobalContext.d();
            httpresponse = msphttpclient.a(((HttpUriRequest) (obj)));
            Header aheader[] = httpresponse.getHeaders("X-Hostname");
            if(aheader != null && aheader.length > 0 && aheader[0] != null)
                httpresponse.getHeaders("X-Hostname")[0].toString();
            Header aheader1[] = httpresponse.getHeaders("X-ExecuteTime");
            if(aheader1 != null && aheader1.length > 0 && aheader1[0] != null)
                httpresponse.getHeaders("X-ExecuteTime")[0].toString();
        }
        // Misplaced declaration of an exception variable
        catch(NetErrorException neterrorexception)
        {
            throw neterrorexception;
        }
        // Misplaced declaration of an exception variable
        catch(ConnectTimeoutException connecttimeoutexception)
        {
            if(msphttpclient != null)
                msphttpclient.b();
            throw new NetErrorException();
        }
        // Misplaced declaration of an exception variable
        catch(SocketException socketexception)
        {
            throw new NetErrorException();
        }
        // Misplaced declaration of an exception variable
        catch(SocketTimeoutException sockettimeoutexception)
        {
            if(msphttpclient != null)
                msphttpclient.b();
            throw new NetErrorException();
        }
        catch(Exception exception)
        {
            throw new NetErrorException();
        }
          goto _L1
_L15:
        s1 = null;
          goto _L17
_L12:
        httphost = null;
          goto _L10
        httphost = null;
          goto _L10
    }

    public final void a(String s)
    {
        b = s;
    }

    public final HttpResponse b(String s)
        throws NetErrorException
    {
        return a(s, ((InteractionData) (null)));
    }
}
