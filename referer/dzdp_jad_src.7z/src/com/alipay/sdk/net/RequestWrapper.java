// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) fieldsfirst 

package com.alipay.sdk.net;

import android.content.Context;
import android.text.TextUtils;
import com.alipay.sdk.data.*;
import com.alipay.sdk.encrypt.*;
import com.alipay.sdk.exception.*;
import com.alipay.sdk.protocol.FrameData;
import com.alipay.sdk.protocol.FrameFactoryManager;
import com.alipay.sdk.sys.GlobalContext;
import java.io.*;
import java.util.Calendar;
import org.apache.http.HttpResponse;
import org.apache.http.StatusLine;
import org.json.JSONException;
import org.json.JSONObject;

// Referenced classes of package com.alipay.sdk.net:
//            RequestUtils

public class RequestWrapper
{

    private int a;
    private InteractionData b;

    public RequestWrapper()
    {
        a = 0;
    }

    public RequestWrapper(InteractionData interactiondata)
    {
        a = 0;
        b = interactiondata;
    }

    private String a(Context context, String s, String s1, InteractionData interactiondata, Response response)
        throws NetErrorException
    {
        String s2;
        HttpResponse httpresponse = RequestUtils.a(context, s, s1, interactiondata);
        StatusLine statusline = httpresponse.getStatusLine();
        response.a(statusline.getStatusCode());
        response.a(statusline.getReasonPhrase());
        FrameUtils.a(b, httpresponse);
        s2 = RequestUtils.a(httpresponse);
        RequestUtils.a();
        return s2;
        Exception exception1;
        exception1;
        throw new NetErrorException();
        Exception exception;
        exception;
        RequestUtils.a();
        throw exception;
    }

    private static String a(String s)
    {
        String s1 = null;
        FileInputStream fileinputstream = new FileInputStream(s);
        BufferedReader bufferedreader;
        StringBuilder stringbuilder;
        bufferedreader = new BufferedReader(new InputStreamReader(fileinputstream));
        char ac[] = new char[2048];
        stringbuilder = new StringBuilder();
        do
        {
            int i = bufferedreader.read(ac);
            if(i <= 0)
                break;
            stringbuilder.append(ac, 0, i);
        } while(true);
          goto _L1
        Exception exception1;
        exception1;
_L5:
        exception1.printStackTrace();
        String s2;
        if(fileinputstream != null)
            try
            {
                fileinputstream.close();
            }
            catch(IOException ioexception1)
            {
                ioexception1.printStackTrace();
            }
        return s1;
_L1:
        bufferedreader.close();
        s2 = stringbuilder.toString();
        s1 = s2;
        try
        {
            fileinputstream.close();
        }
        catch(IOException ioexception2)
        {
            ioexception2.printStackTrace();
        }
        if(true)
            break MISSING_BLOCK_LABEL_85;
        Exception exception2;
        exception2;
        Exception exception;
        fileinputstream = null;
        exception = exception2;
_L3:
        if(fileinputstream != null)
            try
            {
                fileinputstream.close();
            }
            catch(IOException ioexception)
            {
                ioexception.printStackTrace();
            }
        throw exception;
        exception;
        if(true) goto _L3; else goto _L2
_L2:
        exception1;
        fileinputstream = null;
        if(true) goto _L5; else goto _L4
_L4:
    }

    private JSONObject a(Context context, Request request, Response response)
        throws NetErrorException, FailOperatingException, AppErrorException
    {
        String s = GlobalContext.f();
        NetErrorException neterrorexception;
        String s1;
        JSONObject jsonobject;
        JSONObject jsonobject1;
        s1 = a(context, request.a(), request.a(s).toString(), request.b(), response);
        response.a(Calendar.getInstance().getTimeInMillis());
        if(!request.c())
            break MISSING_BLOCK_LABEL_206;
        jsonobject1 = a(s1, response);
        if(response.c() == 1000 && a < 3)
        {
            a = 1 + a;
            jsonobject = a(context, request, response);
            break MISSING_BLOCK_LABEL_248;
        }
        if(response.c() != 0)
            throw new FailOperatingException(response.d());
        String s2;
        String s3;
        try
        {
            a = 0;
            s2 = jsonobject1.optString("res_data");
            if(TextUtils.isEmpty(s2))
                throw new AppErrorException(getClass(), "response data is empty");
        }
        // Misplaced declaration of an exception variable
        catch(NetErrorException neterrorexception)
        {
            throw neterrorexception;
        }
        catch(FailOperatingException failoperatingexception)
        {
            throw failoperatingexception;
        }
        catch(AppErrorException apperrorexception)
        {
            throw apperrorexception;
        }
        catch(Exception exception)
        {
            throw new NetErrorException();
        }
        s3 = TriDes.b(s, s2);
        (new StringBuilder("respData:")).append(s3).toString();
        jsonobject = new JSONObject(s3);
        break MISSING_BLOCK_LABEL_248;
        jsonobject = a(s1, response);
        (new StringBuilder("respData:")).append(jsonobject.toString()).toString();
        return jsonobject;
    }

    private JSONObject a(Context context, Request request, Response response, String s, String s1)
        throws JSONException, AppErrorException, NetErrorException, FailOperatingException
    {
        JSONObject jsonobject = a(s1, response);
        JSONObject jsonobject1;
        if(response.c() == 1000 && a < 3)
        {
            a = 1 + a;
            jsonobject1 = a(context, request, response);
        } else
        {
            if(response.c() != 0)
                throw new FailOperatingException(response.d());
            a = 0;
            String s2 = jsonobject.optString("res_data");
            if(TextUtils.isEmpty(s2))
                throw new AppErrorException(getClass(), "response data is empty");
            String s3 = TriDes.b(s, s2);
            (new StringBuilder("respData:")).append(s3).toString();
            jsonobject1 = new JSONObject(s3);
        }
        return jsonobject1;
    }

    private static JSONObject a(Response response, String s)
        throws JSONException, AppErrorException
    {
        JSONObject jsonobject = a(s, response);
        (new StringBuilder("respData:")).append(jsonobject.toString()).toString();
        return jsonobject;
    }

    private static JSONObject a(String s, Response response)
        throws JSONException, AppErrorException
    {
        JSONObject jsonobject = (new JSONObject(s)).optJSONObject("data");
        if(jsonobject == null) goto _L2; else goto _L1
_L1:
        JSONObject jsonobject1;
        response.a(jsonobject.optInt("code", 503));
        response.a(jsonobject.optString("error_msg", ""));
        jsonobject1 = jsonobject.optJSONObject("params");
        if(jsonobject1 == null) goto _L4; else goto _L3
_L3:
        if(response.c() == 1000)
        {
            String s1 = jsonobject1.optString("public_key");
            if(!TextUtils.isEmpty(s1))
                GlobalContext.a().c().a(s1);
        }
        Envelope envelope = new Envelope();
        envelope.d(jsonobject1.optString("next_api_name"));
        envelope.e(jsonobject1.optString("next_api_version"));
        envelope.c(jsonobject1.optString("next_namespace"));
        envelope.b(jsonobject1.optString("next_request_url"));
        response.a(envelope);
_L5:
        return jsonobject1;
_L4:
        response.c();
_L6:
        jsonobject1 = null;
        if(true) goto _L5; else goto _L2
_L2:
        response.a(503);
        response.a("");
          goto _L6
    }

    private static void a(JSONObject jsonobject)
    {
        String s = jsonobject.optString("public_key");
        if(!TextUtils.isEmpty(s))
            GlobalContext.a().c().a(s);
    }

    public final FrameData a(Context context, Request request, boolean flag)
        throws NetErrorException, FailOperatingException, AppErrorException, UnZipException
    {
        Response response;
        JSONObject jsonobject;
        JSONObject jsonobject1;
        response = new Response();
        jsonobject = a(context, request, response);
        if(!jsonobject.optBoolean("gzip"))
            break MISSING_BLOCK_LABEL_209;
        jsonobject1 = jsonobject.optJSONObject("form");
        if(jsonobject1 == null || !jsonobject1.has("quickpay")) goto _L2; else goto _L1
_L1:
        byte abyte0[] = Base64.a(jsonobject1.optString("quickpay"));
        byte abyte1[] = FrameUtils.a(abyte0);
        if(!TextUtils.equals(MD5.a(abyte1), jsonobject.optString("md5"))) goto _L4; else goto _L3
_L3:
        jsonobject.put("form", new JSONObject(new String(abyte1, "utf-8")));
_L2:
        (new StringBuilder("responsestring decoded ")).append(jsonobject).toString();
        FrameData framedata = new FrameData(request, response);
        framedata.a(jsonobject);
        JSONException jsonexception;
        UnZipException unzipexception;
        UnsupportedEncodingException unsupportedencodingexception;
        if(!flag)
            framedata = FrameFactoryManager.a(framedata);
        return framedata;
_L4:
        try
        {
            throw new UnZipException("client md5  not equal server md5");
        }
        // Misplaced declaration of an exception variable
        catch(UnsupportedEncodingException unsupportedencodingexception)
        {
            throw new UnZipException("unzip byte array unsupport encoding");
        }
        // Misplaced declaration of an exception variable
        catch(UnZipException unzipexception)
        {
            throw unzipexception;
        }
        // Misplaced declaration of an exception variable
        catch(JSONException jsonexception)
        {
            throw new UnZipException("unzip string not jsonObject");
        }
        response.b();
          goto _L2
    }
}
